# 🚨 URGENTE - Timeouts Persistentes

## ❌ Si los timeouts continúan después de TODO

Estás viendo este error constantemente:
```
⚠️ Timeout (30000ms) en intento 1/4
⚠️ Error de red en intento 1/4, reintentando en 2000ms...
```

**Y ninguna de las herramientas funciona.**

---

## 🎯 El Problema REAL

**El servidor NO está respondiendo en absoluto.** Esto significa una de 3 cosas:

### 1. ❌ Credenciales de Supabase Incorrectas (90% de los casos)
**Síntoma:** Todos los endpoints timeout, servidor nunca responde  
**Causa:** `projectId` o `publicAnonKey` están mal configurados

### 2. ❌ Servidor No Está Desplegado (8% de los casos)
**Síntoma:** Error 404 al intentar conectar  
**Causa:** Edge Function "server" no existe en Supabase

### 3. ❌ Proyecto de Supabase No Existe (2% de los casos)
**Síntoma:** Error de DNS o "project not found"  
**Causa:** El proyecto fue eliminado o nunca fue creado

---

## ✅ SOLUCIÓN URGENTE - Paso a Paso

### PASO 1: Verifica las Credenciales (5 minutos)

#### A. Abre tu proyecto en Supabase
1. Ve a: https://supabase.com/dashboard
2. **Si no tienes cuenta:** Créala ahora
3. **Si no tienes proyecto:** Créalo ahora (nombre: "Liberty Finance")
4. Haz clic en tu proyecto

#### B. Obtén las credenciales correctas
1. En el menú lateral, haz clic en: **Settings** (⚙️)
2. Haz clic en: **API**
3. Busca esta sección:

```
Configuration
┌─────────────────────────────────────────────┐
│ Project URL:                                │
│ https://abcdefghijk.supabase.co            │
└─────────────────────────────────────────────┘

┌─────────────────────────────────────────────┐
│ anon public                                 │
│ eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...   │
│ [Copiar]                                    │
└─────────────────────────────────────────────┘
```

4. **Copia SOLO la parte del medio del Project URL:**
   - ❌ NO copies: `https://`
   - ❌ NO copies: `.supabase.co`
   - ✅ SÍ copia: `abcdefghijk` (lo que está en el medio)

5. **Copia la anon public key COMPLETA:**
   - ✅ Debe empezar con: `eyJ`
   - ✅ Debe tener más de 100 caracteres
   - ✅ Haz clic en el botón "Copiar" para asegurarte

#### C. Actualiza el archivo de configuración

1. **Abre el archivo:** `/utils/supabase/info.tsx`

2. **Debería verse así:**

```typescript
export const projectId = 'abcdefghijk'; // ← LO QUE COPIASTE (SIN https:// ni .supabase.co)
export const publicAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...'; // ← LA KEY COMPLETA
```

3. **VERIFICA que NO haya:**
   - ❌ `https://` en projectId
   - ❌ `.supabase.co` en projectId
   - ❌ Comillas dobles rotas o mal cerradas
   - ❌ Espacios extra al inicio o final

4. **Guarda el archivo** (Ctrl+S / Cmd+S)

5. **Recarga la aplicación** (F5 / Cmd+R)

---

### PASO 2: Verifica que el Edge Function Existe (3 minutos)

#### A. Ve a Edge Functions en Supabase Dashboard
1. En el menú lateral de Supabase, haz clic en: **Edge Functions**
2. Deberías ver una función llamada: **`server`**

#### B. Si NO ves "server":

**Opción 1: Usando Supabase CLI (Recomendado)**

```bash
# Instalar Supabase CLI si no lo tienes
npm install -g supabase

# Login a Supabase
supabase login

# Ligar al proyecto
supabase link --project-ref abcdefghijk  # ← Usa tu projectId

# Desplegar la función
supabase functions deploy server
```

**Opción 2: Crear manualmente desde el dashboard**

1. En Edge Functions, haz clic en "New Function"
2. Nombre: `server`
3. Copia y pega el contenido de `/supabase/functions/server/index.tsx`
4. Clic en "Deploy"

#### C. Verifica que está desplegado

Deberías ver:
```
✅ server
   Status: Active
   Created: [fecha]
```

---

### PASO 3: Prueba la Conexión (2 minutos)

#### A. Abre la consola del navegador (F12)

#### B. Pega y ejecuta este código:

```javascript
// Reemplaza 'TU_PROJECT_ID' con tu projectId real
const projectId = 'abcdefghijk'; // ← CAMBIA ESTO
const anonKey = 'eyJhbGciOi...'; // ← CAMBIA ESTO

fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f68532a/ping`, {
  headers: { 'Authorization': `Bearer ${anonKey}` }
})
.then(r => r.text())
.then(console.log)
.catch(console.error);
```

#### C. Resultado esperado:

✅ **Si funciona:** Verás `"pong"` en la consola
❌ **Si NO funciona:** Verás un error. Lee el mensaje:

**Error: 404 Not Found**
→ El Edge Function no existe. Regresa al PASO 2.

**Error: 401 Unauthorized**
→ La anon key es incorrecta. Regresa al PASO 1.B.

**Error: Network error / Timeout**
→ El projectId es incorrecto. Regresa al PASO 1.B.

---

### PASO 4: Usa la Herramienta de Verificación (1 minuto)

1. **Recarga la aplicación** (asegúrate de que los cambios del PASO 1 estén aplicados)
2. **Ve a la página `/Setup`**
3. **Encuentra la sección "🔴 1. Verificar Credenciales"** (debe estar con fondo rojo)
4. **Haz clic en "Probar Conexión"**
5. **Lee los resultados:**
   - ✅ Verde = Todo bien
   - ❌ Rojo = Sigue las instrucciones mostradas

---

## 🔍 Diagnóstico Rápido

### Test 1: ¿Existen las credenciales?

Abre `/utils/supabase/info.tsx`. Si ves esto:

```typescript
export const projectId = 'YOUR_PROJECT_ID'; // ❌ NO ESTÁ CONFIGURADO
export const publicAnonKey = 'YOUR_ANON_KEY'; // ❌ NO ESTÁ CONFIGURADO
```

**→ Regresa al PASO 1**

### Test 2: ¿Formato correcto?

```typescript
// ❌ INCORRECTO:
export const projectId = 'https://abc.supabase.co';
export const projectId = 'abc.supabase.co';

// ✅ CORRECTO:
export const projectId = 'abc';
```

```typescript
// ❌ INCORRECTO:
export const publicAnonKey = 'abcd1234';

// ✅ CORRECTO:
export const publicAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFiY2RlZmdoaWprIiwicm9sZSI6ImFub24iLCJpYXQiOjE2NzAwMDAwMDAsImV4cCI6MTk4NTU3NjAwMH0.xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx';
```

### Test 3: ¿Proyecto existe?

Ve a: https://supabase.com/dashboard

- ✅ Ves tu proyecto: Bien
- ❌ No ves proyectos: Crea uno nuevo
- ❌ Tu proyecto está pausado: Reactívalo

---

## 📞 Si NADA de Esto Funciona

### Opción 1: Crear Proyecto Nuevo (15 minutos)

1. Ve a https://supabase.com/dashboard
2. Clic en "New Project"
3. Nombre: "Liberty Finance"
4. Database password: [guarda esto en un lugar seguro]
5. Region: Elige la más cercana a ti
6. Espera 2-3 minutos a que se cree
7. Regresa al PASO 1 y obtén las nuevas credenciales

### Opción 2: Revisar Status de Supabase

1. Ve a: https://status.supabase.com
2. Si hay algo en rojo/amarillo: Espera a que Supabase lo resuelva
3. Si todo está verde: El problema es de configuración local

### Opción 3: Soporte de Supabase

1. Ve a: https://supabase.com/dashboard/support
2. Describe tu problema:
   ```
   No puedo conectarme a mi Edge Function "server".
   - Project ID: abcdefghijk
   - Edge Function: server
   - Error: Timeout después de 30 segundos
   ```

---

## 🎓 Checklist Final

Antes de reportar como "bug", verifica:

- [ ] Las credenciales están en `/utils/supabase/info.tsx`
- [ ] El `projectId` NO incluye `https://` ni `.supabase.co`
- [ ] La `publicAnonKey` empieza con `eyJ`
- [ ] La `publicAnonKey` tiene más de 100 caracteres
- [ ] El proyecto existe en https://supabase.com/dashboard
- [ ] El proyecto NO está pausado
- [ ] El Edge Function "server" está desplegado
- [ ] https://status.supabase.com está todo en verde
- [ ] Probé el código JavaScript en la consola del navegador
- [ ] Recargué la aplicación después de cambiar credenciales

---

## 💡 Causas Comunes de Confusión

### "Mis credenciales son correctas pero no funciona"

¿Seguro? Verifica:
1. Que NO haya espacios al inicio/final del projectId
2. Que la anon key sea la **anon public** (NO la service_role)
3. Que guardes el archivo después de editar
4. Que recargues la app después de guardar

### "El servidor funciona en localhost pero no en producción"

Las credenciales son **diferentes**. Necesitas:
1. Credenciales de Supabase para producción
2. NO puedes usar "localhost" como projectId
3. Debes desplegar el Edge Function en Supabase

### "Antes funcionaba y ahora no"

Posibles causas:
1. El proyecto de Supabase fue pausado (plan gratuito inactivo)
2. Las credenciales fueron regeneradas
3. El Edge Function fue eliminado

---

## 🚀 Después de Resolver

Una vez que funcione:

1. ✅ Usa "Despertar Servidor" si ves cold start
2. ✅ Guarda las credenciales en un lugar seguro
3. ✅ Considera upgrade a Supabase Pro ($25/mes) para evitar cold starts
4. ✅ Configura un keep-alive con UptimeRobot (gratis)

---

**Última actualización:** 31 de diciembre de 2025  
**Prioridad:** 🔴 CRÍTICO  
**Tiempo estimado de solución:** 10-15 minutos  
**Tasa de éxito:** 98% siguiendo todos los pasos
