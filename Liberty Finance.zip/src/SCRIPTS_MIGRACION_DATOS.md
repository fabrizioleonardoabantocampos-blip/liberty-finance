# 📦 SCRIPTS DE MIGRACIÓN DE DATOS
## Liberty Finance - Exportar e Importar Datos

---

## 🎯 PROPÓSITO

Este documento contiene scripts para:
1. **Exportar** datos de la base de datos antigua
2. **Transformar** datos al nuevo formato
3. **Importar** datos a la nueva base de datos

---

## ⚠️ IMPORTANTE

**Antes de ejecutar cualquier script:**

1. ✅ Haz un backup completo
2. ✅ Prueba en un entorno de desarrollo primero
3. ✅ Verifica que la nueva base de datos esté limpia
4. ✅ Ten las credenciales de ambos proyectos a mano

---

## 📊 SCRIPT 1: EXPORTAR USUARIOS

### JavaScript (Para Ejecutar en Consola del Navegador)

```javascript
// =====================================================
// EXPORTAR TODOS LOS USUARIOS
// =====================================================

async function exportarUsuarios() {
  console.log('🔄 Iniciando exportación de usuarios...');
  
  try {
    const response = await fetch(
      `https://${OLD_PROJECT_ID}.supabase.co/functions/v1/make-server-9f68532a/users`,
      {
        headers: {
          'Authorization': `Bearer ${OLD_ANON_KEY}`
        }
      }
    );
    
    if (!response.ok) {
      throw new Error(`Error: ${response.status}`);
    }
    
    const usuarios = await response.json();
    
    console.log(`✅ ${usuarios.length} usuarios exportados`);
    
    // Crear archivo descargable
    const blob = new Blob(
      [JSON.stringify(usuarios, null, 2)], 
      { type: 'application/json' }
    );
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `usuarios_backup_${new Date().toISOString()}.json`;
    a.click();
    
    console.log('💾 Archivo descargado: usuarios_backup_*.json');
    
    return usuarios;
  } catch (error) {
    console.error('❌ Error al exportar usuarios:', error);
    throw error;
  }
}

// EJECUTAR:
// const OLD_PROJECT_ID = 'tu-project-id-antiguo';
// const OLD_ANON_KEY = 'tu-anon-key-antiguo';
// exportarUsuarios();
```

---

## 📊 SCRIPT 2: EXPORTAR DEPÓSITOS PENDIENTES

```javascript
// =====================================================
// EXPORTAR DEPÓSITOS PENDIENTES
// =====================================================

async function exportarDepositosPendientes() {
  console.log('🔄 Iniciando exportación de depósitos pendientes...');
  
  try {
    const response = await fetch(
      `https://${OLD_PROJECT_ID}.supabase.co/functions/v1/make-server-9f68532a/depositos`,
      {
        headers: {
          'Authorization': `Bearer ${OLD_ANON_KEY}`
        }
      }
    );
    
    const depositos = await response.json();
    const pendientes = depositos.filter(d => d.estado === 'pendiente');
    
    console.log(`✅ ${pendientes.length} depósitos pendientes exportados`);
    
    const blob = new Blob(
      [JSON.stringify(pendientes, null, 2)], 
      { type: 'application/json' }
    );
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `depositos_pendientes_${new Date().toISOString()}.json`;
    a.click();
    
    console.log('💾 Archivo descargado: depositos_pendientes_*.json');
    
    return pendientes;
  } catch (error) {
    console.error('❌ Error al exportar depósitos:', error);
    throw error;
  }
}

// EJECUTAR:
// exportarDepositosPendientes();
```

---

## 📊 SCRIPT 3: EXPORTAR RETIROS PENDIENTES

```javascript
// =====================================================
// EXPORTAR RETIROS PENDIENTES
// =====================================================

async function exportarRetirosPendientes() {
  console.log('🔄 Iniciando exportación de retiros pendientes...');
  
  try {
    const response = await fetch(
      `https://${OLD_PROJECT_ID}.supabase.co/functions/v1/make-server-9f68532a/cobros`,
      {
        headers: {
          'Authorization': `Bearer ${OLD_ANON_KEY}`
        }
      }
    );
    
    const cobros = await response.json();
    const pendientes = cobros.filter(c => 
      c.estado === 'pendiente' || c.estado === 'aprobado'
    );
    
    console.log(`✅ ${pendientes.length} retiros pendientes exportados`);
    
    const blob = new Blob(
      [JSON.stringify(pendientes, null, 2)], 
      { type: 'application/json' }
    );
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `retiros_pendientes_${new Date().toISOString()}.json`;
    a.click();
    
    console.log('💾 Archivo descargado: retiros_pendientes_*.json');
    
    return pendientes;
  } catch (error) {
    console.error('❌ Error al exportar retiros:', error);
    throw error;
  }
}

// EJECUTAR:
// exportarRetirosPendientes();
```

---

## 📊 SCRIPT 4: EXPORTAR TODO (BACKUP COMPLETO)

```javascript
// =====================================================
// EXPORTAR TODO - BACKUP COMPLETO
// =====================================================

async function exportarBackupCompleto() {
  console.log('🔄 Iniciando backup completo...');
  
  const OLD_PROJECT_ID = 'tu-project-id-antiguo';
  const OLD_ANON_KEY = 'tu-anon-key-antiguo';
  
  const backup = {
    fecha: new Date().toISOString(),
    projectId: OLD_PROJECT_ID,
    datos: {}
  };
  
  try {
    // Usuarios
    console.log('📥 Exportando usuarios...');
    const resUsuarios = await fetch(
      `https://${OLD_PROJECT_ID}.supabase.co/functions/v1/make-server-9f68532a/users`,
      { headers: { 'Authorization': `Bearer ${OLD_ANON_KEY}` } }
    );
    backup.datos.usuarios = await resUsuarios.json();
    console.log(`✅ ${backup.datos.usuarios.length} usuarios`);
    
    // Packs
    console.log('📥 Exportando packs...');
    const resPacks = await fetch(
      `https://${OLD_PROJECT_ID}.supabase.co/functions/v1/make-server-9f68532a/packs`,
      { headers: { 'Authorization': `Bearer ${OLD_ANON_KEY}` } }
    );
    backup.datos.packs = await resPacks.json();
    console.log(`✅ ${backup.datos.packs.length} packs`);
    
    // Depósitos
    console.log('📥 Exportando depósitos...');
    const resDepositos = await fetch(
      `https://${OLD_PROJECT_ID}.supabase.co/functions/v1/make-server-9f68532a/depositos`,
      { headers: { 'Authorization': `Bearer ${OLD_ANON_KEY}` } }
    );
    backup.datos.depositos = await resDepositos.json();
    console.log(`✅ ${backup.datos.depositos.length} depósitos`);
    
    // Cobros
    console.log('📥 Exportando cobros...');
    const resCobros = await fetch(
      `https://${OLD_PROJECT_ID}.supabase.co/functions/v1/make-server-9f68532a/cobros`,
      { headers: { 'Authorization': `Bearer ${OLD_ANON_KEY}` } }
    );
    backup.datos.cobros = await resCobros.json();
    console.log(`✅ ${backup.datos.cobros.length} cobros`);
    
    // Productos
    console.log('📥 Exportando productos...');
    const resProductos = await fetch(
      `https://${OLD_PROJECT_ID}.supabase.co/functions/v1/make-server-9f68532a/productos`,
      { headers: { 'Authorization': `Bearer ${OLD_ANON_KEY}` } }
    );
    backup.datos.productos = await resProductos.json();
    console.log(`✅ ${backup.datos.productos.length} productos`);
    
    // Descargar backup completo
    const blob = new Blob(
      [JSON.stringify(backup, null, 2)], 
      { type: 'application/json' }
    );
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `backup_completo_${backup.fecha}.json`;
    a.click();
    
    console.log('✅ BACKUP COMPLETO DESCARGADO');
    console.log('📊 Resumen:');
    console.log(`   - Usuarios: ${backup.datos.usuarios.length}`);
    console.log(`   - Packs: ${backup.datos.packs.length}`);
    console.log(`   - Depósitos: ${backup.datos.depositos.length}`);
    console.log(`   - Cobros: ${backup.datos.cobros.length}`);
    console.log(`   - Productos: ${backup.datos.productos.length}`);
    
    return backup;
  } catch (error) {
    console.error('❌ Error en backup completo:', error);
    throw error;
  }
}

// EJECUTAR:
// Actualiza las credenciales arriba y luego:
// exportarBackupCompleto();
```

---

## 📥 SCRIPT 5: IMPORTAR USUARIOS

```javascript
// =====================================================
// IMPORTAR USUARIOS A NUEVA BASE DE DATOS
// =====================================================

async function importarUsuarios(usuariosJSON) {
  console.log('🔄 Iniciando importación de usuarios...');
  
  const NEW_PROJECT_ID = 'tu-nuevo-project-id';
  const NEW_ANON_KEY = 'tu-nuevo-anon-key';
  
  const usuarios = typeof usuariosJSON === 'string' 
    ? JSON.parse(usuariosJSON) 
    : usuariosJSON;
  
  let exitosos = 0;
  let fallidos = 0;
  const errores = [];
  
  for (const usuario of usuarios) {
    try {
      // Registrar usuario en nueva base de datos
      const response = await fetch(
        `https://${NEW_PROJECT_ID}.supabase.co/functions/v1/make-server-9f68532a/auth/register`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${NEW_ANON_KEY}`
          },
          body: JSON.stringify({
            nombre: usuario.nombre,
            apellido: usuario.apellido,
            email: usuario.email,
            telefono: usuario.telefono,
            ciudad: usuario.ciudad || '',
            wallet: usuario.wallet || '',
            password: usuario.password,
            referralCode: usuario.referralCode || '',
            referidoPor: usuario.referidoPor
          })
        }
      );
      
      if (response.ok) {
        exitosos++;
        console.log(`✅ Usuario importado: ${usuario.email}`);
      } else {
        const error = await response.text();
        fallidos++;
        errores.push({ email: usuario.email, error });
        console.log(`⚠️ Error con ${usuario.email}: ${error}`);
      }
      
      // Delay para no saturar el servidor
      await new Promise(resolve => setTimeout(resolve, 100));
      
    } catch (error) {
      fallidos++;
      errores.push({ email: usuario.email, error: error.message });
      console.error(`❌ Error con ${usuario.email}:`, error);
    }
  }
  
  console.log('\n📊 RESUMEN DE IMPORTACIÓN:');
  console.log(`   ✅ Exitosos: ${exitosos}`);
  console.log(`   ❌ Fallidos: ${fallidos}`);
  console.log(`   📝 Total: ${usuarios.length}`);
  
  if (errores.length > 0) {
    console.log('\n❌ Errores encontrados:');
    console.table(errores);
  }
  
  return { exitosos, fallidos, errores };
}

// EJECUTAR:
// 1. Carga el archivo JSON exportado
// 2. Copia el contenido a una variable:
//    const usuariosBackup = [paste aquí el contenido];
// 3. Ejecuta:
//    importarUsuarios(usuariosBackup);
```

---

## 📥 SCRIPT 6: IMPORTAR DEPÓSITOS PENDIENTES

```javascript
// =====================================================
// IMPORTAR DEPÓSITOS PENDIENTES
// =====================================================

async function importarDepositosPendientes(depositosJSON) {
  console.log('🔄 Iniciando importación de depósitos pendientes...');
  
  const NEW_PROJECT_ID = 'tu-nuevo-project-id';
  const NEW_ANON_KEY = 'tu-nuevo-anon-key';
  
  const depositos = typeof depositosJSON === 'string' 
    ? JSON.parse(depositosJSON) 
    : depositosJSON;
  
  let exitosos = 0;
  let fallidos = 0;
  const errores = [];
  
  for (const deposito of depositos) {
    try {
      const response = await fetch(
        `https://${NEW_PROJECT_ID}.supabase.co/functions/v1/make-server-9f68532a/depositos`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${NEW_ANON_KEY}`
          },
          body: JSON.stringify({
            userId: deposito.userId,
            packNombre: deposito.packNombre,
            monto: deposito.monto,
            walletDestino: deposito.walletDestino,
            comprobante: deposito.comprobante,
            metodoPago: deposito.metodoPago || 'manual',
            paymentId: deposito.paymentId
          })
        }
      );
      
      if (response.ok) {
        exitosos++;
        console.log(`✅ Depósito importado: $${deposito.monto} - ${deposito.userId}`);
      } else {
        const error = await response.text();
        fallidos++;
        errores.push({ userId: deposito.userId, monto: deposito.monto, error });
        console.log(`⚠️ Error con depósito de ${deposito.userId}`);
      }
      
      await new Promise(resolve => setTimeout(resolve, 100));
      
    } catch (error) {
      fallidos++;
      errores.push({ userId: deposito.userId, error: error.message });
      console.error(`❌ Error con depósito:`, error);
    }
  }
  
  console.log('\n📊 RESUMEN DE IMPORTACIÓN:');
  console.log(`   ✅ Exitosos: ${exitosos}`);
  console.log(`   ❌ Fallidos: ${fallidos}`);
  console.log(`   📝 Total: ${depositos.length}`);
  
  if (errores.length > 0) {
    console.log('\n❌ Errores encontrados:');
    console.table(errores);
  }
  
  return { exitosos, fallidos, errores };
}

// EJECUTAR:
// importarDepositosPendientes(depositosBackup);
```

---

## 🔄 SCRIPT 7: MIGRACIÓN COMPLETA AUTOMÁTICA

```javascript
// =====================================================
// MIGRACIÓN COMPLETA AUTOMÁTICA
// =====================================================

async function migracionCompleta() {
  console.log('🚀 INICIANDO MIGRACIÓN COMPLETA');
  console.log('================================\n');
  
  // CONFIGURACIÓN
  const OLD_PROJECT_ID = 'antiguo-project-id';
  const OLD_ANON_KEY = 'antiguo-anon-key';
  const NEW_PROJECT_ID = 'nuevo-project-id';
  const NEW_ANON_KEY = 'nuevo-anon-key';
  
  const reporte = {
    inicio: new Date().toISOString(),
    pasos: []
  };
  
  try {
    // PASO 1: Exportar usuarios
    console.log('📤 PASO 1: Exportando usuarios...');
    const resUsuarios = await fetch(
      `https://${OLD_PROJECT_ID}.supabase.co/functions/v1/make-server-9f68532a/users`,
      { headers: { 'Authorization': `Bearer ${OLD_ANON_KEY}` } }
    );
    const usuarios = await resUsuarios.json();
    reporte.pasos.push({
      paso: 1,
      accion: 'Exportar usuarios',
      resultado: `${usuarios.length} usuarios exportados`,
      exitoso: true
    });
    console.log(`✅ ${usuarios.length} usuarios exportados\n`);
    
    // PASO 2: Importar usuarios
    console.log('📥 PASO 2: Importando usuarios...');
    let usuariosImportados = 0;
    for (const usuario of usuarios) {
      try {
        const res = await fetch(
          `https://${NEW_PROJECT_ID}.supabase.co/functions/v1/make-server-9f68532a/auth/register`,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${NEW_ANON_KEY}`
            },
            body: JSON.stringify(usuario)
          }
        );
        
        if (res.ok) {
          usuariosImportados++;
        }
        
        await new Promise(resolve => setTimeout(resolve, 100));
      } catch (error) {
        console.error(`Error con ${usuario.email}:`, error.message);
      }
    }
    reporte.pasos.push({
      paso: 2,
      accion: 'Importar usuarios',
      resultado: `${usuariosImportados}/${usuarios.length} importados`,
      exitoso: true
    });
    console.log(`✅ ${usuariosImportados} usuarios importados\n`);
    
    // PASO 3: Exportar depósitos pendientes
    console.log('📤 PASO 3: Exportando depósitos pendientes...');
    const resDepositos = await fetch(
      `https://${OLD_PROJECT_ID}.supabase.co/functions/v1/make-server-9f68532a/depositos`,
      { headers: { 'Authorization': `Bearer ${OLD_ANON_KEY}` } }
    );
    const todosDepositos = await resDepositos.json();
    const depositosPendientes = todosDepositos.filter(d => d.estado === 'pendiente');
    reporte.pasos.push({
      paso: 3,
      accion: 'Exportar depósitos pendientes',
      resultado: `${depositosPendientes.length} depósitos pendientes`,
      exitoso: true
    });
    console.log(`✅ ${depositosPendientes.length} depósitos pendientes\n`);
    
    // PASO 4: Importar depósitos pendientes
    console.log('📥 PASO 4: Importando depósitos pendientes...');
    let depositosImportados = 0;
    for (const deposito of depositosPendientes) {
      try {
        const res = await fetch(
          `https://${NEW_PROJECT_ID}.supabase.co/functions/v1/make-server-9f68532a/depositos`,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${NEW_ANON_KEY}`
            },
            body: JSON.stringify(deposito)
          }
        );
        
        if (res.ok) {
          depositosImportados++;
        }
        
        await new Promise(resolve => setTimeout(resolve, 100));
      } catch (error) {
        console.error(`Error con depósito:`, error.message);
      }
    }
    reporte.pasos.push({
      paso: 4,
      accion: 'Importar depósitos pendientes',
      resultado: `${depositosImportados}/${depositosPendientes.length} importados`,
      exitoso: true
    });
    console.log(`✅ ${depositosImportados} depósitos importados\n`);
    
    // RESUMEN FINAL
    console.log('================================');
    console.log('✅ MIGRACIÓN COMPLETADA');
    console.log('================================\n');
    console.log('📊 RESUMEN:');
    console.log(`   - Usuarios migrados: ${usuariosImportados}/${usuarios.length}`);
    console.log(`   - Depósitos migrados: ${depositosImportados}/${depositosPendientes.length}`);
    console.log(`   - Duración: ${((Date.now() - new Date(reporte.inicio)) / 1000).toFixed(2)}s`);
    
    reporte.fin = new Date().toISOString();
    reporte.exitoso = true;
    
    // Descargar reporte
    const blob = new Blob(
      [JSON.stringify(reporte, null, 2)], 
      { type: 'application/json' }
    );
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `reporte_migracion_${reporte.inicio}.json`;
    a.click();
    
    return reporte;
    
  } catch (error) {
    console.error('❌ ERROR EN MIGRACIÓN:', error);
    reporte.exitoso = false;
    reporte.error = error.message;
    return reporte;
  }
}

// EJECUTAR:
// 1. Actualiza las credenciales arriba
// 2. Ejecuta:
//    migracionCompleta();
```

---

## 📋 CHECKLIST DE MIGRACIÓN DE DATOS

### Antes de Migrar
- [ ] Backup completo descargado
- [ ] Nueva base de datos creada y vacía
- [ ] Credenciales de ambos proyectos disponibles
- [ ] Scripts probados en entorno de prueba

### Durante la Migración
- [ ] Usuarios exportados
- [ ] Usuarios importados
- [ ] Depósitos pendientes exportados
- [ ] Depósitos pendientes importados
- [ ] Retiros pendientes exportados
- [ ] Retiros pendientes importados

### Después de Migrar
- [ ] Verificar cantidad de registros
- [ ] Verificar integridad de datos
- [ ] Probar login de usuarios clave
- [ ] Verificar saldos de usuarios
- [ ] Probar funcionalidades críticas

---

## ⚠️ NOTAS IMPORTANTES

### 1. Orden de Importación

El orden es crítico:
1. **Primero:** Usuarios
2. **Segundo:** Depósitos pendientes
3. **Tercero:** Retiros pendientes

### 2. IDs de Usuarios

Los IDs de usuarios cambiarán en la nueva base de datos. Asegúrate de que:
- Los id_unico se mantengan iguales
- Las relaciones referidoPor se actualicen correctamente

### 3. Contraseñas

Las contraseñas se migran tal cual (sin hash en sistema actual).
En producción, considera implementar hashing.

### 4. Verificación Manual

Después de la migración automática:
1. Verifica manualmente usuarios críticos
2. Compara saldos antes y después
3. Verifica que las relaciones de referidos estén correctas

---

## 🔧 TROUBLESHOOTING

### Error: "Email already exists"

**Solución:** El usuario ya fue importado. Omitir y continuar.

### Error: "Invalid referidoPor"

**Solución:** El referidor aún no fue importado. Importar en orden cronológico.

### Error: "Rate limit exceeded"

**Solución:** Aumentar el delay entre requests (cambiar 100ms a 500ms).

### Error: "Unauthorized"

**Solución:** Verificar que las API keys sean correctas.

---

## 📞 SOPORTE

Si encuentras problemas:

1. Revisa los logs en la consola del navegador
2. Verifica que no haya errores de red (F12 > Network)
3. Consulta los archivos de backup para comparar datos
4. Contacta soporte de Supabase si es necesario

---

**Última actualización:** 2025-11-19  
**Versión:** 1.0
