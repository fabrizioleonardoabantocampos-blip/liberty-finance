import { projectId, publicAnonKey } from './supabase/info';
import { isDemoMode, getDemoResponse } from './demoMode';

const API_BASE_URL = `https://${projectId}.supabase.co/functions/v1/make-server-9f68532a`;

// ==========================================
// CONFIGURACIÓN DE FETCH
// ==========================================

// Helper para retry con backoff exponencial
const fetchWithRetry = async (
  url: string,
  options: RequestInit,
  maxRetries: number = 3,
  baseDelay: number = 2000, // ⚡ AUMENTADO: 1s → 2s entre reintentos
  timeoutMs: number = 120000 // ⚡ AUMENTADO: 30s → 120s (2 minutos) para cold start
): Promise<Response> => {
  // 🎭 MODO DEMO: Responder inmediatamente sin hacer fetch real
  if (isDemoMode()) {
    const endpoint = url.replace(API_BASE_URL, '');
    const demoData = getDemoResponse(endpoint);
    
    // Simular delay de red
    await new Promise(resolve => setTimeout(resolve, 100));
    
    return new Response(JSON.stringify(demoData), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });
  }
  
  let lastError: Error | null = null;
  let isFirstTimeout = true; // Para detectar el primer timeout y despertar el servidor
  
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      // ⚡ NUEVO: Crear un AbortController para timeout
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
      
      const response = await fetch(url, {
        ...options,
        signal: controller.signal
      });
      
      clearTimeout(timeoutId);
      
      // Si la respuesta es exitosa o es un error del cliente (4xx), no reintentar
      if (response.ok || (response.status >= 400 && response.status < 500)) {
        return response;
      }
      
      // ⚡ NO REINTENTAR 503 (endpoints deshabilitados intencionalmente)
      if (response.status === 503) {
        console.warn(`⚠️ Endpoint deshabilitado (503), no reintentando: ${url}`);
        return response;
      }
      
      // Si es un error del servidor (5xx) o timeout (504), reintentar
      if (attempt < maxRetries) {
        const delay = baseDelay * Math.pow(2, attempt); // Backoff exponencial
        console.warn(`⚠️ Intento ${attempt + 1}/${maxRetries + 1} falló (${response.status}), reintentando en ${delay}ms...`);
        await new Promise(resolve => setTimeout(resolve, delay));
        continue;
      }
      
      return response;
    } catch (error) {
      lastError = error as Error;
      
      // Si es un error de timeout
      if ((error as Error).name === 'AbortError') {
        console.warn(`⚠️ Timeout (${timeoutMs}ms) en intento ${attempt + 1}/${maxRetries + 1}`);
        
        // ⚡ NUEVO: Si es el primer timeout, intentar despertar el servidor
        if (isFirstTimeout && attempt === 0) {
          isFirstTimeout = false;
          console.log('🔄 Detectado cold start, intentando despertar servidor...');
          
          try {
            // Hacer ping rápido para despertar el servidor
            await fetch(`${API_BASE_URL}/ping`, {
              method: 'GET',
              headers: { 'Authorization': `Bearer ${publicAnonKey}` }
            }).catch(() => {}); // Ignorar errores del ping
            
            console.log('✅ Ping enviado, esperando 3s antes de reintentar...');
            await new Promise(resolve => setTimeout(resolve, 3000));
          } catch {
            // Ignorar errores del ping
          }
        }
      }
      
      // Si es un error de red y aún tenemos intentos, reintentar
      if (attempt < maxRetries) {
        const delay = baseDelay * Math.pow(2, attempt);
        console.warn(`⚠️ Error de red en intento ${attempt + 1}/${maxRetries + 1}, reintentando en ${delay}ms...`);
        await new Promise(resolve => setTimeout(resolve, delay));
        continue;
      }
    }
  }
  
  throw lastError || new Error('Max retries exceeded');
};

export const fetchAPI = async (endpoint: string, options: RequestInit = {}, timeoutMs: number = 120000) => {
  const url = `${API_BASE_URL}${endpoint}`;
  
  // ⚡ Para operaciones de larga duración (>90s), NO hacer retry
  const noRetry = timeoutMs > 90000;
  const maxRetries = noRetry ? 0 : 2; // ⚡ REDUCIDO: 3 → 2 reintentos
  
  if (noRetry) {
    console.log(`⏱️ Timeout extendido detectado (${timeoutMs}ms), desactivando reintentos automáticos`);
  }
  
  try {
    const response = await fetchWithRetry(url, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${publicAnonKey}`,
        ...options.headers,
      },
    }, maxRetries, 2000, timeoutMs); // Pasar timeout configurado

    // Intentar parsear como JSON
    let data;
    const contentType = response.headers.get('content-type');
    
    if (contentType && contentType.includes('application/json')) {
      const text = await response.text();
      try {
        data = text ? JSON.parse(text) : {};
      } catch (parseError) {
        console.error(`Error parsing JSON from ${endpoint}:`, text);
        throw new Error('Error al procesar la respuesta del servidor');
      }
    } else {
      // Si no es JSON, leer como texto
      const text = await response.text();
      console.warn(`Non-JSON response from ${endpoint}:`, text);
      data = { error: text || 'Error desconocido' };
    }

    if (!response.ok) {
      console.error(`API Error (${endpoint}):`, data);
      throw new Error(data.error || data.message || 'Error en la petición');
    }

    return data;
  } catch (error: any) {
    console.error(`Fetch error for ${endpoint}:`, error);
    throw error;
  }
};

// ==========================================
// AUTENTICACIÓN
// ==========================================

export const authAPI = {
  register: async (userData: {
    nombre: string;
    apellido: string;
    email: string;
    telefono: string;
    ciudad: string;
    wallet: string;
    password: string;
    referralCode?: string;
    referidoPor?: string;
  }) => {
    return await fetchAPI('/auth/register', {
      method: 'POST',
      body: JSON.stringify(userData),
    });
  },

  login: async (email: string, password: string) => {
    return await fetchAPI('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
  },
};

// ==========================================
// USUARIOS
// ==========================================

export const usersAPI = {
  getById: async (userId: string) => {
    return await fetchAPI(`/users/${userId}`);
  },

  getAll: async () => {
    return await fetchAPI('/users');
  },

  update: async (userId: string, updates: any) => {
    return await fetchAPI(`/users/${userId}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
  },

  getSaldoWallet: async (userId: string) => {
    return await fetchAPI(`/users/${userId}/saldo-wallet`);
  },
};

// ==========================================
// PACKS
// ==========================================

export const packsAPI = {
  create: async (packData: {
    userId: string;
    nombre: string;
    monto: number;
    rendimientoDiario: number;
  }) => {
    return await fetchAPI('/packs', {
      method: 'POST',
      body: JSON.stringify(packData),
    });
  },

  // NUEVA: Comprar pack con saldo de wallet (reinversión)
  comprarConWallet: async (compraData: {
    userId: string;
    packNombre: string;
    monto: number;
  }) => {
    return await fetchAPI('/packs/comprar-con-wallet', {
      method: 'POST',
      body: JSON.stringify(compraData),
    });
  },

  getByUserId: async (userId: string) => {
    return await fetchAPI(`/users/${userId}/packs`);
  },
};

// ==========================================
// COMISIONES
// ==========================================

export const comisionesAPI = {
  getByUserId: async (userId: string) => {
    return await fetchAPI(`/users/${userId}/comisiones`);
  },

  getTotalByUserId: async (userId: string) => {
    return await fetchAPI(`/users/${userId}/comisiones/total`);
  },
};

// ==========================================
// COBROS
// ==========================================

export const cobrosAPI = {
  create: async (cobroData: {
    userId: string;
    monto: number;
    wallet: string;
  }) => {
    return await fetchAPI('/cobros', {
      method: 'POST',
      body: JSON.stringify(cobroData),
    });
  },

  getByUserId: async (userId: string) => {
    return await fetchAPI(`/users/${userId}/cobros`);
  },

  getAll: async () => {
    return await fetchAPI('/cobros');
  },

  update: async (cobroId: string, updates: any) => {
    return await fetchAPI(`/cobros/${cobroId}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
  },
};

// ==========================================
// DEPÓSITOS
// ==========================================

export const depositosAPI = {
  create: async (depositoData: {
    userId: string;
    packNombre: string;
    monto: number;
    walletDestino: string;
    comprobante?: string;
    txHash?: string;
  }) => {
    return await fetchAPI('/depositos', {
      method: 'POST',
      body: JSON.stringify(depositoData),
    });
  },

  uploadComprobante: async (file: File) => {
    const formData = new FormData();
    formData.append('file', file);
    
    const { projectId } = await import('./supabase/info');
    const response = await fetch(
      `https://${projectId}.supabase.co/functions/v1/make-server-9f68532a/depositos/upload-comprobante`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
        },
        body: formData,
      }
    );
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Error al subir comprobante');
    }
    
    return await response.json();
  },

  getByUserId: async (userId: string) => {
    return await fetchAPI(`/users/${userId}/depositos`);
  },

  getAll: async () => {
    return await fetchAPI('/depositos');
  },

  update: async (depositoId: string, updates: any) => {
    return await fetchAPI(`/depositos/${depositoId}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
  },
};

// ==========================================
// CONFIGURACIÓN ADMIN
// ==========================================

export const configuracionAPI = {
  get: async () => {
    return await fetchAPI('/admin/configuracion');
  },

  update: async (updates: any) => {
    return await fetchAPI('/admin/configuracion', {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
  },
};

// ==========================================
// PRODUCTOS
// ==========================================

export const productosAPI = {
  create: async (productoData: {
    nombre: string;
    descripcion: string;
    precio: number;
    imagen?: string;
    stock: number;
  }) => {
    return await fetchAPI('/productos', {
      method: 'POST',
      body: JSON.stringify(productoData),
    });
  },

  getAll: async () => {
    return await fetchAPI('/productos');
  },

  update: async (productoId: string, updates: any) => {
    return await fetchAPI(`/productos/${productoId}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
  },

  delete: async (productoId: string) => {
    return await fetchAPI(`/productos/${productoId}`, {
      method: 'DELETE',
    });
  },
};

// ==========================================
// RANGOS
// ==========================================

export const rangosAPI = {
  uploadImagen: async (file: File) => {
    const formData = new FormData();
    formData.append('file', file);
    
    const response = await fetch(
      `https://${projectId}.supabase.co/functions/v1/make-server-9f68532a/rangos/upload-imagen`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
        },
        body: formData,
      }
    );
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Error al subir imagen');
    }
    
    return await response.json();
  },

  create: async (rangoData: {
    nombre: string;
    directos: number;
    volumen: number;
    premio: string;
    color: string;
    gradient: string;
    icon: string;
    imagen: string;
  }) => {
    return await fetchAPI('/rangos', {
      method: 'POST',
      body: JSON.stringify(rangoData),
    });
  },

  getAll: async () => {
    return await fetchAPI('/rangos');
  },

  update: async (rangoId: string, updates: any) => {
    return await fetchAPI(`/rangos/${rangoId}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
  },

  delete: async (rangoId: string) => {
    return await fetchAPI(`/rangos/${rangoId}`, {
      method: 'DELETE',
    });
  },

  init: async () => {
    return await fetchAPI('/rangos/init', {
      method: 'POST',
    });
  },
};

export const documentosAPI = {
  uploadPDF: async (file: File, tipo: 'terminos' | 'privacidad' | 'aviso') => {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('tipo', tipo);
    
    const response = await fetch(
      `https://${projectId}.supabase.co/functions/v1/make-server-9f68532a/documentos/upload-pdf`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
        },
        body: formData,
      }
    );
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Error al subir PDF');
    }
    
    return await response.json();
  },

  getLegales: async () => {
    return await fetchAPI('/documentos/legales');
  },
};

// ==========================================
// COMPRAS
// ==========================================

export const comprasAPI = {
  create: async (compraData: {
    userId: string;
    productoId: string;
    cantidad: number;
    precioTotal: number;
  }) => {
    return await fetchAPI('/compras', {
      method: 'POST',
      body: JSON.stringify(compraData),
    });
  },

  getByUserId: async (userId: string) => {
    return await fetchAPI(`/users/${userId}/compras`);
  },
};

// ==========================================
// PUNTOS
// ==========================================

export const puntosAPI = {
  get: async (userId: string) => {
    return await fetchAPI(`/users/${userId}/puntos`);
  },

  add: async (userId: string, puntos: number) => {
    return await fetchAPI(`/users/${userId}/puntos/add`, {
      method: 'POST',
      body: JSON.stringify({ puntos }),
    });
  },
};

// ==========================================
// RULETA
// ==========================================

export const ruletaAPI = {
  spin: async (spinData: {
    userId: string;
    premio: string;
    puntos?: number;
  }) => {
    return await fetchAPI('/ruleta/spin', {
      method: 'POST',
      body: JSON.stringify(spinData),
    });
  },

  getHistorial: async (userId: string) => {
    return await fetchAPI(`/users/${userId}/ruleta`);
  },

  getGastos: async (userId: string) => {
    return await fetchAPI(`/ruleta/gastos/${userId}`);
  },
};

// ==========================================
// RED MULTINIVEL
// ==========================================

export const redAPI = {
  getReferidosDirectos: async (userId: string) => {
    return await fetchAPI(`/users/${userId}/referidos`);
  },

  getReferidosPorNivel: async (userId: string, nivel: number) => {
    return await fetchAPI(`/users/${userId}/red/${nivel}`);
  },
};

// ==========================================
// NOWPAYMENTS
// ==========================================

export const nowpaymentsAPI = {
  // Verificar estado de la API
  checkStatus: async () => {
    return await fetchAPI('/nowpayments/status');
  },

  createPayment: async (paymentData: {
    userId: string;
    packNombre: string;
    monto: number;
  }) => {
    return await fetchAPI('/nowpayments/create-payment', {
      method: 'POST',
      body: JSON.stringify(paymentData),
    });
  },

  getPaymentStatus: async (paymentId: string) => {
    return await fetchAPI(`/nowpayments/payment/${paymentId}`);
  },

  getCurrencies: async () => {
    return await fetchAPI('/nowpayments/currencies');
  },

  getMinAmount: async (currency: string) => {
    return await fetchAPI(`/nowpayments/min-amount/${currency}`);
  },
};

// ==========================================
// ADMIN - ESTADÍSTICAS
// ==========================================

export const adminAPI = {
  getEstadisticas: async () => {
    return await fetchAPI('/admin/estadisticas');
  },

  procesarRendimientos: async () => {
    return await fetchAPI('/admin/procesar-rendimientos', {
      method: 'POST',
    });
  },

  diagnosticarRendimientos: async () => {
    return await fetchAPI('/admin/diagnostico-rendimientos', {
      method: 'GET',
    });
  },

  eliminarDuplicados: async () => {
    return await fetchAPI('/admin/eliminar-rendimientos-duplicados', {
      method: 'POST',
    });
  },

  limpiarLocks: async () => {
    return await fetchAPI('/admin/limpiar-locks', {
      method: 'POST',
    });
  },

  sincronizarIndices: async () => {
    return await fetchAPI('/admin/sync-user-indexes', {
      method: 'POST',
    });
  },

  diagnosticarUsuario: async (idUnico: string) => {
    return await fetchAPI(`/admin/diagnostico-usuario/${idUnico}`, {
      method: 'GET',
    });
  },

  repararPacksUsuario: async (idUnico: string) => {
    return await fetchAPI(`/admin/reparar-packs-usuario/${idUnico}`, {
      method: 'POST',
    });
  },

  analizarRendimientosUsuario: async (idUnico: string) => {
    return await fetchAPI(`/admin/analizar-rendimientos-usuario/${idUnico}`, {
      method: 'GET',
    });
  },

  repararRendimientosHuerfanos: async (idUnico: string) => {
    return await fetchAPI(`/admin/reparar-rendimientos-huerfanos/${idUnico}`, {
      method: 'POST',
    });
  },

  corregirRendimientosHistoricos: async (userId: string) => {
    return await fetchAPI(`/admin/corregir-rendimientos-historicos/${userId}`, {
      method: 'POST',
    });
  },
  
  activarPack: async (userId: string, packId: string) => {
    return await fetchAPI(`/admin/activar-pack/${packId}`, {
      method: 'POST',
    });
  },
};

// ==========================================
// RENDIMIENTOS
// ==========================================

export const rendimientosAPI = {
  getByUserId: async (userId: string) => {
    return await fetchAPI(`/users/${userId}/rendimientos`);
  },

  getTotalByUserId: async (userId: string) => {
    return await fetchAPI(`/users/${userId}/rendimientos/total`);
  },
};

// ==========================================
// FUNCIÓN HELPER GENÉRICA (LEGACY SUPPORT)
// ==========================================

/**
 * Función helper genérica para llamadas al servidor
 * @deprecated Usa las APIs específicas (authAPI, usersAPI, etc.) en su lugar
 */
export const callServer = async (
  endpoint: string,
  method: string = 'GET',
  body?: any
) => {
  const options: RequestInit = {
    method,
  };

  if (body && method !== 'GET') {
    options.body = JSON.stringify(body);
  }

  return await fetchAPI(endpoint, options);
};