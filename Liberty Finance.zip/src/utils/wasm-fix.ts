// 🔧 UTILIDAD: Solución definitiva para errores de WebAssembly en operaciones largas
// Implementa reintentos automáticos y limpieza de caché

export interface RetryOptions {
  maxIntentos?: number;
  delayBase?: number;
  limpiarCacheEnReintento?: boolean;
}

/**
 * Ejecuta una función con reintentos automáticos si falla por errores de WebAssembly o red
 * @param fn Función async a ejecutar
 * @param options Opciones de reintento
 * @returns Resultado de la función
 */
export async function ejecutarConReintentos<T>(
  fn: () => Promise<T>,
  options: RetryOptions = {}
): Promise<T> {
  const {
    maxIntentos = 3,
    delayBase = 2000,
    limpiarCacheEnReintento = true
  } = options;

  let intentos = 0;
  let ultimoError: Error | null = null;

  while (intentos < maxIntentos) {
    try {
      intentos++;
      console.log(`🔄 [Intento ${intentos}/${maxIntentos}]`);

      // Limpiar caché del navegador antes de reintentos
      if (intentos > 1 && limpiarCacheEnReintento && 'caches' in window) {
        try {
          const cacheNames = await caches.keys();
          await Promise.all(cacheNames.map(name => caches.delete(name)));
          console.log('🧹 Caché del navegador limpiada');
        } catch (cacheError) {
          console.warn('⚠️ No se pudo limpiar caché:', cacheError);
        }
      }

      // Ejecutar la función
      const resultado = await fn();
      console.log(`✅ Operación exitosa en intento ${intentos}`);
      return resultado;

    } catch (error: any) {
      ultimoError = error;
      console.error(`❌ Error en intento ${intentos}:`, error);

      // Determinar si es un error recuperable
      const esErrorRecuperable = error.message && (
        error.message.includes('WebAssembly') ||
        error.message.includes('aborted') ||
        error.message.includes('network') ||
        error.message.includes('Failed to fetch') ||
        error.message.includes('Response body loading was aborted')
      );

      // No reintentar si es AbortError (timeout)
      if (error.name === 'AbortError') {
        console.error('⏱️ Timeout detectado, no se reintentará');
        throw error;
      }

      // Si es recuperable y tenemos más intentos, esperar antes de reintentar
      if (esErrorRecuperable && intentos < maxIntentos) {
        const delay = intentos * delayBase; // 2s, 4s, 6s...
        console.log(`⏳ Esperando ${delay}ms antes de reintentar...`);
        await new Promise(resolve => setTimeout(resolve, delay));
        continue; // Reintentar
      }

      // Si no es recuperable o se acabaron los intentos, lanzar el error
      throw error;
    }
  }

  // Si llegamos aquí, se acabaron los intentos
  throw new Error(`Falló después de ${maxIntentos} intentos: ${ultimoError?.message || 'Error desconocido'}`);
}

/**
 * Determina el tipo de error y retorna un mensaje amigable
 */
export function obtenerMensajeError(error: any): string {
  if (error.name === 'AbortError') {
    return '⏱️ La operación tomó demasiado tiempo. Verifica los logs del servidor.';
  }
  
  if (error.message) {
    if (error.message.includes('WebAssembly')) {
      return '❌ Error de WebAssembly. La operación se reintentará automáticamente.';
    }
    if (error.message.includes('aborted') || error.message.includes('Response body loading was aborted')) {
      return '🔄 La conexión se interrumpió. Reintentando...';
    }
    if (error.message.includes('network') || error.message.includes('Failed to fetch')) {
      return '🌐 Error de red. Verifica tu conexión e intenta de nuevo.';
    }
    return error.message;
  }
  
  return 'Error desconocido';
}

/**
 * Limpia el caché del navegador para prevenir problemas con recursos obsoletos
 */
export async function limpiarCacheNavegador(): Promise<void> {
  if ('caches' in window) {
    try {
      const cacheNames = await caches.keys();
      const resultados = await Promise.all(
        cacheNames.map(name => caches.delete(name))
      );
      console.log(`🧹 ${resultados.filter(r => r).length} cachés eliminadas`);
    } catch (error) {
      console.warn('⚠️ No se pudo limpiar el caché:', error);
    }
  }
}
