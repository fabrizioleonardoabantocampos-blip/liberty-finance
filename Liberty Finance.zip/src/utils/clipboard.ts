/**
 * Copia texto al portapapeles intentando usar la API moderna y cayendo en un fallback
 * robusto si la API moderna falla (común en iframes o contextos sin permisos).
 * @param text - Texto a copiar
 * @returns Promise<boolean> - true si se copió exitosamente, false si falló
 */
export async function copyToClipboard(text: string): Promise<boolean> {
  // 1. Intentar API moderna (navigator.clipboard)
  // Nota: Esto suele fallar en iframes sin permisos explícitos (NotAllowedError)
  if (navigator.clipboard && navigator.clipboard.writeText) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch (err) {
      // Silenciosamente capturamos el error para usar el fallback.
      // No logueamos warning para no alarmar al usuario en consolas de producción/desarrollo
      // cuando es un comportamiento esperado en entornos restringidos.
    }
  }

  // 2. Fallback: execCommand('copy')
  return new Promise((resolve) => {
    try {
      const textArea = document.createElement('textarea');
      textArea.value = text;
      
      // Estilos para sacar el elemento del flujo visual pero mantenerlo en el DOM
      // para que sea "seleccionable" y "enfocable"
      textArea.style.position = 'fixed';
      textArea.style.left = '-9999px';
      textArea.style.top = '0';
      textArea.style.opacity = '0';
      
      // Evitar zoom en iOS al enfocar
      textArea.style.fontSize = '16px';
      
      // NO usar display:none ni visibility:hidden, porque impide la selección
      textArea.setAttribute('readonly', ''); // Prevenir teclado virtual en móviles
      
      document.body.appendChild(textArea);
      
      // Enfocar y seleccionar
      textArea.focus({ preventScroll: true });
      textArea.select();
      
      // Selección extra para iOS
      const range = document.createRange();
      range.selectNodeContents(textArea);
      const selection = window.getSelection();
      if (selection) {
        selection.removeAllRanges();
        selection.addRange(range);
      }
      textArea.setSelectionRange(0, 999999);
      
      const successful = document.execCommand('copy');
      document.body.removeChild(textArea);
      resolve(successful);
    } catch (err) {
      console.error('Error fatal al copiar al portapapeles (fallback):', err);
      resolve(false);
    }
  });
}
