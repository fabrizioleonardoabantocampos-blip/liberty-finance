/**
 * MODO DEMO - Datos simulados para usar la app sin servidor
 * 
 * ⚠️ IMPORTANTE: Este es un modo temporal de emergencia.
 * Para usar la aplicación REAL, debes desplegar el servidor en Supabase.
 */

export const DEMO_MODE = false; // ✅ Servidor desplegado - MODO DEMO DESACTIVADO

/**
 * Verifica si el modo demo está activado
 */
export function isDemoMode(): boolean {
  return DEMO_MODE;
}

/**
 * Retorna respuestas simuladas para cada endpoint
 */
export function getDemoResponse(endpoint: string): any {
  // Si el modo demo no está activo, no retornar nada
  if (!DEMO_MODE) {
    return null;
  }

  // Datos de usuario demo
  const demoUser = {
    id: 'demo-user-123',
    email: 'usuario@demo.com',
    nombre: 'Usuario Demo',
    telefono: '+1234567890',
    pais: 'México',
    wallet: '0xDEMO123456789',
    saldo_wallet: 1250.50,
    referido_por: null,
    referral_code: 'DEMO123',
    pierna: null,
    rango_actual: 'Bronce',
    directos_count: 3,
    volumen_red: 750,
    createdAt: '2024-01-15T10:30:00Z'
  };

  // Packs activos demo
  const demoPacks = [
    {
      id: 'pack-1',
      user_id: 'demo-user-123',
      monto: 100,
      ganancia_acumulada: 45.50,
      rendimiento_diario: 0.25,
      activo: true,
      fecha_compra: '2024-01-15T10:30:00Z'
    },
    {
      id: 'pack-2',
      user_id: 'demo-user-123',
      monto: 500,
      ganancia_acumulada: 112.75,
      rendimiento_diario: 1.25,
      activo: true,
      fecha_compra: '2024-01-20T14:20:00Z'
    }
  ];

  // Comisiones demo
  const demoComisiones = [
    {
      id: 'comision-1',
      user_id: 'demo-user-123',
      tipo: 'rendimiento',
      monto: 1.50,
      descripcion: 'Rendimiento diario',
      fecha: new Date().toISOString()
    },
    {
      id: 'comision-2',
      user_id: 'demo-user-123',
      tipo: 'red',
      monto: 15.00,
      descripcion: 'Comisión de red (3%)',
      fecha: new Date(Date.now() - 86400000).toISOString()
    },
    {
      id: 'comision-3',
      user_id: 'demo-user-123',
      tipo: 'patrocinio',
      monto: 25.00,
      descripcion: 'Comisión de patrocinio (5%)',
      fecha: new Date(Date.now() - 172800000).toISOString()
    }
  ];

  // Red de referidos
  const demoReferidos = [
    {
      id: 'ref-1',
      email: 'referido1@demo.com',
      nombre: 'Referido Uno',
      packs_activos: 1,
      volumen_total: 100,
      fecha_registro: '2024-02-01T10:00:00Z'
    },
    {
      id: 'ref-2',
      email: 'referido2@demo.com',
      nombre: 'Referido Dos',
      packs_activos: 2,
      volumen_total: 300,
      fecha_registro: '2024-02-05T15:30:00Z'
    },
    {
      id: 'ref-3',
      email: 'referido3@demo.com',
      nombre: 'Referido Tres',
      packs_activos: 1,
      volumen_total: 200,
      fecha_registro: '2024-02-10T09:15:00Z'
    }
  ];

  // Transacciones demo
  const demoTransacciones = [
    {
      id: 'tx-1',
      tipo: 'deposito',
      monto: 100,
      estado: 'aprobado',
      fecha: '2024-01-15T10:30:00Z'
    },
    {
      id: 'tx-2',
      tipo: 'compra_pack',
      monto: -100,
      estado: 'completado',
      fecha: '2024-01-15T10:35:00Z'
    },
    {
      id: 'tx-3',
      tipo: 'deposito',
      monto: 500,
      estado: 'aprobado',
      fecha: '2024-01-20T14:20:00Z'
    },
    {
      id: 'tx-4',
      tipo: 'compra_pack',
      monto: -500,
      estado: 'completado',
      fecha: '2024-01-20T14:25:00Z'
    },
    {
      id: 'tx-5',
      tipo: 'retiro',
      monto: -50,
      estado: 'pendiente',
      fecha: new Date().toISOString()
    }
  ];

  // Matriz binaria demo
  const demoMatriz = {
    id: 'demo-user-123',
    nombre: 'Usuario Demo',
    email: 'usuario@demo.com',
    pack_activo: true,
    izquierda: {
      id: 'ref-1',
      nombre: 'Referido Uno',
      email: 'referido1@demo.com',
      pack_activo: true,
      izquierda: null,
      derecha: null
    },
    derecha: {
      id: 'ref-2',
      nombre: 'Referido Dos',
      email: 'referido2@demo.com',
      pack_activo: true,
      izquierda: {
        id: 'ref-3',
        nombre: 'Referido Tres',
        email: 'referido3@demo.com',
        pack_activo: true,
        izquierda: null,
        derecha: null
      },
      derecha: null
    }
  };

  // Configuración del sistema
  const demoConfig = {
    wallet_destino: '0xDEMOWALLET123456789',
    porcentaje_rendimiento: 0.25,
    porcentaje_comision_red: 3,
    porcentaje_comision_patrocinio: 5,
    limite_pack_activo: 200
  };

  // Rangos
  const demoRangos = [
    { id: '1', nombre: 'Inicial', directos_requeridos: 0, volumen_requerido: 0, premio: 'Bienvenida' },
    { id: '2', nombre: 'Bronce', directos_requeridos: 3, volumen_requerido: 300, premio: 'Certificado Digital' },
    { id: '3', nombre: 'Plata', directos_requeridos: 6, volumen_requerido: 1000, premio: 'Bono $50' },
    { id: '4', nombre: 'Oro', directos_requeridos: 10, volumen_requerido: 3000, premio: 'Bono $150' },
    { id: '5', nombre: 'Platino', directos_requeridos: 15, volumen_requerido: 7500, premio: 'Bono $400' },
    { id: '6', nombre: 'Diamante', directos_requeridos: 25, volumen_requerido: 15000, premio: 'Viaje Internacional' }
  ];

  // Mapear endpoints a respuestas
  switch (endpoint) {
    case '/me':
      return demoUser;
    
    case '/packs':
      return demoPacks;
    
    case '/comisiones':
      return demoComisiones;
    
    case '/referidos':
      return demoReferidos;
    
    case '/transacciones':
      return demoTransacciones;
    
    case '/matriz':
      return demoMatriz;
    
    case '/config':
      return demoConfig;
    
    case '/rangos':
      return demoRangos;
    
    case '/stats':
      return {
        total_usuarios: 150,
        total_packs_activos: 89,
        volumen_total: 45250,
        depositos_pendientes: 5,
        retiros_pendientes: 3
      };
    
    // Endpoints de admin
    case '/admin/users':
      return [demoUser, ...demoReferidos.map(ref => ({
        ...ref,
        saldo_wallet: Math.random() * 500,
        rango_actual: 'Inicial',
        referral_code: `REF${Math.floor(Math.random() * 1000)}`
      }))];
    
    case '/admin/depositos':
      return [
        {
          id: 'dep-1',
          user_id: 'demo-user-123',
          user_email: 'usuario@demo.com',
          monto: 100,
          comprobante_url: 'https://via.placeholder.com/400x300?text=Comprobante',
          estado: 'pendiente',
          fecha: new Date().toISOString()
        }
      ];
    
    case '/admin/retiros':
      return [
        {
          id: 'ret-1',
          user_id: 'demo-user-123',
          user_email: 'usuario@demo.com',
          monto: 50,
          wallet: '0xDEMO123456789',
          estado: 'pendiente',
          fecha: new Date().toISOString()
        }
      ];
    
    // Operaciones POST (simular éxito)
    default:
      if (endpoint.includes('/comprar-pack')) {
        return { success: true, message: 'Pack comprado exitosamente (demo)' };
      }
      if (endpoint.includes('/depositar')) {
        return { success: true, message: 'Depósito registrado (demo)' };
      }
      if (endpoint.includes('/retirar')) {
        return { success: true, message: 'Retiro solicitado (demo)' };
      }
      if (endpoint.includes('/aprobar')) {
        return { success: true, message: 'Operación aprobada (demo)' };
      }
      if (endpoint.includes('/rechazar')) {
        return { success: true, message: 'Operación rechazada (demo)' };
      }
      
      // Default: retornar objeto vacío
      return {};
  }
}
