/**
 * Sistema de caché inteligente con localStorage
 * Implementa estrategia stale-while-revalidate
 */

interface CacheEntry<T> {
  data: T;
  timestamp: number;
  expiresIn: number; // en milisegundos
}

export class CacheManager {
  /**
   * Guardar datos en caché con tiempo de expiración
   */
  static set<T>(key: string, data: T, expiresInMinutes: number = 5): void {
    try {
      const entry: CacheEntry<T> = {
        data,
        timestamp: Date.now(),
        expiresIn: expiresInMinutes * 60 * 1000
      };
      localStorage.setItem(`cache_${key}`, JSON.stringify(entry));
      console.log(`✅ Caché guardado: ${key} (expira en ${expiresInMinutes} min)`);
    } catch (error) {
      console.error('Error guardando en caché:', error);
    }
  }

  /**
   * Obtener datos del caché si no han expirado
   */
  static get<T>(key: string): T | null {
    try {
      const cached = localStorage.getItem(`cache_${key}`);
      if (!cached) return null;

      const entry: CacheEntry<T> = JSON.parse(cached);
      const age = Date.now() - entry.timestamp;
      const ageSeconds = Math.floor(age / 1000);

      // Si no ha expirado, devolver datos
      if (age < entry.expiresIn) {
        console.log(`✅ Caché válido: ${key} (${ageSeconds}s de antigüedad)`);
        return entry.data;
      }

      // Si expiró, eliminar y devolver null
      console.log(`⏰ Caché expirado: ${key} (${ageSeconds}s de antigüedad)`);
      this.remove(key);
      return null;
    } catch (error) {
      console.error('Error leyendo caché:', error);
      return null;
    }
  }

  /**
   * Obtener datos aunque hayan expirado (stale)
   * Útil para mostrar algo mientras se recarga
   */
  static getStale<T>(key: string): T | null {
    try {
      const cached = localStorage.getItem(`cache_${key}`);
      if (!cached) return null;

      const entry: CacheEntry<T> = JSON.parse(cached);
      const age = Date.now() - entry.timestamp;
      const ageSeconds = Math.floor(age / 1000);

      console.log(`📦 Caché stale: ${key} (${ageSeconds}s de antigüedad)`);
      return entry.data;
    } catch (error) {
      console.error('Error leyendo caché stale:', error);
      return null;
    }
  }

  /**
   * Verificar si el caché es válido (no expirado)
   */
  static isValid(key: string): boolean {
    try {
      const cached = localStorage.getItem(`cache_${key}`);
      if (!cached) return false;

      const entry: CacheEntry<any> = JSON.parse(cached);
      const age = Date.now() - entry.timestamp;
      return age < entry.expiresIn;
    } catch (error) {
      return false;
    }
  }

  /**
   * Verificar si existe caché (aunque esté expirado)
   */
  static exists(key: string): boolean {
    return localStorage.getItem(`cache_${key}`) !== null;
  }

  /**
   * Eliminar entrada de caché
   */
  static remove(key: string): void {
    localStorage.removeItem(`cache_${key}`);
    console.log(`🗑️ Caché eliminado: ${key}`);
  }

  /**
   * Limpiar todo el caché
   */
  static clear(): void {
    const keys = Object.keys(localStorage);
    keys.forEach(key => {
      if (key.startsWith('cache_')) {
        localStorage.removeItem(key);
      }
    });
    console.log('🗑️ Todo el caché limpiado');
  }

  /**
   * Obtener edad del caché en segundos
   */
  static getAge(key: string): number | null {
    try {
      const cached = localStorage.getItem(`cache_${key}`);
      if (!cached) return null;

      const entry: CacheEntry<any> = JSON.parse(cached);
      return Math.floor((Date.now() - entry.timestamp) / 1000);
    } catch (error) {
      return null;
    }
  }
}

/**
 * Hook personalizado para usar con React
 */
export function useCacheOrFetch<T>(
  key: string,
  fetchFn: () => Promise<T>,
  expiresInMinutes: number = 5
): {
  data: T | null;
  isStale: boolean;
  loading: boolean;
  error: Error | null;
  refetch: () => Promise<void>;
} {
  const [data, setData] = React.useState<T | null>(null);
  const [isStale, setIsStale] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState<Error | null>(null);

  const fetchData = async (showStale: boolean = true) => {
    try {
      // Si hay caché stale y se permite, mostrar inmediatamente
      if (showStale) {
        const staleData = CacheManager.getStale<T>(key);
        if (staleData) {
          setData(staleData);
          setIsStale(true);
        }
      }

      setLoading(true);
      const freshData = await fetchFn();
      
      // Guardar en caché
      CacheManager.set(key, freshData, expiresInMinutes);
      
      // Actualizar estado
      setData(freshData);
      setIsStale(false);
      setError(null);
    } catch (err) {
      setError(err as Error);
      console.error('Error fetching data:', err);
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    // Intentar cargar desde caché válido
    const cachedData = CacheManager.get<T>(key);
    if (cachedData) {
      setData(cachedData);
      setIsStale(false);
      return;
    }

    // Si no hay caché válido, fetch con stale
    fetchData(true);
  }, [key]);

  return {
    data,
    isStale,
    loading,
    error,
    refetch: () => fetchData(false)
  };
}

// Para compatibilidad sin React
import React from 'react';
