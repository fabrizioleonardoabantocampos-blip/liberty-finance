# 🚀 INSTRUCCIONES DE INICIALIZACIÓN - LIBERTY FINANCE

## ✅ Ya Conectaste la Nueva Base de Datos

Perfecto! Ahora solo necesitas cargar los datos iniciales.

---

## 📋 OPCIÓN 1: INICIALIZACIÓN AUTOMÁTICA (RECOMENDADA)

### Paso 1: Acceder a la Página de Setup

En tu navegador, ve a:
```
http://localhost:5173/?setup=true
```

O manualmente navega agregando `#setup` en la URL o accediendo directamente a la ruta de setup.

### Paso 2: Hacer Clic en "Inicializar Sistema"

1. Verás una pantalla con el título "Inicializar Sistema"
2. Haz clic en el botón azul **"Inicializar Sistema Completo"**
3. Espera 5-10 segundos mientras se cargan los datos
4. ¡Listo! Verás un resumen con:
   - ✅ 8 Productos cargados
   - ✅ 8 Rangos cargados
   - ✅ Usuario admin configurado

### Paso 3: Iniciar Sesión

Usa estas credenciales de administrador:
```
Email:    admin@libertyfinance.com
Password: admin123
```

---

## 📋 OPCIÓN 2: USANDO LA CONSOLA DEL NAVEGADOR

Si prefieres hacerlo manualmente con JavaScript:

### Paso 1: Abre la Consola del Navegador

- Presiona `F12` en tu navegador
- Ve a la pestaña "Console"

### Paso 2: Copia y Pega este Código

```javascript
// Reemplaza con tu PROJECT_ID de Supabase
const PROJECT_ID = 'tu-nuevo-project-id';
const ANON_KEY = 'tu-nuevo-anon-key';

fetch(`https://${PROJECT_ID}.supabase.co/functions/v1/make-server-9f68532a/init/complete`, {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${ANON_KEY}`
  }
})
.then(res => res.json())
.then(data => {
  console.log('✅ Inicialización completada:', data);
  console.log(`📦 Productos: ${data.resultado.productos}`);
  console.log(`🏆 Rangos: ${data.resultado.rangos}`);
  console.log(`👤 Admin: ${data.resultado.admin ? 'OK' : 'ERROR'}`);
})
.catch(error => {
  console.error('❌ Error:', error);
});
```

### Paso 3: Presiona Enter

Verás en la consola:
```
✅ Inicialización completada: {...}
📦 Productos: 8
🏆 Rangos: 8
👤 Admin: OK
```

---

## 📋 OPCIÓN 3: USANDO CURL (Terminal)

Si tienes acceso a una terminal:

```bash
# Reemplaza con tus credenciales
PROJECT_ID="tu-nuevo-project-id"
ANON_KEY="tu-nuevo-anon-key"

curl -X POST \
  "https://${PROJECT_ID}.supabase.co/functions/v1/make-server-9f68532a/init/complete" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ${ANON_KEY}"
```

---

## 🎯 ¿QUÉ SE CARGA AUTOMÁTICAMENTE?

### ✅ Productos (8 Packs de Inversión)

1. **Pack 50** - $50 USDT
2. **Pack 100** - $100 USDT
3. **Pack 200** - $200 USDT
4. **Pack 300** - $300 USDT
5. **Pack 500** - $500 USDT
6. **Pack 1k** - $1,000 USDT
7. **Pack 5k** - $5,000 USDT
8. **Pack 10k** - $10,000 USDT

Cada pack incluye:
- 100% de rentabilidad
- 1% de rendimiento diario
- Comisiones de red activas

### ✅ Rangos (8 Niveles)

1. **Silver** - 3 directos, $10K volumen
2. **Golden** - 5 directos, $25K volumen
3. **Emprendedora** - 5 directos, $90K volumen
4. **Rubi** - 7 directos, $120K volumen
5. **Platino** - 7 directos, $250K volumen
6. **Diamante** - 8 directos, $500K volumen
7. **Black** - 10 directos, $1M volumen
8. **Crown Black** - 10 directos, $3M volumen

### ✅ Usuario Administrador

```
Email:      admin@libertyfinance.com
Password:   admin123
Rango:      Crown Black
Estado:     Activo
Puntos:     1,000
```

---

## 🔍 VERIFICAR QUE TODO FUNCIONÓ

### Test 1: Health Check

Abre en tu navegador:
```
https://[TU-PROJECT-ID].supabase.co/functions/v1/make-server-9f68532a/health
```

Deberías ver:
```json
{"status":"ok"}
```

### Test 2: Ver Productos

Abre en tu navegador:
```
https://[TU-PROJECT-ID].supabase.co/functions/v1/make-server-9f68532a/productos
```

Deberías ver un array JSON con 8 productos.

### Test 3: Login de Admin

1. Ve a tu aplicación
2. Haz clic en "Iniciar Sesión"
3. Ingresa:
   - Email: `admin@libertyfinance.com`
   - Password: `admin123`
4. Deberías entrar al dashboard de admin

---

## ⚠️ PROBLEMAS COMUNES

### Error: "Failed to fetch"

**Causa:** URL incorrecta o variables de entorno mal configuradas

**Solución:**
1. Verifica que actualizaste `/utils/supabase/info.tsx`
2. Asegúrate de que `projectId` sea correcto
3. Verifica que `publicAnonKey` sea correcto

### Error: "Unauthorized" o 401

**Causa:** API Key incorrecta

**Solución:**
1. Ve a Supabase Dashboard > Settings > API
2. Copia de nuevo el `anon key`
3. Actualiza `/utils/supabase/info.tsx`

### Error: "Products already exist"

**Causa:** Ya inicializaste antes

**Solución:**
- Esto es normal, no es un error
- Los productos no se duplicarán
- Puedes continuar usando el sistema

### No Aparecen los Productos en la App

**Solución:**
1. Refresca la página (F5)
2. Limpia caché (Ctrl+Shift+R)
3. Cierra sesión y vuelve a entrar
4. Verifica que el endpoint `/productos` funcione

---

## 📊 DATOS TÉCNICOS

### Endpoint de Inicialización

```
POST https://[PROJECT-ID].supabase.co/functions/v1/make-server-9f68532a/init/complete
Headers:
  - Content-Type: application/json
  - Authorization: Bearer [ANON_KEY]
```

### Respuesta Exitosa

```json
{
  "success": true,
  "mensaje": "Sistema inicializado correctamente",
  "resultado": {
    "productos": 8,
    "rangos": 8,
    "admin": true,
    "errores": []
  }
}
```

---

## ✅ CHECKLIST FINAL

Después de la inicialización, verifica:

- [ ] Health check responde OK
- [ ] Endpoint /productos devuelve 8 packs
- [ ] Login de admin funciona
- [ ] Dashboard de admin carga correctamente
- [ ] Sección "Productos" muestra los 8 packs
- [ ] Sección "Rangos" muestra los 8 rangos
- [ ] Puedes registrar un nuevo usuario
- [ ] Puedes crear un depósito de prueba

---

## 🎉 ¡TODO LISTO!

Una vez completada la inicialización:

1. ✅ Tu base de datos está lista
2. ✅ Todos los productos cargados
3. ✅ Todos los rangos cargados
4. ✅ Usuario admin creado
5. ✅ Sistema 100% funcional

**Siguiente paso:** Configura tu wallet principal en el panel de admin.

---

## 📞 SOPORTE

Si tienes problemas:

1. **Revisa los logs del servidor:**
   - Dashboard Supabase > Edge Functions > Logs

2. **Revisa la consola del navegador:**
   - F12 > Console
   - Busca errores en rojo

3. **Consulta los archivos de backup:**
   - `BACKUP_DATABASE_STRUCTURE.md`
   - `GUIA_MIGRACION_PASO_A_PASO.md`

---

**Última actualización:** 2025-11-19  
**Versión:** 1.0
