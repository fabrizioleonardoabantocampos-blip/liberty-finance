# PROBLEMA CRÍTICO: Timeout en Endpoint de Matriz

## DIAGNÓSTICO

El endpoint `/users/:userId/matriz` está causando timeouts debido a:

1. **`crm.getAllUsers()`** - Carga TODOS los usuarios del sistema (puede ser 100+)
2. **`crm.getAllPacks()`** - Carga TODOS los packs del sistema  
3. **Construcción de matriz BFS** - Procesa 59,049 posiciones para 10 niveles

Todo esto tarda más de 10-60 segundos, causando el error: `Http: connection closed before message completed`

## SOLUCIÓN RECOMENDADA

El endpoint debe ser reescrito para:

1. **NO cargar todos los usuarios** - Solo el usuario solicitado y sus descendientes
2. **Cargar datos incremental** - Usar BFS para cargar solo los niveles necesarios
3. **Implementar paginación** - Máximo 3 niveles a la vez (39 posiciones)
4. **Usar caché Redis/Memoria** - Almacenar matrices pre-calculadas

## SOLUCIÓN TEMPORAL IMPLEMENTADA

He modificado el endpoint para retornar una matriz vacía temporalmente:

```typescript
// Retorna solo:
// - Datos básicos del usuario
// - Primeros 10 referidos directos
// - Matriz vacía con estructura correcta

Este permite que el frontend cargue sin errores mientras se implementa la solución definitiva.
```

## ARCHIVO A MODIFICAR

`/supabase/functions/server/index.tsx` - Línea 2271-2488 (endpoint `/users/:userId/matriz`)

## PRÓXIMOS PASOS

1. Implementar caché en memoria para matrices pre-calculadas
2. Crear job en background que actualice matrices cada 5 minutos
3. Endpoint solo retorna datos del caché
4. Invalidar caché solo cuando hay cambios (nuevo pack, sync, etc.)
