# 🏆 Sistema de Iconos Personalizados para Rangos

## ✅ IMPLEMENTADO COMPLETAMENTE

He implementado un sistema completo que te permite subir **iconos personalizados** (imágenes) para los rangos de Liberty Finance, además de usar los emojis predefinidos.

---

## 🎯 FUNCIONALIDADES

### 1. **Emojis Predefinidos**
- Puedes seleccionar entre 8 emojis predefinidos: 🥈 🥇 🏅 🎖️ 💎 👑 ⭐ 🔥
- Solo haz clic en el emoji que quieras usar

### 2. **Iconos Personalizados (NUEVO)**
- **Sube tu propia imagen** para usar como icono del rango
- Soporta PNG, JPG, WEBP, y otros formatos
- Máximo 2MB por icono
- **Recomendado:** PNG con fondo transparente (256x256px)

### 3. **Vista Previa en Tiempo Real**
- Ves cómo se verá el icono antes de guardar
- Funciona tanto con emojis como con imágenes

### 4. **Visualización Automática**
- Los iconos personalizados se muestran correctamente en:
  - ✅ Tarjetas de rangos en el panel admin
  - ✅ Vista previa del formulario
  - ✅ Lista de todos los rangos

---

## 📍 CÓMO USAR

### **Paso 1: Acceder a Gestionar Rangos**
1. Inicia sesión como **administrador**
2. Ve a **"Rangos"** en el menú lateral
3. Haz clic en **"Nuevo Rango"** o edita uno existente

### **Paso 2: Seleccionar Icono**

#### **Opción A: Usar Emoji Predefinido**
1. En la sección **"Icono"**, verás 8 emojis disponibles
2. Haz clic en el emoji que quieras usar
3. Se resalta en azul cuando está seleccionado

#### **Opción B: Subir Icono Personalizado (NUEVO)** ⭐
1. En la sección **"Icono"**, ve hasta **"O sube tu propio icono:"**
2. Haz clic en **"Subir Icono Personalizado"**
3. Selecciona tu archivo de imagen (PNG, JPG, etc.)
4. Verás una **vista previa** del icono
5. Si no te gusta, haz clic en **"Eliminar"** y sube otro

### **Paso 3: Completar Formulario**
1. Completa el resto de los campos (nombre, directos, volumen, premio)
2. Selecciona el color y la imagen de fondo
3. Haz clic en **"Guardar"**

### **Paso 4: ¡Listo!**
- El rango se guardará con tu icono personalizado
- Lo verás en la lista de rangos con tu imagen

---

## 🖼️ EJEMPLOS DE USO

### Ejemplo 1: Rango Bronze con emoji 🥈
```
1. Clic en "Nuevo Rango"
2. Nombre: "Bronze"
3. Seleccionar emoji: 🥈
4. Guardar
```

### Ejemplo 2: Rango Diamond con icono personalizado 💎
```
1. Clic en "Nuevo Rango"
2. Nombre: "Diamond"
3. Clic en "Subir Icono Personalizado"
4. Seleccionar archivo: diamond-icon.png
5. Ver vista previa
6. Guardar
```

---

## 📐 ESPECIFICACIONES TÉCNICAS

### Formato de Iconos Personalizados:
- **Tamaño recomendado:** 256x256px (cuadrado)
- **Formato:** PNG con fondo transparente (recomendado)
- **Otros formatos:** JPG, WEBP, GIF
- **Tamaño máximo:** 2MB

### Almacenamiento:
- Los iconos se guardan en **Base64** en la base de datos
- No necesitas hosting externo
- Carga instantánea

### Compatibilidad:
- ✅ Funciona con todos los navegadores modernos
- ✅ Responsive (mobile y desktop)
- ✅ Soporta transparencia (PNG)

---

## 🎨 MEJORES PRÁCTICAS

### Para Iconos Personalizados:

1. **Usa PNG con fondo transparente**
   - Se ve mejor sobre cualquier fondo
   - Recomendado para rangos profesionales

2. **Tamaño cuadrado**
   - 256x256px o 512x512px
   - Evita imágenes rectangulares

3. **Colores simples**
   - Evita demasiado detalle
   - Los iconos se ven pequeños (48x48px en pantalla)

4. **Alto contraste**
   - El icono se muestra sobre la imagen de fondo del rango
   - Asegúrate de que se vea bien con tu color seleccionado

### Para Emojis:

1. **Coherencia visual**
   - Usa emojis relacionados con el nivel del rango
   - Ejemplo: 🥈 Bronze → 🥇 Gold → 💎 Diamond

2. **Progresión lógica**
   - Los emojis deben reflejar el crecimiento del rango

---

## 📊 UBICACIONES DONDE APARECE

```
┌─────────────────────────────────────────┐
│  📍 FORMULARIO DE RANGO                 │
│                                          │
│  [Vista Previa]                          │
│  ┌────────────────────┐                  │
│  │  Imagen de Fondo   │                  │
│  │                    │                  │
│  │    [ICONO] ← Aquí  │                  │
│  └────────────────────┘                  │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│  📍 TARJETA DE RANGO (Lista)            │
│  ┌────────────────────┐                  │
│  │  [ICONO]  [Editar] │  ← Esquina sup. │
│  │                    │                  │
│  │  Gold              │                  │
│  │  👥 5 Directos     │                  │
│  │  💰 $10,000        │                  │
│  └────────────────────┘                  │
└─────────────────────────────────────────┘
```

---

## 🔄 FLUJO COMPLETO

```
1. Admin → "Rangos" → "Nuevo Rango"
   ↓
2. Completar información básica
   ↓
3. Seleccionar icono:
   • Emoji predefinido (🥈 🥇 🏅 etc.)
   • O subir icono personalizado (PNG/JPG)
   ↓
4. Vista previa automática
   ↓
5. "Guardar" → Se guarda en BD
   ↓
6. Icono aparece en todas las vistas
```

---

## 💡 CASOS DE USO

### Caso 1: Sistema con emojis (simple)
```
Bronze → 🥈
Silver → 🥇
Gold → 🏅
Platinum → 💎
Diamond → 👑
```

### Caso 2: Sistema con iconos personalizados (profesional)
```
Bronze → [bronze-medal.png]
Silver → [silver-medal.png]
Gold → [gold-medal.png]
Platinum → [platinum-trophy.png]
Diamond → [diamond-crown.png]
```

### Caso 3: Sistema mixto
```
Starter → 🚀 (emoji)
Pro → [pro-badge.png] (personalizado)
Elite → 💎 (emoji)
Legend → [legend-crown.png] (personalizado)
```

---

## ❓ PREGUNTAS FRECUENTES

### ¿Puedo cambiar un emoji por un icono personalizado después?
✅ Sí, solo edita el rango y sube el nuevo icono.

### ¿El icono se ve pixelado?
Si se ve pixelado, sube una imagen de mayor resolución (512x512px).

### ¿Puedo usar GIFs animados?
Técnicamente sí, pero no es recomendado. Usa PNG estáticos.

### ¿Cuántos iconos puedo subir?
Ilimitados, uno por cada rango que crees.

### ¿Se pueden perder los iconos?
No, se guardan en la base de datos. Son permanentes.

---

## 🛠️ DETALLES TÉCNICOS

### Archivos Modificados:

1. **`/components/admin/GestionarRangos.tsx`**
   - Nueva función: `handleIconUpload()`
   - Sección de subida de iconos personalizados
   - Vista previa de iconos con imágenes
   - Renderizado condicional: emoji vs imagen

### Funciones Clave:

```typescript
// Subir icono personalizado
const handleIconUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
  const file = e.target.files?.[0];
  // Validar tipo y tamaño
  // Convertir a base64
  // Actualizar formData.icon
  toast.success('Icono cargado');
}

// Renderizar icono (emoji o imagen)
{rango.icon.startsWith('data:image') ? (
  <ImageWithFallback src={rango.icon} />
) : (
  <span>{rango.icon}</span>
)}
```

---

## ✨ MEJORAS IMPLEMENTADAS

### Antes:
- ❌ Solo 8 emojis predefinidos
- ❌ No se podían usar imágenes personalizadas
- ❌ Opciones limitadas de personalización

### Ahora:
- ✅ 8 emojis predefinidos
- ✅ **Iconos personalizados ilimitados**
- ✅ Subida de archivos con validación
- ✅ Vista previa en tiempo real
- ✅ Soporte para PNG transparente
- ✅ Fácil de eliminar y cambiar

---

## 🎯 RECOMENDACIONES FINALES

1. **Para empresas serias:** Usa iconos personalizados profesionales
2. **Para startup rápida:** Usa emojis predefinidos
3. **Para branding fuerte:** Diseña iconos que coincidan con tu marca
4. **Para sistema jerárquico:** Usa progresión visual clara (pequeño → grande)

---

## 📞 TROUBLESHOOTING

### Problema: El icono no se guarda
**Solución:** Verifica que el archivo sea menor a 2MB

### Problema: El icono se ve borroso
**Solución:** Sube una imagen de mayor resolución (512x512px)

### Problema: El icono tiene fondo blanco
**Solución:** Usa PNG con transparencia en lugar de JPG

### Problema: No puedo eliminar el icono
**Solución:** Haz clic en "Eliminar" en la vista previa, luego selecciona un emoji

---

**Implementado:** 2025-11-20  
**Versión:** 2.0  
**Estado:** ✅ Funcional y probado  
**Compatibilidad:** Todos los navegadores modernos
