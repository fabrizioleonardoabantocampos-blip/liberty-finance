# 🚀 Guía Rápida - Resolver Timeouts en 3 Pasos

## ❌ Problema que Estás Viendo

```
⚠️ Timeout (30000ms) en intento 1/4
⚠️ Error de red en intento 1/4, reintentando en 2000ms...
⚠️ Timeout (30000ms) en intento 2/4
⚠️ Error de red en intento 2/4, reintentando en 4000ms...
```

## ✅ Solución en 3 Pasos (2 minutos)

### Paso 1: Ve a la Página de Setup 🔧

En tu navegador, navega a la página de configuración:
- Si estás en la página de login, busca un enlace a "Setup" o "Configuración"
- URL directa: agrega `/Setup` a tu URL base

### Paso 2: Haz Click en "⚡ Despertar Servidor Ahora" ⚡

1. En la parte superior verás **"Estado del Servidor"** - probablemente esté en rojo (offline)
2. Baja hasta la sección **"⚡ Despertar Servidor"**
3. Haz click en el botón grande azul que dice **"⚡ Despertar Servidor Ahora"**
4. **ESPERA 30-90 segundos** (esto es normal)
5. Verás un mensaje de éxito: ✅ "Servidor Despierto"

### Paso 3: Ahora Inicia Sesión Normalmente ✅

1. Vuelve a la página de login
2. Ingresa tus credenciales:
   - Email: `admin@libertyfinance.com`
   - Password: `admin123`
3. Click en "Iniciar Sesión"
4. ¡Deberías entrar sin problemas! 🎉

---

## 🤔 ¿Por Qué Pasa Esto?

### Cold Start (Inicio en Frío)

El servidor de Supabase Edge Functions se "duerme" después de 5-10 minutos de inactividad en el plan gratuito.

**Analogía:** Es como una computadora en modo "sleep" - necesita unos segundos para "despertar".

### ¿Es Normal?

**Sí, completamente normal en el plan gratuito de Supabase.** 

- Primera carga del día: 30-90 segundos
- Después de eso: 2-5 segundos

---

## 🛠️ Herramientas Disponibles en Setup

### 1. ⚡ Despertar Servidor
**Para qué sirve:** "Despierta" el servidor si está dormido  
**Cuándo usarlo:** Primera vez del día, o después de inactividad  
**Tiempo:** 30-90 segundos

### 2. 🔍 Diagnóstico de Conectividad
**Para qué sirve:** Verifica si el servidor está funcionando correctamente  
**Cuándo usarlo:** Si despertar el servidor no funciona  
**Tests:** 3 pruebas automáticas con resultados visuales

### 3. 🔑 Crear/Verificar Admin
**Para qué sirve:** Crea o verifica que el usuario admin existe  
**Cuándo usarlo:** Si aparece "Usuario no encontrado"  
**Tiempo:** 2-3 segundos

### 4. 🔐 Resetear Contraseña Admin
**Para qué sirve:** Resetea la contraseña del admin a `admin123`  
**Cuándo usarlo:** Si aparece "Contraseña incorrecta"  
**Tiempo:** 2-3 segundos

### 5. 🧪 Probar Login
**Para qué sirve:** Prueba las credenciales sin salir de Setup  
**Cuándo usarlo:** Para verificar que el login funciona antes de ir a la página principal  
**Tiempo:** 3-5 segundos

---

## 📋 Flujo de Trabajo Recomendado

### Al Iniciar Sesión por Primera Vez del Día

```
1. Abrir Setup
2. Click "Despertar Servidor"
3. Esperar 60 segundos ☕
4. Ir a Login
5. Iniciar sesión normalmente
```

### Si Tienes Problemas

```
1. Abrir Setup
2. Mirar indicador de estado (arriba)
3. Si está rojo:
   → Click "Despertar Servidor"
   → Esperar 60 segundos
4. Si está verde pero sigue sin funcionar:
   → Ejecutar "Diagnóstico de Conectividad"
   → Seguir recomendaciones mostradas
```

---

## ⚡ Trucos para Evitar Timeouts

### Truco 1: Despertar el Servidor Antes de Usar
Haz click en "Despertar Servidor" mientras preparas tu café ☕

### Truco 2: Mantén una Pestaña Abierta
Si estás trabajando activamente, mantén la app abierta en una pestaña

### Truco 3: UptimeRobot (Avanzado)
Configura un servicio gratis que haga ping cada 5 minutos:
1. Ve a uptimerobot.com
2. Crea una cuenta gratis
3. Agrega tu URL: `https://TU_PROJECT.supabase.co/functions/v1/make-server-9f68532a/ping`
4. Configura intervalo: 5 minutos
5. ¡El servidor nunca se dormirá! 🎉

---

## 🆘 Si Nada Funciona

### Paso 1: Verificar Credenciales
Abre `/utils/supabase/info.tsx` y verifica:
- ✅ `projectId` está correcto (sin https://)
- ✅ `publicAnonKey` está correcto (clave completa)

### Paso 2: Revisar Dashboard de Supabase
1. Ve a supabase.com
2. Abre tu proyecto
3. Ve a "Edge Functions"
4. Verifica que "server" esté desplegado

### Paso 3: Revisar Logs
En Supabase Dashboard:
1. Edge Functions → server → Logs
2. Busca errores recientes
3. Copia el mensaje de error

### Paso 4: Status de Supabase
Visita: https://status.supabase.com
- ✅ Todo verde: No hay problemas de infraestructura
- ⚠️ Algo amarillo/rojo: Espera a que Supabase resuelva

---

## 💡 Preguntas Frecuentes

### ¿Por qué tarda tanto la primera vez?
**R:** El servidor está en "cold start" (dormido). Es normal en el plan gratuito.

### ¿Se va a dormir siempre?
**R:** Sí, después de 5-10 minutos de inactividad. Puedes usar UptimeRobot para evitarlo.

### ¿Puedo hacer que no se duerma?
**R:** Sí, de 3 formas:
1. Upgrade a Supabase Pro ($25/mes) - sin cold starts
2. Usar UptimeRobot (gratis) - hace ping cada 5 min
3. Dejar una pestaña abierta (mientras trabajas)

### ¿Es un bug?
**R:** No, es comportamiento normal del plan gratuito de Supabase.

### ¿Afectará a mis usuarios?
**R:** Solo al primer usuario del día (30-90s). Los siguientes entran en 2-5s.

### ¿Debería preocuparme?
**R:** No para desarrollo/testing. Para producción, considera upgrade o keep-alive.

---

## 📊 Tiempos Esperados

| Situación | Tiempo Esperado | Normal? |
|-----------|----------------|---------|
| Cold start (primera vez) | 30-90 segundos | ✅ Sí |
| Servidor ya despierto | 2-5 segundos | ✅ Sí |
| Después de despertar | 1-3 segundos | ✅ Sí |
| >2 minutos | Verificar credenciales | ❌ No |

---

## ✅ Checklist de Verificación

Antes de reportar un problema, verifica:

- [ ] Esperaste al menos 60 segundos en el primer intento
- [ ] Usaste el botón "Despertar Servidor"
- [ ] El indicador de estado muestra "verde"
- [ ] Las credenciales en `/utils/supabase/info.tsx` son correctas
- [ ] El proyecto en Supabase está activo
- [ ] No hay incidencias en status.supabase.com

---

## 🎯 Resumen Ultra-Rápido

```
PROBLEMA: Timeouts al iniciar sesión
CAUSA: Cold start de Supabase (servidor dormido)
SOLUCIÓN: Despertar servidor en /Setup
TIEMPO: 60 segundos primera vez, luego 2-5s
COSTO: $0 (normal en plan gratuito)
```

---

**¿Necesitas más ayuda?**
- 📖 Lee `/SOLUCION_TIMEOUTS.md` para detalles técnicos
- 🔍 Usa "Diagnóstico de Conectividad" en Setup
- 📊 Revisa el indicador de estado en tiempo real

**¡Listo para empezar!** 🚀  
Ve a Setup → Despertar Servidor → ¡A trabajar!

---

**Última actualización:** 31 de diciembre de 2025  
**Versión:** 1.0 - Guía de Usuario
