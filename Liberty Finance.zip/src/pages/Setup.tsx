import { InicializarSistema } from '../components/admin/InicializarSistema';
import { CrearAdmin } from '../components/debug/CrearAdmin';
import { ResetAdminPassword } from '../components/debug/ResetAdminPassword';
import { TestLogin } from '../components/debug/TestLogin';
import { DiagnosticoConectividad } from '../components/debug/DiagnosticoConectividad';
import { ServerStatus } from '../components/debug/ServerStatus';
import { DespertarServidor } from '../components/debug/DespertarServidor';
import { VerificarCredenciales } from '../components/debug/VerificarCredenciales';
import { ServidorNoDeplegado } from '../components/debug/ServidorNoDeplegado';
import { DiagnosticoFinal } from '../components/debug/DiagnosticoFinal';
import { ArrowLeft } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';

interface SetupProps {
  onNavigate?: (page: string) => void;
}

export function Setup({ onNavigate }: SetupProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        {/* Header con botón de regreso */}
        <div className="mb-6">
          <Button
            variant="ghost"
            onClick={() => onNavigate?.('login')}
            className="mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Volver al Login
          </Button>
          
          <div className="text-center mb-8">
            <h1 className="text-4xl text-slate-800 mb-2">
              Liberty Finance
            </h1>
            <p className="text-slate-600">
              Configuración Inicial del Sistema
            </p>
          </div>

          {/* Estado del servidor */}
          <div className="mb-6">
            <ServerStatus showDetails={true} />
          </div>
        </div>

        {/* Componente de inicialización */}
        <InicializarSistema 
          onComplete={() => {
            // Redirigir al login después de completar
            setTimeout(() => {
              onNavigate?.('login');
            }, 2000);
          }}
        />

        {/* 🚨🚨🚨 DIAGNÓSTICO PRINCIPAL - LO MÁS IMPORTANTE */}
        <div className="mt-8 mb-8">
          <Card className="p-6 border-4 border-red-500 bg-gradient-to-br from-red-50 to-orange-50 shadow-2xl">
            <div className="mb-4">
              <h2 className="text-2xl text-red-900 mb-2">
                🚨 DIAGNÓSTICO DE ERRORES DE TIMEOUT
              </h2>
              <p className="text-sm text-red-800">
                Si ves errores de timeout constantemente, ejecuta este diagnóstico para identificar el problema exacto.
              </p>
            </div>
            <DiagnosticoFinal />
          </Card>
        </div>

        {/* 🚨 ALERTA: Servidor no desplegado (Instrucciones) */}
        <div className="mt-8 mb-8">
          <details className="bg-white rounded-xl border-2 border-orange-300 overflow-hidden">
            <summary className="p-4 cursor-pointer hover:bg-orange-50 transition-colors">
              <span className="text-lg text-orange-900">
                📖 Ver Instrucciones Detalladas de Despliegue
              </span>
            </summary>
            <div className="p-6 border-t border-orange-200">
              <ServidorNoDeplegado />
            </div>
          </details>
        </div>

        {/* Herramientas de Debug */}
        <div className="mt-8 space-y-4">
          <h2 className="text-2xl text-slate-800 mb-4">Herramientas Adicionales</h2>
          
          {/* CRÍTICO: Verificar credenciales primero */}
          <Card className="p-6 border-2 border-red-300 bg-red-50/30">
            <h3 className="text-lg mb-4 text-slate-800">🔴 1. Verificar Credenciales (IMPORTANTE)</h3>
            <VerificarCredenciales />
          </Card>

          <Card className="p-6">
            <h3 className="text-lg mb-4 text-slate-800">⚡ 2. Despertar Servidor</h3>
            <DespertarServidor />
          </Card>

          <Card className="p-6">
            <h3 className="text-lg mb-4 text-slate-800">🔍 3. Diagnóstico de Conectividad</h3>
            <DiagnosticoConectividad />
          </Card>

          <Card className="p-6">
            <h3 className="text-lg mb-4 text-slate-800">4. Crear/Verificar Admin</h3>
            <CrearAdmin />
          </Card>

          <Card className="p-6">
            <h3 className="text-lg mb-4 text-slate-800">5. Resetear Contraseña Admin</h3>
            <ResetAdminPassword />
          </Card>

          <Card className="p-6">
            <h3 className="text-lg mb-4 text-slate-800">6. Probar Login</h3>
            <TestLogin />
          </Card>
        </div>
      </div>
    </div>
  );
}