import { useState } from 'react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Card } from '../components/ui/card';
import { callServer } from '../utils/api';

interface DebugLoginProps {
  onNavigate?: (page: string) => void;
}

export function DebugLogin({ onNavigate }: DebugLoginProps) {
  const [email, setEmail] = useState('admin@libertyfinance.com');
  const [password, setPassword] = useState('admin123');
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const testLogin = async () => {
    setLoading(true);
    setResult(null);
    
    try {
      const response = await callServer('/auth/login', 'POST', { email, password });
      setResult({
        success: true,
        data: response
      });
    } catch (error: any) {
      setResult({
        success: false,
        error: error.message
      });
    } finally {
      setLoading(false);
    }
  };

  const testDirectFetch = async () => {
    setLoading(true);
    setResult(null);
    
    try {
      // Importar las credenciales directamente
      const { projectId, publicAnonKey } = await import('../utils/supabase/info');
      
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-9f68532a/auth/login`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`
          },
          body: JSON.stringify({ email, password })
        }
      );
      
      const data = await response.json();
      
      setResult({
        success: response.ok,
        status: response.status,
        data
      });
    } catch (error: any) {
      setResult({
        success: false,
        error: error.message
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-8">
      <div className="max-w-4xl mx-auto space-y-6">
        <Card className="p-6">
          <h1 className="text-2xl text-slate-800 mb-6">🔧 Debug Login</h1>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm text-slate-600 mb-2">Email</label>
              <Input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Email"
              />
            </div>
            
            <div>
              <label className="block text-sm text-slate-600 mb-2">Password</label>
              <Input
                type="text"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Password"
              />
            </div>
            
            <div className="flex gap-4">
              <Button
                onClick={testLogin}
                disabled={loading}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {loading ? 'Probando...' : 'Probar con callServer'}
              </Button>
              
              <Button
                onClick={testDirectFetch}
                disabled={loading}
                className="bg-slate-600 hover:bg-slate-700"
              >
                {loading ? 'Probando...' : 'Probar con fetch directo'}
              </Button>
            </div>
          </div>
        </Card>
        
        {result && (
          <Card className="p-6">
            <h2 className="text-xl text-slate-800 mb-4">Resultado:</h2>
            
            <div className={`p-4 rounded-lg ${result.success ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'}`}>
              <p className="text-sm mb-2">
                <strong>Estado:</strong> {result.success ? '✅ Éxito' : '❌ Error'}
              </p>
              
              {result.status && (
                <p className="text-sm mb-2">
                  <strong>Status Code:</strong> {result.status}
                </p>
              )}
              
              {result.error && (
                <p className="text-sm mb-2 text-red-700">
                  <strong>Error:</strong> {result.error}
                </p>
              )}
            </div>
            
            <div className="mt-4">
              <p className="text-sm text-slate-600 mb-2"><strong>Datos completos:</strong></p>
              <pre className="bg-slate-900 text-green-400 p-4 rounded-lg overflow-auto text-xs">
                {JSON.stringify(result, null, 2)}
              </pre>
            </div>
          </Card>
        )}
        
        <Card className="p-6 bg-blue-50 border-blue-200">
          <h3 className="text-lg text-slate-800 mb-2">💡 Instrucciones</h3>
          <ul className="list-disc list-inside text-sm text-slate-600 space-y-1">
            <li>Ingresa el email y contraseña que quieres probar</li>
            <li>Haz clic en "Probar con callServer" para probar usando la función helper</li>
            <li>Haz clic en "Probar con fetch directo" para probar directamente el endpoint</li>
            <li>Revisa los logs del servidor en la consola de Supabase para ver detalles de la comparación de contraseñas</li>
          </ul>
        </Card>
      </div>
    </div>
  );
}