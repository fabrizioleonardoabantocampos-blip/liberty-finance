import { useState, useEffect } from 'react';
import { callServer } from '../utils/api';
import { ChevronLeft, AlertCircle, CheckCircle, XCircle, RefreshCw } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';
import { toast } from 'sonner@2.0.3';

interface DiagnosticoComisionesProps {
  onNavigate: (page: string) => void;
}

export default function DiagnosticoComisiones({ onNavigate }: DiagnosticoComisionesProps) {
  const [loading, setLoading] = useState(false);
  const [diagnostico, setDiagnostico] = useState<any>(null);
  const [userId, setUserId] = useState('');
  const [autoLoaded, setAutoLoaded] = useState(false);

  // Auto-cargar al montar si hay un usuario logueado
  useEffect(() => {
    if (!autoLoaded) {
      const userStr = localStorage.getItem('currentUser');
      if (userStr) {
        const user = JSON.parse(userStr);
        setUserId(user.id);
        ejecutarDiagnostico(user.id);
        setAutoLoaded(true);
      }
    }
  }, [autoLoaded]);

  const ejecutarDiagnostico = async (userIdToUse?: string) => {
    const idToUse = userIdToUse || userId;
    
    if (!idToUse) {
      toast.error('Por favor ingresa un User ID');
      return;
    }

    setLoading(true);
    try {
      console.log('🔍 Ejecutando diagnóstico para:', idToUse);
      
      // Llamar a los 4 endpoints de debug
      const [comisionesRes, referidosRes, buscarUsuarioRes, referidosDirectosRes] = await Promise.all([
        callServer(`/debug/comisiones/${idToUse}`, 'GET'),
        callServer(`/debug/referidos/${idToUse}`, 'GET'),
        callServer(`/debug/buscar-usuario/${idToUse}`, 'GET'),
        callServer(`/debug/referidos-directos/${idToUse}`, 'GET')
      ]);

      setDiagnostico({
        userId: idToUse,
        comisiones: comisionesRes,
        referidos: referidosRes,
        usuario: buscarUsuarioRes,
        referidosDirectos: referidosDirectosRes
      });

      console.log('✅ Diagnóstico completo:', {
        comisiones: comisionesRes,
        referidos: referidosRes,
        usuario: buscarUsuarioRes,
        referidosDirectos: referidosDirectosRes
      });

      toast.success('Diagnóstico completado');
    } catch (error) {
      console.error('Error al ejecutar diagnóstico:', error);
      toast.error('Error al ejecutar diagnóstico');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-4">
      <div className="max-w-6xl mx-auto py-8">
        <Button
          variant="ghost"
          onClick={() => onNavigate('landing')}
          className="mb-6"
        >
          <ChevronLeft className="w-4 h-4 mr-2" />
          Volver
        </Button>

        <div className="mb-8">
          <h1 className="text-3xl text-slate-900 mb-2">🔍 Diagnóstico de Comisiones</h1>
          <p className="text-slate-600">
            Herramienta de diagnóstico para verificar comisiones y referidos
          </p>
        </div>

        {/* Input para User ID */}
        <Card className="p-6 mb-6">
          <div className="flex gap-4">
            <input
              type="text"
              value={userId}
              onChange={(e) => setUserId(e.target.value)}
              placeholder="User ID (ej: LF1234567890)"
              className="flex-1 px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
            />
            <Button
              onClick={() => ejecutarDiagnostico()}
              disabled={loading || !userId}
            >
              {loading ? (
                <>
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  Ejecutando...
                </>
              ) : (
                <>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Ejecutar Diagnóstico
                </>
              )}
            </Button>
          </div>
        </Card>

        {/* Resultados del diagnóstico */}
        {diagnostico && (
          <div className="space-y-6">
            {/* Información del Usuario */}
            <Card className="p-6">
              <h2 className="text-xl text-slate-900 mb-4 flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-green-600" />
                Información del Usuario
              </h2>
              <div className="bg-slate-50 p-4 rounded-lg">
                <pre className="text-sm text-slate-700 overflow-x-auto">
                  {JSON.stringify(diagnostico.usuario, null, 2)}
                </pre>
              </div>
            </Card>

            {/* Diagnóstico de Comisiones */}
            <Card className="p-6">
              <h2 className="text-xl text-slate-900 mb-4 flex items-center gap-2">
                {diagnostico.comisiones?.totalPorIndiceUsuario > 0 ? (
                  <CheckCircle className="w-5 h-5 text-green-600" />
                ) : (
                  <XCircle className="w-5 h-5 text-red-600" />
                )}
                Comisiones
              </h2>
              
              <div className="space-y-4">
                {/* Resumen */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <p className="text-sm text-slate-600 mb-1">Índice Usuario</p>
                    <p className="text-2xl text-primary">
                      {diagnostico.comisiones?.totalPorIndiceUsuario || 0}
                    </p>
                  </div>
                  <div className="bg-green-50 p-4 rounded-lg">
                    <p className="text-sm text-slate-600 mb-1">Índice Global</p>
                    <p className="text-2xl text-green-600">
                      {diagnostico.comisiones?.totalPorIndiceGlobal || 0}
                    </p>
                  </div>
                  <div className="bg-purple-50 p-4 rounded-lg">
                    <p className="text-sm text-slate-600 mb-1">Total</p>
                    <p className="text-2xl text-purple-600">
                      {Math.max(
                        diagnostico.comisiones?.totalPorIndiceUsuario || 0,
                        diagnostico.comisiones?.totalPorIndiceGlobal || 0
                      )}
                    </p>
                  </div>
                </div>

                {/* Alertas de índice corrupto */}
                {diagnostico.comisiones?.totalPorIndiceUsuario === 0 && 
                 diagnostico.comisiones?.totalPorIndiceGlobal > 0 && (
                  <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                    <h3 className="text-sm text-red-900 mb-2 flex items-center gap-2">
                      <AlertCircle className="w-4 h-4" />
                      ⚠️ ÍNDICE CORRUPTO DETECTADO
                    </h3>
                    <p className="text-sm text-red-700 mb-2">
                      Tienes {diagnostico.comisiones.totalPorIndiceGlobal} comisiones en el índice global 
                      pero 0 en el índice de usuario. Esto causa que el dashboard muestre $0.00.
                    </p>
                    <p className="text-sm text-red-700">
                      <strong>Solución:</strong> Necesitas ejecutar un script de reparación de índices.
                    </p>
                  </div>
                )}

                {/* Por Tipo */}
                {diagnostico.comisiones?.porTipo && (
                  <div>
                    <h3 className="text-sm text-slate-600 mb-2">Comisiones por Tipo (desde índice usuario)</h3>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      <div className="bg-slate-50 p-3 rounded-lg">
                        <p className="text-xs text-slate-600">Rendimiento</p>
                        <p className="text-lg text-slate-900">
                          ${diagnostico.comisiones.porTipo.rendimiento?.toFixed(2) || '0.00'}
                        </p>
                      </div>
                      <div className="bg-slate-50 p-3 rounded-lg">
                        <p className="text-xs text-slate-600">Red/Matriz</p>
                        <p className="text-lg text-slate-900">
                          ${diagnostico.comisiones.porTipo.red?.toFixed(2) || '0.00'}
                        </p>
                      </div>
                      <div className="bg-slate-50 p-3 rounded-lg">
                        <p className="text-xs text-slate-600">Patrocinio</p>
                        <p className="text-lg text-slate-900">
                          ${diagnostico.comisiones.porTipo.patrocinio?.toFixed(2) || '0.00'}
                        </p>
                      </div>
                      <div className="bg-slate-50 p-3 rounded-lg">
                        <p className="text-xs text-slate-600">Rangos</p>
                        <p className="text-lg text-slate-900">
                          ${diagnostico.comisiones.porTipo.rangos?.toFixed(2) || '0.00'}
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {/* Ejemplos de comisiones del índice usuario */}
                {diagnostico.comisiones?.ejemplos && diagnostico.comisiones.ejemplos.length > 0 && (
                  <div>
                    <h3 className="text-sm text-slate-600 mb-2">Ejemplos de Comisiones (índice usuario - primeras 5)</h3>
                    <div className="bg-slate-50 p-4 rounded-lg overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="text-left border-b border-slate-300">
                            <th className="pb-2">Fecha</th>
                            <th className="pb-2">Tipo</th>
                            <th className="pb-2">Monto</th>
                            <th className="pb-2">Descripción</th>
                          </tr>
                        </thead>
                        <tbody>
                          {diagnostico.comisiones.ejemplos.map((comision: any, idx: number) => (
                            <tr key={idx} className="border-b border-slate-200">
                              <td className="py-2">{new Date(comision.fecha).toLocaleDateString()}</td>
                              <td className="py-2">{comision.tipo}</td>
                              <td className="py-2">${comision.monto.toFixed(2)}</td>
                              <td className="py-2 text-xs">{comision.descripcion}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {/* Ejemplos del índice global si es diferente */}
                {diagnostico.comisiones?.porIndiceGlobal && 
                 diagnostico.comisiones.porIndiceGlobal.length > 0 &&
                 diagnostico.comisiones.totalPorIndiceUsuario !== diagnostico.comisiones.totalPorIndiceGlobal && (
                  <div>
                    <h3 className="text-sm text-slate-600 mb-2">
                      Ejemplos de Comisiones (índice global - primeras 10)
                    </h3>
                    <div className="bg-yellow-50 p-4 rounded-lg overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="text-left border-b border-yellow-300">
                            <th className="pb-2">Fecha</th>
                            <th className="pb-2">Tipo</th>
                            <th className="pb-2">Monto</th>
                            <th className="pb-2">Descripción</th>
                          </tr>
                        </thead>
                        <tbody>
                          {diagnostico.comisiones.porIndiceGlobal.slice(0, 10).map((comision: any, idx: number) => (
                            <tr key={idx} className="border-b border-yellow-200">
                              <td className="py-2">{new Date(comision.fecha).toLocaleDateString()}</td>
                              <td className="py-2">{comision.tipo}</td>
                              <td className="py-2">${comision.monto.toFixed(2)}</td>
                              <td className="py-2 text-xs">{comision.descripcion}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {/* Packs del usuario */}
                {diagnostico.comisiones?.packs && diagnostico.comisiones.packs.total > 0 && (
                  <div>
                    <h3 className="text-sm text-slate-600 mb-2">
                      Packs del Usuario ({diagnostico.comisiones.packs.activos} activos de {diagnostico.comisiones.packs.total} total)
                    </h3>
                    <div className="bg-slate-50 p-4 rounded-lg space-y-2">
                      {diagnostico.comisiones.packs.lista.map((pack: any, idx: number) => (
                        <div key={idx} className={`p-2 rounded ${pack.activo ? 'bg-green-50 border border-green-200' : 'bg-white border border-slate-200'}`}>
                          <div className="flex justify-between items-center">
                            <div>
                              <span className="text-slate-900">{pack.nombre}</span>
                              <span className="text-slate-600 ml-2">${pack.monto}</span>
                            </div>
                            <div className="text-right text-xs">
                              {pack.activo ? (
                                <span className="px-2 py-1 bg-green-100 text-green-700 rounded">Activo</span>
                              ) : (
                                <span className="px-2 py-1 bg-slate-100 text-slate-600 rounded">Inactivo</span>
                              )}
                              <div className="text-slate-500 mt-1">{new Date(pack.fechaCompra).toLocaleDateString()}</div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Debug completo */}
                <details className="bg-slate-50 p-4 rounded-lg">
                  <summary className="cursor-pointer text-sm text-slate-600">
                    Ver JSON completo
                  </summary>
                  <pre className="text-xs text-slate-700 mt-2 overflow-x-auto">
                    {JSON.stringify(diagnostico.comisiones, null, 2)}
                  </pre>
                </details>
              </div>
            </Card>

            {/* 🆕 Diagnóstico DETALLADO de Referidos Directos */}
            {diagnostico.referidosDirectos && (
              <Card className="p-6 border-2 border-blue-500">
                <h2 className="text-xl text-slate-900 mb-4 flex items-center gap-2">
                  {diagnostico.referidosDirectos.directosConPack > 0 ? (
                    <CheckCircle className="w-5 h-5 text-green-600" />
                  ) : (
                    <AlertCircle className="w-5 h-5 text-yellow-600" />
                  )}
                  Análisis Detallado de Referidos Directos
                </h2>
                
                <div className="space-y-4">
                  {/* Resumen principal */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-blue-50 p-4 rounded-lg border-2 border-blue-300">
                      <p className="text-sm text-slate-600 mb-1">Total Referidos Directos</p>
                      <p className="text-3xl text-blue-600 font-bold">
                        {diagnostico.referidosDirectos.totalReferidosDirectos}
                      </p>
                    </div>
                    <div className={`p-4 rounded-lg border-2 ${
                      diagnostico.referidosDirectos.directosConPack > 0 
                        ? 'bg-green-50 border-green-300' 
                        : 'bg-red-50 border-red-300'
                    }`}>
                      <p className="text-sm text-slate-600 mb-1">Con Pack Activo</p>
                      <p className={`text-3xl font-bold ${
                        diagnostico.referidosDirectos.directosConPack > 0 
                          ? 'text-green-600' 
                          : 'text-red-600'
                      }`}>
                        {diagnostico.referidosDirectos.directosConPack}
                      </p>
                    </div>
                  </div>

                  {/* Resumen de nombres */}
                  {diagnostico.referidosDirectos.resumen && (
                    <div className="space-y-2">
                      {diagnostico.referidosDirectos.resumen.conPack.length > 0 && (
                        <div className="bg-green-50 p-3 rounded-lg border border-green-200">
                          <p className="text-sm font-bold text-green-700 mb-1">✅ Con Pack Activo:</p>
                          <p className="text-sm text-slate-700">
                            {diagnostico.referidosDirectos.resumen.conPack.join(', ')}
                          </p>
                        </div>
                      )}
                      {diagnostico.referidosDirectos.resumen.sinPack.length > 0 && (
                        <div className="bg-yellow-50 p-3 rounded-lg border border-yellow-200">
                          <p className="text-sm font-bold text-yellow-700 mb-1">⏳ Sin Pack:</p>
                          <p className="text-sm text-slate-700">
                            {diagnostico.referidosDirectos.resumen.sinPack.join(', ')}
                          </p>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Detalle completo de cada referido */}
                  {diagnostico.referidosDirectos.referidos && diagnostico.referidosDirectos.referidos.length > 0 && (
                    <div>
                      <h3 className="text-sm text-slate-600 mb-2 font-bold">Detalle Completo por Referido:</h3>
                      <div className="space-y-3">
                        {diagnostico.referidosDirectos.referidos.map((ref: any, idx: number) => (
                          <div 
                            key={idx} 
                            className={`p-4 rounded-lg border-2 ${
                              ref.tienePackActivo 
                                ? 'bg-green-50 border-green-300' 
                                : 'bg-slate-50 border-slate-300'
                            }`}
                          >
                            <div className="flex justify-between items-start mb-2">
                              <div>
                                <p className="text-lg text-slate-900 font-bold">
                                  {ref.nombre} {ref.apellido}
                                </p>
                                <p className="text-xs text-slate-600">ID: {ref.id_unico}</p>
                              </div>
                              <div className={`px-3 py-1 rounded-full text-xs font-bold ${
                                ref.tienePackActivo 
                                  ? 'bg-green-600 text-white' 
                                  : 'bg-slate-400 text-white'
                              }`}>
                                {ref.tienePackActivo ? '✅ CON PACK' : '❌ SIN PACK'}
                              </div>
                            </div>
                            
                            {/* Info del pack activo */}
                            {ref.packActivo && (
                              <div className="bg-white p-3 rounded border border-green-300 mb-2">
                                <p className="text-sm text-slate-600">Pack Activo:</p>
                                <p className="text-lg text-green-600 font-bold">
                                  {ref.packActivo.nombre} - ${ref.packActivo.monto}
                                </p>
                              </div>
                            )}

                            {/* Historial de packs */}
                            {ref.packs && ref.packs.length > 0 && (
                              <div>
                                <p className="text-xs text-slate-600 mb-1">
                                  Historial de Packs ({ref.totalPacks}):
                                </p>
                                <div className="space-y-1">
                                  {ref.packs.map((pack: any, packIdx: number) => (
                                    <div 
                                      key={packIdx} 
                                      className={`text-xs p-2 rounded ${
                                        pack.activo 
                                          ? 'bg-green-100 text-green-800' 
                                          : 'bg-slate-100 text-slate-600'
                                      }`}
                                    >
                                      <span className="font-bold">{pack.nombre}</span> - ${pack.monto} 
                                      <span className="ml-2">
                                        ({pack.activo ? 'ACTIVO' : 'Inactivo'})
                                      </span>
                                      <span className="ml-2 text-xs">
                                        {new Date(pack.fechaCompra).toLocaleDateString()}
                                      </span>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* JSON completo para debugging */}
                  <details className="bg-slate-50 p-4 rounded-lg">
                    <summary className="cursor-pointer text-sm text-slate-600">
                      Ver JSON completo (debug)
                    </summary>
                    <pre className="text-xs text-slate-700 mt-2 overflow-x-auto">
                      {JSON.stringify(diagnostico.referidosDirectos, null, 2)}
                    </pre>
                  </details>
                </div>
              </Card>
            )}

            {/* Diagnóstico de Referidos */}
            <Card className="p-6">
              <h2 className="text-xl text-slate-900 mb-4 flex items-center gap-2">
                {diagnostico.referidos?.referidosDirectos?.total > 0 ? (
                  <CheckCircle className="w-5 h-5 text-green-600" />
                ) : (
                  <XCircle className="w-5 h-5 text-red-600" />
                )}
                Referidos Directos
              </h2>
              
              <div className="space-y-4">
                {/* Resumen */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <p className="text-sm text-slate-600 mb-1">Total Referidos</p>
                    <p className="text-2xl text-primary">
                      {diagnostico.referidos?.referidosDirectos?.total || 0}
                    </p>
                  </div>
                  <div className="bg-green-50 p-4 rounded-lg">
                    <p className="text-sm text-slate-600 mb-1">Con Pack Activo</p>
                    <p className="text-2xl text-green-600">
                      {diagnostico.referidos?.referidosDirectos?.conPackActivo || 0}
                    </p>
                  </div>
                  <div className="bg-slate-50 p-4 rounded-lg">
                    <p className="text-sm text-slate-600 mb-1">Sin Pack</p>
                    <p className="text-2xl text-slate-600">
                      {(diagnostico.referidos?.referidosDirectos?.total || 0) - (diagnostico.referidos?.referidosDirectos?.conPackActivo || 0)}
                    </p>
                  </div>
                </div>

                {/* Lista de referidos */}
                {diagnostico.referidos?.referidosDirectos?.lista && diagnostico.referidos.referidosDirectos.lista.length > 0 && (
                  <div>
                    <h3 className="text-sm text-slate-600 mb-2">Lista de Referidos</h3>
                    <div className="bg-slate-50 p-4 rounded-lg space-y-2">
                      {diagnostico.referidos.referidosDirectos.lista.map((ref: any, idx: number) => (
                        <div key={idx} className="bg-white p-3 rounded border border-slate-200">
                          <div className="flex justify-between items-start">
                            <div>
                              <p className="text-slate-900">{ref.nombre} {ref.apellido}</p>
                              <p className="text-xs text-slate-500">{ref.email}</p>
                              <p className="text-xs text-slate-500">ID: {ref.id_unico}</p>
                              {ref.inversionTotal > 0 && (
                                <p className="text-xs text-slate-500 mt-1">Inversión Total: ${ref.inversionTotal}</p>
                              )}
                            </div>
                            <div className="text-right">
                              {ref.packActivo ? (
                                <div>
                                  <span className="inline-block px-2 py-1 bg-green-100 text-green-700 text-xs rounded">
                                    {ref.packActivo.nombre}
                                  </span>
                                  <p className="text-xs text-slate-500 mt-1">${ref.packActivo.monto}</p>
                                </div>
                              ) : (
                                <span className="inline-block px-2 py-1 bg-slate-100 text-slate-600 text-xs rounded">
                                  Sin Pack
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Debug completo */}
                <details className="bg-slate-50 p-4 rounded-lg">
                  <summary className="cursor-pointer text-sm text-slate-600">
                    Ver JSON completo
                  </summary>
                  <pre className="text-xs text-slate-700 mt-2 overflow-x-auto">
                    {JSON.stringify(diagnostico.referidos, null, 2)}
                  </pre>
                </details>
              </div>
            </Card>
          </div>
        )}

        {!diagnostico && !loading && (
          <Card className="p-12 text-center">
            <AlertCircle className="w-12 h-12 text-slate-400 mx-auto mb-4" />
            <p className="text-slate-600">
              Ingresa un User ID y presiona "Ejecutar Diagnóstico" para comenzar
            </p>
          </Card>
        )}
      </div>
    </div>
  );
}