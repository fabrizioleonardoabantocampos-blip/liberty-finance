import { projectId, publicAnonKey } from '../utils/supabase/info';

export default function MigracionPage({ onNavigate }: { onNavigate?: (view: string) => void }) {
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState(1);
  
  // Datos de la base ANTERIOR
  const [anteriorProjectId, setAnteriorProjectId] = useState('');
  const [anteriorAnonKey, setAnteriorAnonKey] = useState('');
  
  // Datos exportados
  const [exportData, setExportData] = useState<any>(null);
  const [importResult, setImportResult] = useState<any>(null);

  // PASO 1: Exportar datos de la BASE ANTERIOR
  const exportarDatos = async () => {
    if (!anteriorProjectId || !anteriorAnonKey) {
      toast.error('Por favor completa todos los campos');
      return;
    }

    setLoading(true);
    setExportData(null);

    try {
      console.log('📦 Exportando datos de la base anterior...');
      
      const response = await fetch(
        `https://${anteriorProjectId}.supabase.co/functions/v1/make-server-9f68532a/backup/export`,
        {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${anteriorAnonKey}`
          }
        }
      );

      if (!response.ok) {
        throw new Error(`Error HTTP: ${response.status} - ${await response.text()}`);
      }

      const data = await response.json();
      console.log('✅ Datos exportados:', data);
      
      if (data.success) {
        setExportData(data);
        
        // Descargar automáticamente como archivo JSON
        const blob = new Blob([JSON.stringify(data.backup, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `liberty-backup-${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        toast.success('¡Datos exportados correctamente!', {
          description: `${data.resumen.usuarios} usuarios, ${data.resumen.depositos} depósitos, ${data.resumen.comisiones} comisiones`
        });
        
        setStep(2);
      } else {
        throw new Error(data.error || 'Error al exportar');
      }

    } catch (error) {
      console.error('❌ Error al exportar:', error);
      toast.error('Error al exportar datos', {
        description: error instanceof Error ? error.message : 'Verifica las credenciales y que el servidor tenga las rutas de backup'
      });
    } finally {
      setLoading(false);
    }
  };

  // PASO 2: Importar datos a la BASE NUEVA
  const importarDatos = async (backupData: any) => {
    setLoading(true);
    setImportResult(null);

    try {
      console.log('📥 Importando datos a la nueva base...');
      
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-9f68532a/backup/import`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`
          },
          body: JSON.stringify({ backup: backupData })
        }
      );

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Error: ${errorText}`);
      }

      const data = await response.json();
      console.log('✅ Datos importados:', data);
      
      if (data.success) {
        setImportResult(data.resultado);
        toast.success('¡Migración completada exitosamente!', {
          description: `${data.resultado.usuarios} usuarios, ${data.resultado.depositos} depósitos, ${data.resultado.comisiones} comisiones`
        });
        setStep(3);
      } else {
        throw new Error(data.error || 'Error al importar');
      }

    } catch (error) {
      console.error('❌ Error al importar:', error);
      toast.error('Error al importar datos', {
        description: error instanceof Error ? error.message : 'Error desconocido'
      });
    } finally {
      setLoading(false);
    }
  };

  // Manejar archivo subido
  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const backupData = JSON.parse(e.target?.result as string);
        importarDatos(backupData);
      } catch (error) {
        toast.error('Archivo inválido', {
          description: 'El archivo no es un backup válido'
        });
      }
    };
    reader.readAsText(file);
  };

  // Importar directamente desde datos exportados
  const importarDirecto = () => {
    if (exportData && exportData.backup) {
      importarDatos(exportData.backup);
    }
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast.success(`${label} copiado al portapapeles`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <Card className="p-8 bg-gradient-to-r from-purple-600 to-pink-600 text-white border-0">
          <div className="flex items-start gap-4">
            <div className="w-16 h-16 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center flex-shrink-0">
              <Database className="w-8 h-8 text-white" />
            </div>
            <div className="flex-1">
              <h1 className="text-3xl mb-2">Migración de Datos</h1>
              <p className="text-white/90 mb-4">
                Copia todos tus datos de la base anterior a la nueva base automáticamente
              </p>
              <div className="flex items-center gap-8 text-sm">
                <div className="flex items-center gap-2">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 1 ? 'bg-white text-purple-600' : 'bg-white/20 text-white'}`}>
                    1
                  </div>
                  <span>Exportar</span>
                </div>
                <ArrowRight className="w-5 h-5" />
                <div className="flex items-center gap-2">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 2 ? 'bg-white text-purple-600' : 'bg-white/20 text-white'}`}>
                    2
                  </div>
                  <span>Importar</span>
                </div>
                <ArrowRight className="w-5 h-5" />
                <div className="flex items-center gap-2">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 3 ? 'bg-white text-purple-600' : 'bg-white/20 text-white'}`}>
                    ✓
                  </div>
                  <span>¡Listo!</span>
                </div>
              </div>
            </div>
          </div>
        </Card>

        {/* Info de la base NUEVA */}
        <Card className="p-6 bg-green-50 border-2 border-green-200">
          <h3 className="text-lg mb-3 text-green-900">📍 Base de Datos NUEVA (Destino)</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <Label className="text-xs text-green-700">Project ID</Label>
              <div className="flex gap-2 mt-1">
                <Input 
                  value={projectId} 
                  readOnly 
                  className="bg-white/50 text-sm font-mono"
                />
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => copyToClipboard(projectId, 'Project ID')}
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
            </div>
            <div>
              <Label className="text-xs text-green-700">Anon Key</Label>
              <div className="flex gap-2 mt-1">
                <Input 
                  value={publicAnonKey.substring(0, 20) + '...'} 
                  readOnly 
                  className="bg-white/50 text-sm font-mono"
                />
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => copyToClipboard(publicAnonKey, 'Anon Key')}
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
          <p className="text-xs text-green-700 mt-2">
            ✅ Esta es tu base NUEVA donde se copiarán los datos
          </p>
        </Card>

        {/* PASO 1: Exportar */}
        <Card className="p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${step >= 1 ? 'bg-blue-500 text-white' : 'bg-slate-200 text-slate-500'}`}>
              1
            </div>
            <div>
              <h2 className="text-xl text-slate-900">Exportar de la Base Anterior</h2>
              <p className="text-sm text-slate-600">Descarga todos los datos de tu base antigua</p>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <Label>Project ID de la Base ANTERIOR</Label>
              <Input
                placeholder="abcdefghijklmnop"
                value={anteriorProjectId}
                onChange={(e) => setAnteriorProjectId(e.target.value.trim())}
                className="font-mono"
                disabled={loading || step > 1}
              />
              <p className="text-xs text-slate-500 mt-1">
                El Project ID de Supabase de tu base de datos ANTERIOR (donde están tus usuarios)
              </p>
            </div>

            <div>
              <Label>Anon Key de la Base ANTERIOR</Label>
              <Input
                type="password"
                placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI..."
                value={anteriorAnonKey}
                onChange={(e) => setAnteriorAnonKey(e.target.value.trim())}
                className="font-mono"
                disabled={loading || step > 1}
              />
              <p className="text-xs text-slate-500 mt-1">
                El Anon Key público de tu base ANTERIOR
              </p>
            </div>

            <Button
              onClick={exportarDatos}
              disabled={loading || step > 1 || !anteriorProjectId || !anteriorAnonKey}
              className="w-full h-12"
              size="lg"
            >
              {loading ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Exportando datos...
                </>
              ) : step > 1 ? (
                <>
                  <CheckCircle2 className="w-5 h-5 mr-2" />
                  Datos exportados correctamente
                </>
              ) : (
                <>
                  <Download className="w-5 h-5 mr-2" />
                  Exportar Datos
                </>
              )}
            </Button>

            {exportData && (
              <div className="mt-4 p-4 bg-green-50 rounded-xl border-2 border-green-200">
                <div className="flex items-center gap-2 mb-2">
                  <CheckCircle2 className="w-5 h-5 text-green-600" />
                  <p className="text-sm text-green-900">
                    ¡Exportación completada exitosamente!
                  </p>
                </div>
                <div className="grid grid-cols-3 gap-2 text-sm text-slate-700 mt-3">
                  <div className="bg-white p-2 rounded">
                    <p className="text-xs text-slate-500">Usuarios</p>
                    <p className="text-lg">{exportData.resumen.usuarios}</p>
                  </div>
                  <div className="bg-white p-2 rounded">
                    <p className="text-xs text-slate-500">Depósitos</p>
                    <p className="text-lg">{exportData.resumen.depositos}</p>
                  </div>
                  <div className="bg-white p-2 rounded">
                    <p className="text-xs text-slate-500">Comisiones</p>
                    <p className="text-lg">{exportData.resumen.comisiones}</p>
                  </div>
                  <div className="bg-white p-2 rounded">
                    <p className="text-xs text-slate-500">Packs</p>
                    <p className="text-lg">{exportData.resumen.packs}</p>
                  </div>
                  <div className="bg-white p-2 rounded">
                    <p className="text-xs text-slate-500">Retiros</p>
                    <p className="text-lg">{exportData.resumen.cobros}</p>
                  </div>
                  <div className="bg-white p-2 rounded">
                    <p className="text-xs text-slate-500">Productos</p>
                    <p className="text-lg">{exportData.resumen.productos}</p>
                  </div>
                </div>
                <p className="text-xs text-green-700 mt-3">
                  📥 Archivo descargado. Pasa al siguiente paso para importar.
                </p>
              </div>
            )}
          </div>
        </Card>

        {/* PASO 2: Importar */}
        <Card className={`p-6 ${step < 2 ? 'opacity-50' : ''}`}>
          <div className="flex items-center gap-3 mb-4">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${step >= 2 ? 'bg-blue-500 text-white' : 'bg-slate-200 text-slate-500'}`}>
              2
            </div>
            <div>
              <h2 className="text-xl text-slate-900">Importar a la Base Nueva</h2>
              <p className="text-sm text-slate-600">Copia los datos a tu nueva base de datos</p>
            </div>
          </div>

          {step >= 2 && exportData ? (
            <div className="space-y-3">
              <Button
                onClick={importarDirecto}
                disabled={loading || step > 2}
                className="w-full h-12"
                size="lg"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    Importando datos...
                  </>
                ) : step > 2 ? (
                  <>
                    <CheckCircle2 className="w-5 h-5 mr-2" />
                    Datos importados correctamente
                  </>
                ) : (
                  <>
                    <Upload className="w-5 h-5 mr-2" />
                    Importar Ahora
                  </>
                )}
              </Button>

              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-slate-200"></div>
                </div>
                <div className="relative flex justify-center text-xs">
                  <span className="bg-white px-2 text-slate-500">O sube el archivo manualmente</span>
                </div>
              </div>

              <div>
                <input
                  type="file"
                  accept=".json"
                  onChange={handleFileUpload}
                  className="hidden"
                  id="backup-file"
                  disabled={loading || step > 2}
                />
                <label htmlFor="backup-file">
                  <Button
                    asChild
                    variant="outline"
                    className="w-full h-10 cursor-pointer"
                    disabled={loading || step > 2}
                  >
                    <span>
                      <Upload className="w-4 h-4 mr-2" />
                      Subir Archivo JSON
                    </span>
                  </Button>
                </label>
              </div>
            </div>
          ) : (
            <div className="text-center py-8 text-slate-400">
              <Upload className="w-12 h-12 mx-auto mb-2 opacity-30" />
              <p className="text-sm">Primero completa el paso 1 (Exportar)</p>
            </div>
          )}

          {importResult && (
            <div className="mt-4 p-4 bg-green-50 rounded-xl border-2 border-green-200">
              <div className="flex items-center gap-2 mb-2">
                <CheckCircle2 className="w-5 h-5 text-green-600" />
                <p className="text-sm text-green-900">
                  ¡Importación completada exitosamente!
                </p>
              </div>
              <div className="grid grid-cols-3 gap-2 text-sm text-slate-700 mt-3">
                <div className="bg-white p-2 rounded">
                  <p className="text-xs text-slate-500">Usuarios</p>
                  <p className="text-lg text-green-600">{importResult.usuarios}</p>
                </div>
                <div className="bg-white p-2 rounded">
                  <p className="text-xs text-slate-500">Depósitos</p>
                  <p className="text-lg text-green-600">{importResult.depositos}</p>
                </div>
                <div className="bg-white p-2 rounded">
                  <p className="text-xs text-slate-500">Comisiones</p>
                  <p className="text-lg text-green-600">{importResult.comisiones}</p>
                </div>
                <div className="bg-white p-2 rounded">
                  <p className="text-xs text-slate-500">Packs</p>
                  <p className="text-lg text-green-600">{importResult.packs}</p>
                </div>
                <div className="bg-white p-2 rounded">
                  <p className="text-xs text-slate-500">Retiros</p>
                  <p className="text-lg text-green-600">{importResult.cobros}</p>
                </div>
                <div className="bg-white p-2 rounded">
                  <p className="text-xs text-slate-500">Productos</p>
                  <p className="text-lg text-green-600">{importResult.productos}</p>
                </div>
              </div>

              {importResult.errores && importResult.errores.length > 0 && (
                <div className="mt-3 p-3 bg-yellow-50 rounded-lg border border-yellow-200">
                  <div className="flex items-center gap-2 mb-1">
                    <AlertTriangle className="w-4 h-4 text-yellow-600" />
                    <p className="text-xs text-yellow-800">
                      {importResult.errores.length} registros omitidos (ya existían)
                    </p>
                  </div>
                </div>
              )}
            </div>
          )}
        </Card>

        {/* Paso 3: Completado */}
        {step >= 3 && (
          <Card className="p-8 bg-gradient-to-r from-green-500 to-emerald-600 text-white border-0">
            <div className="text-center">
              <CheckCircle2 className="w-16 h-16 mx-auto mb-4" />
              <h2 className="text-3xl mb-2">¡Migración Completada!</h2>
              <p className="text-white/90 mb-6">
                Todos tus datos han sido migrados exitosamente a la nueva base de datos
              </p>
              <Button
                onClick={() => onNavigate ? onNavigate('admin') : window.location.href = '/admin'}
                variant="secondary"
                size="lg"
              >
                Ir al Panel de Admin
              </Button>
            </div>
          </Card>
        )}

        {/* Advertencia */}
        <Card className="p-6 bg-blue-50 border-2 border-blue-200">
          <div className="flex gap-3">
            <AlertTriangle className="w-6 h-6 text-blue-600 flex-shrink-0 mt-1" />
            <div>
              <p className="text-sm text-blue-900 mb-2">
                <strong>ℹ️ Información importante:</strong>
              </p>
              <ul className="text-sm text-blue-800 space-y-1 list-disc list-inside">
                <li>La exportación NO borra datos de la base anterior</li>
                <li>La importación NO duplica datos si ya existen</li>
                <li>Puedes repetir este proceso las veces que necesites</li>
                <li>Se descarga un archivo backup.json por seguridad</li>
              </ul>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}