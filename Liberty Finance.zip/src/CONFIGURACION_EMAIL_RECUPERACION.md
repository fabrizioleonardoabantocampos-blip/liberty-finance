# 🔐 Configuración de Email para Recuperación de Contraseña

## ✅ Estado Actual

La funcionalidad de recuperación de contraseña está **completamente implementada** con soporte para envío de emails reales a través de Resend.

## 📧 Cómo Funciona

### Flujo Completo:
1. **Usuario solicita recuperación** → Ingresa su correo en `/recuperar-password`
2. **Servidor genera código** → Código de 6 dígitos válido por 15 minutos
3. **Email enviado** → El usuario recibe un email profesional con el código
4. **Usuario verifica código** → Ingresa el código recibido
5. **Cambio de contraseña** → Establece nueva contraseña
6. **Login exitoso** → Puede iniciar sesión con la nueva contraseña

### Modo Desarrollo vs Producción:
- **Sin API Key configurada**: El código se muestra en la consola y en la respuesta del servidor (modo desarrollo)
- **Con API Key configurada**: El email se envía automáticamente al correo del usuario

## 🚀 Configuración de Resend (Recomendado)

### Paso 1: Crear cuenta en Resend
1. Ve a [https://resend.com](https://resend.com)
2. Regístrate con tu correo
3. Verifica tu email

### Paso 2: Obtener API Key
1. Una vez dentro del dashboard, ve a **API Keys**
2. Haz clic en **Create API Key**
3. Dale un nombre descriptivo (ej: "Liberty Finance - Producción")
4. Copia la API Key (empieza con `re_`)

### Paso 3: Configurar dominio (Opcional pero recomendado)
Para usar un email personalizado como `noreply@tudominio.com`:

1. En el dashboard de Resend, ve a **Domains**
2. Haz clic en **Add Domain**
3. Ingresa tu dominio (ej: `libertyfinance.com`)
4. Sigue las instrucciones para configurar los registros DNS
5. Una vez verificado, podrás enviar desde `noreply@libertyfinance.com`

**Nota:** Sin dominio verificado, los emails se enviarán desde un dominio compartido de Resend (puede ir a spam).

### Paso 4: Agregar API Key al sistema
1. La API Key ya fue solicitada a través de la interfaz
2. Cuando se te solicite, pega tu API Key de Resend
3. ¡Listo! El sistema comenzará a enviar emails automáticamente

## 🎨 Email Template

El email enviado incluye:
- **Header profesional** con gradiente morado (colores de Liberty Finance)
- **Código destacado** en formato grande y fácil de leer
- **Alertas de seguridad** sobre la expiración de 15 minutos
- **Footer corporativo** con información legal
- **Diseño responsive** que se ve bien en móviles y desktop

### Vista previa del email:
```
┌─────────────────────────────────┐
│     🔐 Recupera tu Contraseña    │
│    [Gradiente morado de LF]     │
├─────────────────────────────────┤
│ Hola [Nombre Usuario],          │
│                                  │
│ Recibimos una solicitud para    │
│ restablecer tu contraseña...    │
│                                  │
│   Tu Código de Verificación     │
│        ┌───────────┐            │
│        │  123456   │            │
│        └───────────┘            │
│                                  │
│ ⏰ Este código expira en 15 min │
└─────────────────────────────────┘
```

## 🔧 Personalización del Email

Si quieres personalizar el email, edita el archivo:
```
/supabase/functions/server/index.tsx
```

Busca la sección del `emailHtml` en la ruta `/auth/solicitar-recuperacion`.

Puedes cambiar:
- Colores del gradiente
- Texto y mensajes
- Logo (actualmente usa emoji 🔐)
- Footer y enlaces

## 📊 Límites de Resend

### Plan Gratuito:
- **100 emails/día**
- **3,000 emails/mes**
- Perfecto para desarrollo y MVP

### Plan Pro ($20/mes):
- **50,000 emails/mes**
- Soporte prioritario
- Analytics avanzado

## 🐛 Troubleshooting

### El email no llega
1. ✅ Verifica que la API Key esté correctamente configurada
2. ✅ Revisa la carpeta de Spam/Correo no deseado
3. ✅ Si usas dominio personalizado, verifica que esté correctamente verificado
4. ✅ Revisa los logs del servidor para ver si hay errores

### El email va a Spam
- **Solución**: Configura un dominio verificado en Resend
- Los emails desde dominios verificados tienen mejor reputación

### Error "Invalid API Key"
- Verifica que hayas copiado la key completa (empieza con `re_`)
- No agregues espacios al inicio o final
- La key debe estar activa en tu dashboard de Resend

## 🔐 Seguridad

El sistema implementa las siguientes medidas de seguridad:

✅ **Código de 6 dígitos** - Suficientemente seguro y fácil de usar
✅ **Expiración de 15 minutos** - Reduce ventana de ataque
✅ **Código de un solo uso** - No se puede reutilizar
✅ **Sin revelación de existencia** - No indica si el email existe en el sistema
✅ **Logs de auditoría** - Todas las solicitudes quedan registradas

## 🌐 Alternativas a Resend

Si prefieres usar otro servicio, puedes modificar fácilmente el código para usar:

### SendGrid
```typescript
import sgMail from 'npm:@sendgrid/mail';
sgMail.setApiKey(process.env.SENDGRID_API_KEY);
```

### Mailgun
```typescript
import Mailgun from 'npm:mailgun.js';
const mailgun = new Mailgun(FormData);
```

### AWS SES
```typescript
import { SESClient, SendEmailCommand } from 'npm:@aws-sdk/client-ses';
```

### NodeMailer (SMTP genérico)
```typescript
import nodemailer from 'npm:nodemailer';
```

## 📝 Testing

### Probar en modo desarrollo (sin email)
```bash
# Sin configurar RESEND_API_KEY
# El código se mostrará en consola y en la respuesta
```

### Probar con email real
```bash
# 1. Configura RESEND_API_KEY
# 2. Intenta recuperar contraseña con un email real
# 3. Revisa tu bandeja de entrada
```

## 🎉 ¡Todo Listo!

Tu sistema de recuperación de contraseña está completamente funcional:

1. ✅ Frontend con 3 pasos (email → código → nueva contraseña)
2. ✅ Backend con validación y seguridad
3. ✅ Email profesional con template HTML
4. ✅ Modo fallback para desarrollo sin API key
5. ✅ Logs detallados para debugging

---

**Desarrollado para Liberty Finance** 🚀
**Última actualización**: Noviembre 2024
