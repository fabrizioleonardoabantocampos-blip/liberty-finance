// ==========================================
// 🔄 SINCRONIZACIÓN SUPABASE AUTH → KV STORE
// ==========================================
// Este archivo contiene el endpoint para sincronizar usuarios de Supabase Auth al KV Store

import { createClient } from 'npm:@supabase/supabase-js@2';
import * as crm from './crm.tsx';

export async function syncAuthUsers() {
  console.log('🔄 Iniciando sincronización de usuarios de Supabase Auth → KV Store...');
  
  const supabase = createClient(
    Deno.env.get('SUPABASE_URL') ?? '',
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
  );
  
  // Obtener TODOS los usuarios de Supabase Auth
  console.log('📥 Obteniendo usuarios de Supabase Auth...');
  const { data: authUsers, error: authError } = await supabase.auth.admin.listUsers();
  
  if (authError) {
    console.error('❌ Error al obtener usuarios de Auth:', authError);
    throw new Error(authError.message);
  }
  
  console.log(`✅ Encontrados ${authUsers.users.length} usuarios en Supabase Auth`);
  
  // Obtener usuarios existentes en KV
  const kvUsers = await crm.getAllUsers();
  const kvEmails = new Set(kvUsers.map(u => u.email?.toLowerCase()).filter(Boolean));
  console.log(`✅ Encontrados ${kvUsers.length} usuarios en KV Store`);
  
  // Sincronizar usuarios faltantes
  const sincronizados = [];
  const errores = [];
  
  for (const authUser of authUsers.users) {
    const email = authUser.email?.toLowerCase();
    if (!email) continue;
    
    // Si ya existe en KV, saltar
    if (kvEmails.has(email)) {
      console.log(`⏭️ Usuario ya existe en KV: ${email}`);
      continue;
    }
    
    try {
      console.log(`🆕 Creando usuario en KV: ${email}`);
      
      // Extraer datos del usuario de Auth
      const metadata = authUser.user_metadata || {};
      const nombre = metadata.nombre || metadata.name || email.split('@')[0];
      const apellido = metadata.apellido || metadata.last_name || '';
      const telefono = metadata.telefono || metadata.phone || '';
      const wallet = metadata.wallet || '';
      
      // Generar ID único
      const id_unico = `LF${Date.now()}${Math.floor(Math.random() * 1000)}`;
      
      // Crear usuario en KV
      const newUser = await crm.createUser({
        id_unico,
        nombre,
        apellido,
        email,
        telefono,
        ciudad: '',
        wallet,
        password: 'MIGRATED_FROM_AUTH', // Password placeholder
        referralCode: metadata.referralCode || '',
        referidoPor: undefined,
        rango: 'Sin Rango'
      });
      
      // Inicializar puntos
      await crm.setPuntos(newUser.id, 100);
      
      sincronizados.push({
        email,
        nombre: `${nombre} ${apellido}`,
        id: newUser.id
      });
      
      console.log(`✅ Usuario sincronizado: ${nombre} ${apellido} (${email})`);
    } catch (error: any) {
      console.error(`❌ Error sincronizando ${email}:`, error);
      errores.push({ email, error: error.message });
    }
  }
  
  console.log(`\n🎉 SINCRONIZACIÓN COMPLETA:`);
  console.log(`   - Total en Auth: ${authUsers.users.length}`);
  console.log(`   - Ya existían en KV: ${kvEmails.size}`);
  console.log(`   - Sincronizados ahora: ${sincronizados.length}`);
  console.log(`   - Errores: ${errores.length}`);
  
  return {
    success: true,
    totalAuth: authUsers.users.length,
    yaExistian: kvEmails.size,
    sincronizados: sincronizados.length,
    errores: errores.length,
    detalles: {
      sincronizados,
      errores
    }
  };
}