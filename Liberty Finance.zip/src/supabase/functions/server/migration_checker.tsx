// ==========================================
// 🔍 DIAGNÓSTICO Y MIGRACIÓN DE DATOS
// ==========================================
// Este archivo verifica si hay datos en formato antiguo y los migra al nuevo formato

import { createClient } from 'npm:@supabase/supabase-js@2';

/**
 * Función para obtener TODAS las keys de la base de datos
 */
export async function getAllKeys() {
  const supabase = createClient(
    Deno.env.get('SUPABASE_URL') || '',
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || ''
  );
  
  console.log('🔍 Obteniendo todas las keys de la base de datos...');
  
  let allKeys: any[] = [];
  let pageSize = 500;
  let currentPage = 0;
  let hasMore = true;
  
  while (hasMore) {
    const { data, error } = await supabase
      .from('kv_store_9f68532a')
      .select('key, value')
      .range(currentPage * pageSize, (currentPage + 1) * pageSize - 1);
    
    if (error) {
      console.error('❌ Error obteniendo keys:', error);
      break;
    }
    
    if (!data || data.length === 0) {
      hasMore = false;
    } else {
      allKeys = [...allKeys, ...data];
      console.log(`   📄 Página ${currentPage + 1}: ${data.length} registros (Total: ${allKeys.length})`);
      
      if (data.length < pageSize) {
        hasMore = false;
      }
      
      currentPage++;
    }
  }
  
  return allKeys;
}

/**
 * Analizar y categorizar todas las keys
 */
export async function analizarEstructuraDatos() {
  console.log('🔍 ===== ANÁLISIS DE ESTRUCTURA DE DATOS =====\n');
  
  const allKeys = await getAllKeys();
  
  // Categorizar por prefijos
  const categorias: Record<string, number> = {};
  const keysSospechosas: string[] = [];
  const ejemplos: Record<string, string[]> = {};
  
  allKeys.forEach(item => {
    const key = item.key;
    
    // Detectar keys sospechosas (sin el formato esperado)
    if (!key.includes(':')) {
      keysSospechosas.push(key);
    }
    
    // Categorizar por prefijo
    const prefijo = key.split(':')[0];
    categorias[prefijo] = (categorias[prefijo] || 0) + 1;
    
    // Guardar ejemplos
    if (!ejemplos[prefijo]) {
      ejemplos[prefijo] = [];
    }
    if (ejemplos[prefijo].length < 3) {
      ejemplos[prefijo].push(key);
    }
  });
  
  // Mostrar resultados
  console.log('📊 RESUMEN POR CATEGORÍAS:');
  console.log('═'.repeat(60));
  Object.entries(categorias)
    .sort((a, b) => b[1] - a[1])
    .forEach(([prefijo, cantidad]) => {
      console.log(`  ${prefijo.padEnd(20)} : ${cantidad.toString().padStart(6)} registros`);
      if (ejemplos[prefijo]) {
        ejemplos[prefijo].forEach(ejemplo => {
          console.log(`      └─ ${ejemplo}`);
        });
      }
    });
  
  console.log('\n');
  console.log('🚨 KEYS SOSPECHOSAS (sin estructura key:value):');
  console.log('═'.repeat(60));
  if (keysSospechosas.length > 0) {
    keysSospechosas.forEach(key => {
      console.log(`  ⚠️  ${key}`);
    });
  } else {
    console.log('  ✅ No se encontraron keys sospechosas');
  }
  
  console.log('\n');
  console.log('📈 TOTALES:');
  console.log('═'.repeat(60));
  console.log(`  Total de keys: ${allKeys.length}`);
  console.log(`  Categorías: ${Object.keys(categorias).length}`);
  console.log(`  Keys sospechosas: ${keysSospechosas.length}`);
  
  return {
    totalKeys: allKeys.length,
    categorias,
    keysSospechosas,
    ejemplos,
    allKeys
  };
}

/**
 * Buscar datos antiguos en formato monolítico
 */
export async function buscarDatosAntiguos() {
  console.log('\n🔍 ===== BÚSQUEDA DE DATOS ANTIGUOS =====\n');
  
  const supabase = createClient(
    Deno.env.get('SUPABASE_URL') || '',
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || ''
  );
  
  // Buscar keys comunes de datos antiguos
  const keysABuscar = [
    'users',           // Todos los usuarios en una sola key
    'packs',           // Todos los packs en una sola key
    'comisiones',      // Todas las comisiones en una sola key
    'cobros',          // Todos los cobros en una sola key
    'data',            // Datos generales
    'crm_data',        // Datos del CRM
    'liberty_data',    // Datos de Liberty
    'all_users',       // Variante de usuarios
    'all_data',        // Todos los datos
  ];
  
  const datosEncontrados: Record<string, any> = {};
  
  for (const key of keysABuscar) {
    try {
      const { data, error } = await supabase
        .from('kv_store_9f68532a')
        .select('key, value')
        .eq('key', key)
        .single();
      
      if (data && !error) {
        console.log(`✅ Encontrado: ${key}`);
        console.log(`   Tipo de valor: ${typeof data.value}`);
        
        if (typeof data.value === 'object') {
          const keys = Object.keys(data.value);
          console.log(`   Propiedades: ${keys.length}`);
          console.log(`   Primeras propiedades: ${keys.slice(0, 5).join(', ')}`);
          
          // Verificar si contiene arrays de datos
          keys.forEach(k => {
            if (Array.isArray(data.value[k])) {
              console.log(`      └─ ${k}: ${data.value[k].length} items`);
            }
          });
        }
        
        datosEncontrados[key] = data.value;
      }
    } catch (error) {
      // Key no existe, continuar
    }
  }
  
  if (Object.keys(datosEncontrados).length === 0) {
    console.log('✅ No se encontraron datos antiguos en formato monolítico');
  }
  
  return datosEncontrados;
}

/**
 * Analizar registros individuales para detectar estructura monolítica vs individual
 */
export async function analizarEstructuraRegistros() {
  console.log('\n🔬 ===== ANÁLISIS DE ESTRUCTURA DE REGISTROS =====\n');
  
  const allKeys = await getAllKeys();
  
  // Categorías principales a analizar
  const categoriasAnalizar = ['user', 'pack', 'comision', 'rendimiento', 'deposito', 'cobro', 'producto', 'rango'];
  
  const resultados: Record<string, any> = {};
  
  for (const categoria of categoriasAnalizar) {
    console.log(`\n📦 Analizando categoría: ${categoria}`);
    console.log('─'.repeat(60));
    
    // Filtrar keys de esta categoría (excluir índices)
    const keysCategoria = allKeys.filter(item => {
      const key = item.key;
      return key.startsWith(`${categoria}:`) && 
             !key.includes(':email:') && 
             !key.includes(':idUnico:') &&
             key.split(':').length === 2; // Solo keys principales, no índices
    });
    
    if (keysCategoria.length === 0) {
      console.log(`  ⚠️  No se encontraron registros de ${categoria}`);
      continue;
    }
    
    console.log(`  Total de registros: ${keysCategoria.length}`);
    
    // Analizar los primeros registros para determinar estructura
    const muestras = keysCategoria.slice(0, Math.min(5, keysCategoria.length));
    
    let estructuraMonolitica = 0;
    let estructuraIndividual = 0;
    let estructuraHibrida = 0;
    
    const ejemplosMonolitica: any[] = [];
    const ejemplosIndividual: any[] = [];
    
    for (const item of muestras) {
      const key = item.key;
      const value = item.value;
      
      // Determinar tipo de estructura
      if (typeof value === 'object' && value !== null) {
        const propiedades = Object.keys(value);
        
        // Detectar si es estructura monolítica (todo el objeto en una key)
        // vs estructura individual (solo propiedades básicas, lo demás en keys separadas)
        
        // Monolítica: tiene muchas propiedades y arrays/objetos complejos
        const tieneArrays = propiedades.some(p => Array.isArray(value[p]));
        const tieneObjetosComplejos = propiedades.some(p => 
          typeof value[p] === 'object' && 
          value[p] !== null && 
          !Array.isArray(value[p]) &&
          Object.keys(value[p]).length > 3
        );
        
        if (tieneArrays || tieneObjetosComplejos || propiedades.length > 20) {
          estructuraMonolitica++;
          if (ejemplosMonolitica.length < 2) {
            ejemplosMonolitica.push({
              key,
              propiedades: propiedades.length,
              tieneArrays,
              tieneObjetosComplejos,
              ejemploPropiedades: propiedades.slice(0, 5)
            });
          }
        } else if (propiedades.length <= 5) {
          estructuraIndividual++;
          if (ejemplosIndividual.length < 2) {
            ejemplosIndividual.push({
              key,
              propiedades: propiedades.length,
              ejemploPropiedades: propiedades
            });
          }
        } else {
          estructuraHibrida++;
        }
      }
    }
    
    // Mostrar resultados
    console.log(`\n  📊 Análisis de ${muestras.length} muestras:`);
    console.log(`     • Estructura Monolítica: ${estructuraMonolitica}`);
    console.log(`     • Estructura Individual: ${estructuraIndividual}`);
    console.log(`     • Estructura Híbrida: ${estructuraHibrida}`);
    
    if (ejemplosMonolitica.length > 0) {
      console.log('\n  🔴 Ejemplos de ESTRUCTURA MONOLÍTICA:');
      ejemplosMonolitica.forEach(ejemplo => {
        console.log(`     └─ ${ejemplo.key}`);
        console.log(`        Propiedades: ${ejemplo.propiedades}`);
        console.log(`        Tiene arrays: ${ejemplo.tieneArrays}`);
        console.log(`        Tiene objetos complejos: ${ejemplo.tieneObjetosComplejos}`);
        console.log(`        Ejemplo: ${ejemplo.ejemploPropiedades.join(', ')}`);
      });
    }
    
    if (ejemplosIndividual.length > 0) {
      console.log('\n  🟢 Ejemplos de ESTRUCTURA INDIVIDUAL:');
      ejemplosIndividual.forEach(ejemplo => {
        console.log(`     └─ ${ejemplo.key}`);
        console.log(`        Propiedades: ${ejemplo.propiedades}`);
        console.log(`        Ejemplo: ${ejemplo.ejemploPropiedades.join(', ')}`);
      });
    }
    
    // Determinar si requiere migración
    const porcentajeMonolitico = (estructuraMonolitica / muestras.length) * 100;
    const requiereMigracion = porcentajeMonolitico > 50;
    
    resultados[categoria] = {
      totalRegistros: keysCategoria.length,
      muestrasAnalizadas: muestras.length,
      estructuraMonolitica,
      estructuraIndividual,
      estructuraHibrida,
      porcentajeMonolitico: Math.round(porcentajeMonolitico),
      requiereMigracion,
      ejemplosMonolitica,
      ejemplosIndividual
    };
    
    if (requiereMigracion) {
      console.log(`\n  ⚠️  ATENCIÓN: ${Math.round(porcentajeMonolitico)}% de registros usan estructura monolítica`);
      console.log(`     ➜ Esta categoría REQUIERE MIGRACIÓN`);
    } else {
      console.log(`\n  ✅ Estructura correcta (${100 - Math.round(porcentajeMonolitico)}% individual)`);
    }
  }
  
  return resultados;
}

/**
 * Exportar diagnóstico completo
 */
export async function ejecutarDiagnosticoCompleto() {
  console.log('\n🚀 ===== DIAGNÓSTICO COMPLETO DE BASE DE DATOS =====\n');
  
  const analisis = await analizarEstructuraDatos();
  const datosAntiguos = await buscarDatosAntiguos();
  const analisisRegistros = await analizarEstructuraRegistros();
  
  console.log('\n');
  console.log('🎯 CONCLUSIONES:');
  console.log('═'.repeat(60));
  
  // Verificar si alguna categoría requiere migración
  const categoriasConProblemas = Object.entries(analisisRegistros)
    .filter(([_, datos]: [string, any]) => datos.requiereMigracion)
    .map(([categoria]) => categoria);
  
  if (datosAntiguos && Object.keys(datosAntiguos).length > 0) {
    console.log('⚠️  SE ENCONTRARON DATOS ANTIGUOS QUE REQUIEREN MIGRACIÓN');
    console.log(`   Keys encontradas: ${Object.keys(datosAntiguos).join(', ')}`);
  } else {
    console.log('✅ No se encontraron datos antiguos en formato monolítico global');
  }
  
  if (categoriasConProblemas.length > 0) {
    console.log('⚠️  CATEGORÍAS QUE REQUIEREN MIGRACIÓN:');
    categoriasConProblemas.forEach(cat => {
      console.log(`   • ${cat}: ${analisisRegistros[cat].porcentajeMonolitico}% estructura monolítica`);
    });
  } else {
    console.log('✅ Todas las categorías usan estructura individual correcta');
  }
  
  console.log('\n');
  
  const requiereMigracion = Object.keys(datosAntiguos).length > 0 || categoriasConProblemas.length > 0;
  
  return {
    analisis,
    datosAntiguos,
    requiereMigracion,
    analisisRegistros,
    categoriasConProblemas
  };
}