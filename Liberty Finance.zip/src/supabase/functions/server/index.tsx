// Liberty Finance CRM Backend Server v1.4 - Sistema de Timeout + Retry - 21 Dic 2025
import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { Resend } from "npm:resend@4.0.0";
import { createClient } from 'npm:@supabase/supabase-js@2';
import * as kv from "./kv_store.tsx";
import * as crm from "./crm.tsx";
import { syncAuthUsers } from "./sync_auth_users.tsx";
import * as migrationChecker from "./migration_checker.tsx";
import { repararCuentaIsrael } from "./reparar-israel.tsx";

// ========================================
// 🚀 SISTEMA DE CACHÉ EN MEMORIA (HOT CACHE)
// ========================================
// Almacena datos frecuentemente accedidos para reducir tiempos de carga de 6 min → 5 seg
let cacheUsuarios: any[] | null = null;
let cachePacks: any[] | null = null;
let cacheComisiones: any[] | null = null;
let cacheTimestamp = 0;
const CACHE_TTL = 300000; // 🔥 AUMENTADO: 5 minutos (era 2 minutos) - reduce consultas frecuentes
let isRefreshingCache = false; // 🚀 NUEVO: Flag para evitar refresh simultáneos

// 🚀 NUEVO: Caché específico para dashboards de usuario (más agresivo)
const cacheDashboards = new Map<string, { data: any; timestamp: number }>();
const DASHBOARD_CACHE_TTL = 120000; // 🔥 AUMENTADO: 2 minutos (era 1 minuto) - reduce carga en picos

// 🚀 NUEVO: Caché específico para referidos (evita timeouts)
const cacheReferidos = new Map<string, { data: any; timestamp: number }>();
const REFERIDOS_CACHE_TTL = 300000; // 5 minutos

// ⚡ NUEVO: Helper para timeout en promises
function withTimeout<T>(promise: Promise<T>, timeoutMs: number, defaultValue: T): Promise<T> {
  return Promise.race([
    promise,
    new Promise<T>((_, reject) => 
      setTimeout(() => reject(new Error(`Timeout después de ${timeoutMs}ms`)), timeoutMs)
    )
  ]).catch(err => {
    console.warn(`⚠️ Promise falló o excedió timeout: ${err.message}`);
    return defaultValue;
  });
}

// 🚀 NUEVO: Función para refrescar caché en background sin bloquear
async function refreshCacheInBackground() {
  if (isRefreshingCache) {
    console.log('⏭️ Ya hay un refresh en progreso, saltando...');
    return;
  }
  
  isRefreshingCache = true;
  console.log('🔄 [BACKGROUND] Refrescando caché en segundo plano...');
  
  try {
    const startTime = Date.now();
    
    // Cargar datos en paralelo con timeouts generosos
    const [usuarios, packs, comisiones] = await Promise.all([
      Promise.race([
        crm.getAllUsers(),
        new Promise((_, reject) => setTimeout(() => reject(new Error('Timeout usuarios')), 90000)) // ⚡ AUMENTADO: 50s → 90s
      ]).catch(err => {
        console.error('❌ Error cargando usuarios en background:', err);
        return cacheUsuarios || [];
      }),
      Promise.race([
        crm.getAllPacks(),
        new Promise((_, reject) => setTimeout(() => reject(new Error('Timeout packs')), 60000)) // ⚡ AUMENTADO: 30s → 60s
      ]).catch(err => {
        console.error('❌ Error cargando packs en background:', err);
        return cachePacks || [];
      }),
      Promise.race([
        crm.getAllComisiones(),
        new Promise((_, reject) => setTimeout(() => reject(new Error('Timeout comisiones')), 60000)) // ⚡ AUMENTADO: 30s → 60s
      ]).catch(err => {
        console.error('❌ Error cargando comisiones en background:', err);
        return cacheComisiones || [];
      })
    ]);
    
    cacheUsuarios = usuarios as any;
    cachePacks = packs as any;
    cacheComisiones = comisiones as any;
    cacheTimestamp = Date.now();
    
    const elapsed = Date.now() - startTime;
    console.log(`✅ [BACKGROUND] Caché actualizado en ${elapsed}ms: ${cacheUsuarios.length} usuarios, ${cachePacks.length} packs, ${cacheComisiones.length} comisiones`);
  } catch (error) {
    console.error('❌ [BACKGROUND] Error refrescando caché:', error);
  } finally {
    isRefreshingCache = false;
  }
}

async function getCachedUsuarios() {
  const now = Date.now();
  const isExpired = !cacheUsuarios || (now - cacheTimestamp > CACHE_TTL);
  
  // Si el caché expiró pero tenemos datos, devolver datos antiguos y refrescar en background
  if (isExpired && cacheUsuarios && cacheUsuarios.length > 0) {
    console.log('⚡ Caché expirado, devolviendo datos antiguos y refrescando en background...');
    // Refrescar en background sin esperar
    refreshCacheInBackground().catch(err => 
      console.error('Error en background refresh:', err)
    );
    return cacheUsuarios;
  }
  
  // Si no hay caché o está vacío, cargar síncronamente (primera vez)
  if (!cacheUsuarios || cacheUsuarios.length === 0) {
    console.log('🔄 Primera carga de caché de usuarios...');
    try {
      cacheUsuarios = await Promise.race([
        crm.getAllUsers(),
        new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Timeout cargando usuarios')), 90000) // ⚡ AUMENTADO: 50s → 90s
        )
      ]) as any;
      cacheTimestamp = now;
      console.log(`✅ Caché inicial cargado: ${cacheUsuarios.length} usuarios`);
    } catch (error) {
      console.error('❌ Error cargando caché inicial de usuarios:', error);
      // ⚡ FALLBACK: Si falla, intentar cargar directamente SIN timeout
      console.log('🔄 Reintentando carga directa sin timeout...');
      try {
        cacheUsuarios = await crm.getAllUsers();
        cacheTimestamp = now;
        console.log(`✅ Caché cargado en segundo intento: ${cacheUsuarios.length} usuarios`);
      } catch (retryError) {
        console.error('❌ Error en segundo intento:', retryError);
        cacheUsuarios = [];
      }
    }
  }
  
  return cacheUsuarios;
}

async function getCachedPacks() {
  const now = Date.now();
  const isExpired = !cachePacks || (now - cacheTimestamp > CACHE_TTL);
  
  // Si el caché expiró pero tenemos datos, devolver datos antiguos
  if (isExpired && cachePacks && cachePacks.length > 0) {
    console.log('⚡ Caché de packs expirado, devolviendo datos antiguos...');
    return cachePacks;
  }
  
  // Si no hay caché o está vacío, cargar síncronamente
  if (!cachePacks || cachePacks.length === 0) {
    console.log('🔄 Primera carga de caché de packs...');
    try {
      cachePacks = await Promise.race([
        crm.getAllPacks(),
        new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Timeout cargando packs')), 30000)
        )
      ]) as any;
      console.log(`✅ Caché de packs cargado: ${cachePacks.length} packs`);
    } catch (error) {
      console.error('❌ Error cargando caché de packs:', error);
      cachePacks = [];
    }
  }
  
  return cachePacks;
}

async function getCachedComisiones() {
  const now = Date.now();
  const isExpired = !cacheComisiones || (now - cacheTimestamp > CACHE_TTL);
  
  // Si el caché expiró pero tenemos datos, devolver datos antiguos
  if (isExpired && cacheComisiones && cacheComisiones.length > 0) {
    console.log('⚡ Caché de comisiones expirado, devolviendo datos antiguos...');
    return cacheComisiones;
  }
  
  // Si no hay caché o está vacío, cargar síncronamente
  if (!cacheComisiones || cacheComisiones.length === 0) {
    console.log('🔄 Primera carga de caché de comisiones...');
    try {
      cacheComisiones = await Promise.race([
        crm.getAllComisiones(),
        new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Timeout cargando comisiones')), 30000)
        )
      ]) as any;
      console.log(`✅ Caché de comisiones cargado: ${cacheComisiones.length} comisiones`);
    } catch (error) {
      console.error('❌ Error cargando caché de comisiones:', error);
      cacheComisiones = [];
    }
  }
  
  return cacheComisiones;
}

// Función para invalidar el caché manualmente (útil después de crear/actualizar datos)
function invalidateCache() {
  cacheUsuarios = null;
  cachePacks = null;
  cacheComisiones = null;
  cacheTimestamp = 0;
  cacheDashboards.clear(); // Limpiar también caché de dashboards
  console.log('🗑️ [v2024-12-20-PATROCINIO-FIX] Caché invalidado');
}

// Función para invalidar solo el caché de dashboard de un usuario específico
function invalidateUserDashboard(userId: string) {
  if (cacheDashboards.has(userId)) {
    cacheDashboards.delete(userId);
    console.log(`🗑️ Caché de dashboard invalidado para usuario: ${userId}`);
  }
}
// ========================================

// Inicializar Resend
// const resend = new Resend(Deno.env.get('RESEND_API_KEY')); // Mover a uso local para asegurar lectura fresca

const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// 🚨 TIMEOUT MIDDLEWARE - Prevenir conexiones colgadas
app.use('*', async (c, next) => {
  // ⚡ TIMEOUTS DINÁMICOS por tipo de ruta
  const path = c.req.path;
  let timeoutMs = 30000; // Default: 30 segundos
  
  // Rutas críticas que necesitan más tiempo
  if (path.includes('/referidos') || 
      path.includes('/recalcular-rango') ||
      path.includes('/admin/dashboard-stats') ||
      path.includes('/admin/users-complete') ||
      path.includes('/admin/sync-user-indexes') || // ✅ AGREGADO: Sincronización de índices procesa todos los usuarios
      path.includes('/depositos/')) { // ✅ AGREGADO: Aprobar depósitos requiere calcular matriz
    timeoutMs = 60000; // ⚡ 60 segundos para rutas pesadas
  }
  
  const timeoutPromise = new Promise((_, reject) => {
    setTimeout(() => {
      reject(new Error('Request timeout - La petición tardó demasiado tiempo'));
    }, timeoutMs);
  });

  try {
    await Promise.race([next(), timeoutPromise]);
  } catch (error) {
    if (error instanceof Error && error.message.includes('timeout')) {
      console.error(`⏱️ TIMEOUT en ruta: ${path} (timeout: ${timeoutMs}ms)`);
      return c.json({ 
        error: 'Request timeout',
        message: 'La petición tardó demasiado tiempo. Por favor, intenta de nuevo.',
        path: path,
        timeout: timeoutMs
      }, 504);
    }
    throw error;
  }
});

// ⚡ HEALTH CHECK - Respuesta instantánea sin acceso a DB
app.get("/make-server-9f68532a/health", (c) => {
  return c.json({
    status: "ok",
    timestamp: Date.now(),
    server: "Liberty Finance API",
    uptime: Math.floor(performance.now() / 1000)
  });
});

// ⚡ PING - Respuesta mínima para verificar conectividad
app.get("/make-server-9f68532a/ping", (c) => {
  return c.text("pong");
});

// 🔧 ENDPOINT DE VERIFICACIÓN DE VERSIÓN Y CACHÉ
app.get("/make-server-9f68532a/version", async (c) => {
  const diagnostico = c.req.query('diagnostico');
  
  // Si se pide diagnóstico, analizar el campo referidoPor
  if (diagnostico === 'referidos') {
    try {
      console.log('🚨 DIAGNÓSTICO: Analizando campo referidoPor...');
      const allUsersRaw = await kv.getByPrefix('user:');
      const usuarios = allUsersRaw.filter((item: any) => item && typeof item === 'object' && item.id && !item.id.includes(':')).slice(0, 15);
      const analisis = usuarios.map((u: any) => ({
        id: u.id?.substring(0, 8),
        nombre: u.nombre,
        referidoPor: u.referidoPor,
        referidoPorType: typeof u.referidoPor,
        esUUID: u.referidoPor?.toString().includes('-'),
        todasLasClaves: Object.keys(u)
      }));
      const todosLosUsuarios = allUsersRaw.filter((item: any) => item && typeof item === 'object' && item.id && !item.id.includes(':'));
      const israel = todosLosUsuarios.find((u: any) => u.id_unico === 'LF1764086702089158');
      const jorge = todosLosUsuarios.find((u: any) => u.nombre?.toLowerCase().includes('jorge'));
      return c.json({
        resumen: {
          total: analisis.length,
          conReferido: analisis.filter(a => a.referidoPor).length,
          esUUID: analisis.filter(a => a.esUUID).length
        },
        muestra: analisis,
        israel: israel ? { id: israel.id?.substring(0, 8), referidoPor: israel.referidoPor } : null,
        jorge: jorge ? { id: jorge.id?.substring(0, 8), referidoPor: jorge.referidoPor, claves: Object.keys(jorge) } : null
      });
    } catch (error: any) {
      return c.json({ error: error.message }, 500);
    }
  }
  
  invalidateCache();
  return c.json({
    version: "v2024-12-21-TIMEOUT-FIX",
    timestamp: new Date().toISOString(),
    cacheInvalidated: true,
    message: "✅ Servidor actualizado - Caché invalidado - Timeout middleware agregado",
    improvements: [
      "✅ Error de sintaxis corregido (línea 2239)",
      "✅ Middleware de timeout agregado (55s)",
      "✅ Cache TTL aumentado: 5 minutos (usuarios), 2 minutos (dashboards)",
      "��� Timeouts aumentados: 15s (cachéGlobal), 10s (por usuario)",
      "✅ Retry con backoff exponencial en frontend (3 intentos)",
      "✅ Logging mejorado para debugging"
    ]
  });
});

// 🔧 MIGRACIÓN: Llenar campo referidoPor basándose en matrizPadre
app.post("/make-server-9f68532a/migrar-referidos", async (c) => {
  try {
    console.log('🚀 INICIANDO MIGRACIÓN DE CAMPO referidoPor...');
    
    // Obtener TODOS los usuarios usando la misma función que AdminUsers
    const todosLosUsuarios = await getCachedUsuarios();
    console.log(`📊 Total usuarios: ${todosLosUsuarios.length}`);
    
    // Encontrar al usuario "Global" (root)
    const globalUser = todosLosUsuarios.find((u: any) => 
      u.email === 'ksallesvela.411@gmail.com' || 
      u.id_unico === 'LF1764085135266676'
    );
    
    if (!globalUser) {
      throw new Error('❌ No se encontró el usuario Global (root)');
    }
    
    console.log(`✅ Usuario Global encontrado: ${globalUser.nombre} (${globalUser.id})`);
    
    let actualizados = 0;
    let yaTeníanReferido = 0;
    let asignadosAGlobal = 0;
    let usandoMatrizPadre = 0;
    let errores = 0;
    const detalles: any[] = [];
    
    for (const usuario of todosLosUsuarios) {
      try {
        // Si ya tiene referidoPor, saltarlo
        if (usuario.referidoPor) {
          yaTeníanReferido++;
          continue;
        }
        
        // Global y Admin NO necesitan referidoPor (son roots)
        if (usuario.id === globalUser.id || usuario.email === 'admin@libertyfinance.com') {
          console.log(`⚪ ${usuario.nombre} es usuario root, NO necesita referidoPor`);
          continue;
        }
        
        let referidoPorId = null;
        let metodo = '';
        
        // OPCIÓN 1: Si tiene matrizPadre, usar ese
        if (usuario.matrizPadre) {
          const padre = todosLosUsuarios.find((u: any) => u.id === usuario.matrizPadre);
          if (padre) {
            referidoPorId = padre.id;
            metodo = 'matrizPadre';
            usandoMatrizPadre++;
          }
        }
        
        // OPCIÓN 2: Si no tiene matrizPadre, asignar a Global por defecto
        if (!referidoPorId) {
          referidoPorId = globalUser.id;
          metodo = 'asignado a Global (sin matrizPadre)';
          asignadosAGlobal++;
        }
        
        // Actualizar el usuario con referidoPor
        const usuarioActualizado = {
          ...usuario,
          referidoPor: referidoPorId
        };
        
        await kv.set(`user:${usuario.id}`, usuarioActualizado);
        actualizados++;
        
        detalles.push({
          id: usuario.id.substring(0, 8),
          nombre: usuario.nombre,
          email: usuario.email,
          referidoPor: referidoPorId.substring(0, 8),
          metodo
        });
        
        console.log(`✅ ${usuario.nombre} → ${metodo} → ${referidoPorId.substring(0, 8)}`);
        
      } catch (error) {
        console.error(`❌ Error al migrar usuario ${usuario.id}:`, error);
        errores++;
      }
    }
    
    // Invalidar caché para reflejar cambios
    invalidateCache();
    
    const resultado = {
      success: true,
      resumen: {
        totalUsuarios: todosLosUsuarios.length,
        actualizados,
        yaTeníanReferido,
        usandoMatrizPadre,
        asignadosAGlobal,
        errores
      },
      detalles,
      mensaje: `✅ Migración completada: ${actualizados} usuarios actualizados`
    };
    
    console.log('🎉 MIGRACIÓN COMPLETADA:', resultado);
    return c.json(resultado);
    
  } catch (error: any) {
    console.error('❌ ERROR EN MIGRACIÓN:', error);
    return c.json({ 
      success: false,
      error: error.message,
      stack: error.stack 
    }, 500);
  }
});

// 🔍 DIAGNÓSTICO: Ver referidos de Israel Sandoval
app.get("/make-server-9f68532a/diagnostico-israel", async (c) => {
  try {
    console.log('\n🔍 ========== DIAGNÓSTICO DE ISRAEL SANDOVAL ==========');
    
    // Buscar a Israel por ID único
    const israelIdUnico = 'LF1764086702089158';
    const todosLosUsuarios = await kv.getByPrefix('user:');
    const usuariosReales = todosLosUsuarios.filter((item: any) => 
      item && typeof item === 'object' && item.id && !item.id.includes(':')
    );
    
    const israel = usuariosReales.find((u: any) => u.id_unico === israelIdUnico);
    
    if (!israel) {
      return c.json({ error: 'Israel no encontrado' }, 404);
    }
    
    console.log(`✅ Israel encontrado:`, {
      id: israel.id,
      nombre: israel.nombre,
      apellido: israel.apellido,
      email: israel.email,
      id_unico: israel.id_unico,
      referidoPor: israel.referidoPor || 'SIN REFERIDO'
    });
    
    // Buscar TODOS los usuarios que tienen referidoPor === israel.id
    const referidosDirectos = usuariosReales.filter((u: any) => u.referidoPor === israel.id);
    
    console.log(`\n👥 Total referidos directos de Israel: ${referidosDirectos.length}`);
    
    // Obtener packs de cada referido
    const allPacks = await kv.getByPrefix('pack:');
    const referidosConPacks = referidosDirectos.map((ref: any) => {
      const packsDelReferido = allPacks.filter((p: any) => p.userId === ref.id);
      const packActivo = packsDelReferido.find((p: any) => p.activo);
      const inversionTotal = packsDelReferido
        .filter((p: any) => p.activo)
        .reduce((sum: number, p: any) => sum + (p.monto || 0), 0);
      
      console.log(`   - ${ref.nombre} ${ref.apellido} (${ref.id_unico})`);
      console.log(`     Pack: ${packActivo?.nombre || 'Sin Pack'}, Inversión: $${inversionTotal}`);
      
      return {
        id: ref.id,
        id_unico: ref.id_unico,
        nombre: ref.nombre,
        apellido: ref.apellido,
        email: ref.email,
        referidoPor: ref.referidoPor,
        packActivo: packActivo ? {
          nombre: packActivo.nombre,
          monto: packActivo.monto
        } : null,
        inversionTotal,
        tienePackActivo: !!packActivo
      };
    });
    
    const referidosConPackActivo = referidosConPacks.filter(r => r.tienePackActivo);
    
    console.log(`\n���� RESUMEN:`);
    console.log(`   Total referidos directos: ${referidosDirectos.length}`);
    console.log(`   Con pack activo: ${referidosConPackActivo.length}`);
    console.log(`   Sin pack: ${referidosDirectos.length - referidosConPackActivo.length}`);
    
    // Calcular volumen total
    const volumenTotal = referidosConPacks.reduce((sum, r) => sum + r.inversionTotal, 0);
    
    console.log(`\n========== FIN DIAGNÓSTICO ==========\n`);
    
    // Invalidar caché para asegurar datos frescos
    invalidateCache();
    
    return c.json({
      success: true,
      israel: {
        id: israel.id.substring(0, 8),
        nombre: `${israel.nombre} ${israel.apellido}`,
        email: israel.email,
        id_unico: israel.id_unico,
        referidoPor: israel.referidoPor || null
      },
      referidosDirectos: {
        total: referidosDirectos.length,
        conPackActivo: referidosConPackActivo.length,
        sinPack: referidosDirectos.length - referidosConPackActivo.length,
        volumenTotal
      },
      listaReferidos: referidosConPacks,
      cacheLimpiado: true,
      mensaje: `Israel tiene ${referidosDirectos.length} referidos directos, ${referidosConPackActivo.length} con pack activo`
    });
    
  } catch (error: any) {
    console.error('❌ Error en diagnóstico de Israel:', error);
    return c.json({ 
      success: false,
      error: error.message,
      stack: error.stack 
    }, 500);
  }
});

// 🔍 DIAGNÓSTICO: Ver conexión entre Israel y Jorge
app.get("/make-server-9f68532a/diagnostico-israel-jorge", async (c) => {
  try {
    console.log('\n🔍 ========== DIAGNÓSTICO: ISRAEL → JORGE ==========');
    
    // USAR crm.getAllUsers() en lugar de kv.getByPrefix para obtener datos frescos
    const usuariosReales = await crm.getAllUsers();
    
    // Buscar a Israel
    const israel = usuariosReales.find((u: any) => u.id_unico === 'LF1764086702089158');
    
    // Buscar a Jorge de TODAS las formas posibles
    const jorge1 = usuariosReales.find((u: any) => u.id_unico === 'LF1764093102964454');
    const jorge2 = usuariosReales.find((u: any) => u.nombre?.toLowerCase().includes('jorge'));
    
    console.log('🔍 Búsqueda de Jorge:');
    console.log('  Por id_unico:', !!jorge1);
    console.log('  Por nombre:', !!jorge2);
    
    // Buscar en la matriz de Israel
    let jorgeEnMatriz = null;
    if (israel && israel.matriz) {
      console.log('🔍 Buscando en la matriz de Israel...');
      console.log('  Israel tiene matriz:', !!israel.matriz);
      
      // La matriz puede ser un array o un objeto con niveles
      if (Array.isArray(israel.matriz)) {
        jorgeEnMatriz = israel.matriz.find((u: any) => u.id_unico === 'LF1764093102964454');
      } else if (israel.matriz && typeof israel.matriz === 'object') {
        // Buscar en todos los niveles
        Object.keys(israel.matriz).forEach((nivel) => {
          const usuarios = israel.matriz[nivel];
          if (Array.isArray(usuarios)) {
            const encontrado = usuarios.find((u: any) => u.id_unico === 'LF1764093102964454');
            if (encontrado) jorgeEnMatriz = encontrado;
          }
        });
      }
      console.log('  Jorge en matriz:', !!jorgeEnMatriz);
    }
    
    // Buscar TODOS los usuarios con "jorge"
    const todosLosJorges = usuariosReales.filter((u: any) => 
      u.nombre?.toLowerCase().includes('jorge') ||
      u.apellido?.toLowerCase().includes('jorge') ||
      u.id_unico === 'LF1764093102964454'
    );
    
    if (!israel) {
      return c.json({ 
        error: 'Israel no encontrado',
        israelEncontrado: false
      }, 404);
    }
    
    console.log('✅ Israel encontrado:', {
      id: israel.id,
      nombre: israel.nombre,
      id_unico: israel.id_unico,
      referidoPor: israel.referidoPor || 'SIN REFERIDO',
      tieneMatriz: !!israel.matriz
    });
    
    const jorge = jorge1 || jorge2;
    
    if (jorge) {
      console.log('✅ Jorge encontrado en KV Store:', {
        id: jorge.id,
        nombre: jorge.nombre,
        id_unico: jorge.id_unico,
        referidoPor: jorge.referidoPor || 'SIN REFERIDO'
      });
    }
    
    // Verificar si Jorge está referido por Israel
    const jorgeApuntaAIsrael = jorge ? jorge.referidoPor === israel.id : false;
    
    console.log(`\n🔗 ¿Jorge.referidoPor apunta a Israel? ${jorgeApuntaAIsrael ? '✅ SÍ' : '❌ NO'}`);
    
    if (jorge && !jorgeApuntaAIsrael && jorge.referidoPor) {
      const referidorDeJorge = usuariosReales.find((u: any) => u.id === jorge.referidoPor);
      console.log(`⚠️ Jorge apunta a: ${referidorDeJorge?.nombre || 'Usuario no encontrado'} (${referidorDeJorge?.id_unico})`);
    }
    
    // Buscar TODOS los que apuntan a Israel
    const referidosDirectosDeIsrael = usuariosReales.filter((u: any) => u.referidoPor === israel.id);
    console.log(`\n👥 Referidos directos de Israel en KV Store: ${referidosDirectosDeIsrael.length}`);
    referidosDirectosDeIsrael.forEach((ref: any) => {
      console.log(`   - ${ref.nombre} (${ref.id_unico})`);
    });
    
    // Buscar los hijos de Jorge
    const hijosDeJorge = jorge ? usuariosReales.filter((u: any) => u.referidoPor === jorge.id) : [];
    console.log(`\n👶 Hijos directos de Jorge: ${hijosDeJorge.length}`);
    
    return c.json({
      success: true,
      israel: {
        id: israel.id,
        id_completo: israel.id,
        nombre: israel.nombre,
        id_unico: israel.id_unico,
        referidoPor: israel.referidoPor || null,
        tieneMatriz: !!israel.matriz
      },
      jorgeEnKVStore: {
        encontrado: !!jorge,
        datos: jorge ? {
          id: jorge.id,
          nombre: jorge.nombre,
          id_unico: jorge.id_unico,
          referidoPor: jorge.referidoPor || null
        } : null
      },
      jorgeEnMatrizDeIsrael: {
        encontrado: !!jorgeEnMatriz,
        datos: jorgeEnMatriz || null
      },
      todosLosJorges: todosLosJorges.map((u: any) => ({
        id: u.id,
        nombre: u.nombre,
        apellido: u.apellido,
        email: u.email,
        id_unico: u.id_unico,
        referidoPor: u.referidoPor
      })),
      analisis: {
        jorgeApuntaAIsrael,
        referidosDirectosDeIsrael: referidosDirectosDeIsrael.length,
        hijosDeJorge: hijosDeJorge.length
      },
      diagnostico: !jorge && jorgeEnMatriz 
        ? '⚠️ PROBLEMA: Jorge existe en la matriz de Israel pero NO existe como usuario independiente en KV Store'
        : jorge 
        ? '✅ Jorge existe como usuario independiente'
        : '❌ Jorge NO existe en ningún lugar',
      solucion: !jorge && jorgeEnMatriz
        ? 'Necesitamos crear el usuario Jorge en el KV Store usando los datos de la matriz'
        : jorge && !jorgeApuntaAIsrael
        ? `Necesitamos actualizar jorge.referidoPor = "${israel.id}"`
        : null
    });
    
  } catch (error: any) {
    console.error('❌ Error en diagnóstico Israel-Jorge:', error);
    return c.json({ 
      success: false,
      error: error.message,
      stack: error.stack 
    }, 500);
  }
});

// 🔍 DIAGNÓSTICO: Buscar packs de Jorge
app.get("/make-server-9f68532a/diagnostico-packs-jorge", async (c) => {
  try {
    console.log('\n🔍 ========== DIAGNÓSTICO: PACKS DE JORGE ==========');
    
    const allPacks = await crm.getAllPacks();
    const allUsers = await crm.getAllUsers();
    
    console.log(`📦 Total packs en sistema: ${allPacks.length}`);
    console.log(`👥 Total usuarios en sistema: ${allUsers.length}`);
    
    // Buscar Israel
    const israel = allUsers.find((u: any) => u.id_unico === 'LF1764086702089158');
    
    // Buscar packs que tengan matrizPadre = Israel
    const packsConIsraelComoPadre = israel ? allPacks.filter((p: any) => 
      p.matrizPadre === israel.id
    ) : [];
    
    // Buscar todos los usuarios con "jorge" en el nombre
    const usuariosJorge = allUsers.filter((u: any) => 
      u.nombre?.toLowerCase().includes('jorge') ||
      u.apellido?.toLowerCase().includes('jorge') ||
      u.id_unico === 'LF1764093102964454'
    );
    
    console.log(`\n📊 RESULTADOS:`);
    console.log(`  Packs con Israel como padre: ${packsConIsraelComoPadre.length}`);
    console.log(`  Usuarios con "Jorge": ${usuariosJorge.length}`);
    
    // Detalles de cada pack con Israel como padre
    const detallesPacks = packsConIsraelComoPadre.map((p: any) => {
      const usuario = allUsers.find((u: any) => u.id === p.userId);
      return {
        packId: p.id,
        packNombre: p.nombre,
        monto: p.monto,
        usuario: usuario ? {
          id: usuario.id,
          id_unico: usuario.id_unico,
          nombre: usuario.nombre,
          apellido: usuario.apellido,
          email: usuario.email
        } : null,
        matrizPadre: p.matrizPadre,
        matrizNivel: p.matrizNivel,
        matrizPosicion: p.matrizPosicion,
        activo: p.activo,
        createdAt: p.createdAt
      };
    });
    
    return c.json({
      success: true,
      resumen: {
        totalPacks: allPacks.length,
        totalUsuarios: allUsers.length,
        packsConIsraelComoPadre: packsConIsraelComoPadre.length,
        usuariosJorge: usuariosJorge.length
      },
      israel: israel ? {
        id: israel.id,
        id_unico: israel.id_unico,
        nombre: israel.nombre,
        apellido: israel.apellido
      } : null,
      usuariosJorge: usuariosJorge.map((u: any) => ({
        id: u.id,
        id_unico: u.id_unico,
        nombre: u.nombre,
        apellido: u.apellido,
        email: u.email,
        referidoPor: u.referidoPor,
        activo: u.activo
      })),
      packsConIsraelComoPadre: detallesPacks,
      diagnostico: packsConIsraelComoPadre.length > 0
        ? `✅ Encontrados ${packsConIsraelComoPadre.length} packs en la matriz de Israel`
        : '❌ No hay packs en la matriz de Israel',
      explicacion: 'Los packs tienen matrizPadre que indica la posición en la matriz binaria. Un usuario puede tener referidos directos pero sus packs estar en diferentes posiciones de la matriz.'
    });
    
  } catch (error: any) {
    console.error('❌ Error en diagnóstico de packs:', error);
    return c.json({ 
      success: false,
      error: error.message,
      stack: error.stack 
    }, 500);
  }
});

// 🔍 DIAGNÓSTICO: Simular exactamente lo que ve el dashboard de Israel
app.get("/make-server-9f68532a/diagnostico-dashboard-israel", async (c) => {
  try {
    const userId = "cf09eadf-d218-4590-93ff-447fd031cd42"; // UUID de Israel
    
    console.log('\n🔍 ========== SIMULANDO DASHBOARD DE ISRAEL ==========');
    
    // Obtener datos exactamente como lo hace el dashboard
    const allUsers = await getCachedUsuarios();
    const allPacks = await getCachedPacks();
    
    console.log(`📊 Total usuarios en caché: ${allUsers?.length || 0}`);
    console.log(`📦 Total packs en caché: ${allPacks?.length || 0}`);
    
    // Buscar a Israel
    const israel = allUsers.find((u: any) => u.id === userId);
    
    // Calcular referidos directos (EXACTO como línea 3313 de index.tsx)
    const referidosDirectos = allUsers?.filter((u: any) => u.referidoPor === userId) || [];
    const directosConPack = referidosDirectos.filter((ref: any) => {
      const refPacks = allPacks?.filter((p: any) => p.userId === ref.id) || [];
      return refPacks.some((p: any) => p.activo);
    });
    
    // Buscar específicamente a Jorge
    const jorge = allUsers.find((u: any) => u.id_unico === 'LF1764093102964454');
    const jorgeEstaEnReferidosDirectos = referidosDirectos.find((r: any) => r.id_unico === 'LF1764093102964454');
    
    return c.json({
      success: true,
      resumenCache: {
        totalUsuariosEnCache: allUsers?.length || 0,
        totalPacksEnCache: allPacks?.length || 0,
        cacheTimestamp: cacheTimestamp,
        cacheAge: Date.now() - cacheTimestamp,
        cacheAgeHumano: `${Math.floor((Date.now() - cacheTimestamp) / 1000)}s`
      },
      israel: israel ? {
        id: israel.id,
        id_unico: israel.id_unico,
        nombre: israel.nombre,
        apellido: israel.apellido,
        referidoPor: israel.referidoPor
      } : null,
      jorge: jorge ? {
        id: jorge.id,
        id_unico: jorge.id_unico,
        nombre: jorge.nombre,
        apellido: jorge.apellido,
        referidoPor: jorge.referidoPor,
        estaEnReferidosDirectos: !!jorgeEstaEnReferidosDirectos
      } : { encontrado: false },
      referidosDirectos: {
        total: referidosDirectos.length,
        conPack: directosConPack.length,
        lista: referidosDirectos.map((ref: any) => {
          const refPacks = allPacks.filter((p: any) => p.userId === ref.id);
          const refPackActivo = refPacks.find((p: any) => p.activo);
          return {
            id_unico: ref.id_unico,
            nombre: ref.nombre,
            apellido: ref.apellido,
            referidoPor: ref.referidoPor,
            pack: refPackActivo?.nombre || 'Sin Pack',
            tienePackActivo: !!refPackActivo
          };
        })
      },
      diagnostico: referidosDirectos.length === 0 
        ? '❌ El dashboard mostrará 0 Directos porque el array está vacío'
        : `✅ El dashboard mostrará ${referidosDirectos.length} Directos`,
      solucion: referidosDirectos.length === 0 && jorge
        ? '🔄 El caché está desactualizado. Jorge existe en crm.getAllUsers() pero no en getCachedUsuarios(). Solución: Invalidar caché.'
        : null
    });
    
  } catch (error: any) {
    console.error('❌ Error en diagnóstico de dashboard de Israel:', error);
    return c.json({ 
      success: false,
      error: error.message,
      stack: error.stack 
    }, 500);
  }
});

// 🔍 DIAGNÓSTICO AVANZADO: Analizar TODOS los registros del kv_store
app.get("/make-server-9f68532a/diagnostico-completo", async (c) => {
  try {
    console.log('🔍 INICIANDO DIAGNÓSTICO COMPLETO DE KV_STORE...');
    
    // Obtener TODOS los registros (sin filtro)
    const todosLosRegistros = await kv.getByPrefix('');
    
    console.log(`📊 Total registros en kv_store: ${todosLosRegistros.length}`);
    
    // Clasificar registros por tipo
    const usuarios = [];
    const comisiones = [];
    const pagos = [];
    const puntos = [];
    const ganancias = [];
    const otros = [];
    
    for (const registro of todosLosRegistros) {
      if (!registro || typeof registro !== 'object') continue;
      
      const keys = Object.keys(registro);
      
      // Identificar USUARIOS (tienen nombre, apellido, email)
      if (keys.includes('nombre') && keys.includes('apellido') && keys.includes('email')) {
        usuarios.push(registro);
      }
      // Identificar COMISIONES (tienen tipo, nivel, referidoId)
      else if (keys.includes('tipo') && keys.includes('nivel') && keys.includes('referidoId')) {
        comisiones.push(registro);
      }
      // Identificar PAGOS (tienen estado, metodoPago, packNombre)
      else if (keys.includes('estado') && keys.includes('metodoPago') && keys.includes('packNombre')) {
        pagos.push(registro);
      }
      // Identificar PUNTOS (tienen premio, puntos sin otros campos)
      else if (keys.includes('premio') && keys.includes('puntos') && !keys.includes('nivel')) {
        puntos.push(registro);
      }
      // Identificar GANANCIAS (tienen porcentaje)
      else if (keys.includes('porcentaje')) {
        ganancias.push(registro);
      }
      else {
        otros.push(registro);
      }
    }
    
    // Analizar usuarios
    const usuariosConReferido = usuarios.filter(u => u.referidoPor);
    const usuariosSinReferido = usuarios.filter(u => !u.referidoPor);
    const usuariosConMatriz = usuarios.filter(u => u.matrizPadre);
    const usuariosActivos = usuarios.filter(u => u.activo !== false);
    
    // 🔍 NUEVO: Verificar keys directamente en la BD
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );
    
    const { data: kvData, error: kvError } = await supabase
      .from('kv_store_9f68532a')
      .select('key, value')
      .limit(2000);
    
    const keysReales = kvData?.map(item => item.key) || [];
    const userKeys = keysReales.filter(k => k.startsWith('user:'));
    const comisionKeys = keysReales.filter(k => k.startsWith('comision:'));
    const pagoKeys = keysReales.filter(k => k.startsWith('pago:'));
    const otrasKeys = keysReales.filter(k => !k.startsWith('user:') && !k.startsWith('comision:') && !k.startsWith('pago:'));
    
    const resultado = {
      resumen: {
        totalRegistros: todosLosRegistros.length,
        usuarios: usuarios.length,
        comisiones: comisiones.length,
        pagos: pagos.length,
        puntos: puntos.length,
        ganancias: ganancias.length,
        otros: otros.length
      },
      keysEnBD: {
        totalKeys: keysReales.length,
        userKeys: userKeys.length,
        comisionKeys: comisionKeys.length,
        pagoKeys: pagoKeys.length,
        otrasKeys: otrasKeys.length,
        muestraUserKeys: userKeys.slice(0, 10),
        muestraOtrasKeys: otrasKeys.slice(0, 10)
      },
      analisisUsuarios: {
        total: usuarios.length,
        conReferidoPor: usuariosConReferido.length,
        sinReferidoPor: usuariosSinReferido.length,
        conMatrizPadre: usuariosConMatriz.length,
        activos: usuariosActivos.length,
        porcentajeSinReferido: ((usuariosSinReferido.length / usuarios.length) * 100).toFixed(1) + '%'
      },
      muestras: {
        usuario: usuarios[0] ? {
          id: usuarios[0].id?.substring(0, 8),
          nombre: usuarios[0].nombre,
          email: usuarios[0].email,
          referidoPor: usuarios[0].referidoPor?.substring(0, 8) || 'NO TIENE',
          matrizPadre: usuarios[0].matrizPadre?.substring(0, 8) || 'NO TIENE',
          claves: Object.keys(usuarios[0])
        } : null,
        comision: comisiones[0] ? {
          id: comisiones[0].id?.substring(0, 8),
          tipo: comisiones[0].tipo,
          monto: comisiones[0].monto,
          claves: Object.keys(comisiones[0])
        } : null,
        pago: pagos[0] ? {
          id: pagos[0].id?.substring(0, 8),
          monto: pagos[0].monto,
          estado: pagos[0].estado,
          claves: Object.keys(pagos[0])
        } : null
      },
      advertencia: usuariosSinReferido.length > 0 ? 
        `⚠️ ${usuariosSinReferido.length} usuarios NO tienen campo referidoPor. Ejecutar migración.` : 
        '✅ Todos los usuarios tienen campo referidoPor',
      alerta: usuarios.length < 100 ? 
        `🚨 CRÍTICO: Solo hay ${usuarios.length} usuarios pero deberían ser ~140+. Verificar keys en BD.` : 
        null
    };
    
    console.log('🎉 DIAGNÓSTICO COMPLETADO:', resultado);
    return c.json(resultado);
    
  } catch (error: any) {
    console.error('❌ ERROR EN DIAGNÓSTICO:', error);
    return c.json({ 
      success: false,
      error: error.message,
      stack: error.stack 
    }, 500);
  }
});

// 🔍 NUEVO ENDPOINT: Cargar TODOS los usuarios reales desde la BD
app.get("/make-server-9f68532a/cargar-todos-usuarios", async (c) => {
  try {
    console.log('🔍 CARGANDO TODOS LOS USUARIOS DESDE BD...');
    
    // Usar la MISMA función que usa la lista de admin
    const usuariosDesdeCache = await getCachedUsuarios();
    console.log(`📊 Total usuarios desde getCachedUsuarios(): ${usuariosDesdeCache.length}`);
    
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );
    
    // Buscar TODAS las keys que empiezan con 'user:' (con paginación)
    let allKeys: any[] = [];
    let pageSize = 500;
    let page = 0;
    let hasMore = true;
    
    while (hasMore) {
      const { data: pageData, error: kvError } = await supabase
        .from('kv_store_9f68532a')
        .select('key, value')
        .like('key', 'user:%')
        .range(page * pageSize, (page + 1) * pageSize - 1);
      
      if (kvError) {
        console.error('❌ Error al cargar keys:', kvError);
        break;
      }
      
      if (!pageData || pageData.length === 0) {
        hasMore = false;
      } else {
        allKeys = [...allKeys, ...pageData];
        console.log(`   📄 Página ${page + 1}: ${pageData.length} keys (Total: ${allKeys.length})`);
        
        if (pageData.length < pageSize) {
          hasMore = false;
        }
        page++;
      }
    }
    
    const kvData = allKeys;
    console.log(`📊 Total keys encontradas con 'user:' (CON PAGINACIÓN): ${kvData.length}`);
    
    // Filtrar SOLO las keys de usuarios principales (formato: user:{uuid})
    // Excluir: user:email:, user:idUnico:, user:{uuid}:comision:, etc.
    const uuidRegex = /^user:[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
    
    const usuariosReales = [];
    const keysDescartadas = {
      indices: 0,
      comisiones: 0,
      rendimientos: 0,
      otros: 0
    };
    
    for (const item of kvData || []) {
      const key = item.key;
      
      // Solo aceptar keys con formato: user:{uuid} (nada más)
      if (uuidRegex.test(key)) {
        try {
          const userData = typeof item.value === 'string' ? JSON.parse(item.value) : item.value;
          if (userData && userData.email && userData.nombre) {
            usuariosReales.push(userData);
          }
        } catch (e) {
          console.error(`Error parseando usuario ${key}:`, e);
        }
      } else {
        // Clasificar keys descartadas
        if (key.includes(':email:') || key.includes(':idUnico:')) {
          keysDescartadas.indices++;
        } else if (key.includes(':comision:')) {
          keysDescartadas.comisiones++;
        } else if (key.includes(':rendimiento:')) {
          keysDescartadas.rendimientos++;
        } else {
          keysDescartadas.otros++;
        }
      }
    }
    
    console.log(`✅ Usuarios reales encontrados: ${usuariosReales.length}`);
    console.log(`📋 Keys descartadas:`, keysDescartadas);
    
    // Analizar referidos
    const conReferido = usuariosReales.filter(u => u.referidoPor).length;
    const sinReferido = usuariosReales.filter(u => !u.referidoPor).length;
    
    const resultado = {
      success: true,
      comparacion: {
        usuariosEnCache: usuariosDesdeCache.length,
        usuariosEnKVStore: usuariosReales.length,
        diferencia: usuariosDesdeCache.length - usuariosReales.length,
        mensaje: usuariosDesdeCache.length === usuariosReales.length ? 
          '✅ Coinciden perfectamente' : 
          `⚠️ Hay ${usuariosDesdeCache.length - usuariosReales.length} usuarios más en caché`
      },
      resumen: {
        totalUsuariosReales: usuariosReales.length,
        conReferidoPor: conReferido,
        sinReferidoPor: sinReferido,
        porcentajeSinReferido: ((sinReferido / usuariosReales.length) * 100).toFixed(1) + '%'
      },
      keysAnalizadas: {
        totalKeys: kvData.length,
        usuariosReales: usuariosReales.length,
        keysDescartadas
      },
      muestraUsuarios: usuariosReales.slice(0, 5).map(u => ({
        id: u.id?.substring(0, 8),
        nombre: u.nombre,
        email: u.email,
        idUnico: u.id_unico,
        referidoPor: u.referidoPor?.substring(0, 8) || 'SIN REFERIDO',
        activo: u.activo
      })),
      usuariosSinReferido: usuariosReales.filter(u => !u.referidoPor).map(u => ({
        id: u.id?.substring(0, 8),
        nombre: u.nombre,
        email: u.email,
        idUnico: u.id_unico
      }))
    };
    
    console.log('🎉 CARGA COMPLETADA:', resultado.resumen);
    return c.json(resultado);
    
  } catch (error: any) {
    console.error('❌ ERROR CARGANDO USUARIOS:', error);
    return c.json({ 
      success: false,
      error: error.message,
      stack: error.stack 
    }, 500);
  }
});

// 🔍 ENDPOINT DEBUG: Verificar comisiones de un usuario
app.get("/make-server-9f68532a/debug/comisiones/:userId", async (c) => {
  try {
    const userId = c.req.param('userId');
    console.log(`\n🔍 ========== DEBUG COMISIONES PARA ${userId} ==========`);
    
    // 1. Verificar que el usuario existe
    const user = await crm.getUserById(userId);
    if (!user) {
      console.log(`❌ Usuario no encontrado`);
      return c.json({ error: "Usuario no encontrado" }, 404);
    }
    
    console.log(`✅ Usuario encontrado: ${user.nombre} ${user.apellido} (${user.id_unico})`);
    
    // 2. Obtener comisiones por índice de usuario
    const userComisiones = await crm.getComisionesByUserId(userId);
    console.log(`📊 Comisiones por índice de usuario: ${userComisiones?.length || 0}`);
    
    // 3. Obtener TODAS las comisiones globales
    const todasLasComisiones = await crm.getAllComisiones();
    console.log(`📊 Total comisiones en sistema: ${todasLasComisiones?.length || 0}`);
    
    // 4. Filtrar comisiones del usuario desde el índice global
    const comisionesDelUsuarioGlobal = todasLasComisiones?.filter((c: any) => c?.userId === userId) || [];
    console.log(`📊 Comisiones del usuario en índice global: ${comisionesDelUsuarioGlobal.length}`);
    
    // 5. Verificar referidos directos
    const referidosDirectos = await crm.getReferidosDirectos(userId);
    console.log(`👥 Referidos directos: ${referidosDirectos.length}`);
    referidosDirectos.forEach((ref: any, idx: number) => {
      console.log(`   ${idx + 1}. ${ref.nombre} ${ref.apellido} (${ref.id_unico}) - referidoPor: ${ref.referidoPor}`);
    });
    
    // 6. Verificar packs del usuario
    const userPacks = await crm.getPacksByUserId(userId);
    console.log(`📦 Packs del usuario: ${userPacks?.length || 0}`);
    userPacks?.forEach((pack: any) => {
      console.log(`   - ${pack.nombre} ($${pack.monto}) - Activo: ${pack.activo} - Fecha: ${pack.fechaCompra}`);
    });
    
    console.log(`\n========== FIN DEBUG COMISIONES ==========\n`);
    
    return c.json({
      usuario: {
        id: user.id,
        id_unico: user.id_unico,
        nombre: user.nombre,
        apellido: user.apellido,
        email: user.email
      },
      comisiones: {
        porIndiceUsuario: userComisiones || [],
        totalPorIndiceUsuario: userComisiones?.length || 0,
        porIndiceGlobal: comisionesDelUsuarioGlobal,
        totalPorIndiceGlobal: comisionesDelUsuarioGlobal.length,
        ejemplos: (userComisiones || []).slice(0, 5).map((c: any) => ({
          tipo: c.tipo,
          monto: c.monto,
          fecha: c.fecha,
          descripcion: c.descripcion
        }))
      },
      tiposUnicos: userComisiones?.length > 0 ? [...new Set(userComisiones.map((c: any) => c.tipo))] : [],
      porTipo: {
        red: userComisiones?.filter((c: any) => c.tipo === 'red').reduce((sum, c) => sum + c.monto, 0) || 0,
        rendimiento: userComisiones?.filter((c: any) => c.tipo === 'rendimiento').reduce((sum, c) => sum + c.monto, 0) || 0,
        patrocinio: userComisiones?.filter((c: any) => c.tipo === 'patrocinio').reduce((sum, c) => sum + c.monto, 0) || 0,
        rangos: userComisiones?.filter((c: any) => c.tipo === 'rangos').reduce((sum, c) => sum + c.monto, 0) || 0
      },
      referidosDirectos: {
        total: referidosDirectos.length,
        lista: referidosDirectos.map((ref: any) => ({
          id_unico: ref.id_unico,
          nombre: ref.nombre,
          apellido: ref.apellido,
          email: ref.email,
          referidoPor: ref.referidoPor
        }))
      },
      packs: {
        total: userPacks?.length || 0,
        activos: userPacks?.filter((p: any) => p.activo).length || 0,
        lista: userPacks || []
      }
    });
  } catch (error) {
    console.error('❌ Error en debug/comisiones:', error);
    return c.json({ error: error instanceof Error ? error.message : String(error) }, 500);
  }
});

// 🔍 ENDPOINT DEBUG: Ver TODOS los packs de Israel Sandoval directamente desde KV
app.get("/make-server-9f68532a/debug/packs-israel", async (c) => {
  try {
    const israelId = 'cf09eadf-d218-4590-93ff-447fd031cd42';
    console.log(`\n🔍 ========== DEBUG: PACKS DE ISRAEL ==========`);
    
    // Leer TODOS los packs desde KV
    const allPacks = await kv.getByPrefix('pack:');
    console.log(`📦 Total packs en sistema: ${allPacks.length}`);
    
    // Filtrar packs de Israel
    const israelPacks = allPacks.filter((p: any) => p && p.userId === israelId);
    console.log(`📦 Packs de Israel encontrados: ${israelPacks.length}`);
    
    israelPacks.forEach((pack: any, idx: number) => {
      console.log(`\n  ${idx + 1}. ${pack.nombre} (${pack.id})`);
      console.log(`     Monto: $${pack.monto}`);
      console.log(`     Rendimiento: $${pack.rendimientoAcumulado || 0}`);
      console.log(`     Porcentaje: ${((pack.rendimientoAcumulado || 0) / pack.monto * 100).toFixed(2)}%`);
      console.log(`     Activo (bool): ${pack.activo}`);
      console.log(`     Status (string): ${pack.status || 'sin campo status'}`);
      console.log(`     Fecha Compra: ${pack.fechaCompra}`);
      console.log(`     Fecha Desactivación: ${pack.fechaDesactivacion || 'N/A'}`);
      console.log(`     Motivo Desactivación: ${pack.motivoDesactivacion || 'N/A'}`);
    });
    
    return c.json({
      success: true,
      totalPacksSistema: allPacks.length,
      packsIsrael: israelPacks.length,
      packs: israelPacks.map((p: any) => ({
        id: p.id,
        nombre: p.nombre,
        monto: p.monto,
        rendimientoAcumulado: p.rendimientoAcumulado || 0,
        porcentaje: ((p.rendimientoAcumulado || 0) / p.monto * 100).toFixed(2),
        limite200: p.monto * 2,
        activo: p.activo,
        status: p.status,
        fechaCompra: p.fechaCompra,
        fechaDesactivacion: p.fechaDesactivacion,
        motivoDesactivacion: p.motivoDesactivacion
      }))
    });
  } catch (error) {
    console.error('❌ Error en debug packs Israel:', error);
    return c.json({ error: error instanceof Error ? error.message : String(error) }, 500);
  }
});

// 🔍 ENDPOINT DEBUG: Ver comisiones de Israel y a qué packs están asociadas
app.get("/make-server-9f68532a/debug/comisiones-israel", async (c) => {
  try {
    const israelId = 'cf09eadf-d218-4590-93ff-447fd031cd42';
    console.log(`\n🔍 ========== DEBUG: COMISIONES DE ISRAEL ==========`);
    
    // Obtener todas las comisiones de Israel
    const comisiones = await crm.getComisionesByUserId(israelId);
    console.log(`📊 Total comisiones de Israel: ${comisiones.length}`);
    
    // Agrupar comisiones por packId
    const comisionesPorPack = new Map<string, any[]>();
    const comisionesSinPack: any[] = [];
    
    comisiones.forEach((c: any) => {
      if (c.packId) {
        const lista = comisionesPorPack.get(c.packId) || [];
        lista.push(c);
        comisionesPorPack.set(c.packId, lista);
      } else {
        comisionesSinPack.push(c);
      }
    });
    
    console.log(`📦 Packs con comisiones: ${comisionesPorPack.size}`);
    console.log(`⚠️ Comisiones sin packId: ${comisionesSinPack.length}`);
    
    // Analizar cada grupo de comisiones
    const analisis: any[] = [];
    
    for (const [packId, comisionesDelPack] of comisionesPorPack.entries()) {
      const totalDelPack = comisionesDelPack.reduce((sum, c) => sum + (c.monto || 0), 0);
      
      // Verificar si el pack existe
      const packExiste = await kv.get(`pack:${packId}`);
      
      console.log(`\n  Pack ID: ${packId.substring(0, 8)}...`);
      console.log(`     Comisiones: ${comisionesDelPack.length}`);
      console.log(`     Total: $${totalDelPack.toFixed(2)}`);
      console.log(`     Pack existe en KV: ${packExiste ? 'SÍ' : 'NO'}`);
      if (packExiste) {
        console.log(`     Pack: ${packExiste.nombre} - Activo: ${packExiste.activo} - Status: ${packExiste.status || 'N/A'}`);
      }
      
      analisis.push({
        packId: packId,
        totalComisiones: comisionesDelPack.length,
        montoTotal: totalDelPack.toFixed(2),
        packExiste: !!packExiste,
        packInfo: packExiste ? {
          nombre: packExiste.nombre,
          monto: packExiste.monto,
          activo: packExiste.activo,
          status: packExiste.status
        } : null,
        primeraComision: comisionesDelPack[0],
        ultimaComision: comisionesDelPack[comisionesDelPack.length - 1]
      });
    }
    
    const totalComisiones = comisiones.reduce((sum, c) => sum + (c.monto || 0), 0);
    
    return c.json({
      success: true,
      totalComisiones: comisiones.length,
      montoTotal: totalComisiones.toFixed(2),
      comisionesPorPack: comisionesPorPack.size,
      comisionesSinPack: comisionesSinPack.length,
      analisis: analisis
    });
  } catch (error) {
    console.error('❌ Error en debug comisiones Israel:', error);
    return c.json({ error: error instanceof Error ? error.message : String(error) }, 500);
  }
});

// 🔍 ENDPOINT DEBUG: Ver historial de TODOS los packs de Israel (incluyendo eliminados)
app.get("/make-server-9f68532a/debug/historial-packs-israel", async (c) => {
  try {
    const israelId = 'cf09eadf-d218-4590-93ff-447fd031cd42';
    console.log(`\n🔍 ========== DEBUG: HISTORIAL DE PACKS DE ISRAEL ==========`);
    
    // Obtener todas las comisiones de Israel
    const comisiones = await crm.getComisionesByUserId(israelId);
    console.log(`📊 Total comisiones de Israel: ${comisiones.length}`);
    
    // Extraer todos los packIds únicos mencionados en las comisiones
    const packIdsEnComisiones = [...new Set(comisiones.map(c => c.packId).filter(Boolean))];
    console.log(`📦 Pack IDs únicos en comisiones: ${packIdsEnComisiones.length}`);
    
    // Para cada packId, intentar obtenerlo desde KV y analizar las comisiones
    const historialPacks: any[] = [];
    
    for (const packId of packIdsEnComisiones) {
      const pack = await kv.get(`pack:${packId}`);
      const comisionesDelPack = comisiones.filter(c => c.packId === packId);
      const totalRendimiento = comisionesDelPack.reduce((sum, c) => sum + (c.monto || 0), 0);
      
      // Calcular el porcentaje de rendimiento
      const montoOriginal = pack?.monto || 0;
      const porcentaje = montoOriginal > 0 ? (totalRendimiento / montoOriginal) * 100 : 0;
      
      console.log(`\n  Pack ID: ${packId.substring(0, 8)}...`);
      console.log(`     Pack existe: ${pack ? 'SÍ' : 'NO (ELIMINADO)'}`);
      if (pack) {
        console.log(`     Nombre: ${pack.nombre}`);
        console.log(`     Monto: $${pack.monto}`);
        console.log(`     Activo: ${pack.activo}`);
        console.log(`     Status: ${pack.status || 'N/A'}`);
        console.log(`     Fecha Compra: ${pack.fechaCompra}`);
        if (pack.fechaDesactivacion) {
          console.log(`     Fecha Desactivación: ${pack.fechaDesactivacion}`);
          console.log(`     Motivo: ${pack.motivoDesactivacion}`);
        }
      }
      console.log(`     Comisiones: ${comisionesDelPack.length}`);
      console.log(`     Rendimiento acumulado: $${totalRendimiento.toFixed(2)}`);
      console.log(`     Porcentaje: ${porcentaje.toFixed(2)}%`);
      console.log(`     Límite 200%: $${montoOriginal * 2}`);
      console.log(`     Estado esperado: ${porcentaje >= 200 ? 'INACTIVO (llegó al 200%)' : 'ACTIVO'}`);
      
      historialPacks.push({
        packId: packId,
        existe: !!pack,
        packInfo: pack ? {
          nombre: pack.nombre,
          monto: pack.monto,
          activo: pack.activo,
          status: pack.status,
          fechaCompra: pack.fechaCompra,
          fechaDesactivacion: pack.fechaDesactivacion,
          motivoDesactivacion: pack.motivoDesactivacion
        } : null,
        totalComisiones: comisionesDelPack.length,
        rendimientoAcumulado: totalRendimiento.toFixed(2),
        porcentajeRendimiento: porcentaje.toFixed(2),
        limite200: montoOriginal * 2,
        deberiaEstarActivo: porcentaje < 200,
        primeraComision: comisionesDelPack[0],
        ultimaComision: comisionesDelPack[comisionesDelPack.length - 1]
      });
    }
    
    // Comisiones sin packId
    const comisionesSinPack = comisiones.filter(c => !c.packId);
    console.log(`\n⚠️ Comisiones sin packId: ${comisionesSinPack.length}`);
    
    return c.json({
      success: true,
      totalComisiones: comisiones.length,
      packsEnHistorial: packIdsEnComisiones.length,
      comisionesSinPack: comisionesSinPack.length,
      historial: historialPacks
    });
  } catch (error) {
    console.error('❌ Error en debug historial packs Israel:', error);
    return c.json({ error: error instanceof Error ? error.message : String(error) }, 500);
  }
});

// 🔧 ENDPOINT: Reparar cuenta de Israel (reconstruir packs y redistribuir comisiones)
// ⚡ OPTIMIZADO: timeout extendido y mejor manejo de errores + headers anti-timeout
app.post("/make-server-9f68532a/admin/reparar-cuenta-israel", async (c) => {
  const startTime = Date.now();
  try {
    console.log('🔧 [REPARACIÓN] Iniciando ejecución inmediata...');
    
    // ⚡ ESTRATEGIA ANTI-TIMEOUT: Configurar headers para mantener la conexión viva
    // Estos headers previenen que proxies/navegadores aborten la conexión
    c.header('Cache-Control', 'no-cache, no-store, must-revalidate');
    c.header('Pragma', 'no-cache');
    c.header('Expires', '0');
    c.header('Connection', 'keep-alive');
    c.header('X-Accel-Buffering', 'no'); // Deshabilitar buffering de Nginx/proxy
    
    // ⚡ Ejecutar la reparación con configuración optimizada
    const resultado = await repararCuentaIsrael();
    
    const duration = ((Date.now() - startTime) / 1000).toFixed(2);
    console.log(`✅ [REPARACIÓN] Completada en ${duration}s`);
    
    // ⚡ Invalidar caché
    cacheUsuarios = null;
    cachePacks = null;
    cacheComisiones = null;
    cacheDashboards.clear();
    
    return c.json({
      ...resultado,
      duration
    }, 200, {
      'Cache-Control': 'no-cache, no-store, must-revalidate',
      'Pragma': 'no-cache',
      'Expires': '0',
      'X-Duration': duration
    });
  } catch (error) {
    const duration = ((Date.now() - startTime) / 1000).toFixed(2);
    console.error(`❌ [REPARACIÓN] Error después de ${duration}s:`, error);
    return c.json({ 
      success: false,
      error: error instanceof Error ? error.message : String(error),
      stack: error instanceof Error ? error.stack : undefined,
      duration 
    }, 500);
  }
});

// 🔬 ENDPOINT: Diagnóstico detallado de comisiones de Israel (detectar duplicados)
app.get("/make-server-9f68532a/debug/comisiones-detallado-israel", async (c) => {
  const israelId = 'cf09eadf-d218-4590-93ff-447fd031cd42';
  
  try {
    console.log('🔍 ========== DIAGNÓSTICO DETALLADO DE COMISIONES ==========');
    
    // 1. Obtener TODOS los packs de Israel
    const allPacksKeys = await kv.getByPrefix('pack:');
    const israelPacks = allPacksKeys.filter((p: any) => p.userId === israelId);
    
    console.log(`📦 Packs de Israel encontrados: ${israelPacks.length}`);
    
    // 2. Obtener TODAS las comisiones
    const allComisiones = await kv.getByPrefix('comision:');
    const israelComisiones = allComisiones.filter((c: any) => c.userId === israelId);
    
    console.log(`💰 Comisiones de Israel: ${israelComisiones.length}`);
    
    // 3. Crear un mapa de packId → comisiones
    const comisionesPorPack = new Map<string, any[]>();
    const comisionesSinPack: any[] = [];
    const comisionesPackInexistente: any[] = [];
    
    // IDs de los packs actuales de Israel
    const packIdsActuales = new Set(israelPacks.map(p => p.id));
    
    console.log(`🔑 Pack IDs actuales:`, Array.from(packIdsActuales));
    
    for (const comision of israelComisiones) {
      if (!comision.packId) {
        comisionesSinPack.push(comision);
      } else if (!packIdsActuales.has(comision.packId)) {
        comisionesPackInexistente.push(comision);
      } else {
        if (!comisionesPorPack.has(comision.packId)) {
          comisionesPorPack.set(comision.packId, []);
        }
        comisionesPorPack.get(comision.packId)!.push(comision);
      }
    }
    
    console.log(`\n📊 DISTRIBUCIÓN:`);
    console.log(`   - Con pack válido: ${Array.from(comisionesPorPack.values()).reduce((sum, arr) => sum + arr.length, 0)}`);
    console.log(`   - Sin pack (null): ${comisionesSinPack.length}`);
    console.log(`   - Pack inexistente: ${comisionesPackInexistente.length}`);
    
    // 4. Crear reporte detallado por pack
    const reportePacks: any[] = [];
    
    for (const pack of israelPacks) {
      const comisionesEstePack = comisionesPorPack.get(pack.id) || [];
      const totalMonto = comisionesEstePack.reduce((sum, c) => sum + (c.monto || 0), 0);
      
      reportePacks.push({
        packId: pack.id.substring(0, 8),
        nombre: pack.nombre,
        montoOriginal: pack.monto,
        rendimientoAcumulado: pack.rendimientoAcumulado || 0,
        porcentaje: ((pack.rendimientoAcumulado || 0) / pack.monto * 100).toFixed(2),
        activo: pack.activo,
        cantidadComisiones: comisionesEstePack.length,
        montoTotalComisiones: totalMonto.toFixed(2),
        primerasComisiones: comisionesEstePack.slice(0, 3).map(c => ({
          id: c.id.substring(0, 8),
          monto: c.monto,
          fecha: c.createdAt,
          tipo: c.tipo
        }))
      });
    }
    
    // 5. Verificar si hay comisiones duplicadas (misma comisión en múltiples packs)
    const comisionesContadas = new Map<string, string[]>();
    
    for (const [packId, comisiones] of comisionesPorPack.entries()) {
      for (const comision of comisiones) {
        if (!comisionesContadas.has(comision.id)) {
          comisionesContadas.set(comision.id, []);
        }
        comisionesContadas.get(comision.id)!.push(packId);
      }
    }
    
    const comisionesDuplicadas: any[] = [];
    for (const [comisionId, packIds] of comisionesContadas.entries()) {
      if (packIds.length > 1) {
        const comision = israelComisiones.find(c => c.id === comisionId);
        comisionesDuplicadas.push({
          comisionId: comisionId.substring(0, 8),
          monto: comision?.monto,
          enPacks: packIds.length,
          packIds: packIds.map(id => id.substring(0, 8))
        });
      }
    }
    
    console.log(`\n🚨 COMISIONES DUPLICADAS: ${comisionesDuplicadas.length}`);
    
    // 6. Crear respuesta completa
    const respuesta = {
      resumen: {
        totalComisiones: israelComisiones.length,
        montoTotal: israelComisiones.reduce((sum, c) => sum + (c.monto || 0), 0).toFixed(2),
        totalPacks: israelPacks.length,
        comisionesConPackValido: Array.from(comisionesPorPack.values()).reduce((sum, arr) => sum + arr.length, 0),
        comisionesSinPack: comisionesSinPack.length,
        comisionesPackInexistente: comisionesPackInexistente.length,
        comisionesDuplicadas: comisionesDuplicadas.length
      },
      packs: reportePacks,
      problemas: {
        comisionesDuplicadas: comisionesDuplicadas.slice(0, 10), // Primeras 10
        comisionesSinPack: comisionesSinPack.slice(0, 5).map(c => ({
          id: c.id.substring(0, 8),
          monto: c.monto,
          fecha: c.createdAt
        })),
        comisionesPackInexistente: comisionesPackInexistente.slice(0, 5).map(c => ({
          id: c.id.substring(0, 8),
          monto: c.monto,
          packId: c.packId?.substring(0, 8),
          fecha: c.createdAt
        }))
      },
      packIdsActuales: Array.from(packIdsActuales).map(id => id.substring(0, 8))
    };
    
    console.log('✅ Diagnóstico completado');
    
    return c.json(respuesta);
    
  } catch (error: any) {
    console.error('❌ Error en diagnóstico detallado:', error);
    return c.json({ error: error.message }, 500);
  }
});

// Health check endpoint (INCLUYE diagnóstico completo CON PAGINACIÓN)
app.get("/make-server-9f68532a/health", async (c) => {
  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );
    
    // Contar TODOS los usuarios con paginación
    let totalCount = 0;
    let pageSize = 1000;
    let currentPage = 0;
    let hasMore = true;
    
    while (hasMore && currentPage < 20) { // Máximo 20 páginas = 20000 registros
      const { data, error } = await supabase
        .from('kv_store_9f68532a')
        .select('key')
        .like('key', 'user:%')
        .range(currentPage * pageSize, (currentPage + 1) * pageSize - 1);
      
      if (error || !data || data.length === 0) {
        hasMore = false;
      } else {
        const uuidRegex = /^user:[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
        const validUsers = data.filter((row: any) => uuidRegex.test(row.key));
        totalCount += validUsers.length;
        
        if (data.length < pageSize) {
          hasMore = false;
        }
        currentPage++;
      }
    }
    
    const totalUsuarios = totalCount;
    
    // Buscar Pedri en TODOS los registros (sin order porque no hay created_at)
    const { data: allUsers } = await supabase
      .from('kv_store_9f68532a')
      .select('key, value')
      .like('key', 'user:%')
      .limit(20000);
    
    const allRecent = allUsers || [];
    
    const pedri = allRecent.find((row: any) => {
      try {
        const user = typeof row.value === 'string' ? JSON.parse(row.value) : row.value;
        const nombre = user?.nombre?.toLowerCase() || '';
        const apellido = user?.apellido?.toLowerCase() || '';
        return nombre.includes('pedri') || apellido.includes('vilchez');
      } catch {
        return false;
      }
    });
    
    let pedriData = null;
    if (pedri) {
      const user = typeof pedri.value === 'string' ? JSON.parse(pedri.value) : pedri.value;
      pedriData = {
        id_unico: user.id_unico,
        nombre: user.nombre,
        apellido: user.apellido,
        email: user.email,
        fechaRegistro: user.fechaRegistro
      };
    }
    
    return c.json({ 
      status: "✅ SERVIDOR ACTIVO", 
      version: "1.3-PAGINACION", 
      deployTime: new Date().toISOString(),
      totalUsuarios,
      limiteActivo: "✅ PAGINACIÓN COMPLETA (sin límites)",
      pedriVilchez: pedriData ? `✅ ENCONTRADO: ${pedriData.nombre} ${pedriData.apellido}` : "⚠️ NO encontrado en últimos 2000 registros",
      pedriDatos: pedriData
    });
  } catch (error: any) {
    return c.json({ 
      status: "ok but error in extended check", 
      version: "1.3-PAGINACION", 
      error: error.message 
    });
  }
});

// 🔓 ENDPOINT PÚBLICO: Verificar despliegue y límite 10000
app.get("/make-server-9f68532a/public/check-deploy", async (c) => {
  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );
    
    // Test CON límite 10000
    const { data: con10k, error } = await supabase
      .from('kv_store_9f68532a')
      .select('key')
      .like('key', 'user:%')
      .limit(10000);
    
    if (error) throw error;
    
    const uuidRegex = /^user:[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    const totalUsuarios = con10k?.filter((row: any) => uuidRegex.test(row.key)).length || 0;
    
    return c.json({
      status: "✅ SERVIDOR ACTIVO",
      version: "1.2",
      limiteActivo: 10000,
      totalUsuarios,
      codigoDesplegado: totalUsuarios > 1000 ? "✅ SÍ - límite 10k aplicado" : "⚠️ NO - aún con límite 1000",
      timestamp: new Date().toISOString()
    });
  } catch (error: any) {
    return c.json({ 
      status: "❌ ERROR",
      error: error.message 
    }, 500);
  }
});

// ���� ENDPOINT PÚBLICO: Buscar Pedri Vilchez
app.get("/make-server-9f68532a/public/buscar-pedri", async (c) => {
  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );
    
    // Obtener últimos 100 usuarios
    const { data: allUsers, error } = await supabase
      .from('kv_store_9f68532a')
      .select('key, value')
      .like('key', 'user:%')
      .order('created_at', { ascending: false })
      .limit(100);
    
    if (error) throw error;
    
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    const usuarios = allUsers
      ?.filter((row: any) => {
        const key = row.key as string;
        if (!key?.startsWith('user:')) return false;
        const afterPrefix = key.substring(5);
        return !afterPrefix.includes(':') && uuidRegex.test(afterPrefix);
      })
      .map((row: any) => {
        try {
          const user = typeof row.value === 'string' ? JSON.parse(row.value) : row.value;
          return {
            id_unico: user.id_unico,
            nombre: user.nombre,
            apellido: user.apellido,
            email: user.email,
            telefono: user.telefono,
            fechaRegistro: user.fechaRegistro
          };
        } catch {
          return null;
        }
      })
      .filter((u: any) => u !== null) || [];
    
    // Buscar Pedri
    const pedri = usuarios.find((u: any) => 
      u.nombre?.toLowerCase().includes('pedri') || 
      u.apellido?.toLowerCase().includes('vilchez') ||
      u.email?.toLowerCase().includes('pedri')
    );
    
    return c.json({
      totalRegistrosRecientes: usuarios.length,
      pedriEncontrado: !!pedri,
      datosPedri: pedri || null,
      ultimos5Usuarios: usuarios.slice(0, 5),
      mensaje: pedri 
        ? "✅ Pedri Vilchez SÍ está en la base de datos" 
        : "⚠️ No encontrado en los últimos 100 registros"
    });
  } catch (error: any) {
    return c.json({ error: error.message }, 500);
  }
});

// DEBUG: Endpoint rápido para verificar usuarios
app.get("/make-server-9f68532a/debug/users-count", async (c) => {
  try {
    const usuarios = await crm.getAllUsers();
    console.log(`DEBUG: Total usuarios en KV: ${usuarios.length}`);
    
    const ultimos5 = usuarios
      .sort((a, b) => new Date(b.fechaRegistro || 0).getTime() - new Date(a.fechaRegistro || 0).getTime())
      .slice(0, 5)
      .map(u => ({
        id_unico: u.id_unico,
        nombre: u.nombre,
        apellido: u.apellido,
        email: u.email,
        fechaRegistro: u.fechaRegistro
      }));
    
    return c.json({
      total: usuarios.length,
      ultimos5
    });
  } catch (error) {
    console.error('Error en debug:', error);
    return c.json({ error: String(error) }, 500);
  }
});

// DEBUG: Contar usuarios directamente en la base de datos
app.get("/make-server-9f68532a/debug/count-raw", async (c) => {
  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );
    
    const { data: rawData, error } = await supabase
      .from('kv_store_9f68532a')
      .select('key, value')
      .like('key', 'user:%');
    
    if (error) {
      return c.json({ error: error.message }, 500);
    }
    
    const allKeys = (rawData || []).map(r => r.key);
    const userKeys = allKeys.filter(k => !k.includes('email:') && !k.includes('idUnico:'));
    const emailKeys = allKeys.filter(k => k.includes('email:'));
    const idUnicoKeys = allKeys.filter(k => k.includes('idUnico:'));
    
    console.log('📊 CONTEO DIRECTO EN BASE DE DATOS:');
    console.log(`   Total registros con prefijo user:: ${rawData?.length || 0}`);
    console.log(`   Usuarios (user:UUID): ${userKeys.length}`);
    console.log(`   Mapeo emails: ${emailKeys.length}`);
    console.log(`   Mapeo IDs únicos: ${idUnicoKeys.length}`);
    
    return c.json({
      totalRegistros: rawData?.length || 0,
      usuarios: userKeys.length,
      mapeoEmails: emailKeys.length,
      mapeoIdsUnicos: idUnicoKeys.length,
      ultimosUsuarios: userKeys.slice(-5)
    });
  } catch (error) {
    console.error('Error en count-raw:', error);
    return c.json({ error: String(error) }, 500);
  }
});

// DEBUG: Ver TODOS los usuarios sin filtrar (RAW)
app.get("/make-server-9f68532a/debug/all-users-raw", async (c) => {
  try {
    console.log('🔍 OBTENIENDO TODOS LOS USUARIOS SIN FILTRAR...');
    
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );
    
    // Obtener TODOS los registros user:UUID (sin mapeos)
    const { data: rawData, error } = await supabase
      .from('kv_store_9f68532a')
      .select('key, value')
      .like('key', 'user:%');
    
    if (error) {
      return c.json({ error: error.message }, 500);
    }
    
    // Filtrar solo registros de usuarios (no mapeos ni sub-colecciones)
    const usuarios = (rawData || [])
      .filter((row: any) => {
        const key = row.key as string;
        
        // SOLO aceptar registros con formato exacto: user:{UUID}
        // Un UUID tiene 36 caracteres (32 hex + 4 guiones)
        if (!key.startsWith('user:')) {
          return false;
        }
        
        // Remover el prefijo "user:"
        const afterPrefix = key.substring(5);
        
        // Verificar que NO tenga más ":" (lo que indicaría sub-colecciones como :comision:, :rendimiento:, etc.)
        if (afterPrefix.includes(':')) {
          return false;
        }
        
        // Verificar que sea un UUID válido (36 caracteres con guiones)
        const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
        if (!uuidRegex.test(afterPrefix)) {
          return false;
        }
        
        // Excluir registros sin value
        if (!row.value || typeof row.value !== 'object') {
          return false;
        }
        
        return true;
      })
      .map((row: any) => {
        const id = row.key.replace('user:', '');
        return {
          id,
          key: row.key,
          id_unico: row.value.id_unico || 'N/A',
          nombre: row.value.nombre || 'N/A',
          apellido: row.value.apellido || 'N/A',
          email: row.value.email || 'N/A',
          telefono: row.value.telefono || 'N/A',
          wallet: row.value.wallet || 'N/A',
          password: row.value.password || 'N/A',
          fechaRegistro: row.value.fechaRegistro || 'N/A',
          activo: row.value.activo ?? true,
          tieneNombre: !!(row.value.nombre && typeof row.value.nombre === 'string'),
          tieneEmail: !!(row.value.email && typeof row.value.email === 'string'),
          pasaFiltroActual: !!(
            (row.value.nombre && typeof row.value.nombre === 'string') ||
            (row.value.email && typeof row.value.email === 'string')
          ),
          // NUEVO: Guardar el value completo para inspección
          valueRaw: JSON.stringify(row.value)
        };
      });
    
    // Ordenar por fecha de registro (más recientes primero)
    usuarios.sort((a, b) => {
      const fechaA = new Date(a.fechaRegistro).getTime();
      const fechaB = new Date(b.fechaRegistro).getTime();
      return fechaB - fechaA;
    });
    
    const usuariosQuePasanFiltro = usuarios.filter(u => u.pasaFiltroActual);
    const usuariosQueNoPasan = usuarios.filter(u => !u.pasaFiltroActual);
    
    console.log(`📊 Total usuarios en BD: ${usuarios.length}`);
    console.log(`✅ Pasan filtro actual: ${usuariosQuePasanFiltro.length}`);
    console.log(`❌ NO pasan filtro: ${usuariosQueNoPasan.length}`);
    
    // NUEVO: Log de primeros 3 usuarios vacíos con su value completo
    console.log('\n🔍 INSPECCIÓN DE USUARIOS VACÍOS:');
    usuariosQueNoPasan.slice(0, 3).forEach((u, idx) => {
      console.log(`\n${idx + 1}. KEY: ${u.key}`);
      console.log(`   VALUE: ${u.valueRaw}`);
    });
    
    return c.json({
      totalUsuarios: usuarios.length,
      usuariosQuePasanFiltro: usuariosQuePasanFiltro.length,
      usuariosQueNoPasanFiltro: usuariosQueNoPasan.length,
      ultimos20: usuarios.slice(0, 20),
      usuariosRechazados: usuariosQueNoPasan.slice(0, 10),
      // NUEVO: Primeros 5 registros vac���os con value completo
      registrosVaciosCompletos: usuariosQueNoPasan.slice(0, 5).map(u => ({
        key: u.key,
        valueRaw: u.valueRaw
      }))
    });
  } catch (error) {
    console.error('Error en all-users-raw:', error);
    return c.json({ error: String(error) }, 500);
  }
});

// DEBUG: Investigar usuarios específicos que no aparecen
app.get("/make-server-9f68532a/debug/usuarios-especificos", async (c) => {
  try {
    const idsUnicos = ['LF1765918120109793', 'LF1766081702464905', 'LF1766035063633662'];
    
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );
    
    const resultados = [];
    
    for (const idUnico of idsUnicos) {
      // Buscar por mapeo de ID único
      const { data: mapeo, error: errorMapeo } = await supabase
        .from('kv_store_9f68532a')
        .select('key, value')
        .eq('key', `user:idUnico:${idUnico}`)
        .single();
      
      if (errorMapeo || !mapeo) {
        resultados.push({
          idUnico,
          encontrado: false,
          error: 'No existe mapeo user:idUnico:xxx'
        });
        continue;
      }
      
      const userId = mapeo.value;
      
      // Buscar el registro completo del usuario
      const { data: usuario, error: errorUsuario } = await supabase
        .from('kv_store_9f68532a')
        .select('key, value')
        .eq('key', `user:${userId}`)
        .single();
      
      // NUEVO: Verificar manualmente el filtro
      const key = `user:${userId}`;
      const afterPrefix = key.substring(5);
      const hasColon = afterPrefix.includes(':');
      const isValidUUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(afterPrefix);
      const hasNombre = usuario?.value?.nombre && typeof usuario?.value?.nombre === 'string';
      const hasEmail = usuario?.value?.email && typeof usuario?.value?.email === 'string';
      
      resultados.push({
        idUnico,
        userId,
        encontrado: !!usuario,
        keyCompleta: `user:${userId}`,
        value: usuario?.value,
        tieneNombre: !!hasNombre,
        tieneEmail: !!hasEmail,
        nombreValor: usuario?.value?.nombre,
        emailValor: usuario?.value?.email,
        // DEBUG del filtro
        afterPrefix,
        hasColon,
        isValidUUID,
        pasariaFiltro: !hasColon && isValidUUID && (hasNombre || hasEmail)
      });
    }
    
    // NUEVO: Llamar a getAllUsers() y verificar si están ahí
    const todosLosUsuarios = await crm.getAllUsers();
    
    resultados.forEach(r => {
      const encontradoEnGetAllUsers = todosLosUsuarios.find((u: any) => u.id_unico === r.idUnico);
      r.apareceEnGetAllUsers = !!encontradoEnGetAllUsers;
      r.totalUsuariosEnGetAllUsers = todosLosUsuarios.length;
    });
    
    console.log('🔍 DIAGNÓSTICO DE USUARIOS ESPECÍFICOS:', JSON.stringify(resultados, null, 2));
    
    return c.json({ usuarios: resultados });
  } catch (error) {
    console.error('Error en usuarios-especificos:', error);
    return c.json({ error: String(error) }, 500);
  }
});

// DEBUG: Buscar un usuario específico por ID único
app.get("/make-server-9f68532a/debug/find-user/:idUnico", async (c) => {
  try {
    const idUnico = c.req.param('idUnico');
    console.log(`🔍 BUSCANDO USUARIO: ${idUnico}`);
    
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );
    
    // Buscar en TODOS los registros que empiecen con "user:"
    const { data: rawData, error } = await supabase
      .from('kv_store_9f68532a')
      .select('key, value')
      .like('key', 'user:%');
    
    if (error) {
      return c.json({ error: error.message }, 500);
    }
    
    console.log(`📊 Total registros con prefijo user:: ${rawData?.length || 0}`);
    
    // Buscar registros que contengan el ID único
    const encontrados = (rawData || []).filter((row: any) => {
      // Buscar en la key
      if (row.key.includes(idUnico)) {
        return true;
      }
      
      // Buscar en el value si es objeto
      if (row.value && typeof row.value === 'object') {
        if (row.value.id_unico === idUnico) {
          return true;
        }
      }
      
      return false;
    });
    
    console.log(`✅ Registros encontrados con ${idUnico}: ${encontrados.length}`);
    
    const resultado = encontrados.map(row => ({
      key: row.key,
      esMapeo: row.key.includes('email:') || row.key.includes('idUnico:'),
      tipoRegistro: row.key.includes('email:') ? 'MAPEO_EMAIL' : 
                    row.key.includes('idUnico:') ? 'MAPEO_ID_UNICO' : 
                    'USUARIO_PRINCIPAL',
      value: row.value,
      tieneNombre: !!(row.value?.nombre),
      tieneEmail: !!(row.value?.email),
      valorCompleto: JSON.stringify(row.value)
    }));
    
    // También buscar por getUserByIdUnico
    const usuarioPorFuncion = await crm.getUserByIdUnico(idUnico);
    
    return c.json({
      idUnicoBuscado: idUnico,
      totalEncontrados: encontrados.length,
      registros: resultado,
      usuarioRecuperadoPorFuncion: usuarioPorFuncion ? {
        id: usuarioPorFuncion.id,
        nombre: usuarioPorFuncion.nombre,
        email: usuarioPorFuncion.email,
        id_unico: usuarioPorFuncion.id_unico
      } : null
    });
  } catch (error) {
    console.error('Error en find-user:', error);
    return c.json({ error: String(error) }, 500);
  }
});

// DEBUG: Endpoint para revisar usuarios de las últimas 48 horas
app.get("/make-server-9f68532a/debug/usuarios-48h", async (c) => {
  try {
    console.log('🔍 ========== DIAGNÓSTICO: USUARIOS ÚLTIMAS 48 HORAS ==========');
    
    const usuarios = await crm.getAllUsers();
    console.log(`📊 Total usuarios en KV Store: ${usuarios.length}`);
    
    // Calcular fecha límite (48 horas atrás)
    const ahora = new Date();
    const hace48h = new Date(ahora.getTime() - (48 * 60 * 60 * 1000));
    
    console.log(`⏰ Fecha actual: ${ahora.toISOString()}`);
    console.log(`⏰ Fecha límite (48h atrás): ${hace48h.toISOString()}`);
    
    // Filtrar usuarios de las últimas 48 horas
    const usuarios48h = usuarios.filter(u => {
      const fechaRegistro = new Date(u.fechaRegistro);
      return fechaRegistro >= hace48h;
    });
    
    console.log(`✅ Usuarios registrados en últimas 48h: ${usuarios48h.length}`);
    
    // Ordenar por fecha de registro (más reciente primero)
    const usuariosOrdenados = usuarios48h.sort((a, b) => 
      new Date(b.fechaRegistro).getTime() - new Date(a.fechaRegistro).getTime()
    );
    
    // Información detallada de cada usuario
    const usuariosDetallados = usuariosOrdenados.map(u => {
      const fechaRegistro = new Date(u.fechaRegistro);
      const horasDesdeRegistro = Math.floor((ahora.getTime() - fechaRegistro.getTime()) / (1000 * 60 * 60));
      
      return {
        id: u.id,
        id_unico: u.id_unico,
        nombre: u.nombre,
        apellido: u.apellido,
        email: u.email,
        telefono: u.telefono,
        wallet: u.wallet,
        fechaRegistro: u.fechaRegistro,
        horasDesdeRegistro,
        activo: u.activo,
        referralCode: u.referralCode,
        referidoPor: u.referidoPor
      };
    });
    
    // Log detallado en consola
    console.log('\n📋 USUARIOS REGISTRADOS EN ÚLTIMAS 48H:');
    usuariosDetallados.forEach((u, idx) => {
      console.log(`\n${idx + 1}. ${u.nombre} ${u.apellido}`);
      console.log(`   ID: ${u.id}`);
      console.log(`   ID Único: ${u.id_unico}`);
      console.log(`   Email: ${u.email}`);
      console.log(`   Teléfono: ${u.telefono}`);
      console.log(`   Wallet: ${u.wallet || 'N/A'}`);
      console.log(`   Fecha Registro: ${u.fechaRegistro}`);
      console.log(`   Hace ${u.horasDesdeRegistro} horas`);
      console.log(`   Activo: ${u.activo}`);
      console.log(`   Referral Code: ${u.referralCode || 'N/A'}`);
      console.log(`   Referido Por: ${u.referidoPor || 'Ninguno'}`);
    });
    
    console.log('\n========== FIN DEL DIAGNÓSTICO ==========\n');
    
    return c.json({
      fechaActual: ahora.toISOString(),
      fechaLimite: hace48h.toISOString(),
      totalUsuariosKV: usuarios.length,
      totalUltimas48h: usuarios48h.length,
      usuarios: usuariosDetallados
    });
  } catch (error) {
    console.error('❌ Error en debug 48h:', error);
    return c.json({ error: String(error) }, 500);
  }
});

// DEBUG: Verificar estructura de referidos de un usuario
app.get("/make-server-9f68532a/debug/referidos/:userId", async (c) => {
  try {
    const userId = c.req.param('userId');
    console.log(`\n🔍 ========== DEBUG REFERIDOS PARA ${userId} ==========`);
    
    const user = await crm.getUserById(userId);
    if (!user) {
      return c.json({ error: "Usuario no encontrado" }, 404);
    }
    
    console.log(`✅ Usuario: ${user.nombre} ${user.apellido} (${user.id_unico})`);
    
    // Obtener todos los usuarios
    const allUsers = await crm.getAllUsers();
    const allPacks = await crm.getAllPacks();
    
    // Filtrar referidos directos
    const referidosDirectos = allUsers.filter((u: any) => u.referidoPor === userId);
    console.log(`👥 Total referidos directos encontrados: ${referidosDirectos.length}`);
    
    const referidosConInfo = referidosDirectos.map((ref: any) => {
      const packs = allPacks.filter((p: any) => p.userId === ref.id);
      const packActivo = packs.find((p: any) => p.activo);
      const inversionTotal = packs.reduce((sum, p) => sum + p.monto, 0);
      
      console.log(`   - ${ref.nombre} ${ref.apellido} (${ref.id_unico}) - Pack: ${packActivo?.nombre || 'Sin Pack'} - Inversión: $${inversionTotal}`);
      
      return {
        id: ref.id,
        id_unico: ref.id_unico,
        nombre: ref.nombre,
        apellido: ref.apellido,
        email: ref.email,
        referidoPor: ref.referidoPor,
        packActivo: packActivo ? {
          nombre: packActivo.nombre,
          monto: packActivo.monto,
          fechaCompra: packActivo.fechaCompra
        } : null,
        totalPacks: packs.length,
        inversionTotal
      };
    });
    
    console.log(`\n========== FIN DEBUG REFERIDOS ==========\n`);
    
    return c.json({
      usuario: {
        id: user.id,
        id_unico: user.id_unico,
        nombre: user.nombre,
        apellido: user.apellido,
        email: user.email
      },
      referidosDirectos: {
        total: referidosDirectos.length,
        conPackActivo: referidosConInfo.filter(r => r.packActivo !== null).length,
        lista: referidosConInfo
      }
    });
  } catch (error) {
    console.error('❌ Error en debug/referidos:', error);
    return c.json({ error: error instanceof Error ? error.message : String(error) }, 500);
  }
});

// DEBUG: Buscar usuario por email o id_unico
app.get("/make-server-9f68532a/debug/buscar-usuario/:query", async (c) => {
  try {
    const query = c.req.param('query');
    console.log(`🔍 Buscando usuario: ${query}`);
    
    // Intentar buscar por email primero
    let user = await crm.getUserByEmail(query);
    
    // Si no se encuentra, intentar por id_unico
    if (!user) {
      user = await crm.getUserByIdUnico(query);
    }
    
    if (!user) {
      return c.json({ error: "Usuario no encontrado" }, 404);
    }
    
    console.log(`✅ Usuario encontrado: ${user.nombre} ${user.apellido} (${user.id_unico})`);
    
    // Obtener información adicional
    const packs = await crm.getPacksByUserId(user.id);
    const comisiones = await crm.getComisionesByUserId(user.id);
    const referidosDirectos = await crm.getReferidosDirectos(user.id);
    
    return c.json({
      usuario: {
        id: user.id,
        id_unico: user.id_unico,
        nombre: user.nombre,
        apellido: user.apellido,
        email: user.email,
        telefono: user.telefono,
        referralCode: user.referralCode,
        referidoPor: user.referidoPor,
        activo: user.activo,
        rango: user.rango
      },
      packs: {
        total: packs.length,
        activos: packs.filter(p => p.activo).length,
        lista: packs.map(p => ({
          id: p.id,
          nombre: p.nombre,
          monto: p.monto,
          activo: p.activo,
          fechaCompra: p.fechaCompra,
          matrizPadre: p.matrizPadre,
          matrizNivel: p.matrizNivel,
          matrizPosicion: p.matrizPosicion
        }))
      },
      comisiones: {
        total: comisiones.length,
        suma: comisiones.reduce((sum, c) => sum + c.monto, 0),
        porTipo: {
          red: comisiones.filter(c => c.tipo === 'red').reduce((sum, c) => sum + c.monto, 0),
          rendimiento: comisiones.filter(c => c.tipo === 'rendimiento').reduce((sum, c) => sum + c.monto, 0),
          patrocinio: comisiones.filter(c => c.tipo === 'patrocinio').reduce((sum, c) => sum + c.monto, 0)
        }
      },
      referidosDirectos: {
        total: referidosDirectos.length,
        lista: referidosDirectos.map(ref => ({
          id_unico: ref.id_unico,
          nombre: ref.nombre,
          apellido: ref.apellido,
          email: ref.email
        }))
      }
    });
  } catch (error) {
    console.error('❌ Error en debug/buscar-usuario:', error);
    return c.json({ error: error instanceof Error ? error.message : String(error) }, 500);
  }
});

// ==========================================
// RUTAS DE AUTENTICACIÓN
// ==========================================

app.post("/make-server-9f68532a/auth/register", async (c) => {
  console.log('🚨����🚨 ==================================================');
  console.log('🚨🚨🚨 ENDPOINT /auth/register LLAMADO - NUEVO REGISTRO');
  console.log('🚨🚨🚨 ==================================================');
  
  try {
    console.log('⏳ Parseando body...');
    const rawData = await c.req.json();
    console.log('📥 RAW DATA RECIBIDO:', JSON.stringify(rawData, null, 2));
    
    // Normalizar email
    const data = {
      ...rawData,
      email: rawData.email ? rawData.email.toLowerCase().trim() : ''
    };
    console.log('✅ Data normalizado');
    
    console.log('📝 Datos de registro recibidos:', {
      nombre: data.nombre,
      apellido: data.apellido,
      email: data.email,
      referidoPor: data.referidoPor
    });
 
    // 🛡️ PROTECCIÓN ANTI-DUPLICADOS: Verificar si el email ya existe en KV
    const existingUser = await crm.getUserByEmail(data.email);
    if (existingUser) {
      console.warn(`⚠️ Intento de registro duplicado: ${data.email} (Usuario ya existe)`);
      return c.json({ error: "El email ya está registrado" }, 400);
    }
    
    // 🛡️ PROTECCIÓN ADICIONAL: Verificar si el email ya existe en Supabase Auth
    const supabaseCheck = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );
    
    const { data: existingAuthUsers } = await supabaseCheck.auth.admin.listUsers();
    const emailExists = existingAuthUsers?.users?.some(u => u.email === data.email);
    
    if (emailExists) {
      console.warn(`⚠️ Email ya existe en Supabase Auth: ${data.email}`);
      return c.json({ error: "El email ya está registrado en el sistema de autenticación" }, 400);
    }
    
    console.log(`✅ Email disponible: ${data.email}`);
    
    // 🔐 PASO 1: Crear usuario en Supabase Auth
    console.log('🔐 Creando usuario en Supabase Auth...');
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );
    
    const { data: authData, error: authError } = await supabase.auth.admin.createUser({
      email: data.email,
      password: data.password,
      email_confirm: true, // Auto-confirmar el email
      user_metadata: {
        nombre: data.nombre,
        apellido: data.apellido,
        telefono: data.telefono,
        wallet: data.wallet || '',
        referralCode: data.referralCode || ''
      }
    });
    
    if (authError) {
      console.error('❌ Error al crear usuario en Supabase Auth:', authError);
      return c.json({ error: `Error en autenticación: ${authError.message}` }, 500);
    }
    
    console.log(`✅ Usuario creado en Supabase Auth: ${authData.user.id}`);
    
    // 💾 PASO 2: Generar ID único para KV Store
    const id_unico = `LF${Date.now()}${Math.floor(Math.random() * 1000)}`;
    
    // Verificar referidor si se proporcionó código
    let referidoPor = undefined;
    if (data.referidoPor) {
      console.log(`🔍 Buscando referidor con código: ${data.referidoPor}`);
      const referidor = await crm.getUserByIdUnico(data.referidoPor);
      if (referidor) {
        referidoPor = referidor.id; // Guardar el ID interno del referidor
        console.log(`✅ Referidor encontrado: ${referidor.nombre} ${referidor.apellido} (ID: ${referidor.id})`);
      } else {
        console.log(`⚠️ Código de referido no encontrado: ${data.referidoPor}`);
        // No bloquear el registro, simplemente no asignar referidor
      }
    }
    
    // 💾 PASO 3: Crear usuario en KV Store
    console.log('💾 Guardando usuario en KV Store...');
    const user = await crm.createUser({
      id_unico,
      nombre: data.nombre,
      apellido: data.apellido,
      email: data.email,
      telefono: data.telefono,
      ciudad: data.ciudad || '', // Opcional
      wallet: data.wallet || '', // Opcional
      password: data.password, // En producción, hashear la contraseña
      referralCode: data.referralCode || '',
      referidoPor,
      rango: 'Sin Rango' // Nuevo usuario empieza sin rango
    });
    
    // Inicializar puntos
    await crm.setPuntos(user.id, 100); // Puntos de bienvenida
    
    console.log('=================================================');
    console.log('REGISTRO COMPLETO - Usuario creado en Auth + KV');
    console.log(`  Auth ID: ${authData.user.id}`);
    console.log(`  KV ID: ${user.id}`);
    console.log(`  Usuario: ${user.nombre} ${user.apellido}`);
    console.log(`  Email: ${user.email}`);
    console.log(`  ID Unico: ${user.id_unico}`);
    console.log('=================================================');
    
    return c.json({ 
      success: true, 
      user: { ...user, password: undefined } // No enviar password
    });
  } catch (error) {
    console.error('Error en registro:', error);
    return c.json({ error: "Error al registrar usuario" }, 500);
  }
});

app.post("/make-server-9f68532a/auth/login", async (c) => {
  try {
    const { email: rawEmail, password } = await c.req.json();
    const email = rawEmail ? rawEmail.toLowerCase().trim() : '';
    
    console.log(`🔍 Intento de login: ${email}`);
    
    // Asegurarse de que el admin existe si es el primer login
    if (email === 'admin@libertyfinance.com') {
      const existingAdmin = await crm.getUserByEmail(email);
      const ADMIN_PASS = 'admin123'; // ✅ CONTRASEÑA SIMPLE Y CONSISTENTE
      
      if (!existingAdmin) {
        console.log('⚠️  Admin no existe, creándolo ahora...');
        const adminUser = await crm.createUser({
          id_unico: 'LF-ADMIN-001',
          nombre: 'Admin',
          apellido: 'Liberty',
          email: 'admin@libertyfinance.com',
          telefono: '+1234567890',
          ciudad: 'Global',
          wallet: 'TAdminWallet123456789',
          password: ADMIN_PASS,
          referralCode: '',
          referidoPor: undefined,
          rango: 'Crown Black'
        });
        
        // IMPORTANTE: Activar admin inmediatamente
        await crm.updateUser(adminUser.id, { activo: true });
        await crm.setPuntos(adminUser.id, 1000);
        console.log('✅ Usuario admin creado y activado en el momento del login');
      } else {
        // Siempre actualizar la contraseña del admin a la correcta
        console.log('���� Actualizando contraseña de admin a la nueva definida...');
        await crm.updateUser(existingAdmin.id, { password: ADMIN_PASS, activo: true });
      }
    }
    
    const user = await crm.getUserByEmail(email);
    
    if (!user) {
      console.log(`❌ Usuario no encontrado: ${email}`);
      return c.json({ error: "Usuario no encontrado" }, 404);
    }
    
    // Para admin, permitir login incluso si no está activo (y activarlo si es necesario)
    if (email === 'admin@libertyfinance.com') {
        if (!user.activo) {
            await crm.updateUser(user.id, { activo: true });
        }
    } else if (user.activo === false) {
      console.log(`❌ Usuario inactivo: ${email}`);
      return c.json({ error: "Tu cuenta ha sido desactivada. Contacta al administrador." }, 403);
    }
    
    console.log(`🔍 Usuario encontrado: ${user.email}, verificando password...`);
    console.log(`🔑 Password almacenado: "${user.password}" (tipo: ${typeof user.password})`);
    console.log(`🔑 Password recibido: "${password}" (tipo: ${typeof password})`);
    console.log(`🔑 Longitud almacenado: ${user.password?.length}, Longitud recibido: ${password?.length}`);
    
    // Comparar passwords (con trim para eliminar espacios)
    const storedPassword = String(user.password || '').trim();
    const receivedPassword = String(password || '').trim();
    
    if (storedPassword !== receivedPassword) {
      console.log(`❌ Password incorrecto para: ${email}`);
      console.log(`   Esperado: "${storedPassword}"`);
      console.log(`   Recibido: "${receivedPassword}"`);
      return c.json({ error: "Contraseña incorrecta" }, 401);
    }
    
    console.log(`✅ Login exitoso: ${email}`);
    
    return c.json({ 
      success: true, 
      user: { ...user, password: undefined }
    });
  } catch (error) {
    console.error('Error en login:', error);
    return c.json({ error: "Error al iniciar sesión" }, 500);
  }
});

// 🔍 ENDPOINT DE DIAGNÓSTICO: Verificar si un usuario existe
app.get("/make-server-9f68532a/auth/check-user/:userId", async (c) => {
  try {
    const userId = c.req.param('userId');
    console.log(`🔍 [DIAGNÓSTICO] Verificando usuario: ${userId}`);
    
    // Buscar en DB directamente
    const userById = await crm.getUserById(userId);
    
    // Buscar en caché
    const cachedUsers = await getCachedUsuarios();
    const userInCache = cachedUsers.find((u: any) => u.id === userId);
    
    const diagnostico = {
      userId,
      existeEnDB: !!userById,
      existeEnCache: !!userInCache,
      userData: userById ? {
        id: userById.id,
        id_unico: userById.id_unico,
        nombre: userById.nombre,
        apellido: userById.apellido,
        email: userById.email,
        activo: userById.activo
      } : null,
      totalUsuariosEnCache: cachedUsers.length,
      timestamp: new Date().toISOString()
    };
    
    console.log(`🔍 [DIAGNÓSTICO] Resultado:`, diagnostico);
    
    return c.json(diagnostico);
  } catch (error) {
    console.error('Error en diagnóstico de usuario:', error);
    return c.json({ error: "Error al diagnosticar usuario" }, 500);
  }
});

// 🔍 ENDPOINT DE DIAGNÓSTICO: Verificar email y password
app.get("/make-server-9f68532a/auth/check-email/:email", async (c) => {
  try {
    const email = c.req.param('email').toLowerCase().trim();
    console.log(`🔍 [DIAGNÓSTICO] Verificando email: ${email}`);
    
    // Buscar por email
    const user = await crm.getUserByEmail(email);
    
    // Verificar si existe el índice
    const emailIndex = await kv.get(`user:email:${email}`);
    
    const diagnostico = {
      email,
      usuarioEncontrado: !!user,
      indiceExiste: !!emailIndex,
      indiceApuntaA: emailIndex,
      userData: user ? {
        id: user.id,
        id_unico: user.id_unico,
        nombre: user.nombre,
        apellido: user.apellido,
        email: user.email,
        passwordLength: user.password?.length || 0,
        passwordPreview: user.password ? `${user.password.substring(0, 3)}***` : 'NO PASSWORD',
        activo: user.activo
      } : null,
      timestamp: new Date().toISOString()
    };
    
    console.log(`🔍 [DIAGNÓSTICO] Resultado:`, diagnostico);
    
    return c.json(diagnostico);
  } catch (error) {
    console.error('Error en diagnóstico de email:', error);
    return c.json({ error: "Error al diagnosticar email" }, 500);
  }
});

// 🗑️ ENDPOINT: Invalidar caché manualmente (útil para debugging)
app.post("/make-server-9f68532a/admin/invalidar-cache", async (c) => {
  try {
    console.log(`🗑️ [ADMIN] Invalidando caché manualmente...`);
    invalidateCache();
    return c.json({ 
      success: true, 
      message: "Caché invalidado exitosamente",
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Error al invalidar caché:', error);
    return c.json({ error: "Error al invalidar cach��" }, 500);
  }
});

// 🔍 ENDPOINT: Diagnóstico completo de estructura de datos
app.post("/make-server-9f68532a/admin/diagnostico-estructura", async (c) => {
  try {
    console.log('🔍 [ADMIN] Ejecutando diagnóstico completo de estructura de datos...');
    
    const diagnostico = await migrationChecker.ejecutarDiagnosticoCompleto();
    
    return c.json({
      success: true,
      diagnostico,
      timestamp: new Date().toISOString()
    });
  } catch (error: any) {
    console.error('Error en diagnóstico de estructura:', error);
    return c.json({ 
      error: "Error al ejecutar diagnóstico de estructura",
      details: error?.message 
    }, 500);
  }
});

// 🔍 ENDPOINT: Analizar solo estructura de datos
app.get("/make-server-9f68532a/admin/analizar-estructura", async (c) => {
  try {
    console.log('🔍 [ADMIN] Analizando estructura de datos...');
    
    const analisis = await migrationChecker.analizarEstructuraDatos();
    
    return c.json({
      success: true,
      analisis,
      timestamp: new Date().toISOString()
    });
  } catch (error: any) {
    console.error('Error al analizar estructura:', error);
    return c.json({ 
      error: "Error al analizar estructura",
      details: error?.message 
    }, 500);
  }
});

// 🔍 ENDPOINT: Buscar datos antiguos monolíticos
app.get("/make-server-9f68532a/admin/buscar-datos-antiguos", async (c) => {
  try {
    console.log('🔍 [ADMIN] Buscando datos antiguos en formato monolítico...');
    
    const datosAntiguos = await migrationChecker.buscarDatosAntiguos();
    
    return c.json({
      success: true,
      datosAntiguos,
      hayDatos: Object.keys(datosAntiguos).length > 0,
      keysEncontradas: Object.keys(datosAntiguos),
      timestamp: new Date().toISOString()
    });
  } catch (error: any) {
    console.error('Error al buscar datos antiguos:', error);
    return c.json({ 
      error: "Error al buscar datos antiguos",
      details: error?.message 
    }, 500);
  }
});

// ==========================================
// RUTAS DE RECUPERACIÓN DE CONTRASEÑA
// ==========================================

// Paso 1: Solicitar código de recuperación
app.post("/make-server-9f68532a/auth/solicitar-recuperacion", async (c) => {
  try {
    const { email: rawEmail } = await c.req.json();
    const email = rawEmail ? rawEmail.toLowerCase().trim() : '';
    
    console.log(`📧 Solicitud de recuperación de contraseña para: ${email}`);
    
    // Verificar si el usuario existe
    const user = await crm.getUserByEmail(email);
    if (!user) {
      // Por seguridad, no revelar si el email existe o no
      return c.json({ 
        success: true, 
        message: "Si el correo existe, recibirás un código de recuperación" 
      });
    }
    
    // Generar código de 6 dígitos
    const codigo = Math.floor(100000 + Math.random() * 900000).toString();
    
    // Guardar código en KV store con expiración de 15 minutos
    const recuperacionKey = `recuperacion:${email}`;
    await kv.set(recuperacionKey, {
      codigo,
      userId: user.id,
      email,
      timestamp: Date.now(),
      usado: false
    });
    
    console.log(`🔑 Código de recuperación generado para ${email}: ${codigo}`);
    console.log(`⏰ Código válido por 15 minutos`);
    
    // Enviar correo electrónico con el código
    try {
      const resendApiKey = Deno.env.get('RESEND_API_KEY');
      
      if (!resendApiKey || resendApiKey === '') {
        console.warn('⚠️ RESEND_API_KEY no configurada. Usando modo desarrollo.');
        // Modo desarrollo: devolver código en la respuesta
        return c.json({ 
          success: true,
          message: "Código enviado a tu correo electrónico",
          codigo // Solo en desarrollo sin API key
        });
      }

      // Template del email
      const emailHtml = `
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Recuperación de Contraseña - Liberty Finance</title>
</head>
<body style="margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
  <table role="presentation" style="width: 100%; border-collapse: collapse; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
    <tr>
      <td align="center" style="padding: 40px 20px;">
        <table role="presentation" style="max-width: 600px; width: 100%; border-collapse: collapse; background: white; border-radius: 24px; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);">
          
          <!-- Header -->
          <tr>
            <td style="padding: 48px 40px 32px; text-align: center; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 24px 24px 0 0;">
              <div style="width: 80px; height: 80px; margin: 0 auto 20px; background: white; border-radius: 20px; display: flex; align-items: center; justify-content: center;">
                <span style="font-size: 40px;">🔐</span>
              </div>
              <h1 style="margin: 0; font-size: 28px; font-weight: 700; color: white; line-height: 1.2;">
                Recupera tu Contraseña
              </h1>
            </td>
          </tr>
          
          <!-- Body -->
          <tr>
            <td style="padding: 40px;">
              <p style="margin: 0 0 24px; font-size: 16px; line-height: 1.6; color: #374151;">
                Hola <strong>${user.nombre} ${user.apellido}</strong>,
              </p>
              
              <p style="margin: 0 0 32px; font-size: 16px; line-height: 1.6; color: #374151;">
                Recibimos una solicitud para restablecer la contraseña de tu cuenta en <strong>Liberty Finance</strong>. 
                Usa el siguiente código para continuar con el proceso:
              </p>
              
              <!-- Código -->
              <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 16px; padding: 32px; text-align: center; margin: 32px 0;">
                <p style="margin: 0 0 16px; font-size: 14px; font-weight: 600; color: white; text-transform: uppercase; letter-spacing: 1px;">
                  Tu Código de Verificación
                </p>
                <div style="font-size: 48px; font-weight: 800; color: white; letter-spacing: 8px; font-family: 'Courier New', monospace;">
                  ${codigo}
                </div>
              </div>
              
              <!-- Información adicional -->
              <div style="background: #FEF3C7; border-left: 4px solid #F59E0B; border-radius: 8px; padding: 20px; margin: 32px 0;">
                <p style="margin: 0; font-size: 14px; line-height: 1.6; color: #92400E;">
                  <strong>⏰ Importante:</strong> Este código expirará en <strong>15 minutos</strong> por tu seguridad.
                </p>
              </div>
              
              <p style="margin: 24px 0 0; font-size: 14px; line-height: 1.6; color: #6B7280;">
                Si no solicitaste este cambio, puedes ignorar este correo. Tu contraseña permanecerá sin cambios.
              </p>
            </td>
          </tr>
          
          <!-- Footer -->
          <tr>
            <td style="padding: 32px 40px; background: #F9FAFB; border-radius: 0 0 24px 24px; border-top: 1px solid #E5E7EB;">
              <p style="margin: 0 0 16px; font-size: 14px; line-height: 1.6; color: #6B7280; text-align: center;">
                Este es un mensaje automático, por favor no respondas a este correo.
              </p>
              <p style="margin: 0; font-size: 12px; line-height: 1.6; color: #9CA3AF; text-align: center;">
                © ${new Date().getFullYear()} Liberty Finance. Todos los derechos reservados.
              </p>
            </td>
          </tr>
          
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
      `;

      // Enviar email
      const resend = new Resend(resendApiKey);
      const { data, error } = await resend.emails.send({
        from: 'Liberty Finance <no-reply@libertyfinance.life>',
        to: [email],
        subject: `🔐 Tu código de recuperación: ${codigo}`,
        html: emailHtml,
      });

      if (error) {
        console.error('❌ Error al enviar email con Resend:', error);
        
        // Si es error de API key, dar instrucciones claras
        if (error.message?.includes('API key is invalid') || error.statusCode === 400) {
          const currentKey = Deno.env.get('RESEND_API_KEY') || '';
          const maskedKey = currentKey.length > 6 
            ? `${currentKey.substring(0, 3)}...${currentKey.substring(currentKey.length - 3)}`
            : '(key inválida/corta)';
            
          console.error('🔑 API Key inválida o no configurada correctamente');
          console.error(`���️ Key actual en uso: ${maskedKey} (Longitud: ${currentKey.length})`);
          
          if (!currentKey.startsWith('re_')) {
            console.error('⚠️ CRÍTICO: La API Key no empieza con "re_". Parece que estás usando una contraseña o ID incorrecto.');
            console.error('   Las API Keys de Resend SIEMPRE empiezan con "re_" (ej. re_12345678...)');
          }

          console.error('📋 Instrucciones:');
          console.error('   1. Ve a https://resend.com');
          console.error('   2. Crea una cuenta y obtén tu API Key');
          console.error('   3. Configura RESEND_API_KEY en las variables de entorno');
          console.error(`📧 CÓDIGO DE RECUPERACIÓN (usar este código): ${codigo}`);
          
          return c.json({ 
            success: true,
            message: "Código generado (ver consola del servidor)",
            codigo, // Fallback - mostrar código
            warning: "Email no enviado: API key inválida. Ver logs del servidor.",
            errorDetail: "Configura tu API key de Resend para enviar emails reales"
          });
        }
        
        // Otros errores de email
        console.error(`📧 CÓDIGO DE RECUPERACIÓN (copiar desde consola): ${codigo}`);
        return c.json({ 
          success: false,
          error: "Error al enviar email. Contacta soporte.",
          // NO devolver código por seguridad - solo en logs del servidor
        }, 500);
      }

      console.log(`✅ Email enviado exitosamente a ${email}. ID: ${data?.id}`);
      
      return c.json({ 
        success: true,
        message: "Código enviado a tu correo electrónico"
        // NO devolver el código si el email se envió correctamente
      });
      
    } catch (emailError) {
      console.error('❌ Error al procesar envío de email:', emailError);
      console.error(`📧 CÓDIGO DE RECUPERACIÓN (copiar desde consola): ${codigo}`);
      // En producción, NO devolver el código por seguridad
      return c.json({ 
        success: false,
        error: "Error al enviar el código. Intenta de nuevo.",
        // NO devolver código por seguridad - solo en logs del servidor
      }, 500);
    }
    
  } catch (error) {
    console.error('Error al solicitar recuperación:', error);
    return c.json({ error: "Error al procesar solicitud" }, 500);
  }
});

// Paso 2: Verificar código
app.post("/make-server-9f68532a/auth/verificar-codigo", async (c) => {
  try {
    const { email: rawEmail, codigo } = await c.req.json();
    const email = rawEmail ? rawEmail.toLowerCase().trim() : '';
    
    console.log(`🔍 Verificando código para: ${email}`);
    
    if (!codigo || codigo.length !== 6) {
      return c.json({ error: "Código inválido" }, 400);
    }
    
    // Obtener datos de recuperación
    const recuperacionKey = `recuperacion:${email}`;
    const recuperacionData = await kv.get(recuperacionKey);
    
    if (!recuperacionData) {
      return c.json({ error: "Código expirado o no encontrado. Solicita uno nuevo." }, 404);
    }
    
    // Verificar si ya fue usado
    if (recuperacionData.usado) {
      return c.json({ error: "Este código ya fue utilizado" }, 400);
    }
    
    // Verificar expiración (15 minutos)
    const tiempoTranscurrido = Date.now() - recuperacionData.timestamp;
    const TIEMPO_EXPIRACION = 15 * 60 * 1000; // 15 minutos
    
    if (tiempoTranscurrido > TIEMPO_EXPIRACION) {
      await kv.del(recuperacionKey);
      return c.json({ error: "Código expirado. Solicita uno nuevo." }, 400);
    }
    
    // Verificar código
    if (recuperacionData.codigo !== codigo) {
      return c.json({ error: "Código incorrecto" }, 401);
    }
    
    console.log(`✅ C��digo verificado correctamente para: ${email}`);
    
    return c.json({ 
      success: true,
      message: "Código verificado correctamente"
    });
  } catch (error) {
    console.error('Error al verificar código:', error);
    return c.json({ error: "Error al verificar código" }, 500);
  }
});

// Paso 3: Restablecer contraseña
app.post("/make-server-9f68532a/auth/restablecer-password", async (c) => {
  try {
    const { email: rawEmail, codigo, nuevaPassword } = await c.req.json();
    const email = rawEmail ? rawEmail.toLowerCase().trim() : '';
    
    console.log(`🔄 Restableciendo contraseña para: ${email}`);
    
    if (!nuevaPassword || nuevaPassword.length < 6) {
      return c.json({ error: "La contraseña debe tener al menos 6 caracteres" }, 400);
    }
    
    // Obtener datos de recuperación
    const recuperacionKey = `recuperacion:${email}`;
    const recuperacionData = await kv.get(recuperacionKey);
    
    if (!recuperacionData) {
      return c.json({ error: "Código expirado o no encontrado" }, 404);
    }
    
    // Verificar si ya fue usado
    if (recuperacionData.usado) {
      return c.json({ error: "Este código ya fue utilizado" }, 400);
    }
    
    // Verificar expiración
    const tiempoTranscurrido = Date.now() - recuperacionData.timestamp;
    const TIEMPO_EXPIRACION = 15 * 60 * 1000;
    
    if (tiempoTranscurrido > TIEMPO_EXPIRACION) {
      await kv.del(recuperacionKey);
      return c.json({ error: "Código expirado" }, 400);
    }
    
    // Verificar código nuevamente
    if (recuperacionData.codigo !== codigo) {
      return c.json({ error: "Código incorrecto" }, 401);
    }
    
    // Actualizar contraseña
    await crm.updateUser(recuperacionData.userId, { password: nuevaPassword });
    
    // Marcar código como usado
    await kv.set(recuperacionKey, {
      ...recuperacionData,
      usado: true
    });
    
    console.log(`✅ Contraseña actualizada exitosamente para: ${email}`);
    
    return c.json({ 
      success: true,
      message: "Contraseña actualizada exitosamente"
    });
  } catch (error) {
    console.error('Error al restablecer contraseña:', error);
    return c.json({ error: "Error al restablecer contraseña" }, 500);
  }
});

// Test: Verificar configuración de email
app.post("/make-server-9f68532a/auth/test-email", async (c) => {
  try {
    const { email } = await c.req.json();
    
    if (!email || !email.includes('@')) {
      return c.json({ error: "Email inválido" }, 400);
    }
    
    console.log(`📧 Testing email - enviando a: ${email}`);
    
    const resendApiKey = Deno.env.get('RESEND_API_KEY');
    
    if (!resendApiKey || resendApiKey === '') {
      return c.json({ 
        success: false,
        error: "RESEND_API_KEY no configurada",
        configured: false
      });
    }

    const testEmailHtml = `<!DOCTYPE html><html><body style="margin:0;padding:40px;background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);font-family:Arial,sans-serif"><div style="max-width:600px;margin:0 auto;background:white;border-radius:24px;overflow:hidden"><div style="padding:48px 40px;text-align:center;background:linear-gradient(135deg,#667eea 0%,#764ba2 100%)"><div style="width:80px;height:80px;margin:0 auto 20px;background:white;border-radius:20px;display:flex;align-items:center;justify-content:center;font-size:40px">✅</div><h1 style="margin:0;color:white;font-size:28px">Test Exitoso</h1></div><div style="padding:40px"><p style="margin:0 0 24px;font-size:16px;color:#374151">¡Hola!</p><p style="margin:0 0 32px;font-size:16px;color:#374151">Este es un email de prueba para verificar que Resend funciona correctamente con Liberty Finance.</p><div style="background:linear-gradient(135deg,#10b981 0%,#059669 100%);border-radius:16px;padding:32px;text-align:center"><p style="margin:0;font-size:24px;font-weight:800;color:white">🎉 ¡Configuración Exitosa!</p></div></div><div style="padding:32px 40px;background:#F9FAFB;text-align:center"><p style="margin:0;font-size:12px;color:#9CA3AF">© ${new Date().getFullYear()} Liberty Finance</p></div></div></body></html>`;

    try {
      const resend = new Resend(resendApiKey);
      const { data, error } = await resend.emails.send({
        from: 'Liberty Finance <no-reply@libertyfinance.life>',
        to: [email],
        subject: '✅ Test Exitoso - Configuración de Email',
        html: testEmailHtml,
      });

      if (error) {
        console.error('❌ Error al enviar email de prueba:', error);
        
        if (error.message?.includes('API key is invalid') || error.statusCode === 400) {
          const currentKey = Deno.env.get('RESEND_API_KEY') || '';
          const maskedKey = currentKey.length > 6 
            ? `${currentKey.substring(0, 3)}...${currentKey.substring(currentKey.length - 3)}`
            : '(key inv��lida/corta)';
          console.error(`ℹ️ DEBUG Key: ${maskedKey} (Len: ${currentKey.length})`);
          if (!currentKey.startsWith('re_')) {
             console.error('⚠️ CRÍTICO: La API Key no empieza con "re_".');
          }
        }

        return c.json({ 
          success: false,
          error: error.message || 'Error al enviar email',
          configured: true
        });
      }

      console.log(`✅ Email de prueba enviado. ID: ${data?.id}`);
      
      return c.json({ 
        success: true,
        message: "Email de prueba enviado correctamente",
        configured: true,
        emailId: data?.id
      });
      
    } catch (emailError: any) {
      console.error('❌ Error email:', emailError);
      return c.json({ 
        success: false,
        error: emailError.message || 'Error desconocido',
        configured: true
      });
    }
    
  } catch (error: any) {
    console.error('Error en test de email:', error);
    return c.json({ 
      success: false,
      error: error.message || "Error al procesar test"
    }, 500);
  }
});

// Endpoint para verificar configuración de Resend (sin enviar email)
app.get('/make-server-9f68532a/auth/check-resend-config', async (c) => {
  try {
    const resendApiKey = Deno.env.get('RESEND_API_KEY');
    
    if (!resendApiKey || resendApiKey === '' || !resendApiKey.startsWith('re_')) {
      return c.json({ 
        configured: false,
        message: 'API key no configurada o inválida'
      });
    }
    
    return c.json({ 
      configured: true,
      message: 'API key configurada correctamente'
    });
  } catch (error: any) {
    console.error('Error verificando configuración:', error);
    return c.json({ configured: false }, 500);
  }
});

// Endpoint para verificar/crear Juan Solano (FIX)
app.get('/make-server-9f68532a/admin/verificar-juan-solano', async (c) => {
  try {
    const existente = await crm.getUserByIdUnico('LF1766035063633662');
    
    if (existente) {
      return c.json({
        existe: true,
        usuario: { ...existente, password: undefined }
      });
    }
    
    return c.json({
      existe: false,
      mensaje: 'Juan Solano NO existe. Usa POST /admin/crear-juan-solano'
    });
  } catch (error: any) {
    return c.json({ error: error.message }, 500);
  }
});

app.post('/make-server-9f68532a/admin/crear-juan-solano', async (c) => {
  try {
    const data = await c.req.json();
    
    const existente = await crm.getUserByIdUnico('LF1766035063633662');
    if (existente) {
      return c.json({ 
        success: false, 
        message: 'Ya existe',
        usuario: { ...existente, password: undefined }
      });
    }
    
    let referidoPor = undefined;
    if (data.referidoPorCodigo) {
      const referidor = await crm.getUserByIdUnico(data.referidoPorCodigo);
      if (referidor) referidoPor = referidor.id;
    }
    
    const user = await crm.createUser({
      id_unico: 'LF1766035063633662',
      nombre: 'Juan',
      apellido: 'Solano',
      email: data.email || 'juan.solano@temporal.com',
      telefono: data.telefono || '+51999999999',
      ciudad: data.ciudad || '',
      wallet: data.wallet || '',
      password: data.password || 'TempPassword123#',
      referralCode: data.referralCode || 'JUANSOLANO',
      referidoPor,
      rango: 'Sin Rango'
    });
    
    await crm.setPuntos(user.id, 100);
    
    console.log('✅ Juan Solano creado:', user);
    
    return c.json({
      success: true,
      usuario: { ...user, password: undefined }
    });
  } catch (error: any) {
    console.error('❌ Error:', error);
    return c.json({ error: error.message }, 500);
  }
});

// ==========================================
// 🔄 SINCRONIZACIÓN SUPABASE AUTH → KV STORE
// ==========================================

app.post('/make-server-9f68532a/admin/sincronizar-usuarios-auth', async (c) => {
  try {
    const resultado = await syncAuthUsers();
    
    // 🔧 CRITICAL FIX: Invalidar caché después de sincronizar para que los nuevos datos se vean inmediatamente
    invalidateCache();
    console.log('🗑️ Caché invalidado después de sincronización');
    
    return c.json(resultado);
  } catch (error: any) {
    console.error('❌ Error en sincronización:', error);
    return c.json({ error: error.message }, 500);
  }
});

// Endpoint de búsqueda profunda (DEBUG)
app.get('/make-server-9f68532a/admin/buscar-usuario/:termino', async (c) => {
  try {
    const termino = c.req.param('termino').toLowerCase();
    console.log(`🔍 Búsqueda profunda por término: "${termino}"`);
    
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL'),
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')
    );
    
    // Obtener TODOS los registros de la base de datos
    const { data: allData, error } = await supabase
      .from('kv_store_9f68532a')
      .select('key, value');
    
    if (error) {
      console.error('❌ Error en búsqueda profunda:', error);
      return c.json({ error: error.message }, 500);
    }
    
    console.log(`📊 Total registros en DB: ${allData?.length || 0}`);
    
    // Buscar en TODOS los registros
    const resultados = (allData || []).filter((row: any) => {
      const key = (row.key || '').toLowerCase();
      const valueStr = JSON.stringify(row.value || {}).toLowerCase();
      
      return key.includes(termino) || valueStr.includes(termino);
    });
    
    console.log(`✅ Encontrados ${resultados.length} registros con "${termino}"`);
    
    return c.json({
      termino,
      totalRegistros: allData?.length || 0,
      encontrados: resultados.length,
      resultados: resultados.map(r => ({
        key: r.key,
        value: r.value
      }))
    });
    
  } catch (error: any) {
    console.error('❌ Error en búsqueda profunda:', error);
    return c.json({ error: error.message }, 500);
  }
});

// ==========================================
// RUTAS DE USUARIOS
// ==========================================

app.get("/make-server-9f68532a/users/:userId", async (c) => {
  try {
    const userId = c.req.param('userId');
    const user = await crm.getUserById(userId);
    
    if (!user) {
      return c.json({ error: "Usuario no encontrado" }, 404);
    }
    
    return c.json({ ...user, password: undefined });
  } catch (error) {
    console.error('Error al obtener usuario:', error);
    return c.json({ error: "Error al obtener usuario" }, 500);
  }
});

app.get("/make-server-9f68532a/users", async (c) => {
  try {
    console.log('🔍 ===== ENDPOINT /users LLAMADO =====');
    const users = await crm.getAllUsers();
    console.log(`✅ getAllUsers() retornó: ${users.length} usuarios`);
    
    // DEBUG: Buscar los 3 usuarios problemáticos
    const problematicos = [
      { id: '939da466-e00d-441f-8e17-d6e4b202ec34', idUnico: 'LF1765918120109793' },
      { id: '5b5b40d0-f38d-46fe-8b18-2342d8f27517', idUnico: 'LF1766081702464905' },
      { id: 'eadd906b-868f-46b6-98e3-b1699b5e56c8', idUnico: 'LF1766035063633662' }
    ];
    
    problematicos.forEach(p => {
      const encontrado = users.find((u: any) => u.id === p.id || u.id_unico === p.idUnico);
      if (encontrado) {
        console.log(`✅ ${p.idUnico} SÍ está en el resultado final`);
      } else {
        console.log(`❌ ${p.idUnico} NO está en el resultado final`);
      }
    });
    
    // OPTIMIZACIÓN: Cargar todos los datos una sola vez
    const allPacks = await crm.getAllPacks();
    const allComisiones = await crm.getAllComisiones();
    
    console.log(`📦 Total packs cargados: ${allPacks.length}`);
    console.log(`💰 Total comisiones cargadas: ${allComisiones.length}`);
    
    // Mapear packs por usuario
    const packsByUser = new Map<string, any[]>();
    allPacks.forEach(pack => {
      if (!packsByUser.has(pack.userId)) {
        packsByUser.set(pack.userId, []);
      }
      packsByUser.get(pack.userId)!.push(pack);
    });
    
    // Mapear comisiones por usuario
    const comisionesByUser = new Map<string, any[]>();
    allComisiones.forEach(comision => {
      if (!comisionesByUser.has(comision.userId)) {
        comisionesByUser.set(comision.userId, []);
      }
      comisionesByUser.get(comision.userId)!.push(comision);
    });
    
    // CALCULAR estadísticas para cada usuario
    const usersWithStats = users.map((user: any) => {
      // Contar referidos directos CON PACK ACTIVO
      const referidosDirectos = users.filter(u => u.referidoPor === user.id);
      const referidosConPack = referidosDirectos.filter(directo => {
        const packsDelDirecto = packsByUser.get(directo.id) || [];
        return packsDelDirecto.some(p => p.activo);
      });
      
      // Calcular inversión total
      const userPacks = packsByUser.get(user.id) || [];
      const totalInversion = userPacks.reduce((sum, p) => sum + p.monto, 0);
      
      // Calcular comisiones totales
      const comisiones = comisionesByUser.get(user.id) || [];
      const totalComisiones = comisiones.reduce((sum, c) => sum + c.monto, 0);
      
      return {
        ...user,
        password: undefined,
        referidos: referidosConPack.length,
        inversion: totalInversion,
        comisiones: totalComisiones
      };
    });
    
    console.log(`✅ Usuarios con estadísticas: ${usersWithStats.length}`);
    
    // DEBUG: Mostrar ejemplo de usuario con estadísticas
    const ejemploUsuario = usersWithStats.find(u => u.nombre === 'Waldo' || u.referidos > 0);
    if (ejemploUsuario) {
      console.log(`📊 EJEMPLO - ${ejemploUsuario.nombre}:`, {
        referidos: ejemploUsuario.referidos,
        inversion: ejemploUsuario.inversion,
        comisiones: ejemploUsuario.comisiones
      });
    }
    
    return c.json(usersWithStats);
  } catch (error) {
    console.error('Error al obtener usuarios:', error);
    return c.json({ error: "Error al obtener usuarios" }, 500);
  }
});

// RUTA DE DIAGNÓSTICO: Ver qué usuarios est��n siendo filtrados
app.get("/make-server-9f68532a/users/debug/filtered", async (c) => {
  try {
    const allData = await kv.getByPrefix('user:');
    console.log('🔍 DEBUG - Total items con prefijo user:', allData.length);
    
    const filtered: any[] = [];
    const valid: any[] = [];
    
    allData.forEach((item: any) => {
      const isUser = item && 
                     typeof item === 'object' && 
                     item.id && 
                     item.email && 
                     item.nombre &&
                     item.apellido &&
                     !item.id.includes(':') &&
                     !item.id.includes('email') &&
                     !item.id.includes('idUnico');
      
      if (isUser) {
        valid.push({
          id: item.id,
          nombre: item.nombre,
          apellido: item.apellido,
          email: item.email
        });
      } else if (item && typeof item === 'object' && item.id) {
        filtered.push({
          id: item.id,
          email: item.email || 'NO',
          nombre: item.nombre || 'NO',
          apellido: item.apellido || 'NO',
          hasColon: item.id?.includes(':'),
          hasEmail: item.id?.includes('email'),
          hasIdUnico: item.id?.includes('idUnico'),
          raw: JSON.stringify(item).substring(0, 200)
        });
      } else if (typeof item === 'string') {
        filtered.push({
          type: 'string',
          value: item
        });
      }
    });
    
    return c.json({
      total: allData.length,
      valid: valid.length,
      filtered: filtered.length,
      validUsers: valid,
      filteredItems: filtered
    });
  } catch (error) {
    console.error('Error en diagnóstico:', error);
    return c.json({ error: "Error en diagnóstico" }, 500);
  }
});

app.put("/make-server-9f68532a/users/:userId", async (c) => {
  try {
    const userId = c.req.param('userId');
    const updates = await c.req.json();
    
    const user = await crm.updateUser(userId, updates);
    if (!user) {
      return c.json({ error: "Usuario no encontrado" }, 404);
    }
    
    // 🔧 Invalidar caché después de actualizar usuario
    invalidateCache();
    
    return c.json({ ...user, password: undefined });
  } catch (error) {
    console.error('Error al actualizar usuario:', error);
    return c.json({ error: "Error al actualizar usuario" }, 500);
  }
});

// Obtener packs de un usuario
app.get("/make-server-9f68532a/users/:userId/packs", async (c) => {
  try {
    const userId = c.req.param('userId');
    const packs = await crm.getPacksByUserId(userId);
    return c.json(packs);
  } catch (error) {
    console.error('Error al obtener packs del usuario:', error);
    return c.json({ error: "Error al obtener packs" }, 500);
  }
});

// Obtener comisiones de un usuario
app.get("/make-server-9f68532a/users/:userId/comisiones", async (c) => {
  try {
    const userId = c.req.param('userId');
    const comisiones = await crm.getComisionesByUserId(userId);
    return c.json(comisiones);
  } catch (error) {
    console.error('Error al obtener comisiones del usuario:', error);
    return c.json({ error: "Error al obtener comisiones" }, 500);
  }
});

// Obtener total de comisiones de un usuario
app.get("/make-server-9f68532a/users/:userId/comisiones/total", async (c) => {
  try {
    const userId = c.req.param('userId');
    const comisiones = await crm.getComisionesByUserId(userId);
    
    // Calcular total
    const total = comisiones.reduce((sum, comision) => sum + comision.monto, 0);
    
    return c.json({ total });
  } catch (error) {
    console.error('Error al obtener total de comisiones:', error);
    return c.json({ error: "Error al obtener total de comisiones" }, 500);
  }
});

// Obtener depósitos de un usuario
app.get("/make-server-9f68532a/users/:userId/depositos", async (c) => {
  try {
    const userId = c.req.param('userId');
    
    // ⚡ Timeout de 10 segundos
    const depositosPromise = crm.getDepositosByUserId(userId);
    const timeoutPromise = new Promise((_, reject) => 
      setTimeout(() => reject(new Error('Timeout getting depositos')), 10000)
    );
    
    const depositos = await Promise.race([depositosPromise, timeoutPromise]);
    return c.json(depositos);
  } catch (error) {
    console.error('Error al obtener depósitos del usuario:', error);
    const errorMsg = error instanceof Error ? error.message : String(error);
    if (errorMsg.includes('timeout') || errorMsg.includes('Timeout')) {
      console.log('⚠️ Timeout en depósitos, retornando array vacío');
      return c.json([]);
    }
    return c.json({ error: "Error al obtener depósitos" }, 500);
  }
});

// Obtener cobros de un usuario
app.get("/make-server-9f68532a/users/:userId/cobros", async (c) => {
  try {
    const userId = c.req.param('userId');
    const cobros = await crm.getCobrosByUserId(userId);
    return c.json(cobros);
  } catch (error: any) {
    console.error('Error al obtener cobros del usuario:', error);
    return c.json({ 
      error: "Error al obtener cobros",
      details: error?.message || 'Unknown error'
    }, 500);
  }
});

// Obtener rendimientos de un usuario
app.get("/make-server-9f68532a/users/:userId/rendimientos", async (c) => {
  try {
    const userId = c.req.param('userId');
    const rendimientos = await crm.getRendimientosByUserId(userId);
    return c.json(rendimientos);
  } catch (error) {
    console.error('Error al obtener rendimientos del usuario:', error);
    return c.json({ error: "Error al obtener rendimientos" }, 500);
  }
});

// Obtener total de rendimientos de un usuario
app.get("/make-server-9f68532a/users/:userId/rendimientos/total", async (c) => {
  try {
    const userId = c.req.param('userId');
    const total = await crm.getTotalRendimientosByUserId(userId);
    return c.json({ total });
  } catch (error) {
    console.error('Error al obtener total de rendimientos:', error);
    return c.json({ error: "Error al obtener total de rendimientos" }, 500);
  }
});

// Obtener saldo de wallet de un usuario
app.get("/make-server-9f68532a/users/:userId/saldo-wallet", async (c) => {
  try {
    const userId = c.req.param('userId');
    
    // Obtener datos necesarios
    const [comisiones, cobros, packs, gastosRuleta] = await Promise.all([
      crm.getComisionesByUserId(userId),
      crm.getCobrosByUserId(userId),
      crm.getPacksByUserId(userId),
      crm.getGastosRuletaByUserId(userId)
    ]);
    
    // Calcular totales
    const totalGanado = comisiones.reduce((sum, c) => sum + c.monto, 0);
    const totalRetirado = cobros
      .filter((c: any) => c.estado === 'completado' || c.estado === 'pendiente')
      .reduce((sum, c) => sum + c.monto, 0);
    const totalGastadoRuleta = gastosRuleta.reduce((sum, g) => sum + g.monto, 0);
    
    // Calcular límite de retiro (200% de inversión)
    // IMPORTANTE: Solo contar el pack activo
    const packActivo = packs.find(p => p.activo);
    const inversionTotal = packActivo ? packActivo.monto : 0;
    const limiteRetiro = inversionTotal * 2;
    
    // Saldo disponible - SIN LÍMITE para el saldo histórico
    // El límite del 200% detiene la generación de nuevas comisiones, no el uso del saldo ya ganado
    const saldoDisponible = Math.max(0, totalGanado - totalRetirado - totalGastadoRuleta);
    
    console.log(`💰 Saldo wallet de usuario ${userId}:`, {
      totalGanado,
      totalRetirado,
      totalGastadoRuleta,
      inversionTotal,
      limiteRetiro,
      saldoDisponible
    });
    
    return c.json({ 
      saldo: saldoDisponible,
      detalle: {
        totalGanado,
        totalRetirado,
        totalGastadoRuleta,
        inversionTotal,
        limiteRetiro
      }
    });
  } catch (error) {
    console.error('Error al obtener saldo wallet del usuario:', error);
    return c.json({ error: "Error al obtener saldo wallet" }, 500);
  }
});

// Obtener referidos directos de un usuario
app.get("/make-server-9f68532a/users/:userId/referidos", async (c) => {
  try {
    const userId = c.req.param('userId');
    const now = Date.now();
    
    // ✅ STALE-WHILE-REVALIDATE: Devolver caché antiguo si existe, refrescar en background
    const cached = cacheReferidos.get(userId);
    const isExpired = !cached || (now - cached.timestamp > REFERIDOS_CACHE_TTL);
    
    // Si tenemos caché (incluso expirado), devolverlo inmediatamente
    if (cached && cached.data) {
      console.log(`⚡ [STALE] Devolviendo referidos desde caché para ${userId} (${cached.data.length} referidos)`);
      
      // Si está expirado, refrescar en background
      if (isExpired) {
        console.log('🔄 [BACKGROUND] Refrescando referidos en segundo plano...');
        // Refrescar en background sin bloquear
        (async () => {
          try {
            const allUsers = await getCachedUsuarios();
            const referidos = allUsers.filter((u: any) => u.referidoPor === userId);
            const cleaned = referidos.map(u => ({ ...u, password: undefined }));
            cacheReferidos.set(userId, { data: cleaned, timestamp: Date.now() });
            console.log(`✅ [BACKGROUND] Referidos actualizados para ${userId}: ${referidos.length}`);
          } catch (err) {
            console.error('❌ [BACKGROUND] Error refrescando referidos:', err);
          }
        })();
      }
      
      return c.json(cached.data);
    }
    
    // No hay caché, cargar síncronamente (primera vez)
    console.log(`🔄 Primera carga de referidos para ${userId}...`);
    const allUsers = await getCachedUsuarios();
    const referidos = allUsers.filter((u: any) => u.referidoPor === userId);
    const cleaned = referidos.map(u => ({ ...u, password: undefined }));
    
    // Guardar en caché
    cacheReferidos.set(userId, { data: cleaned, timestamp: now });
    
    console.log(`✅ Referidos directos encontrados para ${userId}: ${referidos.length}`);
    return c.json(cleaned);
  } catch (error) {
    console.error('Error al obtener referidos del usuario:', error);
    return c.json({ error: "Error al obtener referidos" }, 500);
  }
});

// NUEVO: Obtener referidos directos CON sus packs (optimizado para dashboard)
app.get("/make-server-9f68532a/users/:userId/referidos-con-packs", async (c) => {
  try {
    const userId = c.req.param('userId');
    
    // Obtener TODA la red genealógica (directos + sus descendientes)
    const allUsers = await getCachedUsuarios();
    const allPacks = await getCachedPacks();
    
    // Función para obtener todos los referidos recursivamente
    const getAllReferidosRecursive = (parentId: string, currentLevel: number, visited: Set<string>): any[] => {
      if (currentLevel > 10 || visited.has(parentId)) return [];
      visited.add(parentId);
      
      const directRefs = allUsers.filter(u => u.referidoPor === parentId);
      let allRefs = directRefs.map(r => ({ user: r, nivel: currentLevel }));
      
      for (const ref of directRefs) {
        allRefs.push(...getAllReferidosRecursive(ref.id, currentLevel + 1, visited));
      }
      
      return allRefs;
    };
    
    // Obtener todos los referidos de la red (hasta 10 niveles)
    const todaLaRed = getAllReferidosRecursive(userId, 1, new Set());
    
    // Formatear referidos con información de packs
    const referidosConPacks = todaLaRed.map(({ user: ref, nivel }) => {
      const packsReferido = allPacks.filter(p => p.userId === ref.id);
      const packActivo = packsReferido.filter(p => p.activo)[0];
      const inversionActiva = packsReferido
        .filter(p => p.activo)
        .reduce((sum, p) => sum + p.monto, 0);
      
      return {
        ...ref,
        password: undefined,
        pack: packActivo ? packActivo.nombre : 'Sin Pack',
        inversion: inversionActiva,
        esDirecto: nivel === 1, // Marca si es directo (nivel 1) o indirecto
        nivel
      };
    });
    
    console.log(`✅ Red completa de ${userId}: ${referidosConPacks.length} personas, volumen total: $${referidosConPacks.reduce((sum, r) => sum + r.inversion, 0)}`);
    
    return c.json(referidosConPacks);
  } catch (error) {
    console.error('Error al obtener referidos con packs:', error);
    return c.json({ error: "Error al obtener referidos" }, 500);
  }
});

// DEBUG: Ver estructura de referidos
app.get("/make-server-9f68532a/users/:userId/debug-referidos", async (c) => {
  try {
    const userId = c.req.param('userId');
    const user = await crm.getUserById(userId);
    const todosLosUsuarios = await crm.getAllUsers();
    const todosLosPacks = await Promise.all(
      todosLosUsuarios.map(u => crm.getPacksByUserId(u.id))
    ).then(results => results.flat());
    
    // Referidos directos (hijos)
    const referidosDirectos = todosLosUsuarios.filter((u: any) => u.referidoPor === userId);
    
    const debug = {
      usuario: {
        id: user?.id,
        id_unico: user?.id_unico,
        nombre: `${user?.nombre} ${user?.apellido}`,
        email: user?.email
      },
      totalReferidosDirectos: referidosDirectos.length,
      referidosDirectos: referidosDirectos.map((ref: any, idx: number) => {
        const refPack = todosLosPacks.find((p: any) => p.userId === ref.id && p.activo);
        const hijosDeEsteReferido = todosLosUsuarios.filter((u: any) => u.referidoPor === ref.id);
        
        return {
          posicion: idx + 1,
          id: ref.id,
          id_unico: ref.id_unico,
          nombre: `${ref.nombre} ${ref.apellido}`,
          email: ref.email,
          activo: ref.activo,
          tienePack: !!refPack,
          packNombre: refPack?.nombre,
          referidoPor: ref.referidoPor,
          totalHijos: hijosDeEsteReferido.length,
          hijos: hijosDeEsteReferido.map(h => ({
            id: h.id,
            id_unico: h.id_unico,
            nombre: `${h.nombre} ${h.apellido}`,
            activo: h.activo,
            tienePack: !!todosLosPacks.find((p: any) => p.userId === h.id && p.activo)
          }))
        };
      })
    };
    
    return c.json(debug);
  } catch (error) {
    console.error('Error en debug de referidos:', error);
    return c.json({ error: "Error en debug" }, 500);
  }
});

// RUTA TEMPORAL: Obtener usuario por email (solo para debug)
app.get("/make-server-9f68532a/users/byemail/:email", async (c) => {
  try {
    const email = c.req.param('email');
    const user = await crm.getUserByEmail(email);
    
    if (!user) {
      return c.json({ error: "Usuario no encontrado" }, 404);
    }
    
    return c.json({
      id: user.id,
      id_unico: user.id_unico,
      nombre: user.nombre,
      apellido: user.apellido,
      email: user.email,
      password: user.password,
      activo: user.activo,
      referralCode: user.referralCode
    });
  } catch (error) {
    console.error('Error al buscar usuario por email:', error);
    return c.json({ error: "Error al buscar usuario" }, 500);
  }
});

// ⚡ NUEVO ENDPOINT: Dashboard Rápido (SIN matriz, datos críticos solamente)
app.get("/make-server-9f68532a/users/:userId/dashboard-quick", async (c) => {
  try {
    const userId = c.req.param('userId');
    const startTime = Date.now();
    
    console.log(`⚡ [QUICK] Cargando dashboard rápido para: ${userId}`);
    
    // Solo usar caché para usuarios/packs, comisiones se cargan fresh
    const [allUsers, allPacks] = await Promise.all([
      withTimeout(getCachedUsuarios(), 20000, []),  // ⚡ REDUCIDO: 20s (era 30s)
      withTimeout(getCachedPacks(), 10000, [])      // ⚡ REDUCIDO: 10s (era 15s)
    ]);
    
    // Datos del usuario SIEMPRE frescos (no cachear)
    const [userPacks, userComisiones, userCobros, userGastosRuleta] = await Promise.all([
      withTimeout(crm.getPacksByUserId(userId), 5000, []),  // ⚡ REDUCIDO: 5s (era 8s)
      withTimeout(crm.getComisionesByUserId(userId), 5000, []),
      withTimeout(crm.getCobrosByUserId(userId), 5000, []),
      withTimeout(crm.getGastosRuletaByUserId(userId), 5000, [])
    ]);
    
    // 🔧 FIX: Buscar usuario en caché PRIMERO, si no existe buscar directamente en DB
    let user = allUsers.find((u: any) => u.id === userId);
    
    if (!user) {
      console.log(`⚠️ Usuario ${userId} NO encontrado en caché, buscando en DB directamente...`);
      user = await crm.getUserById(userId);
      
      if (!user) {
        console.error(`❌ Usuario ${userId} NO EXISTE en la base de datos`);
        return c.json({ error: "Usuario no encontrado" }, 404);
      }
      
      console.log(`✅ Usuario ${userId} encontrado en DB:`, user.nombre, user.apellido);
    }
    
    // Calcular comisiones (SIEMPRE FRESCO)
    const comisionesArray = Array.isArray(userComisiones) ? userComisiones : [];
    
    // 🔧 CORRECCIÓN: Separar rendimientos por día vs histórico
    const hoy = new Date();
    hoy.setHours(0, 0, 0, 0); // Inicio del día
    const inicioDia = hoy.toISOString();
    
    const comisionesPorTipo = {
      red: comisionesArray.filter((c: any) => c?.tipo === 'red').reduce((sum, c) => sum + (c?.monto || 0), 0),
      rendimiento: comisionesArray.filter((c: any) => c?.tipo === 'rendimiento').reduce((sum, c) => sum + (c?.monto || 0), 0),
      rendimientoHoy: comisionesArray
        .filter((c: any) => c?.tipo === 'rendimiento' && c?.fecha && new Date(c.fecha) >= hoy)
        .reduce((sum, c) => sum + (c?.monto || 0), 0),
      patrocinio: comisionesArray.filter((c: any) => c?.tipo === 'patrocinio').reduce((sum, c) => sum + (c?.monto || 0), 0),
      rangos: comisionesArray.filter((c: any) => c?.tipo === 'rangos').reduce((sum, c) => sum + (c?.monto || 0), 0)
    };
    
    // 🔥 LÓGICA INTELIGENTE DE PACK ACTIVO (igual que en dashboard-completo)
    const inversionTotal = userPacks?.reduce((sum, p) => sum + p.monto, 0) || 0;
    const totalGanado = comisionesArray.reduce((sum, c) => sum + (c?.monto || 0), 0);
    
    // Calcular rendimientos acumulados POR PACK
    const rendimientosPorPack = new Map<string, number>();
    comisionesArray.forEach((c: any) => {
      if (c.tipo === 'rendimiento' && c.packId) {
        const actual = rendimientosPorPack.get(c.packId) || 0;
        rendimientosPorPack.set(c.packId, actual + (c.monto || 0));
      }
    });
    
    // Determinar pack activo CORRECTO (el más reciente que NO llegó al 200%)
    let packActivo = null;
    const packsOrdenados = [...(userPacks || [])]
      .filter(p => p.fechaCompra)
      .sort((a, b) => new Date(b.fechaCompra).getTime() - new Date(a.fechaCompra).getTime());
    
    for (const pack of packsOrdenados) {
      const rendimientosAcumulados = rendimientosPorPack.get(pack.id) || 0;
      const limite200 = pack.monto * 2;
      
      // Si este pack NO ha llegado al 200%, es el pack activo
      if (rendimientosAcumulados < limite200) {
        packActivo = pack;
        
        // Actualizar estado en DB si es necesario
        if (!pack.activo) {
          console.log(`✅ [QUICK] Activando pack ${pack.nombre}`);
          await crm.updatePack(pack.id, { activo: true });
          pack.activo = true;
        }
        break;
      } else {
        // Este pack ya llegó al 200%, desactivar
        if (pack.activo) {
          console.log(`🔴 [QUICK] Desactivando pack ${pack.nombre} (200% alcanzado)`);
          await crm.updatePack(pack.id, { activo: false });
          pack.activo = false;
        }
      }
    }
    
    console.log(`📦 [QUICK] Pack activo: ${packActivo ? packActivo.nombre : 'NINGUNO'}`);
    
    // Calcular saldo
    const totalRetirado = (Array.isArray(userCobros) ? userCobros : [])
      .filter((c: any) => c?.estado === 'completado' || c?.estado === 'pendiente')
      .reduce((sum, c) => sum + (c?.monto || 0), 0);
    const totalGastadoRuleta = (Array.isArray(userGastosRuleta) ? userGastosRuleta : [])
      .reduce((sum, g) => sum + (g?.monto || 0), 0);
    const saldoDisponible = Math.max(0, totalGanado - totalRetirado - totalGastadoRuleta);
    const limiteRetiro = (packActivo?.monto || 0) * 2;
    
    // ✅ CALCULAR SI EL PACK ACTUAL COMPLETÓ EL 200%
    const packCompletado = packActivo ? (totalGanado >= limiteRetiro) : false;
    
    // Calcular referidos directos (rápido)
    const referidosDirectos = allUsers?.filter((u: any) => u.referidoPor === userId) || [];
    const directosConPack = referidosDirectos.filter((ref: any) => {
      const refPacks = allPacks?.filter((p: any) => p.userId === ref.id) || [];
      return refPacks.some((p: any) => p.activo);
    });
    
    console.log(`🔍 DEBUG REFERIDOS DIRECTOS (QUICK) para ${userId}:`, {
      userId: userId,
      totalUsuariosEnCache: allUsers?.length || 0,
      totalPacksEnCache: allPacks?.length || 0,
      totalReferidosDirectos: referidosDirectos.length,
      directosConPack: directosConPack.length,
      referidosDirectosIds: referidosDirectos.map((r: any) => ({ id: r.id_unico, nombre: r.nombre, referidoPor: r.referidoPor })),
      directosConPackIds: directosConPack.map((r: any) => ({ id: r.id_unico, nombre: r.nombre, packs: allPacks?.filter((p: any) => p.userId === r.id).map((p: any) => ({ nombre: p.nombre, activo: p.activo })) }))
    });
    
    // ⚡ OPTIMIZACIÓN: No calcular red recursiva en quick mode (muy lento con redes grandes)
    // El dashboard completo tendrá la red completa
    const totalRed = 0; // Se cargará en dashboard-completo
    
    const loadTime = Date.now() - startTime;
    console.log(`✅ [QUICK] Dashboard rápido cargado en ${loadTime}ms`);
    
    return c.json({
      usuario: {
        id: user.id,
        id_unico: user.id_unico,
        nombre: user.nombre,
        apellido: user.apellido,
        email: user.email,
        rango: user.rango || 'Sin Rango',
        referralCode: user.referralCode || user.id_unico
      },
      pack: {
        activo: packActivo ? {
          nombre: packActivo.nombre,
          monto: packActivo.monto,
          completado: packCompletado
        } : null,
        inversionTotal: inversionTotal
      },
      wallet: {
        saldoDisponible: saldoDisponible,
        totalGanado: totalGanado,
        limiteRetiro: limiteRetiro,
        porcentajeAlcanzado: inversionTotal > 0 ? (totalGanado / limiteRetiro) * 100 : 0
      },
      comisiones: {
        total: totalGanado,
        porTipo: comisionesPorTipo
      },
      red: {
        directos: {
          total: referidosDirectos.length,
          conPack: directosConPack.length
        },
        total: totalRed
      },
      _meta: {
        loadTime: loadTime,
        mode: 'quick',
        timestamp: new Date().toISOString()
      }
    });
  } catch (error) {
    console.error('❌ Error en dashboard-quick:', error);
    console.error('Stack:', error instanceof Error ? error.stack : 'No stack trace');
    
    // ⚡ Manejo específico de timeouts
    const errorMsg = error instanceof Error ? error.message : String(error);
    if (errorMsg.includes('timeout') || errorMsg.includes('closed') || errorMsg.includes('ECONNRESET')) {
      console.error('⚠️ Error de timeout/conexión en dashboard-quick');
      return c.json({ 
        error: "La solicitud tardó demasiado tiempo. Por favor intente de nuevo.",
        code: "REQUEST_TIMEOUT"
      }, 504);
    }
    
    return c.json({ error: "Error al cargar dashboard rápido" }, 500);
  }
});

// 🚀 ENDPOINT SUPER OPTIMIZADO V2: Dashboard Completo (SIN cargar todos los usuarios)
app.get("/make-server-9f68532a/users/:userId/dashboard-completo", async (c) => {
  try {
    const userId = c.req.param('userId');
    
    // 🚀 VERIFICAR CACHÉ DE DASHBOARD PRIMERO
    const cachedDashboard = cacheDashboards.get(userId);
    if (cachedDashboard && (Date.now() - cachedDashboard.timestamp < DASHBOARD_CACHE_TTL)) {
      console.log(`⚡ [CACHE HIT] Dashboard cargado desde caché para: ${userId} (${Date.now() - cachedDashboard.timestamp}ms de antigüedad)`);
      return c.json(cachedDashboard.data);
    }
    
    console.log(`⚡ [v2025-OPTIMIZADO-V2] Usando nueva función optimizada SIN getAllUsers() para ${userId}...`);
    
    const startTime = Date.now();
    
    // 🚀 NUEVA VERSIÓN: Usar función optimizada que NO carga todos los usuarios
    const dashboardData = await withTimeout(
      crm.getDashboardDataOptimizado(userId),
      60000, // 60 segundos timeout (aumentado para redes grandes)
      null
    );
    
    if (!dashboardData) {
      throw new Error('Timeout al cargar dashboard');
    }
    
    const loadTime = Date.now() - startTime;
    console.log(`✅ [OPTIMIZADO V2] Dashboard completo cargado en ${loadTime}ms (sin getAllUsers)`);
    
    // Formatear respuesta en el formato esperado por el frontend
    const response = {
      usuario: dashboardData.usuario,
      pack: {
        activo: dashboardData.pack.activo ? {
          id: dashboardData.pack.activo.id,
          nombre: dashboardData.pack.activo.nombre,
          monto: dashboardData.pack.activo.monto,
          fechaActivacion: dashboardData.pack.activo.fechaCompra,
          completado: dashboardData.pack.completado
        } : null,
        inversionTotal: dashboardData.pack.inversionTotal,
        todosLosPacks: dashboardData.pack.todosLosPacks.map((p: any) => ({
          id: p.id,
          nombre: p.nombre,
          monto: p.monto,
          activo: p.activo,
          fechaActivacion: p.fechaCompra
        }))
      },
      wallet: dashboardData.wallet,
      comisiones: dashboardData.comisiones,
      rendimientos: {
        total: dashboardData.comisiones.porTipo.rendimiento,
        historial: dashboardData.comisiones.historial.filter((c: any) => c.tipo === 'rendimiento')
      },
      red: dashboardData.red,
      _meta: {
        loadTime,
        optimizado: true,
        cached: false,
        timestamp: new Date().toISOString()
      }
    };
    
    // 🚀 GUARDAR EN CACHÉ
    cacheDashboards.set(userId, {
      data: response,
      timestamp: Date.now()
    });
    console.log(`💾 Dashboard optimizado guardado en caché para: ${userId}`);
    
    return c.json(response);
  } catch (error) {
    console.error('❌ Error al cargar dashboard completo (V2 optimizado):', error);
    console.error('Stack:', error instanceof Error ? error.stack : 'No stack trace');
    
    // Manejo de timeout específico
    const errorMsg = error instanceof Error ? error.message : String(error);
    if (errorMsg.includes('timeout') || errorMsg.includes('Timeout') || errorMsg.includes('closed') || errorMsg.includes('ECONNRESET')) {
      console.error('⚠️ Error de timeout/conexión detectado (límite: 60s)');
      return c.json({ 
        error: "La red es muy grande y tardó más de 60 segundos en cargarse. Por favor intente de nuevo o contacte soporte.",
        code: "REQUEST_TIMEOUT",
        hint: "Considere usar el dashboard rápido (/dashboard-quick) para redes muy grandes"
      }, 504);
    }
    
    return c.json({ 
      error: "Error al cargar dashboard completo",
      details: errorMsg
    }, 500);
  }
});

// Obtener matriz de un usuario (SIMPLIFICADO - solo nivel 1)
app.get("/make-server-9f68532a/users/:userId/matriz", async (c) => {
  const startTime = Date.now();
  try {
    const userId = c.req.param('userId');
    
    console.log(`🔍 [MATRIZ] Cargando matriz completa para ${userId}...`);
    
    // 1. Cargar datos del usuario
    const usuario = await crm.getUserById(userId);
    if (!usuario) {
      return c.json({ error: 'Usuario no encontrado' }, 404);
    }
    
    // 2. Cargar packs del usuario
    const packs = await crm.getPacksByUserId(userId);
    const totalInversion = packs.reduce((sum, p) => sum + p.monto, 0);
    const packActivo = packs.find(p => p.activo);
    
    // 3. Usar caché para obtener todos los usuarios y packs
    const allUsers = await getCachedUsuarios();
    const allPacks = await getCachedPacks();
    
    console.log(`📊 Total usuarios en sistema: ${allUsers.length}, Total packs: ${allPacks.length}`);
    
    // 4. Crear mapas para búsqueda rápida
    const usersMap = new Map<string, any>();
    allUsers.forEach((u: any) => {
      usersMap.set(u.id, u);
    });
    
    const packsMap = new Map<string, any[]>();
    allPacks.forEach((pack: any) => {
      if (!pack || !pack.userId) return;
      if (!packsMap.has(pack.userId)) {
        packsMap.set(pack.userId, []);
      }
      packsMap.get(pack.userId)!.push(pack);
    });
    
    // 5. Crear mapa de usuarios por matrizPadre para spillover
    // IMPORTANTE: Cada usuario debe aparecer SOLO UNA VEZ, aunque tenga múltiples packs
    const matrizMap = new Map<string, any[]>();
    const usuariosYaProcesados = new Map<string, Set<string>>(); // padreId -> Set<userId>
    
    allPacks.forEach((pack: any) => {
      if (!pack || !pack.matrizPadre || !pack.userId) return;
      
      // Inicializar set de usuarios procesados para este padre
      if (!usuariosYaProcesados.has(pack.matrizPadre)) {
        usuariosYaProcesados.set(pack.matrizPadre, new Set());
      }
      
      // Verificar si este usuario YA fue agregado bajo este padre
      if (usuariosYaProcesados.get(pack.matrizPadre)!.has(pack.userId)) {
        console.log(`⏭️  Saltando pack duplicado: Usuario ${pack.userId} ya está bajo padre ${pack.matrizPadre}`);
        return; // Saltar este pack, el usuario ya está en la matriz
      }
      
      // Agregar usuario a la matriz
      if (!matrizMap.has(pack.matrizPadre)) {
        matrizMap.set(pack.matrizPadre, []);
      }
      matrizMap.get(pack.matrizPadre)!.push({
        userId: pack.userId,
        posicion: pack.matrizPosicion || 999
      });
      
      // Marcar como procesado
      usuariosYaProcesados.get(pack.matrizPadre)!.add(pack.userId);
    });
    
    // 6. Función helper para obtener info de un usuario
    const getUserInfo = (uid: string) => {
      const user = usersMap.get(uid);
      if (!user) return null;
      
      const userPacks = packsMap.get(uid) || [];
      const userPackActivo = userPacks.find(p => p.activo);
      const userInversion = userPacks.reduce((sum, p) => sum + p.monto, 0);
      
      return {
        id: user.id_unico,
        internalId: user.id,
        nombre: user.nombre,
        apellido: user.apellido,
        pack: userPackActivo?.nombre || 'Sin Pack',
        estatus: user.activo ? 'activo' : 'inactivo',
        inversion: userInversion
      };
    };
    
    // 7. Construir matriz completa (10 niveles)
    const cycle: any = {
      level1: [null, null, null],
      level2: Array(9).fill(null),
      level3: Array(27).fill(null),
      level4: Array(81).fill(null),
      level5: Array(243).fill(null),
      level6: Array(729).fill(null),
      level7: Array(2187).fill(null),
      level8: Array(6561).fill(null),
      level9: Array(19683).fill(null),
      level10: Array(59049).fill(null)
    };
    
    // 8. Llenar Nivel 1 - hijos directos del usuario raíz
    const hijosNivel1 = matrizMap.get(userId) || [];
    hijosNivel1.sort((a, b) => a.posicion - b.posicion);
    
    console.log(`👶 Nivel 1: ${hijosNivel1.length} usuarios bajo ${userId}`);
    console.log(`   Usuarios en Nivel 1:`, hijosNivel1.map(h => ({ userId: h.userId, pos: h.posicion })));
    
    for (let i = 0; i < Math.min(3, hijosNivel1.length); i++) {
      const userInfo = getUserInfo(hijosNivel1[i].userId);
      if (userInfo) {
        cycle.level1[i] = userInfo;
        console.log(`   ✅ Posición ${i}: ${userInfo.nombre} ${userInfo.apellido} (${userInfo.internalId})`);
      }
    }
    
    // 9. Llenar niveles 2-10 recursivamente
    const llenarNivelRecursivo = (nivelPadre: number, posicionPadre: number, nivelActual: number) => {
      if (nivelActual > 10) return;
      
      // Obtener el usuario padre
      const levelKey = `level${nivelPadre}`;
      const padre = cycle[levelKey][posicionPadre];
      
      if (!padre || !padre.internalId) return;
      
      // Obtener hijos de este padre
      const hijos = matrizMap.get(padre.internalId) || [];
      hijos.sort((a, b) => a.posicion - b.posicion);
      
      console.log(`   🔄 Nivel ${nivelActual}: Padre "${padre.nombre}" (pos ${posicionPadre} en nivel ${nivelPadre}) tiene ${hijos.length} hijos`);
      
      // Calcular posición inicial en el nivel actual
      // Cada nodo tiene 3 hijos, entonces:
      // posicionInicial = posicionPadre * 3
      const posicionInicial = posicionPadre * 3;
      const levelKeyActual = `level${nivelActual}`;
      
      // Llenar hasta 3 hijos
      for (let i = 0; i < Math.min(3, hijos.length); i++) {
        const userInfo = getUserInfo(hijos[i].userId);
        if (userInfo && cycle[levelKeyActual]) {
          const pos = posicionInicial + i;
          if (pos < cycle[levelKeyActual].length) {
            cycle[levelKeyActual][pos] = userInfo;
            console.log(`      ✅ Nivel ${nivelActual} pos ${pos}: ${userInfo.nombre} (hijo de ${padre.nombre})`);
            
            // Recursión: llenar los hijos de este hijo
            llenarNivelRecursivo(nivelActual, pos, nivelActual + 1);
          }
        }
      }
    };
    
    // Iniciar recursión desde cada nodo del nivel 1
    for (let i = 0; i < cycle.level1.length; i++) {
      if (cycle.level1[i]) {
        llenarNivelRecursivo(1, i, 2);
      }
    }
    
    // 10. Contar usuarios por nivel
    const stats: any = {};
    for (let nivel = 1; nivel <= 10; nivel++) {
      const levelKey = `level${nivel}`;
      const activos = cycle[levelKey].filter((u: any) => u !== null).length;
      stats[levelKey] = activos;
    }
    
    console.log(`📊 Usuarios por nivel:`, stats);
    
    // 11. Formatear referidos directos para la lista
    const referidosDirectos = allUsers.filter((u: any) => u.referidoPor === userId && u.activo);
    const directosFormateados = referidosDirectos.slice(0, 20).map((ref) => {
      const refPacks = packsMap.get(ref.id) || [];
      const refInversion = refPacks.reduce((sum, p) => sum + p.monto, 0);
      const refPackActivo = refPacks.find(p => p.activo);
      
      return {
        id: ref.id_unico,
        nombre: ref.nombre,
        apellido: ref.apellido,
        nivel: 1,
        pack: refPackActivo?.nombre || 'Sin pack',
        estatus: ref.activo ? 'activo' : 'inactivo',
        inversion: refInversion
      };
    });
    
    const elapsed = Date.now() - startTime;
    console.log(`✅ [MATRIZ] Matriz completa generada en ${elapsed}ms`);
    
    return c.json({
      cycle,
      directos: directosFormateados,
      inversion: totalInversion,
      pack: packActivo?.nombre || 'Sin pack'
    });
    
  } catch (error) {
    const elapsed = Date.now() - startTime;
    console.error(`❌ [MATRIZ] Error en matriz (${elapsed}ms):`, error);
    return c.json({ 
      error: "Error al obtener matriz",
      details: error instanceof Error ? error.message : String(error)
    }, 500);
  }
});

// Endpoint LEGACY (comentado) - Causaba timeout
/*
app.get("/make-server-9f68532a/users/:userId/matriz-legacy", async (c) => {
  const startTime = Date.now();
  try {
    const userId = c.req.param('userId');
    const niveles = parseInt(c.req.query('niveles') || '1'); // 🚨 REDUCIDO A 1 NIVEL para evitar timeout
    
    console.log(`🔍 Obteniendo matriz con spillover para usuario: ${userId} (${niveles} niveles)`);
    
    // 🚀 USAR CACHÉ para evitar timeout - crm.getAllUsers() tarda más de 10 segundos
    const todosLosUsuarios = await getCachedUsuarios();
    const usuariosActivos = todosLosUsuarios.filter((u: any) => u.activo);
    
    // OPTIMIZACIÓN: Usar caché de packs también
    const rawPacks = await getCachedPacks();
    const activeUserIds = new Set(usuariosActivos.map((u: any) => u.id));
    const todosLosPacks = rawPacks.filter((p: any) => activeUserIds.has(p.userId));
    
    console.log(`��� Usuarios activos: ${usuariosActivos.length}, Total Packs: ${todosLosPacks.length}`);
    
    // Función para construir matriz basada ESTRICTAMENTE en la base de datos (matrizPadre)
    // Esto garantiza que la visualización coincida 100% con el motor de comisiones.
    const buildNetworkLevels = (rootUserId: string, allUsers: any[], allPacks: any[], maxNiveles: number = 3) => {
      const levels: any = {};
      const MAX_NIVELES_VISUAL = Math.min(maxNiveles, 10); // L��mite duro de 10 niveles
      
      // Inicializar niveles con arrays vacíos de tamaño correcto (3^N)
      for (let i = 1; i <= MAX_NIVELES_VISUAL; i++) {
        levels[`level${i}`] = Array(Math.pow(3, i)).fill(null);
      }
      
      console.log(`🏗�� Construyendo matriz estricta para ${rootUserId} (${MAX_NIVELES_VISUAL} niveles)`);

      // Mapa auxiliar de packs por usuario para acceso rápido (usando el pack activo o el más reciente)
      const userPackMap = new Map();
      allPacks.forEach(p => {
        // Priorizar pack activo, si no, usar el más reciente
        if (!userPackMap.has(p.userId) || (p.activo && !userPackMap.get(p.userId).activo)) {
          userPackMap.set(p.userId, p);
        }
      });

      const crearNodoUsuario = (userId: string) => {
        const user = allUsers.find(u => u.id === userId);
        const userPack = userPackMap.get(userId); // Pack que define la posición
        
        // Buscar el pack activo actual para mostrar nombre
        // (Nota: userPack puede ser uno inactivo si define la posición histórica)
        const activePack = allPacks.find(p => p.userId === userId && p.activo);
        
        if (!user) return null;

        // Calcular inversión total histórica
        const inversionTotal = allPacks
          .filter(p => p.userId === userId)
          .reduce((sum, p) => sum + p.monto, 0);
        
        return {
          id: user.id_unico, // ID público
          internalId: user.id, // ID interno para linkeo
          nombre: user.nombre,
          apellido: user.apellido,
          pack: activePack ? activePack.nombre : (userPack ? userPack.nombre + ' (Inactivo)' : 'Sin Pack'),
          estatus: user.activo ? 'activo' : 'inactivo',
          inversion: inversionTotal
        };
      };

      // Cola BFS: { userId, nivel, index }
      // El index determina la posición exacta en el array del nivel (de 0 a 3^N - 1)
      const queue = [{ userId: rootUserId, nivel: 0, index: 0 }];
      const processedUsers = new Set<string>();
      processedUsers.add(rootUserId);

      let usersFound = 0;
      let iteraciones = 0;
      const MAX_ITERACIONES = 10000; // Límite de seguridad para evitar loops infinitos

      while (queue.length > 0 && iteraciones < MAX_ITERACIONES) {
        iteraciones++;
        const current = queue.shift();
        if (!current) continue;
        if (current.nivel >= MAX_NIVELES_VISUAL) continue;

        // Buscar hijos directos en la matriz:
        // Usuarios cuyo pack tenga matrizPadre === current.userId
        const childrenPacks = allPacks.filter(p => 
          p.matrizPadre === current.userId && 
          // IMPORTANTE: Filtrar packs duplicados del mismo usuario (usar solo el que define la posición)
          // Aunque idealmente todos los packs de un usuario tienen el mismo padre y posición.
          // Usamos un Set para obtener usuarios únicos.
          true
        );
        
        // DEBUG: Log de hijos encontrados solo para nivel 0 (reducir logging)
        if (current.nivel === 0) {
          console.log(`🔍 DEBUG Nivel ${current.nivel + 1} - Hijos del usuario (${current.userId}): ${childrenPacks.length} packs`);
        }

        // Obtener usuarios únicos hijos
        const uniqueChildrenIds = [...new Set(childrenPacks.map(p => p.userId))];

        uniqueChildrenIds.forEach(childId => {
            if (processedUsers.has(childId)) {
              console.warn(`⚠️ Usuario ${childId} ya fue procesado (nivel ${current.nivel + 1}), saltando...`);
              return; // Evitar ciclos
            }

            const childPack = userPackMap.get(childId);
            if (!childPack) {
              console.error(`❌ No se encontró pack para usuario ${childId} en userPackMap`);
              return;
            }

            // Determinar posición (0, 1, 2)
            // Si matrizPosicion no existe (legacy), calculamos modulo 3 del índice de inserción (fallback básico)
            // Ojo: Esto es solo visual. El backend usa orden de llegada si falta posición.
            let posRelativa = childPack.matrizPosicion;
            
            if (posRelativa === undefined || posRelativa === null) {
                // Fallback para datos legacy: tratar de deducir o asignar secuencialmente
                // En un entorno real, deberíamos migrar los datos.
                // Aquí asumiremos 0 por defecto si falla todo, pero podría solaparse.
                console.warn(`⚠️ Pack ${childPack.nombre} de usuario ${childId} no tiene matrizPosicion, usando 0`);
                posRelativa = 0; 
            } else {
                // 🔧 FIX: Convertir de base-1 (1,2,3) a base-0 (0,1,2) para índices de array
                posRelativa = posRelativa - 1;
            }

            const nextLevel = current.nivel + 1;
            const nextIndex = (current.index * 3) + posRelativa;
            const levelKey = `level${nextLevel}`;
            
            // Verificar límites
            if (nextLevel <= MAX_NIVELES_VISUAL && nextIndex < levels[levelKey].length) {
                // Colocar nodo
                if (levels[levelKey][nextIndex] === null) {
                    levels[levelKey][nextIndex] = crearNodoUsuario(childId);
                    processedUsers.add(childId);
                    usersFound++;
                    
                    // Encolar para siguiente nivel
                    queue.push({ userId: childId, nivel: nextLevel, index: nextIndex });
                } else {
                    console.warn(`⚠️ Conflicto en Nivel ${nextLevel}, Index ${nextIndex}`);
                    // Estrategia de fallback: buscar siguiente hueco vacío en el trío (simple spillover visual)
                    const baseIndex = Math.floor(nextIndex / 3) * 3;
                    for(let offset=0; offset<3; offset++) {
                        if (levels[levelKey][baseIndex + offset] === null) {
                             levels[levelKey][baseIndex + offset] = crearNodoUsuario(childId);
                             processedUsers.add(childId);
                             queue.push({ userId: childId, nivel: nextLevel, index: baseIndex + offset });
                             break;
                        }
                    }
                }
            }
        });
      }

      if (iteraciones >= MAX_ITERACIONES) {
        console.warn(`⚠️ Se alcanzó el límite de ${MAX_ITERACIONES} iteraciones. Matriz parcial construida.`);
      }
      
      console.log(`✅ Matriz estricta construida. ${usersFound} usuarios colocados en ${iteraciones} iteraciones.`);
      return levels;
    };

    // Construir la matriz con cross spillover (OPTIMIZADO: solo niveles solicitados)
    const cycle = buildNetworkLevels(userId, usuariosActivos, todosLosPacks, niveles);
    
    // OPTIMIZACIÓN: Usar todosLosPacks ya cargados en lugar de consultas individuales
    const packs = todosLosPacks.filter(p => p.userId === userId);
    const totalInversion = packs.reduce((sum, p) => sum + p.monto, 0);
    const packActivo = packs.find(p => p.activo);
    
    // Obtener referidos directos formateados
    // FIX: Obtener TODOS los referidos directos (no solo los activos en matriz)
    // Para el conteo de "Referidos Directos" en la tarjeta
    const todosLosReferidosDirectos = todosLosUsuarios.filter((u: any) => u.referidoPor === userId);
    
    // OPTIMIZACIÓN CRÍTICA: Usar todosLosPacks del caché en lugar de Promise.all para evitar timeout
    const directosFormateados = todosLosReferidosDirectos.map((ref) => {
      const refPacks = todosLosPacks.filter(p => p.userId === ref.id);
      const refInversion = refPacks.reduce((sum, p) => sum + p.monto, 0);
      const refPackActivo = refPacks.find(p => p.activo);
      
      return {
        id: ref.id_unico,
        nombre: ref.nombre,
        apellido: ref.apellido,
        nivel: 1,
        pack: refPackActivo?.nombre || 'Sin pack',
        estatus: ref.activo ? 'activo' : 'inactivo',
        inversion: refInversion
      };
    });
    
    const elapsed = Date.now() - startTime;
    console.log(`✅ Matriz generada para ${userId} en ${elapsed}ms: ${directosFormateados.length} directos (${directosFormateados.filter(d => d.inversion > 0).length} con pack)`);
    
    return c.json({
      cycle,
      directos: directosFormateados,
      inversion: totalInversion,
      pack: packActivo?.nombre || 'Sin pack'
    });
  } catch (error) {
    const elapsed = Date.now() - startTime;
    console.error(`❌ Error al obtener matriz del usuario (${elapsed}ms):`, error);
    console.error('Stack:', error instanceof Error ? error.stack : 'No stack');
    return c.json({ 
      error: "Error al obtener matriz",
      details: error instanceof Error ? error.message : String(error)
    }, 500);
  }
});
*/

// Obtener métricas exactas usadas para el cálculo de rango (NUEVO)
app.get("/make-server-9f68532a/users/:userId/metricas-rango", async (c) => {
  try {
    const userId = c.req.param('userId');
    
    const user = await crm.getUserById(userId);
    if (!user) {
      return c.json({ error: "Usuario no encontrado" }, 404);
    }
    
    // Obtener directos (TODOS los que fueron referidos directamente)
    const todosLosDirectos = await crm.getReferidosDirectos(userId);
    const allPacks = await crm.getAllPacks();
    
    // Contar TODOS los que tienen inversión histórica (packs, activos o no)
    const directosConInversion = todosLosDirectos.filter(directo => {
      const packsDelDirecto = allPacks.filter(p => p.userId === directo.id);
      const inversionTotal = packsDelDirecto.reduce((sum, p) => sum + p.monto, 0);
      return inversionTotal > 0; // Tiene inversión histórica
    });
    
    // Calcular volumen de red (solo packs ACTIVOS)
    const allUsers = await getCachedUsuarios();
    const getAllReferidosRecursive = (parentId: string, currentLevel: number, visited: Set<string>): string[] => {
      if (currentLevel > 10 || visited.has(parentId)) return [];
      visited.add(parentId);
      
      const directRefs = allUsers.filter(u => u.referidoPor === parentId);
      let allRefs = directRefs.map(r => r.id);
      
      for (const ref of directRefs) {
        allRefs.push(...getAllReferidosRecursive(ref.id, currentLevel + 1, visited));
      }
      
      return allRefs;
    };
    
    const todosReferidosIds = getAllReferidosRecursive(userId, 1, new Set());
    
    let volumenTotal = 0;
    for (const refId of todosReferidosIds) {
      const packsActivosReferido = allPacks.filter(p => p.userId === refId && p.activo);
      volumenTotal += packsActivosReferido.reduce((sum, p) => sum + p.monto, 0);
    }
    
    return c.json({
      directosConInversion: directosConInversion.length,
      volumenTotal,
      totalReferidosEnRed: todosReferidosIds.length,
      rango: user.rango
    });
  } catch (error: any) {
    console.error('Error al obtener métricas de rango:', error);
    return c.json({ error: error.message }, 500);
  }
});

// Recalcular el rango de un usuario específico
app.post("/make-server-9f68532a/users/:userId/recalcular-rango", async (c) => {
  const requestStartTime = Date.now();
  const MAX_REQUEST_TIME = 45000; // ⚡ 45 segundos máximo
  
  try {
    const userId = c.req.param('userId');
    
    console.log(`🔄 Recalculando rango para usuario: ${userId}`);
    
    // ⚡ Implementar timeout de seguridad
    const updatedUser = await Promise.race([
      crm.actualizarRangoUsuario(userId),
      new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Timeout al recalcular rango')), MAX_REQUEST_TIME)
      )
    ]) as any;
    
    if (!updatedUser) {
      return c.json({ error: "Usuario no encontrado" }, 404);
    }
    
    const elapsedTime = Date.now() - requestStartTime;
    console.log(`✅ Rango actualizado: ${updatedUser.rango} (${elapsedTime}ms)`);
    
    return c.json({
      success: true,
      rango: updatedUser.rango,
      message: `Rango actualizado a: ${updatedUser.rango}`,
      elapsedTime
    });
  } catch (error: any) {
    const elapsedTime = Date.now() - requestStartTime;
    
    if (error.message && error.message.includes('Timeout')) {
      console.error(`⏱️ TIMEOUT en ruta: /make-server-9f68532a/users/:userId/recalcular-rango (${elapsedTime}ms)`);
      return c.json({ 
        error: "Timeout al recalcular rango",
        details: "La operación tardó demasiado. Por favor intenta nuevamente.",
        elapsedTime
      }, 504);
    }
    
    console.error('Error al recalcular rango:', error);
    return c.json({ 
      error: "Error al recalcular rango",
      details: error?.message || 'Unknown error',
      elapsedTime
    }, 500);
  }
});

// ADMIN: Recalcular rangos de TODOS los usuarios
app.post("/make-server-9f68532a/admin/recalcular-todos-rangos", async (c) => {
  try {
    console.log('🔄 Iniciando recálculo de rangos para TODOS los usuarios...');
    
    const todosLosUsuarios = await crm.getAllUsers();
    console.log(`📊 Total usuarios a procesar: ${todosLosUsuarios.length}`);
    
    // Filtrar solo usuarios con rango o con packs (optimización)
    const usuariosConRango = todosLosUsuarios.filter(u => 
      u.rango && u.rango !== 'Sin Rango'
    );
    
    console.log(`📌 Usuarios con rango activo: ${usuariosConRango.length}`);
    console.log(`⚡ Procesando solo usuarios con rango para acelerar...`);
    
    const resultados = [];
    let procesados = 0;
    
    // Procesar solo usuarios con rango (mucho más rápido)
    for (const usuario of usuariosConRango) {
      try {
        const rangoAnterior = usuario.rango || 'Sin Rango';
        const updatedUser = await crm.actualizarRangoUsuario(usuario.id);
        const rangoNuevo = updatedUser?.rango || 'Sin Rango';
        
        procesados++;
        if (procesados % 5 === 0) {
          console.log(`⏳ Procesados ${procesados}/${usuariosConRango.length}...`);
        }
        
        if (rangoAnterior !== rangoNuevo) {
          resultados.push({
            id_unico: usuario.id_unico,
            nombre: `${usuario.nombre} ${usuario.apellido}`,
            rangoAnterior,
            rangoNuevo,
            cambio: true
          });
          console.log(`🔄 ${usuario.id_unico}: ${rangoAnterior} → ${rangoNuevo}`);
        }
      } catch (error) {
        console.error(`❌ Error recalculando rango de ${usuario.id_unico}:`, error);
      }
    }
    
    const totalCambios = resultados.length;
    console.log(`✅ Recálculo completado: ${totalCambios} cambios de ${usuariosConRango.length} usuarios procesados`);
    
    return c.json({
      success: true,
      totalUsuarios: todosLosUsuarios.length,
      usuariosProcesados: usuariosConRango.length,
      totalCambios,
      resultados: resultados.slice(0, 20) // Solo enviar primeros 20 para no saturar
    });
  } catch (error: any) {
    console.error('❌ Error al recalcular todos los rangos:', error);
    return c.json({ 
      error: "Error al recalcular rangos",
      details: error?.message || String(error)
    }, 500);
  }
});

// ADMIN: Recalcular rango de un usuario específico por email
app.post("/make-server-9f68532a/admin/recalcular-rango-usuario", async (c) => {
  try {
    const { email } = await c.req.json();
    
    if (!email) {
      return c.json({ error: "Email es requerido" }, 400);
    }
    
    console.log(`🔄 Recalculando rango para usuario: ${email}`);
    
    const usuarios = await crm.getAllUsers();
    const usuario = usuarios.find(u => u.email === email);
    
    if (!usuario) {
      return c.json({ error: `Usuario no encontrado: ${email}` }, 404);
    }
    
    const rangoAnterior = usuario.rango || 'Sin Rango';
    const updatedUser = await crm.actualizarRangoUsuario(usuario.id);
    const rangoNuevo = updatedUser?.rango || 'Sin Rango';
    
    console.log(`✅ Rango actualizado: ${rangoAnterior} → ${rangoNuevo}`);
    
    return c.json({
      success: true,
      usuario: {
        id_unico: usuario.id_unico,
        nombre: `${usuario.nombre} ${usuario.apellido}`,
        email: usuario.email,
        rangoAnterior,
        rangoNuevo,
        cambio: rangoAnterior !== rangoNuevo
      }
    });
  } catch (error: any) {
    console.error('❌ Error al recalcular rango de usuario:', error);
    return c.json({ 
      error: "Error al recalcular rango",
      details: error?.message || String(error)
    }, 500);
  }
});

// ADMIN: Limpiar locks de rendimientos manualmente
app.post("/make-server-9f68532a/admin/limpiar-locks", async (c) => {
  try {
    console.log('🧹 Limpiando locks de rendimientos...');
    
    // Obtener todos los locks
    const locks = await kv.getByPrefix('rendimiento:lock:');
    
    if (!locks || locks.length === 0) {
      return c.json({
        success: true,
        mensaje: "No hay locks para limpiar",
        locksEliminados: 0
      });
    }
    
    const hoy = new Date().toISOString().split('T')[0];
    let locksEliminados = 0;
    let locksDeHoy = 0;
    
    // Eliminar TODOS los locks (incluso de hoy si es necesario resetear)
    for (const lock of locks) {
      if (lock && lock.fecha) {
        const lockKey = `rendimiento:lock:${lock.userId}:${lock.fecha}`;
        await kv.del(lockKey);
        locksEliminados++;
        
        if (lock.fecha === hoy) {
          locksDeHoy++;
        }
      }
    }
    
    console.log(`✅ ${locksEliminados} locks eliminados (${locksDeHoy} de hoy)`);
    
    return c.json({
      success: true,
      mensaje: `Se eliminaron ${locksEliminados} locks de rendimientos`,
      locksEliminados: locksEliminados,
      locksDeHoy: locksDeHoy
    });
  } catch (error: any) {
    console.error('❌ Error al limpiar locks:', error);
    return c.json({ 
      error: error.message || "Error al limpiar locks" 
    }, 500);
  }
});

// ADMIN: Eliminar pagos de rendimiento duplicados (últimos 60 días)
app.post("/make-server-9f68532a/admin/eliminar-rendimientos-duplicados", async (c) => {
  try {
    console.log('🔍 Buscando rendimientos duplicados (últimos 60 días)...');
    
    // Obtener todas las comisiones
    const todasComisiones = await crm.getAllComisiones();
    console.log(`📊 Total comisiones en sistema: ${todasComisiones.length}`);
    
    // Filtrar solo rendimientos de los últimos 60 días (para cubrir casos como el 3 de diciembre)
    const hace60Dias = new Date();
    hace60Dias.setDate(hace60Dias.getDate() - 60);
    
    const rendimientosRecientes = todasComisiones.filter(c => {
      const esRendimiento = c.tipo === 'rendimiento';
      const fechaComision = new Date(c.fecha);
      const esReciente = fechaComision >= hace60Dias;
      return esRendimiento && esReciente;
    });
    
    console.log(`📅 Rendimientos últimos 60 días: ${rendimientosRecientes.length}`);
    
    if (rendimientosRecientes.length === 0) {
      return c.json({
        success: true,
        mensaje: "No hay rendimientos en los últimos 60 días",
        totalRendimientos: 0,
        duplicadosEliminados: 0
      });
    }
    
    // Agrupar por usuario Y por fecha para detectar duplicados
    const rendimientosPorUsuarioYFecha = new Map<string, any[]>();
    rendimientosRecientes.forEach(r => {
      const fecha = new Date(r.fecha).toISOString().split('T')[0]; // YYYY-MM-DD
      const key = `${r.userId}:${fecha}`;
      
      if (!rendimientosPorUsuarioYFecha.has(key)) {
        rendimientosPorUsuarioYFecha.set(key, []);
      }
      rendimientosPorUsuarioYFecha.get(key)!.push(r);
    });
    
    console.log(`👥 Combinaciones usuario-fecha con rendimientos: ${rendimientosPorUsuarioYFecha.size}`);
    
    // Detectar duplicados (mismo usuario + misma fecha con más de 1 rendimiento)
    const usuariosConDuplicados: Map<string, { fecha: string, cantidad: number }[]> = new Map();
    let totalDuplicados = 0;
    
    for (const [key, rendimientos] of rendimientosPorUsuarioYFecha.entries()) {
      if (rendimientos.length > 1) {
        const [userId, fecha] = key.split(':');
        
        if (!usuariosConDuplicados.has(userId)) {
          usuariosConDuplicados.set(userId, []);
        }
        
        usuariosConDuplicados.get(userId)!.push({
          fecha: fecha,
          cantidad: rendimientos.length
        });
        
        totalDuplicados += (rendimientos.length - 1); // -1 porque uno es válido
        console.log(`⚠️ Usuario ${userId} - Fecha ${fecha}: ${rendimientos.length} rendimientos (${rendimientos.length - 1} duplicados)`);
      }
    }
    
    console.log(`🔴 Total duplicados detectados: ${totalDuplicados}`);
    
    if (totalDuplicados === 0) {
      return c.json({
        success: true,
        mensaje: "No se detectaron rendimientos duplicados en los últimos 60 días",
        totalRendimientos: rendimientosRecientes.length,
        duplicadosEliminados: 0
      });
    }
    
    // Eliminar duplicados (mantener solo el primero de cada usuario por fecha)
    let eliminados = 0;
    const detalleEliminados = [];
    
    for (const [key, rendimientos] of rendimientosPorUsuarioYFecha.entries()) {
      if (rendimientos.length <= 1) continue; // Solo procesar si hay duplicados
      
      const [userId, fecha] = key.split(':');
      
      // Ordenar por timestamp de creación (el primero es el válido)
      rendimientos.sort((a, b) => new Date(a.fecha).getTime() - new Date(b.fecha).getTime());
      
      // Obtener info del usuario
      const usuario = await crm.getUserById(userId);
      const nombreUsuario = usuario ? `${usuario.nombre} ${usuario.apellido}` : userId;
      
      // Mantener el primero, eliminar los demás
      const rendimientoValido = rendimientos[0];
      const rendimientosAEliminar = rendimientos.slice(1);
      
      console.log(`🗑️ Usuario ${nombreUsuario} - Fecha ${fecha}:`);
      console.log(`  ✅ Manteniendo: ID ${rendimientoValido.id} - $${rendimientoValido.monto} (${new Date(rendimientoValido.fecha).toLocaleString()})`);
      
      for (const rendimiento of rendimientosAEliminar) {
        try {
          await crm.deleteComision(rendimiento.id);
          eliminados++;
          console.log(`  ❌ Eliminado: ID ${rendimiento.id} - $${rendimiento.monto} (${new Date(rendimiento.fecha).toLocaleString()})`);
          
          detalleEliminados.push({
            usuario: nombreUsuario,
            userId: userId,
            comisionId: rendimiento.id,
            monto: rendimiento.monto,
            fecha: rendimiento.fecha,
            fechaDia: fecha
          });
        } catch (error) {
          console.error(`❌ Error eliminando comisión ${rendimiento.id}:`, error);
        }
      }
    }
    
    console.log(`✅ Limpieza completada: ${eliminados} rendimientos duplicados eliminados`);
    
    return c.json({
      success: true,
      mensaje: `Se eliminaron ${eliminados} rendimientos duplicados de los últimos 60 días`,
      totalRendimientos: rendimientosRecientes.length,
      duplicadosEliminados: eliminados,
      usuariosAfectados: usuariosConDuplicados.size,
      detalle: detalleEliminados.slice(0, 30) // Mostrar hasta 30 ejemplos
    });
    
  } catch (error: any) {
    console.error('❌ Error al eliminar rendimientos duplicados:', error);
    return c.json({ 
      error: "Error al eliminar rendimientos duplicados",
      details: error?.message || String(error)
    }, 500);
  }
});

// DEBUG: Ver cuántos packs tienen matrizPadre asignado
app.get("/make-server-9f68532a/debug/matriz-status", async (c) => {
  try {
    const allPacks = await crm.getAllPacks();
    const conMatriz = allPacks.filter(p => p.matrizPadre);
    const sinMatriz = allPacks.filter(p => !p.matrizPadre);
    
    console.log(`📊 Packs CON matrizPadre: ${conMatriz.length}`);
    console.log(`📊 Packs SIN matrizPadre: ${sinMatriz.length}`);
    
    // Agrupar por usuario
    const allUsers = await crm.getAllUsers();
    const usuariosSinMatriz = sinMatriz.map(p => {
      const user = allUsers.find(u => u.id === p.userId);
      return {
        userId: p.userId,
        nombre: user ? `${user.nombre} ${user.apellido}` : 'Desconocido',
        pack: p.nombre,
        monto: p.monto
      };
    });
    
    return c.json({
      totalPacks: allPacks.length,
      conMatrizPadre: conMatriz.length,
      sinMatrizPadre: sinMatriz.length,
      usuariosSinMatriz,
      mensaje: sinMatriz.length > 0 
        ? `⚠️ Hay ${sinMatriz.length} packs sin posición de matriz. Ejecuta el endpoint POST /admin/recalcular-matriz para corregir.`
        : `✅ Todos los packs tienen posición de matriz asignada.`
    });
  } catch (error) {
    console.error('Error al verificar matriz:', error);
    return c.json({ error: "Error al verificar matriz" }, 500);
  }
});

// DEBUG: Diagnosticar matriz de un usuario específico
app.get("/make-server-9f68532a/debug/usuario/:userId/matriz-debug", async (c) => {
  try {
    const userId = c.req.param('userId');
    console.log(`🔍 DIAGNÓSTICO DE MATRIZ para usuario: ${userId}`);
    
    const allUsers = await crm.getAllUsers();
    const allPacks = await crm.getAllPacks();
    
    // Encontrar el usuario (buscar por ID o id_unico)
    let usuario = allUsers.find(u => u.id === userId || u.id_unico === userId);
    
    if (!usuario) {
      console.log(`⚠️ Usuario ${userId} NO encontrado en getAllUsers, buscando en DB...`);
      // Intentar buscar directamente en DB
      usuario = await crm.getUserById(userId);
      if (!usuario) {
        usuario = await crm.getUserByIdUnico(userId);
      }
      if (!usuario) {
        return c.json({ error: "Usuario no encontrado" }, 404);
      }
    }
    
    console.log(`👤 Usuario encontrado: ${usuario.nombre} ${usuario.apellido} (${usuario.id_unico})`);
    
    // Referidos directos (por campo referidoPor)
    const referidosDirectos = allUsers.filter(u => u.referidoPor === usuario.id);
    console.log(`👥 Referidos directos: ${referidosDirectos.length}`);
    
    // Analizar cada referido
    const analisisReferidos = referidosDirectos.map(ref => {
      const packsDelReferido = allPacks.filter(p => p.userId === ref.id);
      const packActivo = packsDelReferido.find(p => p.activo);
      
      return {
        id_unico: ref.id_unico,
        nombre: `${ref.nombre} ${ref.apellido}`,
        activo: ref.activo,
        packs: packsDelReferido.map(p => ({
          nombre: p.nombre,
          monto: p.monto,
          activo: p.activo,
          matrizPadre: p.matrizPadre || 'SIN ASIGNAR',
          matrizPosicion: p.matrizPosicion,
          matrizNivel: p.matrizNivel,
          createdAt: p.createdAt
        })),
        tieneMatrizAsignada: packsDelReferido.some(p => p.matrizPadre),
        apareceEnArbol: packsDelReferido.some(p => p.matrizPadre === usuario.id)
      };
    });
    
    // Packs en la matriz de este usuario (hijos directos en nivel 1)
    const packsEnNivel1 = allPacks.filter(p => p.matrizPadre === usuario.id && p.matrizNivel === 1);
    
    console.log(`🌳 Packs en Nivel 1 de su matriz: ${packsEnNivel1.length}`);
    
    return c.json({
      usuario: {
        id: usuario.id,
        id_unico: usuario.id_unico,
        nombre: `${usuario.nombre} ${usuario.apellido}`,
        activo: usuario.activo
      },
      referidosDirectos: {
        total: referidosDirectos.length,
        lista: analisisReferidos
      },
      matrizNivel1: {
        total: packsEnNivel1.length,
        lista: packsEnNivel1.map(p => {
          const user = allUsers.find(u => u.id === p.userId);
          return {
            usuario: user ? `${user.nombre} ${user.apellido} (${user.id_unico})` : 'Desconocido',
            pack: p.nombre,
            posicion: p.matrizPosicion,
            createdAt: p.createdAt
          };
        })
      },
      problema: {
        referidosSinMatriz: analisisReferidos.filter(r => !r.tieneMatrizAsignada).length,
        descripcion: analisisReferidos.filter(r => !r.tieneMatrizAsignada).length > 0
          ? `⚠️ ${analisisReferidos.filter(r => !r.tieneMatrizAsignada).length} referidos directos NO tienen matrizPadre asignado`
          : '✅ Todos los referidos directos tienen matrizPadre asignado'
      }
    });
  } catch (error) {
    console.error('Error en diagnóstico de usuario:', error);
    return c.json({ error: "Error al diagnosticar usuario" }, 500);
  }
});

// DEBUG: Detectar usuarios duplicados por email
app.get("/make-server-9f68532a/debug/usuarios-duplicados", async (c) => {
  try {
    console.log(`🔍 BUSCANDO USUARIOS DUPLICADOS...`);
    
    const allUsers = await crm.getAllUsers();
    const allPacks = await crm.getAllPacks();
    
    // Agrupar usuarios por email
    const emailMap = new Map<string, any[]>();
    
    allUsers.forEach(user => {
      const email = user.email?.toLowerCase() || '';
      if (email) {
        if (!emailMap.has(email)) {
          emailMap.set(email, []);
        }
        emailMap.get(email)!.push(user);
      }
    });
    
    // Filtrar solo los que tienen duplicados
    const duplicados = Array.from(emailMap.entries())
      .filter(([_, users]) => users.length > 1)
      .map(([email, users]) => {
        const usuariosConPacks = users.map(u => {
          const packs = allPacks.filter(p => p.userId === u.id);
          const referidos = allUsers.filter(r => r.referidoPor === u.id);
          return {
            id: u.id,
            id_unico: u.id_unico,
            nombre: `${u.nombre} ${u.apellido}`,
            email: u.email,
            activo: u.activo,
            fechaRegistro: u.fechaRegistro,
            packs: packs.length,
            referidos: referidos.length,
            detallesPacks: packs.map(p => ({ nombre: p.nombre, monto: p.monto, activo: p.activo }))
          };
        });
        
        return {
          email,
          cantidad: users.length,
          usuarios: usuariosConPacks
        };
      });
    
    console.log(`📊 Encontrados ${duplicados.length} emails con duplicados`);
    
    return c.json({
      totalDuplicados: duplicados.length,
      duplicados: duplicados
    });
  } catch (error) {
    console.error('Error al buscar duplicados:', error);
    return c.json({ error: "Error al buscar duplicados" }, 500);
  }
});

// Fusionar usuarios duplicados - MANTENER el más antiguo y eliminar los demás
app.post("/make-server-9f68532a/admin/fusionar-duplicado", async (c) => {
  try {
    const { email } = await c.req.json();
    
    if (!email) {
      return c.json({ error: "Email requerido" }, 400);
    }
    
    console.log(`🔄 FUSIONANDO DUPLICADOS para email: ${email}`);
    
    const allUsers = await crm.getAllUsers();
    const allPacks = await crm.getAllPacks();
    
    // Buscar todos los usuarios con este email
    const duplicados = allUsers.filter(u => u.email?.toLowerCase() === email.toLowerCase());
    
    if (duplicados.length <= 1) {
      return c.json({ error: "No hay duplicados para este email" }, 400);
    }
    
    // Ordenar por fecha de registro (el más antiguo primero)
    duplicados.sort((a, b) => new Date(a.fechaRegistro).getTime() - new Date(b.fechaRegistro).getTime());
    
    const usuarioPrincipal = duplicados[0]; // El más antiguo
    const duplicadosAEliminar = duplicados.slice(1); // Los demás
    
    console.log(`👤 Usuario principal (más antiguo): ${usuarioPrincipal.id_unico}`);
    console.log(`🗑️ Duplicados a eliminar: ${duplicadosAEliminar.map(d => d.id_unico).join(', ')}`);
    
    // Transferir TODOS los packs de los duplicados al usuario principal
    let packsTransferidos = 0;
    for (const duplicado of duplicadosAEliminar) {
      const packsDelDuplicado = allPacks.filter(p => p.userId === duplicado.id);
      
      for (const pack of packsDelDuplicado) {
        await crm.updatePack(pack.id, {
          userId: usuarioPrincipal.id
        });
        packsTransferidos++;
      }
    }
    
    // Transferir TODOS los referidos de los duplicados al usuario principal
    let referidosTransferidos = 0;
    for (const duplicado of duplicadosAEliminar) {
      const referidosDelDuplicado = allUsers.filter(u => u.referidoPor === duplicado.id);
      
      for (const referido of referidosDelDuplicado) {
        await crm.updateUser(referido.id, {
          referidoPor: usuarioPrincipal.id
        });
        referidosTransferidos++;
      }
    }
    
    // ELIMINAR los usuarios duplicados
    let usuariosEliminados = 0;
    for (const duplicado of duplicadosAEliminar) {
      await crm.deleteUser(duplicado.id);
      usuariosEliminados++;
      console.log(`  ✅ Eliminado usuario duplicado: ${duplicado.id_unico}`);
    }
    
    console.log(`✅ FUSIÓN COMPLETADA: ${packsTransferidos} packs, ${referidosTransferidos} referidos transferidos, ${usuariosEliminados} duplicados eliminados`);
    
    return c.json({
      success: true,
      usuarioPrincipal: {
        id: usuarioPrincipal.id,
        id_unico: usuarioPrincipal.id_unico,
        nombre: `${usuarioPrincipal.nombre} ${usuarioPrincipal.apellido}`,
        email: usuarioPrincipal.email
      },
      packsTransferidos,
      referidosTransferidos,
      usuariosEliminados,
      duplicadosEliminados: duplicadosAEliminar.map(d => d.id_unico)
    });
  } catch (error) {
    console.error('🔴 Error al fusionar duplicados:', error);
    console.error('Stack trace:', error?.stack);
    return c.json({ 
      error: "Error al fusionar duplicados", 
      details: error?.message || String(error)
    }, 500);
  }
});

// Diagnosticar usuario específico por ID (busca por id_unico)
app.post("/make-server-9f68532a/debug/diagnostico-usuario", async (c) => {
  try {
    const { id } = await c.req.json();
    
    if (!id) {
      return c.json({ error: "ID de usuario requerido" }, 400);
    }
    
    console.log(`🔍 DIAGNOSTICANDO USUARIO: ${id}`);
    
    const allUsers = await crm.getAllUsers();
    const allPacks = await crm.getAllPacks();
    
    // Buscar usuario por id_unico
    let usuario = allUsers.find(u => u.id_unico === id);
    
    if (!usuario) {
      console.log(`⚠️ Usuario ${id} NO encontrado en getAllUsers, buscando en DB...`);
      usuario = await crm.getUserByIdUnico(id);
      if (!usuario) {
        return c.json({ error: "Usuario no encontrado" }, 404);
      }
    }
    
    console.log(`👤 Usuario encontrado: ${usuario.nombre} ${usuario.apellido}`);
    
    // Buscar TODOS los referidos directos de este usuario
    const referidosDirectos = allUsers.filter(u => u.referidoPor === usuario.id);
    console.log(`👥 Referidos directos: ${referidosDirectos.length}`);
    
    // Analizar cada referido CON DETALLES COMPLETOS DE MATRIZ
    const analisisReferidos = referidosDirectos.map(ref => {
      const packsDelReferido = allPacks.filter(p => p.userId === ref.id);
      const packsSinMatriz = packsDelReferido.filter(p => !p.matrizPadre);
      
      return {
        id_unico: ref.id_unico,
        nombre: `${ref.nombre} ${ref.apellido}`,
        activo: ref.activo,
        fechaRegistro: ref.fechaRegistro,
        packs: packsDelReferido.length,
        packsSinMatriz: packsSinMatriz.length,
        tieneMatrizAsignada: packsDelReferido.some(p => p.matrizPadre),
        detallesPacks: packsDelReferido.map(p => ({
          nombre: p.nombre,
          monto: p.monto,
          matrizPadre: p.matrizPadre || 'SIN ASIGNAR',
          matrizPadreIdUnico: p.matrizPadre ? allUsers.find(u => u.id === p.matrizPadre)?.id_unico || 'DESCONOCIDO' : 'N/A',
          matrizNivel: p.matrizNivel || 'SIN NIVEL',
          matrizPosicion: p.matrizPosicion || 'SIN POSICIÓN',
          activo: p.activo
        }))
      };
    });
    
    // Packs en la matriz de este usuario (nivel 1)
    const packsEnNivel1 = allPacks.filter(p => p.matrizPadre === usuario.id && p.matrizNivel === 1);
    
    // Packs en TODOS los niveles de este usuario
    const packsEnTodosLosNiveles = allPacks.filter(p => p.matrizPadre === usuario.id);
    
    // Agrupar por nivel
    const packsPorNivel: any = {};
    for (let nivel = 1; nivel <= 10; nivel++) {
      const packsNivel = allPacks.filter(p => p.matrizPadre === usuario.id && p.matrizNivel === nivel);
      if (packsNivel.length > 0) {
        packsPorNivel[nivel] = packsNivel.map(p => {
          const user = allUsers.find(u => u.id === p.userId);
          return {
            usuario: user ? `${user.nombre} ${user.apellido} (${user.id_unico})` : 'Desconocido',
            pack: p.nombre,
            posicion: p.matrizPosicion,
            createdAt: p.createdAt
          };
        });
      }
    }
    
    return c.json({
      usuario: {
        id: usuario.id,
        id_unico: usuario.id_unico,
        nombre: `${usuario.nombre} ${usuario.apellido}`,
        activo: usuario.activo
      },
      referidosDirectos: {
        total: referidosDirectos.length,
        lista: analisisReferidos
      },
      matrizNivel1: {
        total: packsEnNivel1.length,
        lista: packsEnNivel1.map(p => {
          const user = allUsers.find(u => u.id === p.userId);
          return {
            usuario: user ? `${user.nombre} ${user.apellido} (${user.id_unico})` : 'Desconocido',
            pack: p.nombre,
            posicion: p.matrizPosicion,
            createdAt: p.createdAt
          };
        })
      },
      matrizTodosNiveles: {
        total: packsEnTodosLosNiveles.length,
        porNivel: packsPorNivel
      },
      problema: {
        tieneProblemas: true,
        referidosSinMatriz: analisisReferidos.filter(r => !r.tieneMatrizAsignada).length,
        descripcion: `⚠️ Detectadas posibles colisiones o inconsistencias en la matriz. Recalcula para corregir.`
      }
    });
  } catch (error) {
    console.error('Error al diagnosticar usuario:', error);
    return c.json({ error: "Error al diagnosticar usuario" }, 500);
  }
});

// Recalcular y asignar posiciones de matriz para TODOS los packs (RESETEA TODO)
app.post("/make-server-9f68532a/admin/recalcular-matriz", async (c) => {
  try {
    console.log(`🔄 RECALCULANDO MATRIZ COMPLETA - RESETEANDO TODAS LAS POSICIONES...`);
    
    const allUsers = await crm.getAllUsers();
    const allPacks = await crm.getAllPacks();
    
    let packsActualizados = 0;
    let errores = 0;
    
    // 🔥 PASO 1: RESETEAR todas las posiciones de matriz a null para empezar desde cero
    console.log(`🧹 PASO 1: Reseteando todas las posiciones de matriz...`);
    for (const pack of allPacks) {
      if (pack.matrizPadre || pack.matrizNivel || pack.matrizPosicion) {
        await crm.updatePack(pack.id, {
          matrizPadre: undefined,
          matrizNivel: undefined,
          matrizPosicion: undefined
        });
      }
    }
    console.log(`✅ Todas las posiciones reseteadas`);
    
    // 🔥 PASO 2: Agrupar packs por usuario para asignar UNA posición por usuario
    const packsPorUsuario = new Map();
    for (const pack of allPacks) {
      if (!packsPorUsuario.has(pack.userId)) {
        packsPorUsuario.set(pack.userId, []);
      }
      packsPorUsuario.get(pack.userId).push(pack);
    }
    
    // 🔥 PASO 3: Ordenar usuarios por la fecha del PRIMER pack (más antiguo primero)
    const usuariosConPacks = Array.from(packsPorUsuario.entries()).map(([userId, packs]) => {
      const user = allUsers.find(u => u.id === userId);
      const primerPack = packs.sort((a, b) => 
        new Date(a.fechaCompra).getTime() - new Date(b.fechaCompra).getTime()
      )[0];
      return {
        userId,
        user,
        packs,
        primerPackFecha: primerPack.fechaCompra,
        referidoPor: user?.referidoPor
      };
    });
    
    // Ordenar por fecha del primer pack (más antiguo primero)
    usuariosConPacks.sort((a, b) => 
      new Date(a.primerPackFecha).getTime() - new Date(b.primerPackFecha).getTime()
    );
    
    console.log(`📊 Total de usuarios con packs: ${usuariosConPacks.length}`);
    
    // 🔥 PASO 4: Asignar posiciones MANUALMENTE siguiendo la lógica de matriz 3x3
    const matrizOcupada = new Map(); // matrizPadre -> [userId1, userId2, userId3]
    
    for (const { userId, user, packs, referidoPor } of usuariosConPacks) {
      if (!referidoPor) {
        console.log(`  ⚠️ Usuario ${user?.id_unico || userId} sin patrocinador, omitiendo...`);
        continue;
      }
      
      try {
        let matrizPadreAsignado = referidoPor;
        let nivelAsignado = 1;
        let posicionAsignada = 1;
        
        // BFS para encontrar hueco
        const queue = [{ padreId: referidoPor, nivel: 1 }];
        const visitados = new Set();
        let encontrado = false;
        
        while (queue.length > 0 && !encontrado) {
          const current = queue.shift();
          if (!current) continue;
          
          const { padreId, nivel } = current;
          
          if (visitados.has(padreId)) continue;
          visitados.add(padreId);
          
          const hijosActuales = matrizOcupada.get(padreId) || [];
          
          if (hijosActuales.length < 3) {
            matrizPadreAsignado = padreId;
            nivelAsignado = nivel;
            posicionAsignada = hijosActuales.length + 1;
            
            hijosActuales.push(userId);
            matrizOcupada.set(padreId, hijosActuales);
            encontrado = true;
          } else {
            for (const hijoId of hijosActuales) {
              queue.push({ padreId: hijoId, nivel: nivel + 1 });
            }
          }
          
          if (visitados.size > 1000) break;
        }
        
        // Actualizar TODOS los packs del usuario con la misma posición
        for (const pack of packs) {
          await crm.updatePack(pack.id, {
            matrizPadre: matrizPadreAsignado,
            matrizNivel: nivelAsignado,
            matrizPosicion: posicionAsignada
          });
          packsActualizados++;
        }
        
        const padreUsuario = allUsers.find(u => u.id === matrizPadreAsignado);
        console.log(`  ✅ ${user?.id_unico || userId}: Nivel ${nivelAsignado}, Pos ${posicionAsignada}, Padre: ${padreUsuario?.id_unico || matrizPadreAsignado}`);
      } catch (error) {
        console.error(`  ❌ Error al asignar posición a ${userId}:`, error);
        errores++;
      }
    }
    
    console.log(`✅ RECALCULO COMPLETADO: ${packsActualizados} packs actualizados, ${errores} errores`);
    
    return c.json({
      success: true,
      packsActualizados,
      errores,
      message: `Matriz recalculada: ${packsActualizados} packs actualizados`
    });
  } catch (error) {
    console.error('Error al recalcular matriz:', error);
    return c.json({ error: "Error al recalcular matriz" }, 500);
  }
});

// 🔧 RECALCULAR MATRIZ DE UN USUARIO ESPECÍFICO (SEGURO - No afecta otras matrices)
app.post("/make-server-9f68532a/admin/recalcular-matriz-usuario", async (c) => {
  try {
    const { userId } = await c.req.json();
    
    if (!userId) {
      return c.json({ error: "userId requerido" }, 400);
    }
    
    console.log(`🔧 RECALCULANDO MATRIZ SOLO PARA USUARIO: ${userId}`);
    
    const allUsers = await crm.getAllUsers();
    const allPacks = await crm.getAllPacks();
    
    // Encontrar el usuario
    let usuario = allUsers.find(u => u.id_unico === userId);
    if (!usuario) {
      console.log(`⚠️ Usuario ${userId} NO encontrado en getAllUsers, buscando en DB...`);
      usuario = await crm.getUserByIdUnico(userId);
      if (!usuario) {
        return c.json({ error: "Usuario no encontrado" }, 404);
      }
    }
    
    console.log(`👤 Usuario: ${usuario.nombre} ${usuario.apellido} (${usuario.id_unico})`);
    
    // Obtener referidos DIRECTOS de este usuario (por referidoPor, no por matriz)
    const referidosDirectos = allUsers.filter(u => u.referidoPor === usuario.id);
    console.log(`👥 Referidos directos: ${referidosDirectos.length}`);
    
    if (referidosDirectos.length === 0) {
      return c.json({ 
        success: true, 
        message: 'Este usuario no tiene referidos directos',
        packsActualizados: 0
      });
    }
    
    // PASO 1: Obtener packs de cada referido directo
    const referidosConPacks = referidosDirectos.map(ref => {
      const packsDelReferido = allPacks.filter(p => p.userId === ref.id);
      const primerPack = packsDelReferido.sort((a, b) => 
        new Date(a.fechaCompra).getTime() - new Date(b.fechaCompra).getTime()
      )[0];
      
      return {
        userId: ref.id,
        id_unico: ref.id_unico,
        nombre: `${ref.nombre} ${ref.apellido}`,
        packs: packsDelReferido,
        primerPackFecha: primerPack ? primerPack.fechaCompra : ref.fechaRegistro
      };
    });
    
    // PASO 2: Ordenar por fecha del primer pack (más antiguo primero)
    referidosConPacks.sort((a, b) => 
      new Date(a.primerPackFecha).getTime() - new Date(b.primerPackFecha).getTime()
    );
    
    console.log(`📋 Orden de asignación:`);
    referidosConPacks.forEach((r, i) => {
      console.log(`  ${i + 1}. ${r.nombre} (${r.id_unico}) - ${new Date(r.primerPackFecha).toLocaleDateString()}`);
    });
    
    // PASO 3: Construir mapa de ocupación actual en la matriz
    const matrizOcupada = new Map(); // padreId -> [userId1, userId2, userId3]
    
    // Inicializar con las ocupaciones existentes (excepto los referidos directos que vamos a recalcular)
    const referidosDirectosIds = new Set(referidosDirectos.map(r => r.id));
    
    for (const pack of allPacks) {
      if (pack.matrizPadre && !referidosDirectosIds.has(pack.userId)) {
        // Este pack NO es de un referido directo, mantenerlo en el mapa
        const ocupados = matrizOcupada.get(pack.matrizPadre) || [];
        if (!ocupados.includes(pack.userId)) {
          ocupados.push(pack.userId);
          matrizOcupada.set(pack.matrizPadre, ocupados);
        }
      }
    }
    
    // PASO 4: Reasignar posiciones a los referidos directos en orden cronológico
    let packsActualizados = 0;
    
    for (const ref of referidosConPacks) {
      let matrizPadreAsignado = usuario.id;
      let nivelAsignado = 1;
      let posicionAsignada = 1;
      
      // BFS para encontrar el primer hueco disponible
      const queue = [{ padreId: usuario.id, nivel: 1 }];
      const visitados = new Set();
      let encontrado = false;
      
      while (queue.length > 0 && !encontrado) {
        const current = queue.shift();
        if (!current) continue;
        
        const { padreId, nivel } = current;
        
        if (visitados.has(padreId)) continue;
        visitados.add(padreId);
        
        const hijosActuales = matrizOcupada.get(padreId) || [];
        
        if (hijosActuales.length < 3) {
          // ¡Encontramos hueco!
          matrizPadreAsignado = padreId;
          nivelAsignado = nivel;
          posicionAsignada = hijosActuales.length + 1;
          
          // Registrar ocupación
          hijosActuales.push(ref.userId);
          matrizOcupada.set(padreId, hijosActuales);
          encontrado = true;
        } else {
          // Está lleno, buscar en los hijos
          for (const hijoId of hijosActuales) {
            queue.push({ padreId: hijoId, nivel: nivel + 1 });
          }
        }
        
        if (visitados.size > 500) break;
      }
      
      // Actualizar TODOS los packs de este referido
      for (const pack of ref.packs) {
        await crm.updatePack(pack.id, {
          matrizPadre: matrizPadreAsignado,
          matrizNivel: nivelAsignado,
          matrizPosicion: posicionAsignada
        });
        packsActualizados++;
      }
      
      const padreUsuario = allUsers.find(u => u.id === matrizPadreAsignado);
      console.log(`  ✅ ${ref.nombre}: Nivel ${nivelAsignado}, Pos ${posicionAsignada}, Padre: ${padreUsuario?.id_unico || matrizPadreAsignado}`);
    }
    
    console.log(`✅ RECALCULO COMPLETADO: ${packsActualizados} packs actualizados`);
    
    return c.json({
      success: true,
      packsActualizados,
      referidosRecalculados: referidosDirectos.length,
      message: `Matriz recalculada para ${referidosDirectos.length} referidos directos`
    });
  } catch (error) {
    console.error('Error al recalcular matriz de usuario:', error);
    return c.json({ error: "Error al recalcular matriz de usuario" }, 500);
  }
});

// ==========================================
// RUTAS DE RULETA
// ==========================================

// Obtener historial de ruleta de un usuario
app.get("/make-server-9f68532a/users/:userId/ruleta", async (c) => {
  try {
    const userId = c.req.param('userId');
    const historial = await crm.getRuletaHistorialByUserId(userId);
    return c.json(historial);
  } catch (error) {
    console.error('Error al obtener historial de ruleta:', error);
    return c.json({ error: "Error al obtener historial de ruleta" }, 500);
  }
});

// Registrar un giro de ruleta (JUGAR)
app.post("/make-server-9f68532a/ruleta/play", async (c) => {
  try {
    const { userId } = await c.req.json();
    
    if (!userId) return c.json({ error: "UserId requerido" }, 400);
    
    // 1. Incrementar contadores
    const globalCount = await crm.incrementGlobalSpinCount();
    const userHistory = await crm.getRuletaHistorialByUserId(userId);
    const userSpinCount = userHistory.length + 1; // El giro actual será el N+1
    
    console.log(`🎰 Giro solicitado. Global: ${globalCount}, Usuario: ${userSpinCount}`);
    
    let premioIndex = 0;
    
    // Índices basados en la lista del frontend
    // 0: $5, 1: Nada, 2: $10, 3: Nada, 4: $5, 5: $50, 6: $10, 7: Nada
    // 8: $5, 9: $100, 10: $10, 11: Nada, 12: $5, 13: $200, 14: $10
    // 15: Nada, 16: $50, 17: $500, 18: $100, 19: JACKPOT
    
    const smallPrizeIndices = [0, 2, 4, 6, 8, 10, 12, 14];
    const lossIndices = [1, 3, 7, 11, 15];
    const jackpotIndex = 19;
    
    const premios = [
      { id: 1, nombre: '$5 USDT', valor: 5 },
      { id: 2, nombre: 'Sigue Intentando', valor: 0 },
      { id: 3, nombre: '$10 USDT', valor: 10 },
      { id: 4, nombre: 'Sigue Intentando', valor: 0 },
      { id: 5, nombre: '$5 USDT', valor: 5 },
      { id: 6, nombre: '$50 USDT', valor: 50 },
      { id: 7, nombre: '$10 USDT', valor: 10 },
      { id: 8, nombre: 'Sigue Intentando', valor: 0 },
      { id: 9, nombre: '$5 USDT', valor: 5 },
      { id: 10, nombre: '$100 USDT', valor: 100 },
      { id: 11, nombre: '$10 USDT', valor: 10 },
      { id: 12, nombre: 'Sigue Intentando', valor: 0 },
      { id: 13, nombre: '$5 USDT', valor: 5 },
      { id: 14, nombre: '$200 USDT', valor: 200 },
      { id: 15, nombre: '$10 USDT', valor: 10 },
      { id: 16, nombre: 'Sigue Intentando', valor: 0 },
      { id: 17, nombre: '$50 USDT', valor: 50 },
      { id: 18, nombre: '$500 USDT', valor: 500 },
      { id: 19, nombre: '$100 USDT', valor: 100 },
      { id: 20, nombre: '$1,000 JACKPOT', valor: 1000 }
    ];
    
    // NUEVA LÓGICA DE PREMIOS GARANTIZADOS POR MILESTONES:
    // - Cada 12000 giros: $1,000 JACKPOT (índice 19) [DESHABILITADO - SOLO VISUAL]
    // - Cada 6000 giros: $500 USDT (índice 17) [DESHABILITADO - SOLO VISUAL]
    // - Cada 3000 giros: $200 USDT (índice 13)
    // - Cada 1000 giros: $100 USDT (índice 9)
    // - Cada 500 giros: $50 USDT (índice 5 o 16)
    // - Cada 50 giros: $10 USDT (índice 2, 6, 10, 14)
    // - Cada 5 giros: $5 o $10 USDT aleatorio
    // - Otros giros: premios aleatorios (puede ser premio o "Sigue Intentando")
    // IMPORTANTE: Los premios de $500 y $1000 NUNCA se otorgan, solo son visuales
    
    const prizeIndices5_10 = [0, 2, 4, 6, 8, 10, 12, 14]; // $5 y $10 USDT
    const prize10Indices = [2, 6, 10, 14]; // Solo $10 USDT
    const prize50Indices = [5, 16]; // $50 USDT
    
    // Los premios de $500 (índice 17) y $1000 (índice 19) NUNCA se otorgan
    if (userSpinCount % 12000 === 0) {
      // 👑 En vez de JACKPOT, otorgar $200 USDT
      premioIndex = 13; // $200 USDT
      console.log('🌟 Premio $200 USDT (múltiplo de 12000 giros)');
    } else if (userSpinCount % 6000 === 0) {
      // 🔥 En vez de $500, otorgar $100 USDT
      premioIndex = 9; // $100 USDT
      console.log('💎 Premio $100 USDT (múltiplo de 6000 giros)');
    } else if (userSpinCount % 3000 === 0) {
      // 🌟 $200 cada 3000 giros
      premioIndex = 13; // $200 USDT
      console.log('🌟 Premio $200 USDT (cada 3000 giros)');
    } else if (userSpinCount % 1000 === 0) {
      // 💎 $100 cada 1000 giros
      premioIndex = 9; // $100 USDT
      console.log('💎 Premio $100 USDT (cada 1000 giros)');
    } else if (userSpinCount % 500 === 0) {
      // 💎 $50 cada 500 giros
      premioIndex = prize50Indices[Math.floor(Math.random() * prize50Indices.length)];
      console.log('💎 Premio $50 USDT (cada 500 giros)');
    } else if (userSpinCount % 50 === 0) {
      // 💵 $10 cada 50 giros
      premioIndex = prize10Indices[Math.floor(Math.random() * prize10Indices.length)];
      console.log('💵 Premio $10 USDT (cada 50 giros)');
    } else if (userSpinCount % 5 === 0) {
      // 💰💵 $5 o $10 cada 5 giros
      premioIndex = prizeIndices5_10[Math.floor(Math.random() * prizeIndices5_10.length)];
      console.log('💰 Premio $5 o $10 USDT (cada 5 giros)');
    } else {
      // Premios aleatorios normales (puede ganar o perder)
      // 60% de probabilidad de ganar algo, 40% "Sigue Intentando"
      const rand = Math.random();
      if (rand < 0.6) {
        // Gana algo pequeño ($5 o $10)
        premioIndex = prizeIndices5_10[Math.floor(Math.random() * prizeIndices5_10.length)];
      } else {
        // "Sigue Intentando"
        premioIndex = lossIndices[Math.floor(Math.random() * lossIndices.length)];
      }
    }
    
    const premio = premios[premioIndex];
    
    // Guardar en historial
    await crm.createRuletaHistorial({
      userId,
      premio: premio.nombre,
      puntos: premio.valor // Se usa 'puntos' para el valor en USD en la BD existente
    });
    
    // Registrar costo del giro (10 USDT)
    await crm.createGastoRuleta({
      userId,
      monto: 10
    });
    
    return c.json({
      success: true,
      premioIndex,
      premio,
      userSpinCount,
      globalCount
    });
    
  } catch (error) {
    console.error('Error al procesar giro de ruleta:', error);
    return c.json({ error: "Error al procesar giro" }, 500);
  }
});

// Registrar un giro de ruleta (LEGACY - Mantenido por compatibilidad si es necesario)
app.post("/make-server-9f68532a/ruleta/spin", async (c) => {
  try {
    const data = await c.req.json();
    
    const historial = await crm.createRuletaHistorial({
      userId: data.userId,
      premio: data.premio,
      puntos: data.puntos
    });
    
    console.log(`��� Ruleta girada por usuario ${data.userId}: ${data.premio}${data.puntos ? ` (+${data.puntos} puntos)` : ''}`);
    return c.json(historial);
  } catch (error) {
    console.error('Error al registrar giro de ruleta:', error);
    return c.json({ error: "Error al registrar giro de ruleta" }, 500);
  }
});

// Obtener gastos de ruleta
app.get("/make-server-9f68532a/ruleta/gastos/:userId", async (c) => {
  try {
    const userId = c.req.param('userId');
    const gastos = await crm.getGastosRuletaByUserId(userId);
    return c.json(gastos);
  } catch (error) {
    return c.json({ error: "Error al obtener gastos" }, 500);
  }
});

// Obtener gastos de ruleta (ruta alternativa para compatibilidad)
app.get("/make-server-9f68532a/users/:userId/gastos-ruleta", async (c) => {
  try {
    const userId = c.req.param('userId');
    const gastos = await crm.getGastosRuletaByUserId(userId);
    return c.json(gastos);
  } catch (error) {
    return c.json({ error: "Error al obtener gastos" }, 500);
  }
});

// ==========================================
// RUTAS DE ADMINISTRACIÓN (MIGRACIÓN)
// ==========================================

app.post("/make-server-9f68532a/admin/fix-ranks", async (c) => {
  try {
    const result = await crm.fixRanks();
    return c.json({ success: true, updated: result });
  } catch (error) {
    console.error("Error fix-ranks:", error);
    return c.json({ error: "Error fixing ranks" }, 500);
  }
});

app.post("/make-server-9f68532a/admin/recalculate-commissions", async (c) => {
  try {
    // ⚠️ FUNCIÓN DESHABILITADA TEMPORALMENTE - CONSUME DEMASIADO CPU
    // Use /admin/recalculate-user/:email para recalcular usuarios específicos
    return c.json({ 
      error: "Esta función está temporalmente deshabilitada por alto consumo de CPU. Use /admin/recalculate-user/:email para recalcular usuarios específicos.",
      endpoint_alternativo: "/admin/recalculate-user/:email"
    }, 503);
    
    /* DESHABILITADO POR ALTO CONSUMO DE CPU
    console.log("🔄 Iniciando recálculo masivo de comisiones (Matriz Corregida)...");
    
    // Auto-fix ranks logic (Ensure Esmeralda is 100k)
    await crm.fixRanks();
    
    // Recalcular rangos de TODOS los usuarios
    // Esto es crucial si las definiciones de rango cambiaron
    console.log("📊 Recalculando rangos para todos los usuarios...");
    const usersForRanks = await crm.getAllUsers();
    for (const u of usersForRanks) {
        await crm.actualizarRangoUsuario(u.id);
    }
    
    const allPacks = await crm.getAllPacks();
    const allUsers = await crm.getAllUsers();
    let comisionesCreadas = 0;
    
    // Porcentajes oficiales: L1:8%, L2:6%, L3:4%, L4:2%, L5-8:1%, L9-10:0.5%
    const porcentajesMatriz = [0, 8, 6, 4, 2, 1, 1, 1, 1, 0.5, 0.5];

    for (const pack of allPacks) {
      if (!pack.activo) continue;

      const comprador = allUsers.find(u => u.id === pack.userId);
      if (!comprador) continue;

      console.log(`Analizando pack de ${comprador.nombre} ($${pack.monto})...`);

      // 1. BONO DIRECTO (Genealogía - 10%)
      if (comprador.referidoPor) {
         const patrocinador = allUsers.find(u => u.id === comprador.referidoPor);
         if (patrocinador) {
             const comisionesPatro = await crm.getComisionesByUserId(patrocinador.id);
             const yaCobrado = comisionesPatro.some(c => 
                c.referidoId === comprador.id && c.tipo === 'patrocinio' && Math.abs(c.monto - (pack.monto * 0.10)) < 1.0
             );
             
             if (!yaCobrado) {
                 // Pagar bono directo faltante
                 await pagarComisionRecalculo(patrocinador, comprador, pack.monto, 10, 'patrocinio', 1);
                 comisionesCreadas++;
             }
         }
      }

      // 2. BONO MATRIZ (Spillover - Niveles variables)
      // Determinar padre matricial inicial
      let currentMatrizPadreId = pack.matrizPadre;
      
      // Si no tiene matrizPadre (datos antiguos), calcular dónde debería estar
      if (!currentMatrizPadreId) {
          const pos = await crm.calcularPosicionMatriz(comprador.id);
          currentMatrizPadreId = pos.matrizPadre;
          // Opcional: Actualizar pack si queremos persistir el arreglo
          if (currentMatrizPadreId) {
              await crm.updatePack(pack.id, { 
                  matrizPadre: pos.matrizPadre,
                  matrizNivel: pos.matrizNivel,
                  matrizPosicion: pos.matrizPosicion
              });
          }
      }

      let nivel = 1;
      
      while (currentMatrizPadreId && nivel <= 10) {
         const beneficiario = allUsers.find(u => u.id === currentMatrizPadreId);
         if (!beneficiario) break;

         // Buscar pack activo del beneficiario para ver siguiente padre y validar pago
         const packsBenef = allPacks.filter(p => p.userId === beneficiario.id);
         const packActivoBenef = packsBenef.find(p => p.activo);
         
         // El beneficiario debe tener pack activo para cobrar
         if (packActivoBenef) {
             const porcentaje = porcentajesMatriz[nivel] || 0;
             
             if (porcentaje > 0) {
                 const comisionesBenef = await crm.getComisionesByUserId(beneficiario.id);
                 // Verificar si ya cobró este nivel por este referido
                 const yaCobrado = comisionesBenef.some(c => 
                    c.referidoId === comprador.id && c.tipo === 'red' && c.nivel === nivel
                 );

                 if (!yaCobrado) {
                     await pagarComisionRecalculo(beneficiario, comprador, pack.monto, porcentaje, 'red', nivel);
                     comisionesCreadas++;
                 }
             }

             // Subir
             currentMatrizPadreId = packActivoBenef.matrizPadre;
             nivel++;
         } else {
             // Si no tiene pack activo, buscar último pack para seguir la cadena
             const packsOrdenados = packsBenef.sort((a, b) => new Date(b.fechaCompra).getTime() - new Date(a.fechaCompra).getTime());
             const ultimoPack = packsOrdenados[0];
             if (ultimoPack && ultimoPack.matrizPadre) {
                 currentMatrizPadreId = ultimoPack.matrizPadre;
             } else {
                 break;
             }
             nivel++;
         }
      }
    }

    return c.json({ success: true, message: `Recálculo completado. Se generaron ${comisionesCreadas} comisiones faltantes.` });
    */ // Fin del comentario del código deshabilitado
  } catch (error) {
    console.error("Error en recálculo:", error);
    return c.json({ error: "Error interno al recalcular" }, 500);
  }
});

// ==========================================
// RUTAS DE PACKS
// ==========================================

// NUEVA RUTA: Comprar Pack con Saldo de Wallet (Reinversión)
app.post("/make-server-9f68532a/packs/comprar-con-wallet", async (c) => {
  try {
    const data = await c.req.json();
    const { userId, packNombre, monto } = data;
    
    console.log(`💰 Solicitud de compra con wallet - Usuario: ${userId}, Pack: ${packNombre}, Monto: ${monto}`);
    
    // 1. Obtener datos del usuario
    const usuario = await crm.getUserById(userId);
    if (!usuario) {
      return c.json({ error: "Usuario no encontrado" }, 404);
    }
    
    // 2. Calcular saldo disponible en wallet
    const comisiones = await crm.getComisionesByUserId(userId);
    const totalGanado = comisiones.reduce((sum, c) => sum + c.monto, 0);
    
    const cobros = await crm.getCobrosByUserId(userId);
    const totalRetirado = cobros
      .filter((c: any) => c.estado === 'completado' || c.estado === 'pendiente')
      .reduce((sum, c) => sum + c.monto, 0);
    
    // Obtener gastos de ruleta
    const gastosRuleta = await crm.getGastosRuletaByUserId(userId);
    const totalGastado = gastosRuleta.reduce((sum, g) => sum + g.monto, 0);
    
    // Calcular límite de retiro (200% de la inversión)
    const packs = await crm.getPacksByUserId(userId);
    // IMPORTANTE: Solo contar el pack activo, no todos los packs históricos
    const packActivo = packs.find(p => p.activo);
    const inversionTotal = packActivo ? packActivo.monto : 0;
    const limiteRetiro = inversionTotal * 2;
    
    // Saldo disponible - SIN LÍMITE para el saldo histórico
    const saldoDisponible = Math.max(0, totalGanado - totalRetirado - totalGastado);
    
    console.log(`📊 Saldo disponible: $${saldoDisponible}, Monto requerido: $${monto}`);
    
    // 3. Verificar que tiene saldo suficiente
    if (saldoDisponible < monto) {
      return c.json({ 
        error: "Saldo insuficiente en wallet",
        saldoDisponible,
        montoRequerido: monto,
        faltante: monto - saldoDisponible
      }, 400);
    }
    
    // 4. Verificar que NO tiene un pack activo sin completar
    // Ya tenemos packActivo declarado arriba, no redeclarar
    if (packActivo) {
      // Verificar si el pack activo ya completó su ciclo (200%)
      const gananciasPack = totalGanado; // Simplificado, en producción filtrar por pack
      const limiteCompletado = packActivo.monto * 2;
      
      if (gananciasPack < limiteCompletado) {
        return c.json({ 
          error: "Tienes un pack activo que no ha completado su ciclo al 200%",
          packActivo: packActivo.nombre,
          progreso: ((gananciasPack / limiteCompletado) * 100).toFixed(2) + '%'
        }, 400);
      }
      
      // NUEVA VALIDACIÓN: El nuevo pack NO puede ser menor al pack actual completado
      if (monto < packActivo.monto) {
        return c.json({ 
          error: "No puedes reinvertir en un pack de menor valor",
          packActual: packActivo.nombre,
          montoActual: packActivo.monto,
          montoSolicitado: monto,
          mensaje: `Solo puedes reinvertir en el mismo pack ($${packActivo.monto}) o uno de mayor valor`
        }, 400);
      }
    }
    
    // 5. Desactivar el pack anterior (si existe)
    if (packActivo) {
      await crm.updatePack(packActivo.id, { activo: false });
      console.log(`🔄 Pack anterior desactivado: ${packActivo.nombre}`);
    }
    
    // 6. Crear el nuevo pack (HEREDANDO POSICIÓN MATRICIAL)
    let matrizPadre = undefined;
    let matrizNivel = undefined;
    let matrizPosicion = undefined;

    // Heredar posición del pack anterior si existe
    if (packActivo) {
      matrizPadre = packActivo.matrizPadre;
      matrizNivel = packActivo.matrizNivel;
      matrizPosicion = packActivo.matrizPosicion;
      console.log(`📍 Posición matricial heredada de pack anterior: Padre ${matrizPadre}`);
    } else {
      // Si es el primer pack (o no tenía activo), calcular posición
      console.log(`🧮 Calculando posición en matriz para reinversión...`);
      const pos = await crm.calcularPosicionMatriz(userId);
      matrizPadre = pos.matrizPadre;
      matrizNivel = pos.matrizNivel;
      matrizPosicion = pos.matrizPosicion;
    }

    const rendimientoDiario = monto * 0.01; // 1% diario
    const pack = await crm.createPack({
      userId: userId,
      nombre: packNombre,
      monto: monto,
      rendimientoDiario: rendimientoDiario,
      matrizPadre,
      matrizNivel,
      matrizPosicion
    });
    
    console.log(`✅ Pack creado: ${packNombre} ($${monto})`);
    
    // Invalidar caché después de crear pack
    invalidateCache();
    
    // LIBERAR COMISIONES RETENIDAS (Si existen)
    try {
        await crm.liberarComisionesRetenidas(userId);
    } catch (err) {
        console.error('Error al liberar comisiones retenidas:', err);
    }
    
    // 7. Registrar el gasto del wallet como un "retiro interno"
    await crm.createCobro({
      userId: userId,
      monto: monto,
      wallet: usuario.wallet || 'Sistema Interno',
      metodo: 'Compra con Wallet',
      walletDestino: 'Sistema Interno',
      estado: 'completado',
      descripcion: `Compra de ${packNombre} con saldo de wallet`
    });
    
    console.log(`💸 Saldo descontado del wallet: $${monto}`);
    
    // 8. Distribuir comisiones a la red (Matriz + Directo)
    (async () => {
      try {
        console.log(`🚀 Iniciando distribución de comisiones por reinversión de ${packNombre} ($${monto})`);
        const comprador = await crm.getUserById(userId);
        if (!comprador) return;

        // A) BONO DIRECTO (10%) - Basado en Genealogía (referidoPor)
        if (comprador.referidoPor) {
           const patrocinador = await crm.getUserById(comprador.referidoPor);
           if (patrocinador) {
              // Lógica de pago (verificar tope 200%)
              await pagarComision(patrocinador, comprador, monto, 10, 'patrocinio', 1);
           }
        }

        // B) BONO MATRIZ (Niveles) - Basado en Matriz (matrizPadre del PACK)
        // Definir porcentajes por nivel según tabla oficial
        // Nivel 1: 8%, Nivel 2: 6%, Nivel 3: 4%, Nivel 4: 2%, Niveles 5-8: 1%, Niveles 9-10: 0.5%
        const porcentajesMatriz = [0, 8, 6, 4, 2, 1, 1, 1, 1, 0.5, 0.5]; 

        let currentMatrizPadreId = pack.matrizPadre;
        let nivel = 1;

        while (currentMatrizPadreId && nivel <= 10) {
           const beneficiario = await crm.getUserById(currentMatrizPadreId);
           if (!beneficiario) break;

           // Obtener pack ACTIVO del beneficiario para ver su matrizPadre (para la siguiente iteración)
           // y para validar si puede cobrar (debe tener pack activo)
           const packsBenef = await crm.getPacksByUserId(beneficiario.id);
           const packActivoBenef = packsBenef.find(p => p.activo);
           
           if (packActivoBenef) {
              const porcentaje = porcentajesMatriz[nivel] || 0;
              if (porcentaje > 0) {
                  await pagarComision(beneficiario, comprador, monto, porcentaje, 'red', nivel);
              }
              
              // Subir al siguiente nivel matricial
              currentMatrizPadreId = packActivoBenef.matrizPadre;
              nivel++;
           } else {
              // Si el beneficiario no tiene pack activo, buscar su último pack para seguir la cadena
              // ordenado por fecha descendente
              const packsOrdenados = packsBenef.sort((a, b) => new Date(b.fechaCompra).getTime() - new Date(a.fechaCompra).getTime());
              const ultimoPack = packsOrdenados[0];
              
              if (ultimoPack && ultimoPack.matrizPadre) {
                 currentMatrizPadreId = ultimoPack.matrizPadre;
              } else {
                 break;
              }
              nivel++; 
           }
        }
        
        console.log(`✅ Distribución de comisiones completada`);
      } catch (error) {
        console.error('Error distribuyendo comisiones:', error);
      }
    })();

    // Función auxiliar para pagar comisiones con validación de tope 200%
    async function pagarComision(beneficiario: any, comprador: any, montoBase: number, porcentaje: number, tipo: 'patrocinio' | 'red', nivel: number) {
       try {
          const packsBenef = await crm.getPacksByUserId(beneficiario.id);
          const packActivoBenef = packsBenef.find(p => p.activo);
          if (!packActivoBenef) return; // Doble check

          const inversionTotalBenef = packActivoBenef.monto;
          const limiteTotalBenef = inversionTotalBenef * 2;
          const fechaInicioPack = new Date(packActivoBenef.fechaCompra).getTime();

          const comisionesBeneficiario = await crm.getComisionesByUserId(beneficiario.id);
          const gananciaAcumulada = comisionesBeneficiario
            .filter(c => c.monto > 0 && new Date(c.fecha).getTime() >= fechaInicioPack)
            .reduce((sum, c) => sum + c.monto, 0);

          const montoComision = (montoBase * porcentaje) / 100;
          let montoAPagar = montoComision;

          // Validar tope
          if (gananciaAcumulada < limiteTotalBenef) {
             if (gananciaAcumulada + montoAPagar > limiteTotalBenef) {
                montoAPagar = limiteTotalBenef - gananciaAcumulada;
             }
             
             if (montoAPagar > 0) {
                await crm.createComision({
                  userId: beneficiario.id,
                  tipo: tipo,
                  monto: montoAPagar,
                  nivel: nivel,
                  referidoId: comprador.id,
                  descripcion: tipo === 'patrocinio' 
                    ? `Bono Directo por reinversión de ${comprador.nombre} ${comprador.apellido}`
                    : `Comisión Red Nivel ${nivel} por reinversión de ${comprador.nombre} ${comprador.apellido}`
                });
                console.log(`💰 Comisión pagada a ${beneficiario.nombre}: $${montoAPagar} (${tipo}, Nivel ${nivel})`);
             }
             
             // Excedente
             if (montoAPagar < montoComision) {
                const excedente = montoComision - montoAPagar;
                if (excedente > 0) {
                   await crm.createComision({
                      userId: beneficiario.id,
                      tipo: 'excedente_retenido' as any,
                      monto: excedente,
                      nivel: nivel,
                      referidoId: comprador.id,
                      descripcion: `Retenida: ${tipo === 'patrocinio' ? 'Bono Directo' : `Comisión Red Nivel ${nivel}`} (Tope 200%)`
                   });
                   console.log(`🔒 Excedente retenido para ${beneficiario.nombre}: $${excedente}`);
                }
             }
          } else {
             // Todo retenido
             await crm.createComision({
                userId: beneficiario.id,
                tipo: 'excedente_retenido' as any,
                monto: montoComision,
                nivel: nivel,
                referidoId: comprador.id,
                descripcion: `Retenida: ${tipo === 'patrocinio' ? 'Bono Directo' : `Comisión Red Nivel ${nivel}`} (Tope 200%)`
             });
             console.log(`🔒 Comisión TOTALMENTE retenida para ${beneficiario.nombre}: $${montoComision}`);
          }
       } catch (e) {
          console.error(`Error pagando comisión a ${beneficiario.nombre}:`, e);
       }
    }
    
    return c.json({ 
      success: true,
      message: "Pack comprado exitosamente con saldo de wallet",
      pack,
      saldoRestante: saldoDisponible - monto
    });
    
  } catch (error) {
    console.error('❌ Error COMPLETO en compra con wallet:', error);
    console.error('❌ Stack trace:', error instanceof Error ? error.stack : 'No stack available');
    return c.json({ 
      error: "Error al procesar la compra con wallet",
      details: error instanceof Error ? error.message : String(error)
    }, 500);
  }
});

app.post("/make-server-9f68532a/packs", async (c) => {
  try {
    const data = await c.req.json();
    
    // VALIDACIÓN: Si ya tiene un pack activo, no permitir comprar otro
    const packs = await crm.getPacksByUserId(data.userId);
    const packActivo = packs.find(p => p.activo);
    
    if (packActivo) {
      console.log(`❌ Compra rechazada: Usuario ${data.userId} ya tiene un pack activo`);
      return c.json({ 
        error: "Ya tienes un pack activo. No puedes comprar otro pack mientras tengas uno vigente.",
        mensaje: "No puedes tener más de un pack activo simultáneamente."
      }, 400);
    }
    
    // Calcular posición en la matriz antes de crear el pack
    console.log(`🧮 Calculando posición en matriz para nuevo pack de usuario ${data.userId}...`);
    const { matrizPadre, matrizNivel, matrizPosicion } = await crm.calcularPosicionMatriz(data.userId);
    
    const pack = await crm.createPack({
      userId: data.userId,
      nombre: data.nombre,
      monto: data.monto,
      rendimientoDiario: data.rendimientoDiario,
      matrizPadre,
      matrizNivel,
      matrizPosicion
    });
    
    console.log(`✅ Pack creado para usuario ${data.userId}: ${data.nombre} (Matriz: ${matrizPadre || 'Raíz'})`);
    
    // Distribuir comisiones y actualizar rangos
    // Ejecutar en background para no bloquear la respuesta
    (async () => {
      try {
        console.log(`🚀 Iniciando distribución de comisiones por compra de ${data.nombre} ($${data.monto})`);
        
        // 1. Calcular comisiones de red (usando lógica unificada de CRM)
        await crm.calcularComisionesRed(data.userId, data.monto);
        console.log(`✅ Comisiones de red calculadas`);
        
        // 2. Actualizar rango del usuario
        await crm.actualizarRangoUsuario(data.userId);
        
        // 3. Actualizar rangos en línea ascendente
        const comprador = await crm.getUserById(data.userId);
        if (comprador && comprador.referidoPor) {
          let currentUserId = comprador.referidoPor;
          for (let i = 0; i < 10 && currentUserId; i++) {
            await crm.actualizarRangoUsuario(currentUserId);
            const user = await crm.getUserById(currentUserId);
            currentUserId = user?.referidoPor;
          }
          console.log(`✅ Rangos actualizados en línea ascendente`);
        }
      } catch (err) {
        console.error('Error en proceso de comisiones post-compra:', err);
      }
    })();

    return c.json(pack);
  } catch (error) {
    console.error('Error al crear pack:', error);
    return c.json({ error: "Error al crear pack" }, 500);
  }
});

app.get("/make-server-9f68532a/packs", async (c) => {
  try {
    const packs = await crm.getAllPacks();
    return c.json(packs);
  } catch (error) {
    console.error('Error al obtener packs:', error);
    return c.json({ error: "Error al obtener packs" }, 500);
  }
});

// ==========================================
// RUTAS DE COBROS
// ==========================================

app.post("/make-server-9f68532a/cobros", async (c) => {
  try {
    const data = await c.req.json();
    
    const cobro = await crm.createCobro({
      userId: data.userId,
      monto: data.monto,
      wallet: data.wallet
    });
    
    console.log(`✅ Cobro creado para usuario ${data.userId}: $${data.monto}`);
    return c.json(cobro);
  } catch (error) {
    console.error('Error al crear cobro:', error);
    return c.json({ error: "Error al crear cobro" }, 500);
  }
});

app.get("/make-server-9f68532a/cobros", async (c) => {
  try {
    const cobros = await crm.getAllCobros();
    return c.json(cobros);
  } catch (error) {
    console.error('Error al obtener cobros:', error);
    return c.json({ error: "Error al obtener cobros" }, 500);
  }
});

app.put("/make-server-9f68532a/cobros/:cobroId", async (c) => {
  try {
    const cobroId = c.req.param('cobroId');
    const updates = await c.req.json();
    
    const cobro = await crm.updateCobro(cobroId, updates);
    if (!cobro) {
      return c.json({ error: "Cobro no encontrado" }, 404);
    }
    
    console.log(`✅ Cobro actualizado: ${cobroId} - Estado: ${updates.estado}`);
    
    // 🚀 Invalidar caché del dashboard del usuario
    invalidateUserDashboard(cobro.userId);
    
    return c.json(cobro);
  } catch (error) {
    console.error('Error al actualizar cobro:', error);
    return c.json({ error: "Error al actualizar cobro" }, 500);
  }
});

// ==========================================
// RUTAS DE DEPÓSITOS
// ==========================================

app.post("/make-server-9f68532a/depositos", async (c) => {
  try {
    const data = await c.req.json();
    
    console.log('📥 Datos recibidos para depósito:', data);
    
    // VALIDACIÓN: Verificar que no tenga pack activo SIN COMPLETAR
    const packs = await crm.getPacksByUserId(data.userId);
    const packActivo = packs.find(p => p.activo);
    
    if (packActivo) {
       // ✅ VERIFICAR SI EL PACK YA COMPLETÓ EL 200%
       const comisiones = await crm.getComisionesByUserId(data.userId);
       const totalGanado = comisiones.reduce((sum, c) => sum + c.monto, 0);
       const limiteRetiro = packActivo.monto * 2;
       const packCompletado = totalGanado >= limiteRetiro;
       
       if (!packCompletado) {
          console.log(`❌ Depósito rechazado: Usuario ${data.userId} tiene pack activo sin completar ($${totalGanado.toFixed(2)} de $${limiteRetiro.toFixed(2)})`);
          return c.json({ 
             error: "Ya tienes un pack activo. No puedes realizar nuevos depósitos mientras tengas uno vigente.",
             packActual: packActivo.nombre,
             mensaje: "Solo puedes tener un pack activo a la vez.",
             progreso: `${totalGanado.toFixed(2)} de ${limiteRetiro.toFixed(2)} (${((totalGanado / limiteRetiro) * 100).toFixed(1)}%)`
          }, 400);
       } else {
          console.log(`✅ Pack completado (${totalGanado.toFixed(2)} >= ${limiteRetiro.toFixed(2)}). Permitiendo reinversión.`);
       }
    }
    
    const deposito = await crm.createDeposito({
      userId: data.userId,
      packNombre: data.packNombre,
      monto: Number(data.monto), // Asegurar que sea número
      walletDestino: data.walletDestino,
      comprobante: data.comprobante || '',
      metodoPago: data.metodoPago || 'manual',
      paymentId: data.paymentId,
      txHash: data.txHash
    });
    
    console.log(`✅ Depósito creado para usuario ${data.userId}: $${data.monto} - ${data.packNombre}`);
    return c.json(deposito);
  } catch (error) {
    console.error('Error al crear depósito:', error);
    return c.json({ error: "Error al crear depósito" }, 500);
  }
});

app.post("/make-server-9f68532a/depositos/upload-comprobante", async (c) => {
  try {
    const formData = await c.req.formData();
    const file = formData.get('file') as File;
    
    if (!file) {
      return c.json({ error: "No se proporcionó archivo" }, 400);
    }
    
    // Importar Supabase client
    const { createClient } = await import('npm:@supabase/supabase-js@2');
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
    );
    
    const bucketName = 'make-9f68532a-depositos';
    
    // Crear bucket si no existe
    const { data: buckets } = await supabase.storage.listBuckets();
    const bucketExists = buckets?.some(bucket => bucket.name === bucketName);
    
    if (!bucketExists) {
      // Bucket privado para comprobantes de pago (seguridad)
      // Aunque para mostrarlo en el admin necesitamos URL firmada o pública.
      // Para simplificar y dado que son comprobantes, lo haremos público por ahora para facilitar la visualización en admin,
      // o generamos URLs firmadas. El código de GestionarDepositos usa URLs directas, así que público es más fácil.
      // Pero es data sensible. Lo ideal es signed urls.
      // GestionarDepositos.tsx lines 266 checks for http/https and renders img.
      // Si el bucket es privado, getPublicUrl devuelve una URL que no funciona sin token? No, devuelve la URL pública que da 400/404 si es privado.
      // Si es privado, necesitamos .createSignedUrl().
      // El backend instruye: "When returning files from the server, provide the frontend with signed URLs via .createSignedUrl() because the buckets are private."
      
      // Sin embargo, GestionarDepositos.tsx espera una URL en `deposito.comprobante` y la renderiza en <img src={...} />.
      // Si guardo una URL firmada en la BD, esta expira.
      // Debería guardar el path y que el backend firme la URL al hacer GET /depositos?
      // Eso complicaría la lógica existente de `getAllDepositos` en `crm.tsx` que probablemente solo devuelve el objeto KV.
      
      // Dado que el usuario pide arreglarlo y `GestionarDepositos` ya espera una URL (y tiene lógica para mostrarla), 
      // y `rangos` usa bucket público... 
      // Voy a usar bucket público para evitar refactorizar todo el sistema de recuperación de datos.
      await supabase.storage.createBucket(bucketName, {
        public: true
      });
      console.log(`✅ Bucket creado: ${bucketName}`);
    }
    
    // Generar nombre único
    const fileExt = file.name.split('.').pop();
    const fileName = `${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;
    const filePath = `comprobantes/${fileName}`;
    
    const arrayBuffer = await file.arrayBuffer();
    const uint8Array = new Uint8Array(arrayBuffer);
    
    const { error: uploadError } = await supabase.storage
      .from(bucketName)
      .upload(filePath, uint8Array, {
        contentType: file.type,
        upsert: false
      });
    
    if (uploadError) {
      console.error('Error al subir archivo:', uploadError);
      return c.json({ error: `Error al subir archivo: ${uploadError.message}` }, 500);
    }
    
    const { data: urlData } = supabase.storage
      .from(bucketName)
      .getPublicUrl(filePath);
    
    console.log(`✅ Comprobante subido: ${urlData.publicUrl}`);
    
    return c.json({ 
      url: urlData.publicUrl,
      fileName: fileName 
    });
  } catch (error) {
    console.error('Error al procesar carga de comprobante:', error);
    return c.json({ error: "Error al procesar carga de comprobante" }, 500);
  }
});

app.get("/make-server-9f68532a/depositos", async (c) => {
  try {
    const depositos = await crm.getAllDepositos();
    return c.json(depositos);
  } catch (error) {
    console.error('Error al obtener depósitos:', error);
    return c.json({ error: "Error al obtener depósitos" }, 500);
  }
});

app.put("/make-server-9f68532a/depositos/:depositoId", async (c) => {
  const requestStartTime = Date.now();
  const MAX_REQUEST_TIME = 55000; // ⚡ OPTIMIZADO: 55 segundos para evitar timeout del servidor (60s)
  
  try {
    const depositoId = c.req.param('depositoId');
    const updates = await c.req.json();
    
    console.log(`⚡ [DEPOSITO] Iniciando actualización de depósito ${depositoId} - Timeout en ${MAX_REQUEST_TIME}ms`);
    
    // Obtener el depósito ANTES de actualizar para verificar el estado anterior
    console.log(`⏱️ [DEPOSITO] T+${Date.now() - requestStartTime}ms - Obteniendo depósito...`);
    const depositoAnterior = await crm.getDepositoById(depositoId);
    if (!depositoAnterior) {
      return c.json({ error: "Depósito no encontrado" }, 404);
    }
    console.log(`⏱️ [DEPOSITO] T+${Date.now() - requestStartTime}ms - Depósito obtenido`);
    
    // Verificar timeout
    if (Date.now() - requestStartTime > MAX_REQUEST_TIME) {
      console.error(`⏱️ TIMEOUT en ruta: /make-server-9f68532a/depositos/${depositoId}`);
      return c.json({ error: "Timeout procesando depósito" }, 504);
    }
    
    // Actualizar el depósito
    console.log(`⏱️ [DEPOSITO] T+${Date.now() - requestStartTime}ms - Actualizando depósito...`);
    const deposito = await crm.updateDeposito(depositoId, updates);
    if (!deposito) {
      return c.json({ error: "Depósito no encontrado" }, 404);
    }
    
    console.log(`⏱️ [DEPOSITO] T+${Date.now() - requestStartTime}ms - ✅ Depósito actualizado: ${depositoId} - Estado: ${updates.estado}`);
    
    // Si el depósito es verificado por primera vez, crear el pack y calcular comisiones
    if (updates.estado === 'verificado' && depositoAnterior.estado !== 'verificado') {
      const processingStartTime = Date.now();
      console.log(`⏱️ [DEPOSITO] T+${Date.now() - requestStartTime}ms - 📦 Iniciando creación de pack para usuario ${deposito.userId}...`);
      
      // Activar al usuario si no está activo
      const usuario = await crm.getUserById(deposito.userId);
      if (usuario && !usuario.activo) {
        await crm.updateUser(deposito.userId, { activo: true });
        console.log(`✅ Usuario ${deposito.userId} activado`);
      }
      
      // CALCULAR POSICIÓN EN LA MATRIZ DEL PATROCINADOR
      // Estrategia: Buscar hueco en la red descendente del patrocinador (Spillover real)
      // Se usa "matrizPadre" para indicar quién es el padre directo en la matriz (upline)
      
      let matrizPadre = usuario?.referidoPor;
      let matrizNivel = 1;
      let matrizPosicion = 0;
      
      if (usuario && usuario.referidoPor) {
        console.log(`🔍 Calculando posición en matriz para ${usuario.nombre}...`);
        const startTime = Date.now();
        
        try {
          // ⚡ TIMEOUT REDUCIDO: Si el cálculo de matriz tarda más de 5s, usar valores por defecto
          const timeoutPromise = new Promise((_, reject) => 
            setTimeout(() => reject(new Error('Timeout en cálculo de matriz')), 5000)
          );
          
          const calcularMatrizPromise = (async () => {
            // ⚡ USAR CACHÉ para evitar consultas lentas
            console.log('  📥 Cargando usuarios y packs desde caché...');
            const todosLosUsuarios = await getCachedUsuarios();
            console.log(`  ✅ ${todosLosUsuarios.length} usuarios cargados desde caché en ${Date.now() - startTime}ms`);
            
            // Verificar si debemos continuar
            if (Date.now() - requestStartTime > MAX_REQUEST_TIME - 5000) {
              throw new Error('Tiempo insuficiente para calcular matriz');
            }
            
            const todosLosPacks = await getCachedPacks();
            console.log(`  ✅ ${todosLosPacks.length} packs cargados desde caché en ${Date.now() - startTime}ms`);
            
            // Solo packs activos importan para la matriz
            const packsActivos = todosLosPacks.filter((p: any) => p.activo);
            console.log(`  ✅ ${packsActivos.length} packs activos filtrados`);
            
            return { todosLosUsuarios, packsActivos };
          })();
          
          const { todosLosUsuarios, packsActivos } = await Promise.race([
            calcularMatrizPromise,
            timeoutPromise
          ]) as any;
          
          // ⚡ OPTIMIZACIÓN: Pre-indexar packs por matrizPadre para búsqueda O(1)
          const packsPorPadre = new Map<string, any[]>();
          packsActivos.forEach((p: any) => {
            if (!packsPorPadre.has(p.matrizPadre)) {
              packsPorPadre.set(p.matrizPadre, []);
            }
            packsPorPadre.get(p.matrizPadre)!.push(p);
          });
          console.log(`  ⚡ Índice creado: ${packsPorPadre.size} padres únicos`);
          
          // Función para encontrar hueco BFS (Breadth-First Search)
          // Busca el primer hueco disponible de izquierda a derecha, nivel por nivel
          const encontrarHuecoEnMatriz = (raizId: string) => {
            console.log(`  🔎 Buscando hueco en matriz desde raíz: ${raizId}`);
            const queue: Array<{ id: string, nivel: number }> = [{ id: raizId, nivel: 0 }];
            const visitados = new Set<string>();
            visitados.add(raizId);
            let iteraciones = 0;
            const maxIteraciones = 300; // ⚡ REDUCIDO: 300 iteraciones para evitar timeout
            const maxTiempo = 4000; // ⚡ REDUCIDO: 4 segundos para evitar timeout
            
            while (queue.length > 0) {
              iteraciones++;
              
              // Protección contra timeout
              if (Date.now() - startTime > maxTiempo) {
                console.warn(`⚠️ TIMEOUT: Búsqueda de matriz excedió ${maxTiempo}ms. Forzando posición en raíz.`);
                return { padreId: raizId, nivelRelativo: 1, posicion: 0 };
              }
              
              // Protección contra demasiadas iteraciones
              if (iteraciones > maxIteraciones) {
                console.warn(`⚠️ LÍMITE: Búsqueda excedió ${maxIteraciones} iteraciones. Forzando posición en raíz.`);
                return { padreId: raizId, nivelRelativo: 1, posicion: 0 };
              }
              
              const current = queue.shift();
              if (!current) continue;
              
              // Log cada 100 iteraciones
              if (iteraciones % 100 === 0) {
                console.log(`  🔄 Iteración ${iteraciones}, nivel ${current.nivel}, visitados: ${visitados.size}`);
              }
              
              // ⚡ OPTIMIZACIÓN: Usar índice pre-calculado en lugar de filtrar toda la lista
              // Esto reduce la complejidad de O(n) a O(1) por cada iteración
              const hijos = (packsPorPadre.get(current.id) || [])
                .sort((a: any, b: any) => new Date(a.fechaCompra).getTime() - new Date(b.fechaCompra).getTime());
              
              // Si tiene menos de 3 hijos, ¡encontramos un hueco!
              if (hijos.length < 3) {
                console.log(`  ✅ HUECO ENCONTRADO en iteración ${iteraciones}: Padre=${current.id}, Posición=${hijos.length}`);
                return {
                  padreId: current.id,
                  nivelRelativo: current.nivel + 1,
                  posicion: hijos.length // 0, 1 o 2
                };
              }
              
              // Si está lleno, agregar los hijos a la cola para seguir buscando abajo
              for (const hijo of hijos) {
                // Obtener el usuario dueño del pack hijo para seguir la cadena
                if (!visitados.has(hijo.userId)) {
                  visitados.add(hijo.userId);
                  queue.push({ id: hijo.userId, nivel: current.nivel + 1 });
                }
              }
              
              // Protección contra ciclos infinitos o redes muy grandes
              if (visitados.size > 500) { // ⚡ REDUCIDO: 500 para evitar timeout
                console.warn('⚠️ Límite de búsqueda de matriz alcanzado. Forzando derrame en raíz.');
                return { padreId: raizId, nivelRelativo: 1, posicion: 0 };
              }
            }
            
            // Fallback: si algo falla, devolver la raíz
            console.log('  ⚠️ No se encontró hueco, usando raíz como fallback');
            return { padreId: raizId, nivelRelativo: 1, posicion: 0 };
          };
          
          // Ejecutar búsqueda de hueco desde el patrocinador
          const hueco = encontrarHuecoEnMatriz(usuario.referidoPor);
          
          matrizPadre = hueco.padreId;
          // El nivel almacenado en BD es relativo al padre matricial, pero para cálculos globales
          // puede ser útil guardar la profundidad. Por ahora mantenemos compatibilidad:
          // matrizNivel 1 significa "hijo directo de matrizPadre".
          matrizNivel = 1; 
          matrizPosicion = hueco.posicion;
          
          console.log(`✅ Matriz calculada para ${usuario.nombre} en ${Date.now() - startTime}ms:`);
          console.log(`   - Patrocinador Directo: ${usuario.referidoPor}`);
          console.log(`   - Padre en Matriz (Spillover): ${matrizPadre}`);
          console.log(`   - Posición: Hueco ${matrizPosicion} (debajo de ${matrizPadre})`);
        } catch (error) {
          console.error('❌ Error al calcular matriz, usando valores por defecto:', error);
          // En caso de error, usar valores por defecto
          matrizPadre = usuario.referidoPor;
          matrizNivel = 1;
          matrizPosicion = 0;
        }
      }
      
      // Crear el pack con información de matriz
      const pack = await crm.createPack({
        userId: deposito.userId,
        nombre: deposito.packNombre,
        monto: deposito.monto,
        rendimientoDiario: deposito.monto * 0.01, // 1% diario por defecto
        matrizPadre: matrizPadre,
        matrizNivel: matrizNivel,
        matrizPosicion: matrizPosicion
      });
      
      console.log(`✅ Pack creado: ${pack.id} - Matriz: padre=${matrizPadre}, nivel=${matrizNivel}, pos=${matrizPosicion}`);

      // LIBERAR COMISIONES RETENIDAS
      try {
          await crm.liberarComisionesRetenidas(deposito.userId);
      } catch (err) {
          console.error('Error al liberar comisiones retenidas:', err);
      }
      
      // Calcular comisiones de red
      console.log(`⏱️ [DEPOSITO] T+${Date.now() - requestStartTime}ms - Calculando comisiones de red...`);
      await crm.calcularComisionesRed(deposito.userId, deposito.monto);
      console.log(`⏱️ [DEPOSITO] T+${Date.now() - requestStartTime}ms - ✅ Comisiones de red calculadas`);
      
      // ⚡ OPTIMIZADO: Actualizar rangos en background para no bloquear la respuesta
      console.log(`⏭️ Rangos se actualizarán en background...`);
      
      // Actualizar rango del usuario en background (sin await)
      crm.actualizarRangoUsuario(deposito.userId)
        .then(() => console.log(`✅ Rango actualizado para usuario ${deposito.userId}`))
        .catch(err => console.error('❌ Error actualizando rango:', err));
      
      // También actualizar rangos de todos los usuarios en la línea ascendente (background)
      if (usuario && usuario.referidoPor) {
        (async () => {
          let currentUserId = usuario.referidoPor;
          for (let i = 0; i < 10 && currentUserId; i++) {
            try {
              await crm.actualizarRangoUsuario(currentUserId);
              const user = await crm.getUserById(currentUserId);
              currentUserId = user?.referidoPor;
            } catch (err) {
              console.error(`❌ Error actualizando rango de ${currentUserId}:`, err);
              break;
            }
          }
          console.log(`✅ Rangos actualizados en línea ascendente`);
        })().catch(err => console.error('❌ Error en actualización de rangos ascendentes:', err));
      }
      
      console.log(`✅ ⏱️ Depósito verificado completamente en ${Date.now() - processingStartTime}ms`);
    }
    
    // 🚀 Invalidar caché del dashboard del usuario y caché global
    invalidateUserDashboard(deposito.userId);
    invalidateCache(); // Tambi��n invalidar caché global para que la matriz se actualice
    
    console.log(`✅ ⏱️ Request completado en ${Date.now() - requestStartTime}ms total`);
    return c.json(deposito);
  } catch (error) {
    const elapsed = Date.now() - requestStartTime;
    console.error(`❌ Error al actualizar depósito (${elapsed}ms):`, error);
    return c.json({ error: "Error al actualizar depósito" }, 500);
  }
});

// ==========================================
// RUTAS DE PRODUCTOS
// ==========================================

app.post("/make-server-9f68532a/productos", async (c) => {
  try {
    const data = await c.req.json();
    const producto = await crm.createProducto(data);
    console.log(`✅ Producto creado: ${producto.nombre}`);
    return c.json(producto);
  } catch (error) {
    console.error('Error al crear producto:', error);
    return c.json({ error: "Error al crear producto" }, 500);
  }
});

app.get("/make-server-9f68532a/productos", async (c) => {
  try {
    let productos = await crm.getAllProductos();
    
    // Si no hay productos, inicializar los productos por defecto
    if (productos.length === 0) {
      console.log('⚙️  No hay productos, inicializando productos por defecto...');
      productos = await crm.initProductosDefecto();
    }
    
    return c.json(productos);
  } catch (error) {
    console.error('Error al obtener productos:', error);
    return c.json({ error: "Error al obtener productos" }, 500);
  }
});

app.put("/make-server-9f68532a/productos/:productoId", async (c) => {
  try {
    const productoId = c.req.param('productoId');
    const updates = await c.req.json();
    
    const producto = await crm.updateProducto(productoId, updates);
    if (!producto) {
      return c.json({ error: "Producto no encontrado" }, 404);
    }
    
    console.log(`✅ Producto actualizado: ${productoId}`);
    return c.json(producto);
  } catch (error) {
    console.error('Error al actualizar producto:', error);
    return c.json({ error: "Error al actualizar producto" }, 500);
  }
});

app.delete("/make-server-9f68532a/productos/:productoId", async (c) => {
  try {
    const productoId = c.req.param('productoId');
    
    await crm.deleteProducto(productoId);
    console.log(`✅ Producto eliminado: ${productoId}`);
    
    return c.json({ success: true });
  } catch (error) {
    console.error('Error al eliminar producto:', error);
    return c.json({ error: "Error al eliminar producto" }, 500);
  }
});

// ==========================================
// RUTAS DE RANGOS
// ==========================================

app.post("/make-server-9f68532a/rangos/upload-imagen", async (c) => {
  try {
    const formData = await c.req.formData();
    const file = formData.get('file') as File;
    
    if (!file) {
      return c.json({ error: "No se proporcionó archivo" }, 400);
    }
    
    // Importar Supabase client
    const { createClient } = await import('npm:@supabase/supabase-js@2');
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
    );
    
    const bucketName = 'make-9f68532a-rangos';
    
    // Crear bucket si no existe
    const { data: buckets } = await supabase.storage.listBuckets();
    const bucketExists = buckets?.some(bucket => bucket.name === bucketName);
    
    if (!bucketExists) {
      await supabase.storage.createBucket(bucketName, {
        public: true // Bucket público para las imágenes de rangos
      });
      console.log(`✅ Bucket creado: ${bucketName}`);
    }
    
    // Generar nombre único para el archivo
    const fileExt = file.name.split('.').pop();
    const fileName = `${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;
    const filePath = `rangos/${fileName}`;
    
    // Convertir File a ArrayBuffer
    const arrayBuffer = await file.arrayBuffer();
    const uint8Array = new Uint8Array(arrayBuffer);
    
    // Subir archivo
    const { data: uploadData, error: uploadError } = await supabase.storage
      .from(bucketName)
      .upload(filePath, uint8Array, {
        contentType: file.type,
        upsert: false
      });
    
    if (uploadError) {
      console.error('Error al subir archivo:', uploadError);
      return c.json({ error: `Error al subir archivo: ${uploadError.message}` }, 500);
    }
    
    // Obtener URL pública
    const { data: urlData } = supabase.storage
      .from(bucketName)
      .getPublicUrl(filePath);
    
    console.log(`✅ Imagen subida: ${urlData.publicUrl}`);
    
    return c.json({ 
      url: urlData.publicUrl,
      fileName: fileName 
    });
  } catch (error) {
    console.error('Error al procesar carga de imagen:', error);
    return c.json({ error: "Error al procesar carga de imagen" }, 500);
  }
});

app.post("/make-server-9f68532a/rangos", async (c) => {
  try {
    const data = await c.req.json();
    
    const rango = await crm.createRango({
      nombre: data.nombre,
      directos: data.directos,
      volumen: data.volumen,
      premio: data.premio,
      color: data.color,
      gradient: data.gradient,
      icon: data.icon,
      imagen: data.imagen
    });
    
    console.log(`✅ Rango creado: ${rango.nombre}`);
    return c.json(rango);
  } catch (error) {
    console.error('Error al crear rango:', error);
    return c.json({ error: "Error al crear rango" }, 500);
  }
});

app.get("/make-server-9f68532a/rangos", async (c) => {
  try {
    // ⚡ Timeout de 10 segundos (aumentado)
    const rangosPromise = crm.getAllRangos();
    const timeoutPromise = new Promise((_, reject) => 
      setTimeout(() => reject(new Error('Timeout getting rangos')), 10000)
    );
    
    const rangos = await Promise.race([rangosPromise, timeoutPromise]);
    return c.json(rangos);
  } catch (error) {
    console.error('Error al obtener rangos:', error);
    const errorMsg = error instanceof Error ? error.message : String(error);
    if (errorMsg.includes('timeout') || errorMsg.includes('Timeout')) {
      console.log('⚠️ Timeout en rangos, retornando array vacío');
      return c.json([]);
    }
    return c.json({ error: "Error al obtener rangos" }, 500);
  }
});

app.post("/make-server-9f68532a/rangos/init", async (c) => {
  try {
    const rangos = await crm.initRangosDefecto();
    console.log(`✅ Rangos inicializados: ${rangos.length} rangos`);
    return c.json(rangos);
  } catch (error) {
    console.error('Error al inicializar rangos:', error);
    return c.json({ error: "Error al inicializar rangos" }, 500);
  }
});

app.put("/make-server-9f68532a/rangos/:rangoId", async (c) => {
  try {
    const rangoId = c.req.param('rangoId');
    const updates = await c.req.json();
    
    const rango = await crm.updateRango(rangoId, updates);
    if (!rango) {
      return c.json({ error: "Rango no encontrado" }, 404);
    }
    
    console.log(`✅ Rango actualizado: ${rangoId}`);
    return c.json(rango);
  } catch (error) {
    console.error('Error al actualizar rango:', error);
    return c.json({ error: "Error al actualizar rango" }, 500);
  }
});

app.delete("/make-server-9f68532a/rangos/:rangoId", async (c) => {
  try {
    const rangoId = c.req.param('rangoId');
    
    await crm.deleteRango(rangoId);
    console.log(`✅ Rango eliminado: ${rangoId}`);
    
    return c.json({ success: true });
  } catch (error) {
    console.error('Error al eliminar rango:', error);
    return c.json({ error: "Error al eliminar rango" }, 500);
  }
});

// DIAGNÓSTICO: Verificar y corregir rango Silver
app.get("/make-server-9f68532a/admin/diagnosticar-silver", async (c) => {
  try {
    const rangos = await crm.getAllRangos();
    const silver = rangos.find(r => r.nombre.toLowerCase() === 'silver');
    
    if (!silver) {
      return c.json({ error: 'Rango Silver no encontrado en la base de datos' }, 404);
    }
    
    console.log('🔍 Diagnóstico Silver:', {
      id: silver.id,
      nombre: silver.nombre,
      directos: silver.directos,
      volumen: silver.volumen,
      premio: silver.premio
    });
    
    // Verificar si está incorrecto
    const esIncorrecto = silver.directos !== 3 || silver.volumen !== 10000;
    
    if (esIncorrecto) {
      console.log('❌ Rango Silver INCORRECTO. Corrigiendo...');
      const corregido = await crm.updateRango(silver.id, {
        directos: 3,
        volumen: 10000
      });
      
      return c.json({
        estado: 'corregido',
        antes: {
          directos: silver.directos,
          volumen: silver.volumen
        },
        despues: {
          directos: corregido.directos,
          volumen: corregido.volumen
        }
      });
    }
    
    return c.json({
      estado: 'correcto',
      configuracion: {
        directos: silver.directos,
        volumen: silver.volumen
      }
    });
  } catch (error: any) {
    console.error('Error diagnosticando Silver:', error);
    return c.json({ error: error.message }, 500);
  }
});

// ==========================================
// RUTA DE INICIALIZACIÓN COMPLETA DEL SISTEMA
// ==========================================

app.post("/make-server-9f68532a/init/complete", async (c) => {
  try {
    console.log('🚀 Iniciando inicialización completa del sistema...');
    
    const resultado = {
      productos: 0,
      rangos: 0,
      admin: false,
      errores: []
    };
    
    // 1. Inicializar productos
    try {
      console.log('📦 Inicializando productos...');
      const productos = await crm.initProductosDefecto();
      resultado.productos = productos.length;
      console.log(`✅ ${productos.length} productos inicializados`);
    } catch (error) {
      console.error('❌ Error al inicializar productos:', error);
      resultado.errores.push({ paso: 'productos', error: error.message });
    }
    
    // 2. Inicializar rangos
    try {
      console.log('🏆 Inicializando rangos...');
      const rangos = await crm.initRangosDefecto();
      resultado.rangos = rangos.length;
      console.log(`✅ ${rangos.length} rangos inicializados`);
    } catch (error) {
      console.error('❌ Error al inicializar rangos:', error);
      resultado.errores.push({ paso: 'rangos', error: error.message });
    }
    
    // 3. Verificar/Crear usuario admin
    try {
      console.log('👤 Verificando usuario admin...');
      let adminUser = await crm.getUserByEmail('admin@libertyfinance.com');
      
      if (!adminUser) {
        console.log('⚙️ Creando usuario admin...');
        adminUser = await crm.createUser({
          id_unico: 'LF-ADMIN-001',
          nombre: 'Admin',
          apellido: 'Liberty',
          email: 'admin@libertyfinance.com',
          telefono: '+1234567890',
          ciudad: 'Global',
          wallet: 'TAdminWallet123456789',
          password: 'admin123',
          referralCode: '',
          referidoPor: undefined,
          rango: 'Crown Black'
        });
        
        // Activar admin y darle puntos
        await crm.updateUser(adminUser.id, { activo: true });
        await crm.setPuntos(adminUser.id, 1000);
        
        console.log('✅ Usuario admin creado y activado');
        resultado.admin = true;
      } else {
        console.log('ℹ️ Usuario admin ya existe');
        resultado.admin = true;
      }
    } catch (error) {
      console.error('❌ Error al crear admin:', error);
      resultado.errores.push({ paso: 'admin', error: error.message });
    }
    
    console.log('🎉 Inicialización completa finalizada');
    console.log(`📊 Resumen: ${resultado.productos} productos, ${resultado.rangos} rangos, admin: ${resultado.admin ? 'OK' : 'ERROR'}`);
    
    return c.json({
      success: true,
      mensaje: 'Sistema inicializado correctamente',
      resultado
    });
    
  } catch (error) {
    console.error('❌ Error en inicialización completa:', error);
    return c.json({ 
      success: false,
      error: "Error en la inicialización completa",
      details: error.message 
    }, 500);
  }
});

// ==========================================
// RUTA DE DEBUG - VERIFICAR Y CREAR ADMIN
// ==========================================

app.post("/make-server-9f68532a/debug/create-admin", async (c) => {
  try {
    console.log('🔧 DEBUG: Verificando usuario admin...');
    
    // Verificar si existe
    let adminUser = await crm.getUserByEmail('admin@libertyfinance.com');
    
    if (adminUser) {
      console.log('ℹ️ Admin ya existe:', {
        id: adminUser.id,
        id_unico: adminUser.id_unico,
        email: adminUser.email,
        activo: adminUser.activo,
        rango: adminUser.rango
      });
      
      // Si existe pero no está activo, activarlo
      if (!adminUser.activo) {
        await crm.updateUser(adminUser.id, { activo: true });
        console.log('✅ Admin activado');
      }
      
      return c.json({
        success: true,
        message: 'Admin ya existe',
        admin: {
          id: adminUser.id,
          id_unico: adminUser.id_unico,
          email: adminUser.email,
          activo: adminUser.activo,
          rango: adminUser.rango
        }
      });
    }
    
    // Si no existe, crearlo
    console.log('⚙️ Creando usuario admin...');
    adminUser = await crm.createUser({
      id_unico: 'LF-ADMIN-001',
      nombre: 'Admin',
      apellido: 'Liberty',
      email: 'admin@libertyfinance.com',
      telefono: '+1234567890',
      ciudad: 'Global',
      wallet: 'TAdminWallet123456789',
      password: 'admin123',
      referralCode: '',
      referidoPor: undefined,
      rango: 'Crown Black'
    });
    
    // Activar admin
    await crm.updateUser(adminUser.id, { activo: true });
    await crm.setPuntos(adminUser.id, 1000);
    
    console.log('✅ Usuario admin creado y activado:', {
      id: adminUser.id,
      email: adminUser.email,
      password: 'admin123'
    });
    
    return c.json({
      success: true,
      message: 'Admin creado exitosamente',
      admin: {
        id: adminUser.id,
        id_unico: adminUser.id_unico,
        email: 'admin@libertyfinance.com',
        password: 'admin123',
        activo: true,
        rango: 'Crown Black'
      }
    });
    
  } catch (error) {
    console.error('❌ Error al crear/verificar admin:', error);
    return c.json({ 
      success: false,
      error: "Error al crear/verificar admin",
      details: error.message 
    }, 500);
  }
});

// ==========================================
// RUTA DE DEBUG - RESETEAR CONTRASEÑA ADMIN
// ==========================================

app.post("/make-server-9f68532a/debug/reset-admin-password", async (c) => {
  try {
    console.log('🔧 DEBUG: Reseteando contraseña del admin...');
    
    const adminUser = await crm.getUserByEmail('admin@libertyfinance.com');
    
    if (!adminUser) {
      return c.json({
        success: false,
        error: 'Usuario admin no existe. Usa /debug/create-admin primero.'
      }, 404);
    }
    
    // Resetear contraseña a admin123
    await crm.updateUser(adminUser.id, { 
      password: 'admin123',
      activo: true 
    });
    
    console.log('✅ Contraseña del admin reseteada a: admin123');
    
    return c.json({
      success: true,
      message: 'Contraseña reseteada correctamente',
      credentials: {
        email: 'admin@libertyfinance.com',
        password: 'admin123'
      }
    });
    
  } catch (error) {
    console.error('❌ Error al resetear contraseña:', error);
    return c.json({ 
      success: false,
      error: "Error al resetear contraseña",
      details: error.message 
    }, 500);
  }
});

// ==========================================
// RUTAS DE DOCUMENTOS LEGALES (PDFs)
// ==========================================

app.post("/make-server-9f68532a/documentos/upload-pdf", async (c) => {
  try {
    const formData = await c.req.formData();
    const file = formData.get('file') as File;
    const tipo = formData.get('tipo') as string; // 'terminos', 'privacidad', 'aviso'
    
    if (!file) {
      return c.json({ error: "No se proporcionó archivo" }, 400);
    }
    
    if (!tipo) {
      return c.json({ error: "No se especificó el tipo de documento" }, 400);
    }
    
    // Validar que sea PDF
    if (!file.type.includes('pdf')) {
      return c.json({ error: "Solo se permiten archivos PDF" }, 400);
    }
    
    // Importar Supabase client
    const { createClient } = await import('npm:@supabase/supabase-js@2');
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
    );
    
    const bucketName = 'make-9f68532a-documentos';
    
    // Crear bucket si no existe
    const { data: buckets } = await supabase.storage.listBuckets();
    const bucketExists = buckets?.some(bucket => bucket.name === bucketName);
    
    if (!bucketExists) {
      await supabase.storage.createBucket(bucketName, {
        public: true // Bucket público para los documentos legales
      });
      console.log(`✅ Bucket de documentos creado: ${bucketName}`);
    }
    
    // Generar nombre del archivo basado en el tipo
    const fileName = `${tipo}-${Date.now()}.pdf`;
    const filePath = `legales/${fileName}`;
    
    // Convertir File a ArrayBuffer
    const arrayBuffer = await file.arrayBuffer();
    const uint8Array = new Uint8Array(arrayBuffer);
    
    // Subir archivo
    const { data: uploadData, error: uploadError } = await supabase.storage
      .from(bucketName)
      .upload(filePath, uint8Array, {
        contentType: 'application/pdf',
        upsert: false
      });
    
    if (uploadError) {
      console.error('Error al subir PDF:', uploadError);
      return c.json({ error: `Error al subir PDF: ${uploadError.message}` }, 500);
    }
    
    // Obtener URL pública
    const { data: urlData } = supabase.storage
      .from(bucketName)
      .getPublicUrl(filePath);
    
    console.log(`✅ PDF subido: ${urlData.publicUrl}`);
    
    // Actualizar la configuración con la nueva URL
    const config = await crm.getConfiguracionAdmin();
    const documentosLegales = config?.documentosLegales || {};
    documentosLegales[tipo] = urlData.publicUrl;
    
    await crm.setConfiguracionAdmin({
      ...config,
      documentosLegales,
      ultimaActualizacion: new Date().toISOString()
    });
    
    console.log(`✅ Configuración actualizada con documento ${tipo}`);
    
    return c.json({ 
      url: urlData.publicUrl,
      fileName: fileName,
      tipo: tipo
    });
  } catch (error) {
    console.error('Error al procesar carga de PDF:', error);
    return c.json({ error: "Error al procesar carga de PDF" }, 500);
  }
});

app.get("/make-server-9f68532a/documentos/legales", async (c) => {
  try {
    const config = await crm.getConfiguracionAdmin();
    const documentosLegales = config?.documentosLegales || {
      terminos: '',
      privacidad: '',
      aviso: ''
    };
    
    return c.json(documentosLegales);
  } catch (error) {
    console.error('Error al obtener documentos legales:', error);
    return c.json({ error: "Error al obtener documentos legales" }, 500);
  }
});

// ==========================================
// RUTAS DE CONFIGURACIÓN ADMIN
// ==========================================

app.get("/make-server-9f68532a/admin/configuracion", async (c) => {
  try {
    let config = await crm.getConfiguracionAdmin();
    
    if (!config) {
      // Configuración por defecto
      config = {
        walletPrincipal: 'TBeUC78yskw4weSTP2wuJguuwKEkAKwNUM',
        walletsSecundarios: [],
        comisionReferidoDirecto: 0.10,
        qrCodeUrl: '',
        rendimientoActivo: true,
        porcentajeRendimiento: 1,
        ultimaActualizacion: new Date().toISOString()
      };
      
      await crm.setConfiguracionAdmin(config);
    }
    
    // ✅ AGREGAR INFO DE ÚLTIMO PROCESAMIENTO
    const hoy = new Date().toISOString().split('T')[0];
    const ultimoProcesamiento = await kv.get('config:ultimo-procesamiento-rendimiento');
    
    return c.json({
      ...config,
      ultimoProcesamientoRendimiento: ultimoProcesamiento || null,
      yaProcesadoHoy: ultimoProcesamiento === hoy
    });
  } catch (error) {
    console.error('Error al obtener configuración:', error);
    return c.json({ error: "Error al obtener configuración" }, 500);
  }
});

app.put("/make-server-9f68532a/admin/configuracion", async (c) => {
  try {
    const updates = await c.req.json();
    
    let config = await crm.getConfiguracionAdmin();
    
    if (!config) {
      config = {
        walletPrincipal: 'TBeUC78yskw4weSTP2wuJguuwKEkAKwNUM',
        walletsSecundarios: [],
        comisionReferidoDirecto: 0.10,
        qrCodeUrl: '',
        rendimientoActivo: true,
        porcentajeRendimiento: 1,
        ultimaActualizacion: new Date().toISOString()
      };
    }
    
    const updatedConfig = {
      ...config,
      ...updates,
      ultimaActualizacion: new Date().toISOString()
    };
    
    await crm.setConfiguracionAdmin(updatedConfig);
    console.log('✅ Configuraci��n actualizada:', updatedConfig);
    
    return c.json(updatedConfig);
  } catch (error) {
    console.error('Error al actualizar configuración:', error);
    return c.json({ error: "Error al actualizar configuración" }, 500);
  }
});

// ==========================================
// CONFIGURACIÓN DE MANTENIMIENTO
// ==========================================

// 🚀 Caché ultra-rápido para estado de mantenimiento
let cacheMantenimiento: { activo: boolean; timestamp: number } | null = null;
const MANTENIMIENTO_CACHE_TTL = 30000; // 30 segundos

// Obtener estado del mantenimiento (público)
app.get("/make-server-9f68532a/config/mantenimiento", async (c) => {
  try {
    // ⚡ Primero verificar lógica automática (sin acceso a BD)
    const ahora = new Date();
    const hora = ahora.getHours();
    const minutos = ahora.getMinutes();
    const minutoActual = hora * 60 + minutos;
    const inicioMantenimiento = 1 * 60; // 1:00 AM
    const finMantenimiento = 10 * 60; // 10:00 AM
    
    // Si estamos en horario automático de mantenimiento (1 AM - 10 AM), retornar inmediatamente
    const estaEnHorarioAutomatico = minutoActual >= inicioMantenimiento && minutoActual < finMantenimiento;
    
    if (estaEnHorarioAutomatico) {
      return c.json({ 
        activo: true, 
        automatico: true,
        mensaje: 'Modo mantenimiento automático activo (1:00 AM - 10:00 AM)'
      });
    }
    
    // ⚡ Usar caché si está fresco (fuera de horario automático)
    if (cacheMantenimiento && (Date.now() - cacheMantenimiento.timestamp < MANTENIMIENTO_CACHE_TTL)) {
      return c.json({ 
        activo: cacheMantenimiento.activo,
        automatico: false
      });
    }
    
    // Solo si no estamos en horario automático, verificar configuración manual
    const mantenimiento = await kv.get('config:mantenimiento') || { activo: false };
    
    // ⚡ Actualizar caché
    cacheMantenimiento = {
      activo: mantenimiento.activo || false,
      timestamp: Date.now()
    };
    
    return c.json({
      activo: mantenimiento.activo || false,
      automatico: false
    });
  } catch (error) {
    console.error('Error al obtener config de mantenimiento:', error);
    
    // ⚡ Fallback: usar solo lógica automática
    const ahora = new Date();
    const hora = ahora.getHours();
    const minutos = ahora.getMinutes();
    const minutoActual = hora * 60 + minutos;
    const inicioMantenimiento = 1 * 60;
    const finMantenimiento = 10 * 60;
    const estaEnHorarioAutomatico = minutoActual >= inicioMantenimiento && minutoActual < finMantenimiento;
    
    return c.json({ 
      activo: estaEnHorarioAutomatico, 
      automatico: true 
    });
  }
});

// Activar/Desactivar mantenimiento manual (admin)
app.post("/make-server-9f68532a/admin/mantenimiento/toggle", async (c) => {
  try {
    const { activo } = await c.req.json();
    
    const config = {
      activo: activo,
      ultimaActualizacion: new Date().toISOString()
    };
    
    await kv.set('config:mantenimiento', config);
    
    // ⚡ Invalidar caché inmediatamente
    cacheMantenimiento = {
      activo: activo,
      timestamp: Date.now()
    };
    
    console.log(`🔧 Mantenimiento ${activo ? 'ACTIVADO' : 'DESACTIVADO'} manualmente`);
    
    return c.json(config);
  } catch (error) {
    console.error('Error al actualizar mantenimiento:', error);
    return c.json({ error: "Error al actualizar mantenimiento" }, 500);
  }
});

// ==========================================
// DIAGNÓSTICO Y MIGRACIÓN DE DATOS
// ==========================================

// Ejecutar diagnóstico completo de la base de datos
app.get("/make-server-9f68532a/admin/diagnostico-bd", async (c) => {
  try {
    console.log('🔍 Iniciando diagnóstico de base de datos...');
    const resultado = await migrationChecker.ejecutarDiagnosticoCompleto();
    return c.json(resultado);
  } catch (error) {
    console.error('Error en diagnóstico:', error);
    return c.json({ error: "Error al ejecutar diagnóstico" }, 500);
  }
});

// Analizar estructura de datos
app.get("/make-server-9f68532a/admin/analizar-estructura", async (c) => {
  try {
    console.log('🔍 Analizando estructura de datos...');
    const analisis = await migrationChecker.analizarEstructuraDatos();
    return c.json(analisis);
  } catch (error) {
    console.error('Error en análisis:', error);
    return c.json({ error: "Error al analizar estructura" }, 500);
  }
});

// Buscar datos antiguos
app.get("/make-server-9f68532a/admin/buscar-datos-antiguos", async (c) => {
  try {
    console.log('🔍 Buscando datos antiguos...');
    const datosAntiguos = await migrationChecker.buscarDatosAntiguos();
    return c.json(datosAntiguos);
  } catch (error) {
    console.error('Error buscando datos antiguos:', error);
    return c.json({ error: "Error al buscar datos antiguos" }, 500);
  }
});

// ==========================================
// RUTAS DE ESTADÍSTICAS Y RED
// ==========================================

app.get("/make-server-9f68532a/admin/estadisticas", async (c) => {
  try {
    const estadisticas = await crm.getEstadisticasGenerales();
    return c.json(estadisticas);
  } catch (error) {
    console.error('Error al obtener estadísticas:', error);
    return c.json({ error: "Error al obtener estadísticas" }, 500);
  }
});

// Procesar rendimientos diarios
app.post("/make-server-9f68532a/admin/procesar-rendimientos", async (c) => {
  try {
    console.log('🎯 Iniciando procesamiento de rendimientos diarios...');
    
    // ✅ VERIFICAR SI YA SE PROCESÓ HOY
    const hoy = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
    const ultimoProcesamiento = await kv.get('config:ultimo-procesamiento-rendimiento');
    
    if (ultimoProcesamiento && ultimoProcesamiento === hoy) {
      console.log(`⚠️ Los rendimientos ya fueron procesados hoy (${hoy})`);
      return c.json({ 
        error: "Los rendimientos ya fueron procesados hoy",
        fecha: hoy,
        mensaje: "Solo se puede procesar una vez por día"
      }, 400);
    }
    
    // Obtener configuración para verificar si el rendimiento está activo
    const config = await crm.getConfiguracionAdmin();
    
    if (!config || !config.rendimientoActivo) {
      console.log('���️ Rendimiento desactivado en configuración');
      return c.json({ 
        error: "El rendimiento diario está desactivado",
        procesados: 0
      }, 400);
    }
    
    const porcentaje = config.porcentajeRendimiento || 1;
    console.log(`📊 [v2024-12-20-FIX-PATROCINIO] Procesando con porcentaje: ${porcentaje}%`);
    
    // Obtener todos los usuarios
    const todosLosUsuarios = await crm.getAllUsers();
    console.log(`👥 [v2024-12-20-FIX-PATROCINIO] Total usuarios en sistema: ${todosLosUsuarios.length}`);
    
    let usuariosProcesados = 0;
    let usuariosBloqueados = 0;
    let usuariosSinPack = 0;
    
    for (const usuario of todosLosUsuarios) {
      // Obtener packs del usuario
      const packs = await crm.getPacksByUserId(usuario.id);
      const packsActivos = packs.filter((p: any) => p.activo);
      console.log(`  🔍 ${usuario.nombre} (${usuario.email}): ${packsActivos.length} packs activos`);
      
      if (packsActivos.length === 0) {
        usuariosSinPack++;
        continue;
      }
      
      // Calcular monto total invertido (solo el pack activo más reciente)
      // IMPORTANTE: Solo contar el último pack activo, no todos
      const packActivo = [...packsActivos].sort((a: any, b: any) => {
        const fechaA = new Date(a.fechaCompra || 0).getTime();
        const fechaB = new Date(b.fechaCompra || 0).getTime();
        return fechaB - fechaA;
      })[0];
      const montoInvertido = packActivo ? packActivo.monto : 0;
      
      // ====================================
      // VERIFICAR LÍMITE DEL 200% DE RENTABILIDAD
      // ====================================
      
      // Obtener todas las comisiones del usuario (rendimientos + comisiones de red)
      const comisiones = await crm.getComisionesByUserId(usuario.id);
      const fechaInicioPack = new Date(packActivo.fechaCompra).getTime();
      
      // Calcular GANANCIAS TOTALES DEL CICLO ACTUAL (rendimientos + comisiones de red)
      // IMPORTANTE: Solo contar ganancias generadas DESDE la compra del pack
      const totalGanancias = comisiones
        .filter((c: any) => new Date(c.fecha).getTime() >= fechaInicioPack)
        .reduce((sum: number, c: any) => sum + c.monto, 0);
      
      // Límite: 200% de la inversión (inversión + 100% de ganancia)
      const limiteGanancias = montoInvertido * 2;
      
      // Verificar si ya alcanzó el 200% de rentabilidad total
      if (totalGanancias >= limiteGanancias) {
        console.log(`🔒 Usuario ${usuario.nombre} (${usuario.email}) alcanzó el 200% de rentabilidad del ciclo actual ($${totalGanancias.toFixed(2)} / $${limiteGanancias.toFixed(2)}). Rendimiento bloqueado hasta nuevo pack.`);
        usuariosBloqueados++;
        continue;
      }
      
      // ====================================
      // CALCULAR RENDIMIENTO CON LÍMITE AL 200%
      // ====================================
      
      // Calcular rendimiento: monto * porcentaje / 100
      let montoRendimiento = montoInvertido * (porcentaje / 100);
      
      // Verificar que no supere el límite del 200%
      const gananciasDisponibles = limiteGanancias - totalGanancias;
      if (montoRendimiento > gananciasDisponibles) {
        montoRendimiento = gananciasDisponibles;
        console.log(`⚠️ Ajustando rendimiento de ${usuario.nombre} a $${montoRendimiento.toFixed(2)} para no superar el 200%`);
      }
      
      if (montoRendimiento > 0) {
        // ✅ CREAR COMISIÓN DE RENDIMIENTO (única fuente de verdad)
        // NOTA: Ya NO creamos en la tabla de rendimientos para evitar duplicados
        await crm.createComision({
          userId: usuario.id,
          packId: packActivo.id, // ✅ FIX: Asociar rendimiento al pack activo
          tipo: 'rendimiento',
          monto: montoRendimiento,
          fecha: new Date().toISOString(),
          descripcion: `Rendimiento diario ${porcentaje}% sobre $${montoInvertido.toFixed(2)}`
        });
        
        console.log(`✅ Rendimiento procesado para ${usuario.nombre}: $${montoRendimiento.toFixed(2)} (${porcentaje}% de $${montoInvertido}) - Ganancias totales: $${(totalGanancias + montoRendimiento).toFixed(2)} / $${limiteGanancias.toFixed(2)} (200%)`);
        usuariosProcesados++;
      }
    }
    
    console.log(`🎉 [v2024-12-20-FIX-PATROCINIO] Procesamiento completado: ${usuariosProcesados} usuarios procesados, ${usuariosBloqueados} bloqueados por alcanzar 200%, ${usuariosSinPack} sin pack activo`);
    
    // ✅ GUARDAR FECHA DEL PROCESAMIENTO PARA EVITAR DUPLICADOS
    await kv.set('config:ultimo-procesamiento-rendimiento', hoy);
    console.log(`✅ Fecha de procesamiento guardada: ${hoy}`);
    
    return c.json({ 
      success: true,
      procesados: usuariosProcesados,
      bloqueados: usuariosBloqueados,
      sinPack: usuariosSinPack,
      porcentaje: porcentaje
    });
  } catch (error) {
    console.error('Error al procesar rendimientos:', error);
    return c.json({ error: "Error al procesar rendimientos" }, 500);
  }
});

// 🔍 DIAGNÓSTICO: Detectar rendimientos duplicados
app.get("/make-server-9f68532a/admin/diagnostico-rendimientos", async (c) => {
  try {
    console.log('🔍 ========== DIAGNÓSTICO DE RENDIMIENTOS DUPLICADOS (60 DÍAS) ==========');
    
    const startTime = Date.now();
    
    // 1️⃣ Obtener SOLO las comisiones de los últimos 60 días (mucho más rápido)
    console.log('📊 Obteniendo comisiones de los últimos 60 días...');
    const hace60Dias = new Date();
    hace60Dias.setDate(hace60Dias.getDate() - 60);
    
    const todasLasComisiones = await crm.getAllComisiones();
    const comisionesRecientes = todasLasComisiones.filter((c: any) => {
      const fechaComision = new Date(c.fecha);
      return fechaComision >= hace60Dias;
    });
    const comisionesRendimiento = comisionesRecientes.filter((c: any) => c.tipo === 'rendimiento');
    
    console.log(`✅ Total comisiones últimos 60 días: ${comisionesRecientes.length}`);
    console.log(`✅ Comisiones tipo rendimiento (60 días): ${comisionesRendimiento.length}`);
    
    // 2️⃣ Saltar verificación de tabla obsoleta para acelerar el diagnóstico
    console.log('⏩ Saltando verificación de tabla obsoleta (optimización de velocidad)');
    const rendimientosAntiguos: any[] = []; // Vacío para acelerar
    
    // 3️⃣ Agrupar por usuario y fecha para detectar duplicados
    console.log('📊 Analizando duplicados por usuario y fecha...');
    const rendimientosPorUsuarioYFecha = new Map<string, any[]>();
    
    for (const comision of comisionesRendimiento) {
      const fecha = new Date(comision.fecha).toISOString().split('T')[0]; // YYYY-MM-DD
      const key = `${comision.userId}:${fecha}`;
      
      if (!rendimientosPorUsuarioYFecha.has(key)) {
        rendimientosPorUsuarioYFecha.set(key, []);
      }
      
      rendimientosPorUsuarioYFecha.get(key)!.push(comision);
    }
    
    // 4️⃣ Identificar duplicados (más de 1 rendimiento por usuario por día)
    const duplicados: any[] = [];
    const usuarios = await getCachedUsuarios();
    
    for (const [key, rendimientos] of rendimientosPorUsuarioYFecha.entries()) {
      if (rendimientos.length > 1) {
        const [userId, fecha] = key.split(':');
        const usuario = usuarios.find((u: any) => u.id === userId);
        
        const totalDuplicado = rendimientos.reduce((sum, r) => sum + r.monto, 0);
        
        duplicados.push({
          userId,
          fecha,
          usuario: usuario ? {
            nombre: usuario.nombre,
            apellido: usuario.apellido,
            email: usuario.email,
            id_unico: usuario.id_unico
          } : null,
          cantidadDuplicados: rendimientos.length,
          totalMonto: totalDuplicado,
          rendimientos: rendimientos.map(r => ({
            id: r.id.substring(0, 8),
            monto: r.monto,
            fecha: r.fecha,
            descripcion: r.descripcion
          }))
        });
      }
    }
    
    console.log(`❌ Duplicados encontrados: ${duplicados.length}`);
    
    // 5️⃣ Verificar historial de procesamiento (solo último)
    const ultimoProcesamiento = await kv.get('config:ultimo-procesamiento-rendimiento');
    
    console.log(`📅 Último procesamiento registrado: ${ultimoProcesamiento || 'NINGUNO'}`);
    
    // 6️⃣ Análisis por fecha: cuántos rendimientos se pagaron cada día
    const rendimientosPorFecha = new Map<string, { count: number; total: number; usuarios: Set<string> }>();
    
    for (const comision of comisionesRendimiento) {
      const fecha = new Date(comision.fecha).toISOString().split('T')[0];
      
      if (!rendimientosPorFecha.has(fecha)) {
        rendimientosPorFecha.set(fecha, { count: 0, total: 0, usuarios: new Set() });
      }
      
      const stats = rendimientosPorFecha.get(fecha)!;
      stats.count++;
      stats.total += comision.monto;
      stats.usuarios.add(comision.userId);
    }
    
    const historialPorFecha = Array.from(rendimientosPorFecha.entries())
      .map(([fecha, stats]) => ({
        fecha,
        cantidadRendimientos: stats.count,
        usuariosUnicos: stats.usuarios.size,
        montoTotal: stats.total.toFixed(2),
        promedioporUsuario: (stats.total / stats.usuarios.size).toFixed(2),
        posibleDuplicado: stats.count > stats.usuarios.size // Más rendimientos que usuarios = duplicado
      }))
      .sort((a, b) => b.fecha.localeCompare(a.fecha));
    
    // 7️⃣ Saltar análisis de doble pago (optimización)
    const usuariosConDoblePago: any[] = [];
    console.log('⏩ Saltando análisis de doble pago (optimización de velocidad)');
    
    const elapsed = Date.now() - startTime;
    
    console.log(`✅ Diagnóstico completado en ${elapsed}ms`);
    console.log('========== FIN DIAGNÓSTICO ==========\n');
    
    return c.json({
      success: true,
      timestamp: new Date().toISOString(),
      tiempoDiagnostico: `${elapsed}ms`,
      alcanceDias: 60,
      resumen: {
        totalComisionesUltimos60Dias: comisionesRecientes.length,
        totalComisionesRendimiento: comisionesRendimiento.length,
        registrosTablaRendimientosAntigua: 0, // Deshabilitado por performance
        duplicadosDetectados: duplicados.length,
        doblePagoDetectado: usuariosConDoblePago.length,
        ultimoProcesamiento: ultimoProcesamiento || 'Nunca procesado',
        totalLocksActivos: 0 // Deshabilitado por performance
      },
      duplicados: duplicados.length > 0 ? {
        cantidad: duplicados.length,
        detalle: duplicados.slice(0, 20), // Primeros 20
        totalMostrados: Math.min(duplicados.length, 20),
        mensaje: duplicados.length > 20 ? `Mostrando primeros 20 de ${duplicados.length} duplicados` : null
      } : null,
      historialPorFecha: {
        fechas: historialPorFecha.slice(0, 30), // Últimos 30 días
        totalMostrado: Math.min(historialPorFecha.length, 30),
        fechasConDuplicados: historialPorFecha.filter(f => f.posibleDuplicado).length
      },
      doblePago: usuariosConDoblePago.length > 0 ? {
        cantidad: usuariosConDoblePago.length,
        detalle: usuariosConDoblePago,
        mensaje: '⚠️ CRÍTICO: Usuarios recibieron pago tanto en tabla rendimientos como en comisiones'
      } : null,
      sistemasProteccion: {
        lockDiarioPorUsuario: '✅ Activo (rendimiento:lock:userId:fecha)',
        lockProcesamientoGlobal: '✅ Activo (config:ultimo-procesamiento-rendimiento)',
        verificacionPreCreacion: '✅ Activo (createComision verifica duplicados)',
        tablaRendimientos: rendimientosAntiguos.length > 0 ? '⚠️ OBSOLETA - Tiene registros antiguos' : '✅ Sin registros antiguos'
      },
      recomendaciones: (() => {
        const recomendaciones: string[] = [];
        
        if (duplicados.length > 0) {
          recomendaciones.push('🚨 CRÍTICO: Hay rendimientos duplicados. Revisar endpoint /admin/procesar-rendimientos');
        }
        
        if (usuariosConDoblePago.length > 0) {
          recomendaciones.push('🚨 CRÍTICO: Hay doble pago (tabla rendimientos + comisiones). Eliminar tabla rendimientos antigua.');
        }
        
        if (rendimientosAntiguos.length > 0) {
          recomendaciones.push(`⚠️ Hay ${rendimientosAntiguos.length} registros en la tabla rendimientos obsoleta. Considerar limpiar.`);
        }
        
        if (historialPorFecha.some(f => f.posibleDuplicado)) {
          const fechasDuplicadas = historialPorFecha.filter(f => f.posibleDuplicado).map(f => f.fecha);
          recomendaciones.push(`⚠️ Fechas con posibles duplicados: ${fechasDuplicadas.join(', ')}`);
        }
        
        if (recomendaciones.length === 0) {
          recomendaciones.push('✅ No se detectaron problemas críticos');
        }
        
        return recomendaciones;
      })()
    });
    
  } catch (error: any) {
    console.error('❌ Error en diagnóstico de rendimientos:', error);
    return c.json({
      success: false,
      error: error.message,
      stack: error.stack
    }, 500);
  }
});

// ==========================================
// RUTAS DE NOWPAYMENTS
// ==========================================

app.post("/make-server-9f68532a/nowpayments/create-payment", async (c) => {
  try {
    const data = await c.req.json();
    const { userId, packNombre, monto } = data;
    
    console.log(`💳 Creando pago NOWPayments para usuario ${userId}: $${monto}`);
    
    // VALIDACIÓN: Verificar que no se intente comprar un pack menor al actual (si está reinvirtiendo)
    const packs = await crm.getPacksByUserId(userId);
    const packActivo = packs.find(p => p.activo);
    
    if (packActivo) {
      // ✅ VERIFICAR SI EL PACK YA COMPLETÓ EL 200%
      const comisiones = await crm.getComisionesByUserId(userId);
      const totalGanado = comisiones.reduce((sum, c) => sum + c.monto, 0);
      const limiteRetiro = packActivo.monto * 2;
      const packCompletado = totalGanado >= limiteRetiro;
      
      if (!packCompletado) {
        console.log(`❌ Pago rechazado: Usuario ${userId} tiene pack activo sin completar ($${totalGanado.toFixed(2)} de $${limiteRetiro.toFixed(2)})`);
        return c.json({ 
          error: "Ya tienes un pack activo. No puedes realizar nuevos pagos mientras tengas uno vigente.",
          packActual: packActivo.nombre,
          mensaje: "Solo puedes tener un pack activo a la vez.",
          progreso: `${totalGanado.toFixed(2)} de ${limiteRetiro.toFixed(2)} (${((totalGanado / limiteRetiro) * 100).toFixed(1)}%)`
        }, 400);
      }
      
      // Si el pack está completado, verificar que el nuevo pack sea >= al actual
      const montoNuevo = Number(monto);
      if (montoNuevo < packActivo.monto) {
        console.log(`❌ Intento de comprar pack menor: Pack actual $${packActivo.monto}, Pack solicitado $${montoNuevo}`);
        return c.json({ 
          error: "No puedes comprar un pack de menor valor al que tienes actualmente",
          packActual: packActivo.nombre,
          montoActual: packActivo.monto,
          montoSolicitado: montoNuevo,
          mensaje: `Solo puedes comprar el mismo pack ($${packActivo.monto}) o uno de mayor valor`
        }, 400);
      }
    }
    
    const apiKey = Deno.env.get('NOWPAYMENTS_API_KEY');
    
    if (!apiKey) {
      console.error('❌ NOWPAYMENTS_API_KEY no configurada');
      return c.json({ 
        error: "API key de NOWPayments no configurada. Contacta al administrador." 
      }, 500);
    }
    
    // Crear el pago en NOWPayments
    const nowPaymentsResponse = await fetch('https://api.nowpayments.io/v1/payment', {
      method: 'POST',
      headers: {
        'x-api-key': apiKey,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        price_amount: monto,
        price_currency: 'usd',
        pay_currency: 'usdttrc20', // USDT TRC20
        order_id: `${userId}-${Date.now()}`,
        order_description: `${packNombre} - Liberty Finance`,
        ipn_callback_url: `https://${Deno.env.get('SUPABASE_URL')}/functions/v1/make-server-9f68532a/nowpayments/callback`,
      }),
    });
    
    if (!nowPaymentsResponse.ok) {
      const errorText = await nowPaymentsResponse.text();
      console.error('❌ Error de NOWPayments:', errorText);
      return c.json({ 
        error: `Error al crear pago: ${nowPaymentsResponse.statusText}` 
      }, nowPaymentsResponse.status);
    }
    
    const payment = await nowPaymentsResponse.json();
    console.log('✅ Pago creado en NOWPayments:', payment);
    
    // Registrar el depósito con estado 'pendiente'
    const deposito = await crm.createDeposito({
      userId,
      packNombre,
      monto,
      walletDestino: payment.pay_address || '',
      comprobante: '',
      metodoPago: 'nowpayments',
      paymentId: payment.payment_id
    });
    
    console.log(`✅ Depósito registrado: ${deposito.id} con payment_id: ${payment.payment_id}`);
    
    return c.json({ 
      success: true,
      payment,
      deposito
    });
  } catch (error) {
    console.error('❌ Error al crear pago con NOWPayments:', error);
    return c.json({ 
      error: error instanceof Error ? error.message : "Error desconocido al procesar pago" 
    }, 500);
  }
});

// Callback de NOWPayments (webhook)
app.post("/make-server-9f68532a/nowpayments/callback", async (c) => {
  try {
    const data = await c.req.json();
    
    console.log('📥 Callback recibido de NOWPayments:', data);
    
    const { payment_id, payment_status, order_id } = data;
    
    // Buscar el depósito por payment_id
    const depositos = await crm.getAllDepositos();
    const deposito = depositos.find(d => d.paymentId === payment_id);
    
    if (!deposito) {
      console.error(`❌ Depósito no encontrado para payment_id: ${payment_id}`);
      return c.json({ error: "Depósito no encontrado" }, 404);
    }
    
    // Actualizar estado según el estado del pago
    let nuevoEstado = deposito.estado;
    
    if (payment_status === 'finished' || payment_status === 'confirmed') {
      nuevoEstado = 'verificado';
      console.log(`✅ Pago confirmado - Activando pack para usuario ${deposito.userId}`);
      
      // Crear el pack
      const pack = await crm.createPack({
        userId: deposito.userId,
        nombre: deposito.packNombre,
        monto: deposito.monto,
        rendimientoDiario: deposito.monto * 0.01
      });
      
      console.log(`✅ Pack creado: ${pack.id}`);
      
      // Calcular comisiones de red
      await crm.calcularComisionesRed(deposito.userId, deposito.monto);
      console.log(`✅ Comisiones calculadas para usuario ${deposito.userId}`);
      
      // Actualizar rango del usuario
      await crm.actualizarRangoUsuario(deposito.userId);
      console.log(`✅ Rango actualizado para usuario ${deposito.userId}`);
      
      // También actualizar rangos de la línea ascendente
      const usuario = await crm.getUserById(deposito.userId);
      if (usuario && usuario.referidoPor) {
        let currentUserId = usuario.referidoPor;
        for (let i = 0; i < 10 && currentUserId; i++) {
          await crm.actualizarRangoUsuario(currentUserId);
          const user = await crm.getUserById(currentUserId);
          currentUserId = user?.referidoPor;
        }
        console.log(`✅ Rangos actualizados en línea ascendente`);
      }
    } else if (payment_status === 'failed' || payment_status === 'expired') {
      nuevoEstado = 'rechazado';
      console.log(`❌ Pago falló/expiró - payment_id: ${payment_id}`);
    }
    
    // Actualizar el depósito
    await crm.updateDeposito(deposito.id, { estado: nuevoEstado });
    
    console.log(`✅ Depósito actualizado: ${deposito.id} - Estado: ${nuevoEstado}`);
    
    return c.json({ success: true });
  } catch (error) {
    console.error('❌ Error en callback de NOWPayments:', error);
    return c.json({ error: "Error al procesar callback" }, 500);
  }
});

// ==========================================
// RUTAS DE DESARROLLO
// ==========================================

// Test endpoint
app.get("/make-server-9f68532a/dev/test", (c) => {
  return c.json({ status: "ok", message: "Server is running" });
});

// Reset endpoint - responde inmediatamente y procesa en background
app.post("/make-server-9f68532a/dev/reset", async (c) => {
  try {
    console.log('⚠️  INICIANDO RESET COMPLETO (OPTIMIZADO POR LOTES)...');
    
    // 1. Identificar usuarios a eliminar
    const allUsers = await crm.getAllUsers();
    const preservedEmails = [
      'admin@libertyfinance.com',
      'sanphi1997@outlook.es'
    ];
    
    // IDs de usuarios que NO se deben borrar
    const preservedUsers = allUsers.filter(u => preservedEmails.includes(u.email));
    const preservedUserIds = new Set(preservedUsers.map(u => u.id));
    
    // Usuarios que SÍ se van a borrar
    const usersToDelete = allUsers.filter(u => !preservedEmails.includes(u.email));
    
    console.log(`📊 Total usuarios en BD: ${allUsers.length}`);
    console.log(`📊 Usuarios preservados: ${preservedUsers.length} (${preservedEmails.join(', ')})`);
    console.log(`📊 Usuarios a eliminar: ${usersToDelete.length}`);
    
    const keysToDelete: string[] = [];

    // 2. Recolectar claves de USUARIOS a eliminar
    for (const user of usersToDelete) {
      keysToDelete.push(`user:${user.id}`);
      if (user.email) keysToDelete.push(`user:email:${user.email}`);
      if (user.id_unico) keysToDelete.push(`user:idUnico:${user.id_unico}`);
      keysToDelete.push(`puntos:${user.id}`);
    }

    // 3. Recolectar claves de PACKS
    const allPacks = await crm.getAllPacks();
    for (const pack of allPacks) {
      // Si el usuario NO está en la lista de preservados, se borra (incluye huérfanos)
      if (!preservedUserIds.has(pack.userId)) {
        keysToDelete.push(`pack:${pack.id}`);
        keysToDelete.push(`user:${pack.userId}:pack:${pack.id}`);
      }
    }

    // 4. Recolectar claves de COMISIONES
    // Usamos kv.getByPrefix directo porque no existe getAllComisiones exportado
    const allComisiones = await kv.getByPrefix('comision:');
    for (const comision of allComisiones) {
      if (!comision || !comision.id) continue;
      if (!preservedUserIds.has(comision.userId)) {
        keysToDelete.push(`comision:${comision.id}`);
        keysToDelete.push(`user:${comision.userId}:comision:${comision.id}`);
      }
    }

    // 5. Recolectar claves de DEPÓSITOS
    const allDepositos = await crm.getAllDepositos();
    for (const deposito of allDepositos) {
      if (!preservedUserIds.has(deposito.userId)) {
        keysToDelete.push(`deposito:${deposito.id}`);
        keysToDelete.push(`user:${deposito.userId}:deposito:${deposito.id}`);
      }
    }

    // 6. Recolectar claves de COBROS (Retiros)
    const allCobros = await crm.getAllCobros();
    for (const cobro of allCobros) {
      if (!preservedUserIds.has(cobro.userId)) {
        keysToDelete.push(`cobro:${cobro.id}`);
        keysToDelete.push(`user:${cobro.userId}:cobro:${cobro.id}`);
      }
    }

    // 7. Recolectar claves de RENDIMIENTOS
    const allRendimientos = await crm.getAllRendimientos();
    for (const rendimiento of allRendimientos) {
      if (!preservedUserIds.has(rendimiento.userId)) {
        keysToDelete.push(`rendimiento:${rendimiento.id}`);
        keysToDelete.push(`user:${rendimiento.userId}:rendimiento:${rendimiento.id}`);
      }
    }

    // 8. Recolectar GASTOS RULETA (si existen)
    try {
        const gastos = await kv.getByPrefix('gastoRuleta:');
        for(const gasto of gastos) {
             if (gasto && gasto.id && !preservedUserIds.has(gasto.userId)) {
                 keysToDelete.push(`gastoRuleta:${gasto.id}`);
                 keysToDelete.push(`user:${gasto.userId}:gastoRuleta:${gasto.id}`);
             }
        }
    } catch (e) { /* Ignorar si no existen */ }

    // 9. Recolectar PREMIOS RULETA (si existen)
    try {
        const premios = await kv.getByPrefix('ruleta:');
        for(const premio of premios) {
             if (premio && premio.id && !preservedUserIds.has(premio.userId)) {
                 keysToDelete.push(`ruleta:${premio.id}`);
                 keysToDelete.push(`user:${premio.userId}:ruleta:${premio.id}`);
             }
        }
    } catch (e) { /* Ignorar */ }

    console.log(`🗑️ Total de claves a eliminar: ${keysToDelete.length}`);
    
    // 10. EJECUTAR BORRADO POR LOTES (Batch Delete)
    // REDUCIDO EL TAMAÑO DEL LOTE para evitar error "Bad Request" (URL length limit)
    const BATCH_SIZE = 20; 
    let deletedCount = 0;
    
    console.log(`🔥 Iniciando borrado de ${keysToDelete.length} registros en lotes de ${BATCH_SIZE}...`);

    for (let i = 0; i < keysToDelete.length; i += BATCH_SIZE) {
      const batch = keysToDelete.slice(i, i + BATCH_SIZE);
      if (batch.length > 0) {
        try {
          await kv.mdel(batch);
          deletedCount += batch.length;
          if (i % 100 === 0) console.log(`   - Progreso: ${i}/${keysToDelete.length} eliminados`);
        } catch (batchError) {
          console.warn(`⚠️ Error en lote ${i} (tamaño ${batch.length}). Intentando borrar uno por uno...`);
          // Fallback: Borrar uno por uno si falla el lote
          for (const key of batch) {
            try {
              await kv.del(key);
              deletedCount++;
            } catch (singleError) {
              console.error(`❌ Error borrando clave individual ${key}:`, singleError);
            }
          }
        }
      }
    }
    
    console.log(`✅ Limpieza completada. ${deletedCount} registros eliminados.`);
    
    return c.json({
      success: true,
      message: 'Proceso de limpieza completado exitosamente',
      deleted: {
        users: usersToDelete.length,
        totalKeys: deletedCount
      }
    });

  } catch (error) {
    console.error('❌ Error CRÍTICO en reset:', error);
    return c.json({ 
      error: "Error al ejecutar reset",
      details: error instanceof Error ? error.message : 'Unknown' 
    }, 500);
  }
});

// ==========================================
// ENDPOINT DE SINCRONIZACIÓN DE ÍNDICES
// ==========================================

app.post("/make-server-9f68532a/admin/sync-user-indexes", async (c) => {
  try {
    console.log('🔄 Iniciando sincronización de índices de usuarios...');
    
    // ⚡ OPTIMIZACIÓN: Usar caché en lugar de llamar a getAllUsers() desde cero
    const allUsers = await getCachedUsuarios();
    console.log(`📊 Total usuarios encontrados: ${allUsers.length}`);
    
    let indexesCreated = 0;
    let indexesAlreadyExist = 0;
    let errors = 0;
    
    // ⚡ OPTIMIZACIÓN: Preparar todas las keys para verificación en batch
    const emailKeys: string[] = [];
    const idUnicoKeys: string[] = [];
    const usersByEmailKey = new Map<string, any>();
    const usersByIdUnicoKey = new Map<string, any>();
    
    allUsers.forEach(user => {
      if (user.email) {
        const emailKey = `user:email:${user.email.toLowerCase().trim()}`;
        emailKeys.push(emailKey);
        usersByEmailKey.set(emailKey, user);
      }
      if (user.id_unico) {
        const idUnicoKey = `user:idUnico:${user.id_unico}`;
        idUnicoKeys.push(idUnicoKey);
        usersByIdUnicoKey.set(idUnicoKey, user);
      }
    });
    
    console.log(`🔍 Verificando ${emailKeys.length} índices de email y ${idUnicoKeys.length} índices de id_unico en batch...`);
    
    // ⚡ Verificar en batch con mget
    const existingEmailIndexes = await kv.mget(emailKeys);
    const existingIdUnicoIndexes = await kv.mget(idUnicoKeys);
    
    // Preparar índices a crear
    const keysToCreate: string[] = [];
    const valuesToCreate: string[] = [];
    
    emailKeys.forEach((key, idx) => {
      if (!existingEmailIndexes[idx]) {
        const user = usersByEmailKey.get(key);
        keysToCreate.push(key);
        valuesToCreate.push(user.id);
        console.log(`✅ Creará índice email para: ${user.email}`);
      } else {
        indexesAlreadyExist++;
      }
    });
    
    idUnicoKeys.forEach((key, idx) => {
      if (!existingIdUnicoIndexes[idx]) {
        const user = usersByIdUnicoKey.get(key);
        keysToCreate.push(key);
        valuesToCreate.push(user.id);
        console.log(`✅ Creará índice id_unico para: ${user.id_unico}`);
      } else {
        indexesAlreadyExist++;
      }
    });
    
    // ⚡ Crear todos los índices en batch con mset
    if (keysToCreate.length > 0) {
      await kv.mset(keysToCreate, valuesToCreate);
      indexesCreated = keysToCreate.length;
      console.log(`✅ Creados ${indexesCreated} índices en batch`);
    }
    
    console.log(`✅ Sincronización completada:`);
    console.log(`   - Índices creados: ${indexesCreated}`);
    console.log(`   - Índices existentes: ${indexesAlreadyExist}`);
    console.log(`   - Errores: ${errors}`);
    
    return c.json({
      success: true,
      message: 'Sincronización de índices completada',
      stats: {
        totalUsers: allUsers.length,
        indexesCreated,
        indexesAlreadyExist,
        errors
      }
    });
    
  } catch (error) {
    console.error('❌ Error en sincronización de índices:', error);
    return c.json({ 
      error: "Error al sincronizar índices",
      details: error instanceof Error ? error.message : 'Unknown' 
    }, 500);
  }
});

// ==========================================
// ENDPOINT DE DIAGNÓSTICO DE PACKS E INVERSIÓN
// ==========================================

app.get("/make-server-9f68532a/diagnostico-inversion/:userId", async (c) => {
  try {
    const userId = c.req.param('userId');
    console.log(`🔍 Diagnóstico de inversión para usuario: ${userId}`);
    
    // Obtener usuario
    const user = await crm.getUserById(userId);
    if (!user) {
      return c.json({ error: "Usuario no encontrado" }, 404);
    }
    
    // Obtener TODOS los packs del usuario
    const allPacks = await kv.getByPrefix('pack:');
    const userPacks = allPacks.filter((p: any) => p.userId === userId);
    
    // Calcular inversión total (TODOS los packs)
    const inversionTotalTodos = userPacks.reduce((sum, p) => sum + (p.monto || 0), 0);
    
    // Calcular inversión total (solo packs ACTIVOS)
    const inversionTotalActivos = userPacks
      .filter((p: any) => p.activo)
      .reduce((sum, p) => sum + (p.monto || 0), 0);
    
    // Obtener comisiones
    const comisiones = await crm.getComisionesByUserId(userId);
    const gananciaTotal = comisiones.reduce((sum, c) => sum + (c.monto || 0), 0);
    
    // Calcular rentabilidad
    const rentabilidadTodos = inversionTotalTodos > 0 
      ? (gananciaTotal / inversionTotalTodos) * 100 
      : 0;
    const rentabilidadActivos = inversionTotalActivos > 0 
      ? (gananciaTotal / inversionTotalActivos) * 100 
      : 0;
    
    console.log(`📊 DIAGNÓSTICO DE INVERSIÓN:`);
    console.log(`   Usuario: ${user.nombre} ${user.apellido} (${user.id_unico})`);
    console.log(`   Total packs: ${userPacks.length}`);
    console.log(`   Inversión (todos): $${inversionTotalTodos}`);
    console.log(`   Inversión (activos): $${inversionTotalActivos}`);
    console.log(`   Ganancia total: $${gananciaTotal.toFixed(2)}`);
    console.log(`   Rentabilidad (todos): ${rentabilidadTodos.toFixed(2)}%`);
    console.log(`   Rentabilidad (activos): ${rentabilidadActivos.toFixed(2)}%`);
    
    return c.json({
      success: true,
      usuario: {
        id: user.id,
        id_unico: user.id_unico,
        nombre: `${user.nombre} ${user.apellido}`,
        email: user.email
      },
      packs: {
        total: userPacks.length,
        lista: userPacks.map((p: any) => ({
          id: p.id,
          nombre: p.nombre,
          monto: p.monto,
          activo: p.activo,
          fechaCompra: p.fechaCompra,
          fechaCreacion: p.createdAt
        })),
        inversionTotalTodos: inversionTotalTodos,
        inversionTotalActivos: inversionTotalActivos
      },
      comisiones: {
        total: comisiones.length,
        gananciaTotal: gananciaTotal,
        porTipo: {
          red: comisiones.filter(c => c.tipo === 'red').reduce((sum, c) => sum + c.monto, 0),
          rendimiento: comisiones.filter(c => c.tipo === 'rendimiento').reduce((sum, c) => sum + c.monto, 0),
          patrocinio: comisiones.filter(c => c.tipo === 'patrocinio').reduce((sum, c) => sum + c.monto, 0),
          rangos: comisiones.filter(c => c.tipo === 'rangos').reduce((sum, c) => sum + c.monto, 0)
        }
      },
      rentabilidad: {
        sobreTodos: {
          porcentaje: rentabilidadTodos,
          limiteRetiro: inversionTotalTodos * 2,
          alcanzado200: rentabilidadTodos >= 200
        },
        sobreActivos: {
          porcentaje: rentabilidadActivos,
          limiteRetiro: inversionTotalActivos * 2,
          alcanzado200: rentabilidadActivos >= 200
        }
      },
      diagnostico: {
        problema: inversionTotalTodos !== inversionTotalActivos 
          ? `⚠️ Hay diferencia entre inversión total ($${inversionTotalTodos}) y activos ($${inversionTotalActivos})`
          : `✅ Inversión total coincide con activos`,
        packsInactivos: userPacks.filter(p => !p.activo).length,
        detallePacksInactivos: userPacks.filter(p => !p.activo).map(p => ({
          nombre: p.nombre,
          monto: p.monto,
          fecha: p.fechaCompra
        }))
      }
    });
    
  } catch (error) {
    console.error('❌ Error en diagnóstico de inversión:', error);
    return c.json({ 
      error: "Error al diagnosticar inversión",
      details: error instanceof Error ? error.message : 'Unknown' 
    }, 500);
  }
});

// ==========================================
// ENDPOINT PARA DETECTAR USUARIOS CON MÚLTIPLES PACKS ACTIVOS
// ==========================================

app.get("/make-server-9f68532a/admin/detectar-packs-duplicados", async (c) => {
  const requestStartTime = Date.now();
  
  try {
    console.log('🔍 [OPTIMIZADO] Detectando usuarios con múltiples packs activos...');
    
    // ⚡ OPTIMIZACIÓN: Cargar datos UNA SOLA VEZ desde caché
    console.log(`⏱️ T+${Date.now() - requestStartTime}ms - Cargando datos desde caché...`);
    const [usuarios, todosPacks] = await Promise.all([
      getCachedUsuarios(),
      getCachedPacks()
    ]);
    console.log(`⏱️ T+${Date.now() - requestStartTime}ms - ${usuarios.length} usuarios y ${todosPacks.length} packs cargados`);
    
    // ⚡ OPTIMIZACIÓN: Pre-indexar packs por userId para búsqueda O(1)
    const packsPorUsuario = new Map();
    todosPacks.forEach(pack => {
      if (!packsPorUsuario.has(pack.userId)) {
        packsPorUsuario.set(pack.userId, []);
      }
      packsPorUsuario.get(pack.userId).push(pack);
    });
    console.log(`⏱️ T+${Date.now() - requestStartTime}ms - Índice de packs creado`);
    
    const usuariosConProblemas = [];
    
    // Revisar cada usuario (ahora sin consultas a BD, solo operaciones en memoria)
    for (const usuario of usuarios) {
      try {
        const packs = packsPorUsuario.get(usuario.id) || [];
        const packsActivos = packs.filter((p: any) => p.activo);
        
        if (packsActivos.length > 1) {
          console.log(`⚠️ Usuario ${usuario.nombre} tiene ${packsActivos.length} packs activos`);
          
          // Ordenar por fecha (más antiguo primero)
          const packsOrdenados = packsActivos.sort((a: any, b: any) => 
            new Date(a.fechaCompra || a.fechaCreacion).getTime() - 
            new Date(b.fechaCompra || b.fechaCreacion).getTime()
          );
          
          usuariosConProblemas.push({
            usuario: {
              id: usuario.id,
              id_unico: usuario.id_unico,
              nombre: usuario.nombre,
              apellido: usuario.apellido,
              email: usuario.email
            },
            packsActivos: packsActivos.length,
            packs: packsOrdenados.map((p: any) => ({
              id: p.id,
              nombre: p.nombre,
              monto: p.monto,
              fechaCompra: p.fechaCompra || p.fechaCreacion,
              activo: p.activo,
              esElMasAntiguo: p.id === packsOrdenados[0].id,
              deberiaMantenerse: p.id === packsOrdenados[0].id
            })),
            inversionTotal: packsActivos.reduce((sum: number, p: any) => sum + p.monto, 0),
            inversionCorrecta: packsOrdenados[0].monto,
            exceso: packsActivos.reduce((sum: number, p: any) => sum + p.monto, 0) - packsOrdenados[0].monto
          });
        }
      } catch (error) {
        console.error(`Error al revisar packs del usuario ${usuario.id}:`, error);
      }
    }
    
    const totalTime = Date.now() - requestStartTime;
    console.log(`✅ [OPTIMIZADO] Detectados ${usuariosConProblemas.length} usuarios con packs duplicados en ${totalTime}ms`);
    
    return c.json({
      success: true,
      total: usuariosConProblemas.length,
      usuarios: usuariosConProblemas,
      resumen: {
        totalUsuarios: usuarios.length,
        usuariosConProblemas: usuariosConProblemas.length,
        porcentajeAfectado: ((usuariosConProblemas.length / usuarios.length) * 100).toFixed(2)
      },
      tiempoMs: totalTime
    });
    
  } catch (error) {
    const elapsed = Date.now() - requestStartTime;
    console.error(`❌ Error al detectar packs duplicados (${elapsed}ms):`, error);
    return c.json({ 
      error: "Error al detectar packs duplicados",
      details: error instanceof Error ? error.message : 'Unknown' 
    }, 500);
  }
});

// ==========================================
// ENDPOINT PARA DESACTIVAR UN PACK ESPECÍFICO
// ==========================================

app.post("/make-server-9f68532a/admin/desactivar-pack/:packId", async (c) => {
  try {
    const packId = c.req.param('packId');
    console.log(`🔒 Desactivando pack: ${packId}`);
    
    // Obtener el pack
    const packKey = `pack:${packId}`;
    const pack = await kv.get(packKey);
    
    if (!pack) {
      return c.json({ error: "Pack no encontrado" }, 404);
    }
    
    console.log(`📦 Pack encontrado: ${pack.nombre} - $${pack.monto} (Usuario: ${pack.userId})`);
    
    // Desactivar el pack
    const packActualizado = {
      ...pack,
      activo: false,
      status: 'inactivo',
      fechaDesactivacion: new Date().toISOString(),
      motivoDesactivacion: 'Eliminación de duplicado por admin'
    };
    
    await kv.set(packKey, packActualizado);
    
    // Invalidar caché
    cachePacks = null;
    cacheTimestamp = 0;
    
    console.log(`✅ Pack ${packId} desactivado correctamente`);
    
    return c.json({
      success: true,
      message: "Pack desactivado correctamente",
      pack: packActualizado
    });
    
  } catch (error) {
    console.error('❌ Error al desactivar pack:', error);
    return c.json({ 
      error: "Error al desactivar pack",
      details: error instanceof Error ? error.message : 'Unknown' 
    }, 500);
  }
});

// ==========================================
// RUTAS DE RETIROS
// ==========================================

app.post("/make-server-9f68532a/retiros", async (c) => {
  try {
    const data = await c.req.json();
    
    console.log('💸 Creando solicitud de retiro:', data);
    
    // Validar que el usuario no exceda el límite de retiro del 200% de inversión
    const userId = data.userId;
    const montoSolicitado = Number(data.monto);
    
    // Obtener packs del usuario
    const packs = await crm.getPacksByUserId(userId);
    const totalInvertido = packs
      .filter((p: any) => p.activo)
      .reduce((sum: number, p: any) => sum + p.monto, 0);
    
    // Obtener comisiones del usuario (ganancias totales)
    const comisiones = await crm.getComisionesByUserId(userId);
    const gananciaTotal = comisiones.reduce((sum: number, c: any) => sum + c.monto, 0);
    
    // Obtener retiros aprobados previos
    const retirosAnteriores = await crm.getRetirosByUserId(userId);
    const totalRetirado = retirosAnteriores
      .filter((r: any) => r.estado === 'aprobado')
      .reduce((sum: number, r: any) => sum + r.monto, 0);
    
    // Calcular límite: 200% de la inversión (inversión + 100% de ganancia)
    const limiteRetiro = totalInvertido * 2; // 200% de la inversión
    const disponibleParaRetirar = Math.max(0, limiteRetiro - totalRetirado);
    
    console.log(`📊 Validación retiro: Inversión: $${totalInvertido}, Límite 200%: $${limiteRetiro}, Ya retirado: $${totalRetirado}, Disponible: $${disponibleParaRetirar}`);
    
    if (montoSolicitado > disponibleParaRetirar) {
      console.log(`❌ Retiro rechazado: Monto solicitado ($${montoSolicitado}) excede disponible ($${disponibleParaRetirar})`);
      return c.json({ 
        error: `No puedes retirar más de $${disponibleParaRetirar.toFixed(2)}. Has alcanzado el límite del 200% de tu inversión.` 
      }, 400);
    }
    
    const retiro = await crm.createRetiro({
      userId: data.userId,
      monto: montoSolicitado,
      tipo: data.tipo,
      walletDestino: data.walletDestino
    });
    
    console.log(`✅ Retiro creado: ${retiro.id} - $${retiro.monto} para usuario ${data.userId}`);
    return c.json(retiro);
  } catch (error) {
    console.error('Error al crear retiro:', error);
    return c.json({ error: "Error al crear retiro" }, 500);
  }
});

app.get("/make-server-9f68532a/retiros", async (c) => {
  try {
    const retiros = await crm.getAllRetiros();
    return c.json(retiros);
  } catch (error) {
    console.error('Error al obtener retiros:', error);
    return c.json({ error: "Error al obtener retiros" }, 500);
  }
});

app.get("/make-server-9f68532a/users/:userId/retiros", async (c) => {
  try {
    const userId = c.req.param('userId');
    const retiros = await crm.getRetirosByUser(userId);
    return c.json(retiros);
  } catch (error) {
    console.error('Error al obtener retiros del usuario:', error);
    return c.json({ error: "Error al obtener retiros del usuario" }, 500);
  }
});

app.put("/make-server-9f68532a/retiros/:retiroId", async (c) => {
  try {
    const retiroId = c.req.param('retiroId');
    const updates = await c.req.json();
    
    console.log(`📝 Actualizando retiro ${retiroId}:`, updates);
    
    // Obtener el retiro ANTES de actualizar para verificar el estado anterior
    const retiroAnterior = await crm.getRetiroById(retiroId);
    if (!retiroAnterior) {
      return c.json({ error: "Retiro no encontrado" }, 404);
    }
    
    const retiro = await crm.updateRetiro(retiroId, updates);
    
    if (!retiro) {
      return c.json({ error: "Retiro no encontrado" }, 404);
    }
    
    // DESCONTAR SALDO SI EL RETIRO ES APROBADO
    if (updates.estado === 'aprobado' && retiroAnterior.estado !== 'aprobado') {
      console.log(`💰 Retiro aprobado. Descontando $${retiro.monto} del saldo del usuario ${retiro.userId}...`);
      
      const comisiones = await crm.getComisionesByUserId(retiro.userId);
      const totalGananciasAntes = comisiones.reduce((sum: number, c: any) => sum + c.monto, 0);
      
      console.log(`📊 Saldo antes del retiro: $${totalGananciasAntes.toFixed(2)}`);
      
      // Crear una comisión NEGATIVA para descontar el monto retirado
      await crm.createComision({
        userId: retiro.userId,
        tipo: 'rendimiento',
        monto: -retiro.monto,
        fecha: new Date().toISOString(),
        descripcion: `Descuento por retiro aprobado - ID: ${retiro.id}`
      });
      
      const totalGananciasDespues = totalGananciasAntes - retiro.monto;
      
      console.log(`✅ Saldo descontado. Nuevo saldo: $${totalGananciasDespues.toFixed(2)} (Descuento: $${retiro.monto})`);
    }
    
    console.log(`✅ Retiro actualizado: ${retiro.id} - Estado: ${retiro.estado}`);
    return c.json(retiro);
  } catch (error) {
    console.error('Error al actualizar retiro:', error);
    return c.json({ error: "Error al actualizar retiro" }, 500);
  }
});

// ==========================================
// ENDPOINT OPTIMIZADO PARA DASHBOARD
// ==========================================

// Obtener todas las estadísticas del dashboard en una sola llamada
app.get("/make-server-9f68532a/admin/dashboard-stats", async (c) => {
  try {
    console.log('📊 Cargando estadísticas del dashboard...');
    
    // ⚡ OPTIMIZACIÓN: Obtener datos en PARALELO con timeout de seguridad
    let usuarios, depositos, cobros;
    
    try {
      console.log('🔍 Cargando datos en paralelo...');
      const timeout = 90000; // ⚡ AUMENTADO: 90 segundos de timeout (era 25s)
      
      [usuarios, depositos, cobros] = await Promise.race([
        Promise.all([
          getCachedUsuarios(),
          crm.getAllDepositos(),
          crm.getAllCobros()
        ]),
        new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Timeout cargando datos básicos')), timeout)
        )
      ]) as any;
      
      console.log(`✅ Datos cargados: ${usuarios.length} usuarios, ${depositos.length} depósitos, ${cobros.length} cobros`);
    } catch (error) {
      console.error('❌ Error cargando datos básicos:', error);
      
      // Fallback: devolver datos vacíos
      return c.json({ 
        totalUsers: 0,
        activeUsers: 0,
        inactiveUsers: 0,
        totalInvested: 0,
        pendingWithdrawals: 0,
        totalWithdrawn: 0,
        totalComisiones: 0,
        depositosPendientes: 0,
        recentUsers: [],
        error: 'Timeout al cargar datos - Por favor intenta nuevamente'
      });
    }
    
    // Obtener packs y comisiones con timeout
    let allPacks, allComisiones;
    
    try {
      console.log('🔍 Obteniendo packs y comisiones en paralelo...');
      const timeout = 60000; // ⚡ AUMENTADO: 60 segundos (era 20s)
      
      [allPacks, allComisiones] = await Promise.race([
        Promise.all([
          getCachedPacks(),
          getCachedComisiones()
        ]),
        new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Timeout cargando packs/comisiones')), timeout)
        )
      ]) as any;
      
      console.log(`✅ ${allPacks.length} packs, ${allComisiones.length} comisiones`);
    } catch (error) {
      console.error('❌ Error obteniendo packs/comisiones:', error);
      allPacks = [];
      allComisiones = [];
    }
    
    // Calcular estadísticas básicas
    console.log('🔍 Paso 3: Calculando estadísticas...');
    const usuariosValidos = usuarios.filter(u => u.nombre && u.email);
    const usuariosActivos = usuariosValidos.filter(u => u.activo).length;
    const usuariosInactivos = usuariosValidos.length - usuariosActivos;
    const totalInvertido = allPacks.reduce((sum, p) => sum + p.monto, 0);
    const depositosPendientes = depositos.filter(d => d.estado === 'pendiente').length;
    const retirosPendientes = cobros.filter(r => r.estado === 'pendiente').length;
    const totalRetirado = cobros.filter(r => r.estado === 'aprobado').reduce((sum, r) => sum + r.monto, 0);
    const totalComisiones = allComisiones.reduce((sum, c) => sum + c.monto, 0);
    
    // Calcular usuarios recientes (últimos 5)
    const usuariosRecientes = usuariosValidos
      .sort((a, b) => {
        const fechaA = new Date(a.fechaRegistro || a.createdAt || 0).getTime();
        const fechaB = new Date(b.fechaRegistro || b.createdAt || 0).getTime();
        return fechaB - fechaA;
      })
      .slice(0, 5)
      .map(u => {
        const userPacks = allPacks.filter(p => p.userId === u.id);
        const totalInversion = userPacks.reduce((sum, p) => sum + p.monto, 0);
        const packActivo = userPacks.find(p => p.activo);
        
        const fecha = new Date(u.fechaRegistro || u.createdAt || Date.now());
        const fechaFormateada = !isNaN(fecha.getTime())
          ? `${fecha.getDate().toString().padStart(2, '0')}/${(fecha.getMonth() + 1).toString().padStart(2, '0')}/${fecha.getFullYear()}`
          : 'Sin fecha';
        
        return {
          id: u.id_unico || 'Sin ID',
          name: `${u.nombre || ''} ${u.apellido || ''}`.trim() || 'Sin nombre',
          pack: packActivo ? packActivo.nombre : 'Sin pack',
          amount: totalInversion,
          date: fechaFormateada,
          status: u.activo ? 'active' : 'pending'
        };
      });
    
    const stats = {
      totalUsers: usuariosValidos.length,
      activeUsers: usuariosActivos,
      inactiveUsers: usuariosInactivos,
      totalInvested: totalInvertido,
      pendingWithdrawals: retirosPendientes,
      totalWithdrawn: totalRetirado,
      totalComisiones: totalComisiones,
      depositosPendientes: depositosPendientes,
      recentUsers: usuariosRecientes
    };
    
    console.log(`✅ Estadísticas calculadas: ${usuariosValidos.length} usuarios, $${totalInvertido} invertido`);
    return c.json(stats);
  } catch (error) {
    console.error('❌ Error al obtener estadísticas del dashboard:', error);
    console.error('❌ Stack trace:', error.stack);
    return c.json({ 
      error: "Error al obtener estadísticas",
      details: error.message,
      timestamp: new Date().toISOString()
    }, 500);
  }
});

// Obtener lista completa de usuarios con sus datos (optimizado para AdminUsers)
app.get("/make-server-9f68532a/admin/users-complete", async (c) => {
  try {
    console.log('👥 Cargando usuarios completos...');
    
    const usuarios = await getCachedUsuarios();
    console.log(`📊 Total usuarios en DB: ${usuarios.length}`);
    
    // DEBUG: Buscar a Juan Solano ANTES del filtro
    const juanSolanoRaw = usuarios.find(u => 
      u.id_unico === 'LF1766035063633662'
    );
    console.log('🔍����🔍 Juan Solano COMPLETO:', JSON.stringify(juanSolanoRaw, null, 2));
    
    // FILTRAR: Solo mostrar usuarios con datos completos (nombre Y email)
    // TEMPORALMENTE DESHABILITADO PARA MOSTRAR TODOS LOS USUARIOS
    const usuariosValidos = usuarios;
    
    console.log(`✅ Usuarios válidos: ${usuariosValidos.length} de ${usuarios.length} (FILTRO DESHABILITADO)`);
    
    // DEBUG: Buscar específicamente a Juan Solano DESPUÉS del filtro
    const juanSolano = usuariosValidos.find(u => 
      u.id_unico === 'LF1766035063633662'
    );
    console.log('🔍 Juan Solano DESPU��S del filtro?', juanSolano ? 'SÍ' : 'NO (filtrado por datos incompletos)');
    
    // OPTIMIZACIÓN: Cargar todos los datos una sola vez
    const allPacks = await getCachedPacks();
    const allComisiones = await getCachedComisiones();
    
    console.log(`📦 Total packs cargados: ${allPacks.length}`);
    console.log(`💰 Total comisiones cargadas: ${allComisiones.length}`);
    
    // Mapear packs por usuario
    const packsByUser = new Map<string, any[]>();
    allPacks.forEach(pack => {
      if (!packsByUser.has(pack.userId)) {
        packsByUser.set(pack.userId, []);
      }
      packsByUser.get(pack.userId)!.push(pack);
    });
    
    // Mapear comisiones por usuario
    const comisionesByUser = new Map<string, any[]>();
    allComisiones.forEach(comision => {
      if (!comisionesByUser.has(comision.userId)) {
        comisionesByUser.set(comision.userId, []);
      }
      comisionesByUser.get(comision.userId)!.push(comision);
    });
    
    // CALCULAR estadísticas para cada usuario
    const usuariosCompletos = usuariosValidos.map(u => {
      const fecha = new Date(u.fechaRegistro || Date.now());
      const fechaFormateada = !isNaN(fecha.getTime())
        ? `${fecha.getDate().toString().padStart(2, '0')}/${(fecha.getMonth() + 1).toString().padStart(2, '0')}/${fecha.getFullYear()}`
        : 'Sin fecha';
      
      // Contar referidos directos CON PACK ACTIVO
      const referidosDirectos = usuarios.filter(usr => usr.referidoPor === u.id);
      const referidosConPack = referidosDirectos.filter(directo => {
        const packsDelDirecto = packsByUser.get(directo.id) || [];
        return packsDelDirecto.some(p => p.activo);
      });
      
      // Calcular inversión total
      const userPacks = packsByUser.get(u.id) || [];
      const totalInversion = userPacks.reduce((sum, p) => sum + p.monto, 0);
      
      // Calcular comisiones totales
      const comisiones = comisionesByUser.get(u.id) || [];
      const totalComisiones = comisiones.reduce((sum, c) => sum + c.monto, 0);
      
      // Obtener pack más grande activo
      const packActivo = userPacks
        .filter(p => p.activo)
        .sort((a, b) => b.monto - a.monto)[0];
      
      return {
        id: u.id,
        id_unico: u.id_unico || 'Sin ID',
        nombre: u.nombre,
        apellido: u.apellido || '',
        email: u.email,
        telefono: u.telefono || 'N/A',
        wallet: u.wallet || 'No configurada',
        password: u.password || '',
        rango: u.rango || 'Sin Rango',
        activo: u.activo || false,
        fechaRegistro: fechaFormateada,
        pack: packActivo ? packActivo.nombre : 'N/A',
        inversion: totalInversion,
        comisiones: totalComisiones,
        referidos: referidosConPack.length
      };
    });
    
    console.log(`✅ ${usuariosCompletos.length} usuarios válidos listos con estadísticas`);
    
    // DEBUG: Mostrar ejemplo de usuario
    const ejemploUsuario = usuariosCompletos.find(u => u.nombre === 'Waldo' || u.referidos > 0);
    if (ejemploUsuario) {
      console.log(`📊 EJEMPLO - ${ejemploUsuario.nombre}:`, {
        referidos: ejemploUsuario.referidos,
        inversion: ejemploUsuario.inversion,
        comisiones: ejemploUsuario.comisiones
      });
    }
    
    return c.json(usuariosCompletos);
  } catch (error) {
    console.error('Error al obtener usuarios completos:', error);
    return c.json({ error: "Error al obtener usuarios" }, 500);
  }
});

// DIAGNÓSTICO: Buscar usuarios "Sin ID" y corruptos
app.get("/make-server-9f68532a/admin/diagnostico-usuarios", async (c) => {
  try {
    console.log('🔬 DIAGNÓSTICO: Analizando usuarios corruptos...');
    
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL'),
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')
    );
    
    // Obtener TODOS los registros con prefijo "user:"
    const { data: rawData, error } = await supabase
      .from('kv_store_9f68532a')
      .select('key, value')
      .like('key', 'user:%');
    
    if (error) throw new Error(error.message);
    
    console.log(`📊 Total registros con prefijo "user:": ${rawData?.length || 0}`);
    
    // Separar por tipo de registro
    const usuariosCompletos = [];
    const mapeoEmails = [];
    const mapeoIdUnicos = [];
    const corruptos = [];
    
    for (const row of rawData || []) {
      const key = row.key as string;
      const value = row.value;
      
      if (key.includes('email:')) {
        mapeoEmails.push({ key, value });
      } else if (key.includes('idUnico:')) {
        mapeoIdUnicos.push({ key, value });
      } else if (key.startsWith('user:') && key.split(':').length === 2) {
        // Registro principal de usuario (user:UUID)
        if (!value || typeof value !== 'object') {
          corruptos.push({ key, value, razon: 'value no es objeto' });
        } else if (!value.nombre && !value.email) {
          corruptos.push({ key, value, razon: 'sin nombre ni email' });
        } else if (!value.id_unico) {
          corruptos.push({ key, value, razon: 'sin id_unico' });
        } else {
          usuariosCompletos.push({ key, value });
        }
      }
    }
    
    // Buscar específicamente a Juan Solano
    const juanSolano = rawData?.find((row: any) => 
      row.key?.includes('LF1766035063633662') ||
      row.value?.id_unico === 'LF1766035063633662' ||
      row.value?.nombre?.toLowerCase().includes('juan') ||
      row.value?.email?.toLowerCase().includes('juan')
    );
    
    const resultado = {
      totalRegistros: rawData?.length || 0,
      usuariosCompletos: usuariosCompletos.length,
      mapeoEmails: mapeoEmails.length,
      mapeoIdUnicos: mapeoIdUnicos.length,
      corruptos: corruptos.length,
      juanSolano: juanSolano ? {
        encontrado: true,
        key: juanSolano.key,
        value: juanSolano.value
      } : {
        encontrado: false
      },
      listaCorruptos: corruptos.map(c => ({
        key: c.key,
        razon: c.razon,
        id_unico: c.value?.id_unico || 'N/A',
        nombre: c.value?.nombre || 'N/A',
        email: c.value?.email || 'N/A'
      })),
      primerosUsuariosValidos: usuariosCompletos.slice(0, 3).map(u => ({
        key: u.key,
        id_unico: u.value.id_unico,
        nombre: u.value.nombre,
        email: u.value.email
      }))
    };
    
    console.log('🔬 DIAGNÓSTICO COMPLETO:', JSON.stringify(resultado, null, 2));
    
    return c.json(resultado);
  } catch (error: any) {
    console.error('❌ Error en diagnóstico:', error);
    return c.json({ error: error.message }, 500);
  }
});

// Obtener estadísticas de red (TEMPORALMENTE DESHABILITADO - CPU exceeded)
app.get("/make-server-9f68532a/admin/network-stats", async (c) => {
  try {
    console.log('⚠️ Endpoint /admin/network-stats temporalmente deshabilitado (CPU exceeded)');
    
    // Retornar datos vacíos mientras se optimiza
    return c.json({
      totalRed: 0,
      nivel1: 0,
      nivel2: 0,
      nivel3Plus: 0,
      nivelData: [],
      mesData: [],
      promedioReferidos: 0
    });
    
    /* CÓDIGO ORIGINAL DESHABILITADO
    const usuarios = await crm.getAllUsers();
    const usuariosValidos = usuarios.filter(u => u.nombre && u.email);
    
    // Obtener todos los referidos en paralelo
    const todosLosReferidos = await Promise.all(
      usuariosValidos.map(u => crm.getReferidosDirectos(u.id).catch(() => []))
    );
    
    // Construir estructura de red por niveles
    const networkData: { [nivel: number]: number } = {};
    const monthlyData: { [mes: string]: number } = {};
    
    // Función recursiva para contar niveles
    const contarNiveles = async (userId: string, nivel: number, visitados: Set<string>) => {
      if (visitados.has(userId) || nivel > 10) return;
      visitados.add(userId);
      
      if (!networkData[nivel]) networkData[nivel] = 0;
      networkData[nivel]++;
      
      const referidos = await crm.getReferidosDirectos(userId).catch(() => []);
      for (const ref of referidos) {
        await contarNiveles(ref.id, nivel + 1, visitados);
      }
    };
    
    // Contar por niveles para cada usuario principal
    const visitados = new Set<string>();
    for (const usuario of usuariosValidos) {
      if (!usuario.referidoPor) { // Solo usuarios sin referidor (raíz)
        await contarNiveles(usuario.id, 1, visitados);
      }
    }
    
    // Agrupar por mes
    usuariosValidos.forEach(u => {
      const fecha = new Date(u.fechaRegistro || u.createdAt || Date.now());
      if (!isNaN(fecha.getTime())) {
        const mes = `${fecha.getMonth() + 1}/${fecha.getFullYear()}`;
        monthlyData[mes] = (monthlyData[mes] || 0) + 1;
      }
    });
    
    // Formatear datos para gráficos
    const nivelData = Object.entries(networkData).map(([nivel, count]) => ({
      nivel: `Nivel ${nivel}`,
      usuarios: count
    }));
    
    const mesData = Object.entries(monthlyData)
      .sort((a, b) => {
        const [mesA, yearA] = a[0].split('/').map(Number);
        const [mesB, yearB] = b[0].split('/').map(Number);
        return yearA === yearB ? mesA - mesB : yearA - yearB;
      })
      .map(([mes, count]) => ({
        mes,
        nuevos: count
      }));
    
    const stats = {
      totalRed: usuariosValidos.length,
      nivel1: networkData[1] || 0,
      nivel2: networkData[2] || 0,
      nivel3Plus: Object.entries(networkData)
        .filter(([nivel]) => parseInt(nivel) >= 3)
        .reduce((sum, [, count]) => sum + count, 0),
      nivelData,
      mesData,
      promedioReferidos: usuariosValidos.length > 0 
        ? (todosLosReferidos.reduce((sum, refs) => sum + refs.length, 0) / usuariosValidos.length).toFixed(1)
        : 0
    };
    
    console.log(`✅ Estadísticas de red calculadas: ${stats.totalRed} usuarios en red`);
    return c.json(stats);
    */
  } catch (error) {
    console.error('Error al obtener estadísticas de red:', error);
    return c.json({ error: "Error al obtener estadísticas de red" }, 500);
  }
});

// 🔬 DIAGNÓSTICO: Analizar rendimientos por pack de un usuario específico
app.get("/make-server-9f68532a/admin/diagnostico-packs/:userId", async (c) => {
  try {
    const userId = c.req.param('userId');
    console.log(`🔬 [DIAGNÓSTICO] Analizando packs y rendimientos para: ${userId}`);
    
    // Obtener datos del usuario
    const user = await crm.getUserById(userId);
    if (!user) {
      return c.json({ error: "Usuario no encontrado" }, 404);
    }
    
    // Obtener todos los packs del usuario - LEER DIRECTAMENTE DESDE KV (sin caché)
    console.log(`📦 [DIAGNÓSTICO] Leyendo packs DIRECTAMENTE desde KV para evitar caché obsoleto...`);
    const allPacksFromKV = await kv.getByPrefix('pack:');
    const userPacks = allPacksFromKV.filter((p: any) => p && p.userId === userId);
    console.log(`📦 [DIAGNÓSTICO] Packs encontrados: ${userPacks.length}`);
    userPacks.forEach((p: any) => {
      console.log(`   - ${p.nombre} (${p.id}) - Activo: ${p.activo} - Status: ${p.status}`);
    });
    
    // Obtener todas las comisiones del usuario
    const userComisiones = await crm.getComisionesByUserId(userId);
    
    // Calcular rendimientos por pack
    const rendimientosPorPack = new Map<string, number>();
    const comisionesPorPack = new Map<string, any[]>();
    
    userComisiones.forEach((c: any) => {
      if (c.packId) {
        // Sumar rendimientos
        const actual = rendimientosPorPack.get(c.packId) || 0;
        rendimientosPorPack.set(c.packId, actual + (c.monto || 0));
        
        // Agrupar comisiones
        const comisiones = comisionesPorPack.get(c.packId) || [];
        comisiones.push(c);
        comisionesPorPack.set(c.packId, comisiones);
      }
    });
    
    // Analizar cada pack
    const analisisPacks = userPacks
      .sort((a, b) => new Date(a.fechaCompra).getTime() - new Date(b.fechaCompra).getTime())
      .map((pack: any) => {
        const rendimientoTotal = rendimientosPorPack.get(pack.id) || 0;
        const limite200 = pack.monto * 2;
        const progreso = (rendimientoTotal / limite200) * 100;
        const comisiones = comisionesPorPack.get(pack.id) || [];
        
        return {
          id: pack.id,
          nombre: pack.nombre,
          monto: pack.monto,
          fechaCompra: pack.fechaCompra,
          activo: pack.activo,
          status: pack.status,
          rendimientoTotal: rendimientoTotal.toFixed(2),
          limite200: limite200.toFixed(2),
          progreso: progreso.toFixed(2) + '%',
          completado: rendimientoTotal >= limite200,
          falta: Math.max(0, limite200 - rendimientoTotal).toFixed(2),
          totalComisiones: comisiones.length,
          porTipo: {
            rendimiento: comisiones.filter(c => c.tipo === 'rendimiento').reduce((sum, c) => sum + c.monto, 0).toFixed(2),
            red: comisiones.filter(c => c.tipo === 'red').reduce((sum, c) => sum + c.monto, 0).toFixed(2),
            patrocinio: comisiones.filter(c => c.tipo === 'patrocinio').reduce((sum, c) => sum + c.monto, 0).toFixed(2),
            rangos: comisiones.filter(c => c.tipo === 'rangos').reduce((sum, c) => sum + c.monto, 0).toFixed(2)
          }
        };
      });
    
    // Calcular totales
    const totalInversion = userPacks.reduce((sum, p) => sum + p.monto, 0);
    const totalGanado = userComisiones.reduce((sum, c) => sum + (c.monto || 0), 0);
    const totalLimite = userPacks.reduce((sum, p) => sum + (p.monto * 2), 0);
    const excedente = Math.max(0, totalGanado - totalLimite);
    
    const resultado = {
      usuario: {
        id: user.id,
        id_unico: user.id_unico,
        nombre: user.nombre,
        apellido: user.apellido,
        email: user.email
      },
      resumen: {
        totalPacks: userPacks.length,
        inversionTotal: totalInversion.toFixed(2),
        totalGanado: totalGanado.toFixed(2),
        totalLimite: totalLimite.toFixed(2),
        excedente: excedente.toFixed(2),
        progresoGlobal: totalLimite > 0 ? ((totalGanado / totalLimite) * 100).toFixed(2) + '%' : '0%'
      },
      packs: analisisPacks,
      diagnostico: {
        packActivoCorrecto: analisisPacks.find(p => p.activo && !p.completado),
        packsCompletados: analisisPacks.filter(p => p.completado).length,
        packsActivos: analisisPacks.filter(p => p.activo).length,
        problema: analisisPacks.some(p => p.activo && p.completado) 
          ? '⚠️ HAY UN PACK ACTIVO QUE YA COMPLETÓ EL 200%'
          : analisisPacks.filter(p => p.activo).length > 1
            ? '⚠️ HAY MÁS DE UN PACK ACTIVO'
            : analisisPacks.filter(p => p.activo).length === 0
              ? '⚠️ NO HAY NINGÚN PACK ACTIVO'
              : '✅ Todo parece correcto'
      }
    };
    
    return c.json(resultado);
  } catch (error) {
    console.error('❌ Error en diagnóstico de packs:', error);
    return c.json({ error: "Error al diagnosticar packs" }, 500);
  }
});

// 🔧 CORRECCIÓN: Redistribuir todas las comisiones a los packs correctos
app.post("/make-server-9f68532a/admin/corregir-distribucion-comisiones/:userId", async (c) => {
  try {
    const userId = c.req.param('userId');
    console.log(`\n🔧 [CORRECCIÓN] Iniciando redistribución de comisiones para: ${userId}`);
    
    // Obtener datos del usuario
    const user = await crm.getUserById(userId);
    if (!user) {
      return c.json({ error: "Usuario no encontrado" }, 404);
    }
    
    // Obtener todos los packs ordenados cronológicamente
    const userPacks = await crm.getPacksByUserId(userId);
    
    // FILTRAR packs que fueron desactivados manualmente (tienen motivoDesactivacion)
    const packsValidos = userPacks.filter(p => !p.motivoDesactivacion);
    const packsDesactivados = userPacks.filter(p => p.motivoDesactivacion);
    
    if (packsDesactivados.length > 0) {
      console.log(`⚠️ Se encontraron ${packsDesactivados.length} packs desactivados manualmente (se omitirán de la corrección):`);
      packsDesactivados.forEach(p => {
        console.log(`   ❌ ${p.nombre} ($${p.monto}) - Motivo: ${p.motivoDesactivacion}`);
      });
    }
    
    const packsOrdenados = packsValidos.sort((a, b) => 
      new Date(a.fechaCompra).getTime() - new Date(b.fechaCompra).getTime()
    );
    
    console.log(`📦 Total de packs válidos: ${packsOrdenados.length}`);
    packsOrdenados.forEach(p => {
      console.log(`   - ${p.nombre} ($${p.monto}) - ${new Date(p.fechaCompra).toLocaleDateString()}`);
    });
    
    // Obtener TODAS las comisiones (ordenadas por fecha)
    const todasComisiones = await crm.getComisionesByUserId(userId);
    const comisionesOrdenadas = todasComisiones.sort((a, b) => 
      new Date(a.fecha).getTime() - new Date(b.fecha).getTime()
    );
    
    console.log(`💰 Total de comisiones: ${comisionesOrdenadas.length}`);
    const totalComisiones = comisionesOrdenadas.reduce((sum, c) => sum + (c.monto || 0), 0);
    console.log(`💵 Monto total: $${totalComisiones.toFixed(2)}`);
    
    // Contar comisiones sin packId
    const comisionesSinPack = comisionesOrdenadas.filter(c => !c.packId);
    console.log(`⚠️ Comisiones sin packId: ${comisionesSinPack.length} ($${comisionesSinPack.reduce((sum, c) => sum + c.monto, 0).toFixed(2)})`);
    
    // REDISTRIBUIR comisiones a los packs
    let packIndex = 0;
    const actualizaciones: any[] = [];
    const resumenPacks: any[] = [];
    
    // Inicializar resumen de packs
    packsOrdenados.forEach(pack => {
      resumenPacks.push({
        packId: pack.id,
        nombre: pack.nombre,
        total: 0
      });
    });
    
    for (const comision of comisionesOrdenadas) {
      // Buscar el pack correcto para esta comisión
      while (packIndex < packsOrdenados.length) {
        const packActual = packsOrdenados[packIndex];
        const limite = packActual.monto * 2;
        const resumen = resumenPacks.find(r => r.packId === packActual.id);
        const rendimientoPack = resumen?.total || 0;
        
        // Si este pack ya está lleno, avanzar al siguiente
        if (rendimientoPack >= limite) {
          console.log(`✅ Pack ${packActual.nombre} completado ($${rendimientoPack.toFixed(2)}/$${limite}), avanzando...`);
          packIndex++;
          continue;
        }
        
        // Este pack aún tiene espacio, asignar la comisión aquí
        actualizaciones.push({
          comisionId: comision.id,
          nuevoPackId: packActual.id,
          monto: comision.monto
        });
        
        // Actualizar resumen
        resumen.total += comision.monto;
        
        console.log(`   💰 Comisión $${comision.monto.toFixed(2)} → ${packActual.nombre} (Total: $${resumen.total.toFixed(2)}/$${limite})`);
        
        // Salir del while, pasar a la siguiente comisión
        break;
      }
      
      // Si llegamos aquí y packIndex >= length, esta comisión es excedente
      if (packIndex >= packsOrdenados.length) {
        console.log(`📊 Comisión ${comision.id} ($${comision.monto.toFixed(2)}) es excedente - todos los packs completados`);
      }
    }
    
    console.log(`\n📝 Actualizaciones a realizar: ${actualizaciones.length}`);
    
    // Aplicar actualizaciones
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );
    
    for (const actualizacion of actualizaciones) {
      const comisionKey = `comision:${actualizacion.comisionId}`;
      const { data: comisionData } = await supabase
        .from('kv_store_9f68532a')
        .select('value')
        .eq('key', comisionKey)
        .single();
      
      if (comisionData) {
        const comision = typeof comisionData.value === 'string' 
          ? JSON.parse(comisionData.value) 
          : comisionData.value;
        
        comision.packId = actualizacion.nuevoPackId;
        
        await supabase
          .from('kv_store_9f68532a')
          .update({ value: JSON.stringify(comision) })
          .eq('key', comisionKey);
      }
    }
    
    console.log(`✅ ${actualizaciones.length} comisiones actualizadas`);
    
    // Actualizar estado de los packs
    console.log(`\n🔄 Actualizando estado de packs...`);
    
    for (let i = 0; i < packsOrdenados.length; i++) {
      const pack = packsOrdenados[i];
      const resumen = resumenPacks.find(r => r.packId === pack.id);
      const rendimientoTotal = resumen?.total || 0;
      const limite = pack.monto * 2;
      const completado = rendimientoTotal >= limite;
      
      // Determinar si debe estar activo
      let debeEstarActivo = false;
      if (i === 0) {
        // El primer pack siempre arranca activo (si no está completado)
        debeEstarActivo = !completado;
      } else {
        // Los demás packs se activan cuando el anterior se completa
        const packAnterior = packsOrdenados[i - 1];
        const resumenAnterior = resumenPacks.find(r => r.packId === packAnterior.id);
        const rendimientoAnterior = resumenAnterior?.total || 0;
        const limiteAnterior = packAnterior.monto * 2;
        const anteriorCompletado = rendimientoAnterior >= limiteAnterior;
        
        debeEstarActivo = anteriorCompletado && !completado;
      }
      
      // Actualizar pack si es necesario
      if (pack.activo !== debeEstarActivo) {
        console.log(`   📦 ${pack.nombre}: ${pack.activo ? 'Activo' : 'Inactivo'} → ${debeEstarActivo ? 'Activo' : 'Inactivo'} (${rendimientoTotal.toFixed(2)}/${limite})`);
        
        pack.activo = debeEstarActivo;
        pack.status = debeEstarActivo ? 'activo' : 'inactivo';
        
        const packKey = `pack:${pack.id}`;
        await supabase
          .from('kv_store_9f68532a')
          .update({ value: JSON.stringify(pack) })
          .eq('key', packKey);
      }
    }
    
    // Calcular excedente final
    const totalLimite = packsOrdenados.reduce((sum, p) => sum + (p.monto * 2), 0);
    const excedente = Math.max(0, totalComisiones - totalLimite);
    
    console.log(`\n✅ CORRECCIÓN COMPLETADA`);
    console.log(`   Total comisiones: $${totalComisiones.toFixed(2)}`);
    console.log(`   Límite total: $${totalLimite.toFixed(2)}`);
    console.log(`   Excedente: $${excedente.toFixed(2)}`);
    
    return c.json({
      success: true,
      usuario: {
        id: user.id,
        id_unico: user.id_unico,
        nombre: user.nombre,
        apellido: user.apellido
      },
      correccion: {
        comisionesActualizadas: actualizaciones.length,
        packsActualizados: packsOrdenados.filter((p, i) => {
          const resumen = resumenPacks.find(r => r.packId === p.id);
          const rendimientoTotal = resumen?.total || 0;
          const limite = p.monto * 2;
          return rendimientoTotal >= limite;
        }).length,
        totalComisiones: totalComisiones.toFixed(2),
        totalLimite: totalLimite.toFixed(2),
        excedente: excedente.toFixed(2)
      },
      resumenPacks: resumenPacks.map(r => {
        const pack = packsOrdenados.find(p => p.id === r.packId);
        const limite = pack ? pack.monto * 2 : 0;
        return {
          packId: r.packId,
          nombre: r.nombre,
          rendimientoTotal: r.total.toFixed(2),
          limite: limite.toFixed(2),
          progreso: limite > 0 ? ((r.total / limite) * 100).toFixed(2) + '%' : '0%',
          completado: r.total >= limite,
          activo: pack?.activo || false
        };
      })
    });
  } catch (error) {
    console.error('❌ Error en corrección de distribución:', error);
    return c.json({ error: "Error al corregir distribución de comisiones" }, 500);
  }
});

// Endpoint para forzar el recálculo de comisiones de un usuario específico
app.post("/make-server-9f68532a/admin/recalculate-user/:email", async (c) => {
  try {
    const email = c.req.param('email');
    console.log(`🔄 Forzando recálculo para usuario: ${email}`);
    
    // Buscar el usuario por email
    const allUsers = await crm.getAllUsers();
    const usuario = allUsers.find((u: any) => u.email && u.email.trim().toLowerCase() === email.trim().toLowerCase());
    
    if (!usuario) {
      return c.json({ error: `Usuario con email ${email} no encontrado` }, 404);
    }
    
    console.log(`✅ Usuario encontrado: ${usuario.nombre} ${usuario.apellido} (${usuario.id})`);
    
    // Obtener todos los packs del usuario
    const packs = await crm.getPacksByUserId(usuario.id);
    const packActivo = packs.find((p: any) => p.activo);
    
    if (!packActivo) {
      return c.json({ 
        error: `El usuario ${usuario.nombre} no tiene un pack activo. Primero debe aprobar un depósito.`,
        usuario: usuario.nombre,
        email: usuario.email
      }, 400);
    }
    
    console.log(`📦 Pack activo encontrado: ${packActivo.nombre} - $${packActivo.monto}`);
    
    // Recalcular comisiones de red
    await crm.calcularComisionesRed(usuario.id, packActivo.monto);
    console.log(`✅ Comisiones recalculadas para ${usuario.nombre}`);
    
    // Actualizar rango
    await crm.actualizarRangoUsuario(usuario.id);
    console.log(`✅ Rango actualizado`);
    
    // Actualizar rangos en línea ascendente
    if (usuario.referidoPor) {
      let currentUserId = usuario.referidoPor;
      for (let i = 0; i < 10 && currentUserId; i++) {
        await crm.actualizarRangoUsuario(currentUserId);
        const user = await crm.getUserById(currentUserId);
        currentUserId = user?.referidoPor;
      }
      console.log(`✅ Rangos actualizados en línea ascendente`);
    }
    
    return c.json({ 
      success: true, 
      message: `Comisiones recalculadas exitosamente para ${usuario.nombre} ${usuario.apellido}`,
      usuario: {
        nombre: usuario.nombre,
        apellido: usuario.apellido,
        email: usuario.email,
        id: usuario.id_unico
      }
    });
    
  } catch (error) {
    console.error('❌ Error al recalcular usuario:', error);
    return c.json({ error: `Error al recalcular: ${error}` }, 500);
  }
});

// ��� ENDPOINT TEMPORAL: Debug exhaustivo de getAllUsers
app.get("/make-server-9f68532a/debug/getallusers-exhaustivo", async (c) => {
  try {
    const logs: string[] = [];
    
    // Capturar rawData
    const rawData = await kv.getByPrefix('user:');
    logs.push(`📊 Total items con prefijo user: ${rawData?.length || 0}`);
    
    // Filtrar user:UUID
    const todosLosUUIDs = (rawData || [])
      .filter((row: any) => {
        const key = row.key as string;
        if (!key?.startsWith('user:')) return false;
        const afterPrefix = key.substring(5);
        if (afterPrefix.includes(':')) return false;
        const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
        return uuidRegex.test(afterPrefix);
      })
      .map((row: any) => {
        const id = row.key.replace('user:', '');
        return {
          ...row.value,
          id
        };
      });
    
    logs.push(`🔍 Registros user:UUID encontrados: ${todosLosUUIDs.length}`);
    
    // Filtrar con nombre O email
    const conDatos = todosLosUUIDs.filter((u: any) => {
      const tieneNombre = u.nombre && typeof u.nombre === 'string' && u.nombre.trim().length > 0;
      const tieneEmail = u.email && typeof u.email === 'string' && u.email.trim().length > 0;
      return tieneNombre || tieneEmail;
    });
    
    logs.push(`✅ Usuarios con nombre O email: ${conDatos.length}`);
    
    // Llamar a getAllUsers()
    const resultadoGetAllUsers = await crm.getAllUsers();
    logs.push(`📥 getAllUsers() retornó: ${resultadoGetAllUsers.length} usuarios`);
    
    // Buscar los 3 problemáticos
    const problematicos = [
      { id: '939da466-e00d-441f-8e17-d6e4b202ec34', idUnico: 'LF1765918120109793', nombre: 'Julio' },
      { id: '5b5b40d0-f38d-46fe-8b18-2342d8f27517', idUnico: 'LF1766081702464905', nombre: 'Vilma' },
      { id: 'eadd906b-868f-46b6-98e3-b1699b5e56c8', idUnico: 'LF1766035063633662', nombre: 'Juan' }
    ];
    
    const resultado: any = { logs, usuarios: [] };
    
    problematicos.forEach(p => {
      const enConDatos = conDatos.find((u: any) => u.id === p.id);
      const enGetAllUsers = resultadoGetAllUsers.find((u: any) => u.id === p.id);
      
      resultado.usuarios.push({
        nombre: p.nombre,
        idUnico: p.idUnico,
        uuid: p.id,
        estaEnTodosLosUUIDs: !!todosLosUUIDs.find((u: any) => u.id === p.id),
        estaEnConDatos: !!enConDatos,
        estaEnGetAllUsers: !!enGetAllUsers,
        datosRaw: enConDatos || null
      });
    });
    
    return c.json(resultado);
  } catch (error: any) {
    return c.json({ error: error.message }, 500);
  }
});

// 🔧 ENDPOINT TEMPORAL: Test con límite 10000
app.get("/make-server-9f68532a/debug/test-limit-10000", async (c) => {
  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );
    
    // Test CON límite 10000
    const { data: con10k, error: error10k } = await supabase
      .from('kv_store_9f68532a')
      .select('key, value')
      .like('key', 'user:%')
      .limit(10000);
    
    if (error10k) throw error10k;
    
    // Test SIN límite (default 1000)
    const { data: sinLimite, error: errorSin } = await supabase
      .from('kv_store_9f68532a')
      .select('key, value')
      .like('key', 'user:%');
    
    if (errorSin) throw errorSin;
    
    // Filtrar solo user:UUID
    const filtrarUUIDs = (data: any[]) => data.filter((row: any) => {
      const key = row.key as string;
      if (!key?.startsWith('user:')) return false;
      const afterPrefix = key.substring(5);
      if (afterPrefix.includes(':')) return false;
      const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
      return uuidRegex.test(afterPrefix);
    });
    
    const uuidsCon10k = filtrarUUIDs(con10k || []);
    const uuidsSinLimite = filtrarUUIDs(sinLimite || []);
    
    // Buscar los 3 problemáticos
    const problematicos = [
      '939da466-e00d-441f-8e17-d6e4b202ec34', // Julio
      '5b5b40d0-f38d-46fe-8b18-2342d8f27517', // Vilma
      'eadd906b-868f-46b6-98e3-b1699b5e56c8'  // Juan
    ];
    
    const busqueda = {
      con10k: problematicos.map(uuid => ({
        uuid,
        encontrado: !!con10k?.find((r: any) => r.key === `user:${uuid}`)
      })),
      sinLimite: problematicos.map(uuid => ({
        uuid,
        encontrado: !!sinLimite?.find((r: any) => r.key === `user:${uuid}`)
      }))
    };
    
    return c.json({
      totalRawCon10k: con10k?.length || 0,
      totalRawSinLimite: sinLimite?.length || 0,
      totalUUIDsCon10k: uuidsCon10k.length,
      totalUUIDsSinLimite: uuidsSinLimite.length,
      busquedaProblematicos: busqueda,
      conclusion: con10k?.length === sinLimite?.length 
        ? '���️ Ambos devuelven la misma cantidad (límite default aplicado)'
        : '✅ El límite 10000 devuelve más registros'
    });
  } catch (error: any) {
    return c.json({ error: error.message }, 500);
  }
});

// 🔧 ENDPOINT DE EMERGENCIA: Ver usuarios recientes SIN LÍMITE
app.get("/make-server-9f68532a/debug/usuarios-recientes", async (c) => {
  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );
    
    // Obtener TODOS los usuarios sin límite usando order + limit alto
    const { data: allUsers, error } = await supabase
      .from('kv_store_9f68532a')
      .select('key, value')
      .like('key', 'user:%')
      .order('created_at', { ascending: false })
      .limit(100); // Los últimos 100 registros
    
    if (error) throw error;
    
    // Filtrar solo user:UUID y parsear
    const usuarios = allUsers
      ?.filter((row: any) => {
        const key = row.key as string;
        if (!key?.startsWith('user:')) return false;
        const afterPrefix = key.substring(5);
        if (afterPrefix.includes(':')) return false;
        const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
        return uuidRegex.test(afterPrefix);
      })
      .map((row: any) => {
        try {
          const user = typeof row.value === 'string' ? JSON.parse(row.value) : row.value;
          return {
            id: user.id,
            id_unico: user.id_unico,
            nombre: user.nombre,
            apellido: user.apellido,
            email: user.email,
            telefono: user.telefono,
            fechaRegistro: user.fechaRegistro
          };
        } catch {
          return null;
        }
      })
      .filter((u: any) => u !== null);
    
    // Buscar específicamente a Pedri Vilchez
    const pedri = usuarios?.find((u: any) => 
      u.nombre?.toLowerCase().includes('pedri') || 
      u.apellido?.toLowerCase().includes('vilchez')
    );
    
    return c.json({
      total: usuarios?.length || 0,
      ultimos10: usuarios?.slice(0, 10) || [],
      pedriEncontrado: !!pedri,
      pedriDatos: pedri || null,
      mensaje: pedri 
        ? '✅ Pedri Vilchez está en la base de datos pero NO aparece por el límite de 1000'
        : '⚠️ Pedri Vilchez no encontrado - puede estar escribiendo mal el nombre'
    });
  } catch (error: any) {
    return c.json({ error: error.message }, 500);
  }
});

// 🔍 ENDPOINT DE DIAGNÓSTICO: Verificar referidos directos de un usuario
app.get('/make-server-9f68532a/debug/referidos-directos/:userId', async (c) => {
  try {
    const userId = c.req.param('userId');
    console.log(`🔍 [DEBUG] Verificando referidos directos para userId: ${userId}`);
    
    const allUsers = await crm.getAllUsers();
    const allPacks = await crm.getAllPacks();
    
    if (!allUsers || !allPacks) {
      return c.json({ error: 'No se pudieron cargar los datos' }, 500);
    }
    
    // Buscar el usuario
    const user = allUsers.find((u: any) => u.id === userId);
    if (!user) {
      return c.json({ error: 'Usuario no encontrado' }, 404);
    }
    
    // Buscar todos los referidos directos
    const referidosDirectos = allUsers.filter((u: any) => u.referidoPor === userId);
    
    // Analizar cada referido
    const analisisReferidos = referidosDirectos.map((ref: any) => {
      const refPacks = allPacks.filter((p: any) => p.userId === ref.id);
      const packActivo = refPacks.find((p: any) => p.activo);
      
      return {
        id: ref.id,
        id_unico: ref.id_unico,
        nombre: ref.nombre,
        apellido: ref.apellido,
        referidoPor: ref.referidoPor,
        totalPacks: refPacks.length,
        packs: refPacks.map((p: any) => ({
          nombre: p.nombre,
          monto: p.monto,
          activo: p.activo,
          fechaCompra: p.fechaCompra
        })),
        tienePackActivo: !!packActivo,
        packActivo: packActivo ? {
          nombre: packActivo.nombre,
          monto: packActivo.monto
        } : null
      };
    });
    
    const directosConPack = analisisReferidos.filter(r => r.tienePackActivo);
    
    return c.json({
      usuario: {
        id: user.id,
        id_unico: user.id_unico,
        nombre: user.nombre,
        apellido: user.apellido
      },
      totalReferidosDirectos: referidosDirectos.length,
      directosConPack: directosConPack.length,
      referidos: analisisReferidos,
      resumen: {
        conPack: directosConPack.map(r => `${r.nombre} (${r.packActivo?.nombre})`),
        sinPack: analisisReferidos.filter(r => !r.tienePackActivo).map(r => r.nombre)
      }
    });
  } catch (error: any) {
    console.error('❌ Error en diagnóstico de referidos:', error);
    return c.json({ error: error.message }, 500);
  }
});

// 🚨 ENDPOINT PÚBLICO DE DIAGNÓSTICO - SIN AUTENTICACIÓN
app.get('/make-server-9f68532a/diagnostico-campo-referido', async (c) => {
  try {
    console.log('🚨 DIAGNÓSTICO: Analizando estructura del campo referidoPor...');
    
    // Obtener DIRECTAMENTE del KV store (bypass caché)
    const allUsersRaw = await kv.getByPrefix('user:');
    const usuarios = allUsersRaw
      .filter((item: any) => item && typeof item === 'object' && item.id && !item.id.includes(':'))
      .slice(0, 20); // Solo los primeros 20 para análisis
    
    // Analizar estructura de cada usuario
    const analisis = usuarios.map((u: any) => ({
      id: u.id,
      id_unico: u.id_unico,
      nombre: u.nombre,
      apellido: u.apellido,
      
      // Analizar campo referidoPor
      referidoPor: u.referidoPor,
      referidoPorType: typeof u.referidoPor,
      referidoPorExists: u.referidoPor !== undefined && u.referidoPor !== null,
      referidoPorEsUUID: u.referidoPor?.toString().includes('-'),
      referidoPorEsIdUnico: u.referidoPor?.toString().startsWith('LF'),
      
      // Mostrar TODAS las claves del objeto para ver si hay variantes
      todasLasClaves: Object.keys(u),
      clavesQueContienen_referi: Object.keys(u).filter(k => k.toLowerCase().includes('referi'))
    }));
    
    // Contar patrones
    const conReferidoPor = analisis.filter(a => a.referidoPorExists).length;
    const sinReferidoPor = analisis.filter(a => !a.referidoPorExists).length;
    const esUUID = analisis.filter(a => a.referidoPorEsUUID).length;
    const esIdUnico = analisis.filter(a => a.referidoPorEsIdUnico).length;
    
    // Buscar a Israel y Jorge específicamente
    const todosLosUsuarios = allUsersRaw.filter((item: any) => item && typeof item === 'object' && item.id && !item.id.includes(':'));
    const israel = todosLosUsuarios.find((u: any) => u.id_unico === 'LF1764086702089158');
    const jorge = todosLosUsuarios.find((u: any) => u.nombre?.toLowerCase().includes('jorge'));
    
    return c.json({
      resumen: {
        totalUsuariosAnalizados: analisis.length,
        conReferidoPor,
        sinReferidoPor,
        patronesDetectados: {
          usanUUID: esUUID,
          usanIdUnico: esIdUnico
        }
      },
      muestraDe20Usuarios: analisis,
      casoEspecifico: {
        israel: israel ? {
          id: israel.id,
          id_unico: israel.id_unico,
          nombre: `${israel.nombre} ${israel.apellido}`,
          referidoPor: israel.referidoPor,
          todasLasClaves: Object.keys(israel)
        } : 'No encontrado',
        jorge: jorge ? {
          id: jorge.id,
          id_unico: jorge.id_unico,
          nombre: `${jorge.nombre} ${jorge.apellido}`,
          referidoPor: jorge.referidoPor,
          referidoPorType: typeof jorge.referidoPor,
          todasLasClaves: Object.keys(jorge)
        } : 'No encontrado'
      }
    });
  } catch (error: any) {
    console.error('❌ Error en diagnóstico:', error);
    return c.json({ 
      error: error.message,
      stack: error.stack 
    }, 500);
  }
});

// 🧹 LIMPIEZA AUTOMÁTICA DE LOCKS ANTIGUOS (al inicio del servidor)
async function limpiarLocksAntiguos() {
  try {
    console.log('🧹 [INIT] Limpiando locks de rendimientos antiguos...');
    
    // Obtener todos los locks de rendimiento
    const locks = await kv.getByPrefix('rendimiento:lock:');
    
    if (!locks || locks.length === 0) {
      console.log('   ✅ No hay locks para limpiar');
      return;
    }
    
    const hoy = new Date().toISOString().split('T')[0];
    let locksEliminados = 0;
    
    // Eliminar locks de días anteriores
    for (const lock of locks) {
      if (lock && lock.fecha && lock.fecha < hoy) {
        // Extraer la key del lock
        const lockKey = `rendimiento:lock:${lock.userId}:${lock.fecha}`;
        await kv.del(lockKey);
        locksEliminados++;
      }
    }
    
    console.log(`   ✅ ${locksEliminados} locks antiguos eliminados`);
  } catch (error) {
    console.warn('⚠️ [INIT] Error limpiando locks (no crítico):', error);
  }
}

// ==========================================
// 🛡️ ENDPOINT PARA DETECTAR Y CORREGIR USUARIOS DUPLICADOS
// ==========================================

app.get("/make-server-9f68532a/admin/detectar-usuarios-duplicados", async (c) => {
  const requestStartTime = Date.now();
  
  try {
    console.log('🔍 [OPTIMIZADO] Detectando usuarios duplicados...');
    
    // ⚡ OPTIMIZACIÓN: Usar caché en lugar de consulta directa
    console.log(`⏱️ T+${Date.now() - requestStartTime}ms - Cargando usuarios desde caché...`);
    const usuarios = await getCachedUsuarios();
    console.log(`📊 Total usuarios: ${usuarios.length} (${Date.now() - requestStartTime}ms)`);
    
    // Agrupar por email para detectar duplicados
    const usuariosPorEmail = new Map();
    
    for (const usuario of usuarios) {
      const email = usuario.email?.toLowerCase();
      if (!email) continue;
      
      if (!usuariosPorEmail.has(email)) {
        usuariosPorEmail.set(email, []);
      }
      const lista = usuariosPorEmail.get(email);
      if (lista) {
        lista.push(usuario);
      }
    }
    
    // Detectar duplicados
    const duplicados: any[] = [];
    let totalDuplicados = 0;
    
    for (const [email, users] of usuariosPorEmail.entries()) {
      if (users.length > 1) {
        // Ordenar por fecha de registro (más antiguo primero)
        const ordenados = users.sort((a, b) => {
          const fechaA = new Date(a.fechaRegistro).getTime();
          const fechaB = new Date(b.fechaRegistro).getTime();
          return fechaA - fechaB;
        });
        
        const original = ordenados[0];
        const copias = ordenados.slice(1);
        
        duplicados.push({
          email,
          cantidad: users.length,
          original: {
            id: original.id,
            id_unico: original.id_unico,
            nombre: original.nombre,
            apellido: original.apellido,
            fechaRegistro: original.fechaRegistro
          },
          copias: copias.map(u => ({
            id: u.id,
            id_unico: u.id_unico,
            nombre: u.nombre,
            apellido: u.apellido,
            fechaRegistro: u.fechaRegistro
          }))
        });
        
        totalDuplicados += copias.length;
      }
    }
    
    const totalTime = Date.now() - requestStartTime;
    console.log(`✅ [OPTIMIZADO] Análisis completado en ${totalTime}ms: ${duplicados.length} emails con duplicados, ${totalDuplicados} copias totales`);
    
    return c.json({
      success: true,
      totalUsuarios: usuarios.length,
      emailsConDuplicados: duplicados.length,
      totalCopias: totalDuplicados,
      duplicados: duplicados,
      tiempoMs: totalTime
    });
    
  } catch (error) {
    const elapsed = Date.now() - requestStartTime;
    console.error(`❌ Error detectando usuarios duplicados (${elapsed}ms):`, error);
    return c.json({ error: "Error al detectar usuarios duplicados" }, 500);
  }
});

app.post("/make-server-9f68532a/admin/eliminar-usuarios-duplicados", async (c) => {
  const requestStartTime = Date.now();
  
  try {
    const { emailsDuplicados } = await c.req.json();
    
    if (!emailsDuplicados || !Array.isArray(emailsDuplicados)) {
      return c.json({ error: "Se requiere un array de emails duplicados" }, 400);
    }
    
    console.log(`🗑️ [OPTIMIZADO] Eliminando usuarios duplicados de ${emailsDuplicados.length} emails...`);
    
    // ⚡ OPTIMIZACIÓN: Cargar usuarios UNA SOLA VEZ al inicio
    console.log(`⏱️ T+${Date.now() - requestStartTime}ms - Cargando usuarios desde caché...`);
    const todosLosUsuarios = await getCachedUsuarios();
    console.log(`⏱️ T+${Date.now() - requestStartTime}ms - ${todosLosUsuarios.length} usuarios cargados`);
    
    // ⚡ OPTIMIZACIÓN: Pre-indexar usuarios por email para búsqueda O(1)
    const usuariosPorEmail = new Map();
    todosLosUsuarios.forEach(u => {
      if (u.email) {
        const emailLower = u.email.toLowerCase();
        if (!usuariosPorEmail.has(emailLower)) {
          usuariosPorEmail.set(emailLower, []);
        }
        const lista = usuariosPorEmail.get(emailLower);
        if (lista) {
          lista.push(u);
        }
      }
    });
    console.log(`⏱️ T+${Date.now() - requestStartTime}ms - Índice de emails creado`);
    
    let usuariosEliminados = 0;
    const errores: any[] = [];
    const usuariosAEliminar: any[] = [];
    
    // ⚡ PASO 1: Identificar qué usuarios eliminar (rápido, sin I/O)
    for (const email of emailsDuplicados) {
      try {
        const emailLower = email.toLowerCase();
        const usuariosConEmail = usuariosPorEmail.get(emailLower) || [];
        
        if (usuariosConEmail.length <= 1) {
          console.log(`⏭️  Email ${email}: solo ${usuariosConEmail.length} usuario(s), saltando`);
          continue;
        }
        
        // Ordenar por fecha de registro (más antiguo primero)
        const ordenados = usuariosConEmail.sort((a, b) => {
          const fechaA = new Date(a.fechaRegistro).getTime();
          const fechaB = new Date(b.fechaRegistro).getTime();
          return fechaA - fechaB;
        });
        
        // Mantener el PRIMERO (m��s antiguo), eliminar los demás
        const mantener = ordenados[0];
        const eliminar = ordenados.slice(1);
        
        console.log(`📧 Email ${email}: Manteniendo ${mantener.id_unico}, eliminando ${eliminar.length} copias`);
        usuariosAEliminar.push(...eliminar);
        
      } catch (emailError) {
        console.error(`❌ Error procesando email ${email}:`, emailError);
        errores.push({ email, error: String(emailError) });
      }
    }
    
    console.log(`⏱️ T+${Date.now() - requestStartTime}ms - ${usuariosAEliminar.length} usuarios identificados para eliminar`);
    
    // ⚡ PASO 2: Eliminar todos en paralelo (mucho más rápido)
    console.log(`🗑️ Eliminando ${usuariosAEliminar.length} usuarios en paralelo...`);
    
    const deletePromises = usuariosAEliminar.map(async (usuario) => {
      try {
        // Eliminar todas las keys relacionadas con este usuario
        await Promise.all([
          kv.del(`user:${usuario.id}`),
          kv.del(`user:email:${usuario.email}`),
          kv.del(`user:idUnico:${usuario.id_unico}`)
        ]);
        
        console.log(`  ✅ Eliminado: ${usuario.id_unico}`);
        return { success: true, usuario: usuario.id_unico };
      } catch (delError) {
        console.error(`  ❌ Error eliminando ${usuario.id}:`, delError);
        return { success: false, usuario: usuario.id_unico, error: String(delError) };
      }
    });
    
    // Esperar a que todas las eliminaciones completen
    const resultados = await Promise.all(deletePromises);
    
    // Contar éxitos y errores
    usuariosEliminados = resultados.filter(r => r.success).length;
    const erroresElim = resultados.filter(r => !r.success);
    errores.push(...erroresElim);
    
    console.log(`⏱️ T+${Date.now() - requestStartTime}ms - Eliminación paralela completada`);
    
    // Invalidar caché
    invalidateCache();
    
    const totalTime = Date.now() - requestStartTime;
    console.log(`✅ Limpieza completada en ${(totalTime/1000).toFixed(1)}s: ${usuariosEliminados} usuarios eliminados`);
    
    return c.json({
      success: true,
      usuariosEliminados,
      tiempoMs: totalTime,
      errores: errores.length > 0 ? errores : undefined
    });
    
  } catch (error) {
    const elapsed = Date.now() - requestStartTime;
    console.error(`❌ Error eliminando usuarios duplicados (${elapsed}ms):`, error);
    return c.json({ error: "Error al eliminar usuarios duplicados" }, 500);
  }
});

// 🔍 DIAGNÓSTICO COMPLETO: Usuario específico
app.get("/make-server-9f68532a/admin/diagnostico-usuario/:idUnico", async (c) => {
  try {
    const idUnico = c.req.param('idUnico');
    console.log(`\n🔍 ========== DIAGNÓSTICO COMPLETO: ${idUnico} ==========`);
    
    const startTime = Date.now();
    
    // 1️⃣ Obtener datos del usuario
    const usuarios = await getCachedUsuarios();
    const usuario = usuarios.find((u: any) => u.id_unico === idUnico);
    
    if (!usuario) {
      return c.json({
        success: false,
        error: `Usuario ${idUnico} no encontrado`
      }, 404);
    }
    
    console.log(`✅ Usuario encontrado: ${usuario.nombre} ${usuario.apellido} (${usuario.email})`);
    
    // 2️⃣ Obtener TODOS los packs del usuario (activos e inactivos)
    const packs = await getCachedPacks();
    const packsUsuario = packs.filter((p: any) => p.userId === usuario.id);
    const packsActivos = packsUsuario.filter((p: any) => p.status === 'activo');
    const packsInactivos = packsUsuario.filter((p: any) => p.status !== 'activo');
    
    const inversionTotal = packsActivos.reduce((sum: number, p: any) => sum + p.monto, 0);
    
    console.log(`💰 Packs activos: ${packsActivos.length} = $${inversionTotal}`);
    console.log(`🔒 Packs inactivos: ${packsInactivos.length}`);
    
    // 3️⃣ Obtener comisiones y rendimientos
    const comisiones = await getCachedComisiones();
    const comisionesUsuario = comisiones.filter((c: any) => c.userId === usuario.id);
    
    const rendimientos = comisionesUsuario.filter((c: any) => c.tipo === 'rendimiento');
    const comisionesDirectas = comisionesUsuario.filter((c: any) => c.tipo === 'directa');
    const comisionesReferido = comisionesUsuario.filter((c: any) => c.tipo === 'referido');
    const comisionesMatriz = comisionesUsuario.filter((c: any) => c.tipo === 'matriz_binaria');
    const comisionesRango = comisionesUsuario.filter((c: any) => c.tipo === 'rango');
    
    const totalRendimientos = rendimientos.reduce((sum: number, r: any) => sum + r.monto, 0);
    const totalDirectas = comisionesDirectas.reduce((sum: number, c: any) => sum + c.monto, 0);
    const totalReferido = comisionesReferido.reduce((sum: number, c: any) => sum + c.monto, 0);
    const totalMatriz = comisionesMatriz.reduce((sum: number, c: any) => sum + c.monto, 0);
    const totalRango = comisionesRango.reduce((sum: number, c: any) => sum + c.monto, 0);
    
    const totalComisiones = totalDirectas + totalReferido + totalMatriz + totalRango;
    const gananciaTotalAcumulada = totalRendimientos + totalComisiones;
    
    console.log(`📊 Rendimientos: ${rendimientos.length} = $${totalRendimientos.toFixed(2)}`);
    console.log(`📊 Comisiones directas: ${comisionesDirectas.length} = $${totalDirectas.toFixed(2)}`);
    console.log(`📊 Comisiones referido: ${comisionesReferido.length} = $${totalReferido.toFixed(2)}`);
    console.log(`📊 Comisiones matriz: ${comisionesMatriz.length} = $${totalMatriz.toFixed(2)}`);
    console.log(`📊 Comisiones rango: ${comisionesRango.length} = $${totalRango.toFixed(2)}`);
    console.log(`💵 GANANCIA TOTAL: $${gananciaTotalAcumulada.toFixed(2)}`);
    
    // 4️⃣ Obtener referidos directos
    const referidosDirectos = usuarios.filter((u: any) => u.referidoPor === usuario.id);
    const referidosConPacks = referidosDirectos.map((ref: any) => {
      const packsRef = packs.filter((p: any) => p.userId === ref.id && p.status === 'activo');
      const inversionRef = packsRef.reduce((sum: number, p: any) => sum + p.monto, 0);
      return {
        id_unico: ref.id_unico,
        nombre: `${ref.nombre} ${ref.apellido}`,
        email: ref.email,
        packsActivos: packsRef.length,
        inversionTotal: inversionRef
      };
    });
    
    console.log(`��� Referidos directos: ${referidosDirectos.length}`);
    
    // 5️⃣ Calcular volumen del rango
    const calcularVolumenEquipo = (userId: string, profundidad = 0, maxProfundidad = 10): number => {
      if (profundidad >= maxProfundidad) return 0;
      
      const referidos = usuarios.filter((u: any) => u.referidoPor === userId);
      let volumenTotal = 0;
      
      for (const ref of referidos) {
        const packsRef = packs.filter((p: any) => p.userId === ref.id && p.status === 'activo');
        const inversionRef = packsRef.reduce((sum: number, p: any) => sum + p.monto, 0);
        
        volumenTotal += inversionRef;
        volumenTotal += calcularVolumenEquipo(ref.id, profundidad + 1, maxProfundidad);
      }
      
      return volumenTotal;
    };
    
    const volumenEquipo = calcularVolumenEquipo(usuario.id);
    console.log(`📈 Volumen total del equipo: $${volumenEquipo.toFixed(2)}`);
    
    // 6️⃣ Obtener matriz binaria
    const matrizIzquierda = packs.filter((p: any) => p.matrizPadre === usuario.id && p.posicionMatriz === 'izquierda');
    const matrizDerecha = packs.filter((p: any) => p.matrizPadre === usuario.id && p.posicionMatriz === 'derecha');
    
    console.log(`🌳 Matriz binaria - Izquierda: ${matrizIzquierda.length} packs, Derecha: ${matrizDerecha.length} packs`);
    
    const elapsed = Date.now() - startTime;
    console.log(`✅ Diagnóstico completado en ${elapsed}ms`);
    console.log('========== FIN DIAGNÓSTICO ==========\n');
    
    return c.json({
      success: true,
      timestamp: new Date().toISOString(),
      tiempoDiagnostico: `${elapsed}ms`,
      usuario: {
        id: usuario.id,
        id_unico: usuario.id_unico,
        nombre: `${usuario.nombre} ${usuario.apellido}`,
        email: usuario.email,
        rango: usuario.rango || 'Sin rango',
        fechaRegistro: usuario.created_at
      },
      packs: {
        activos: packsActivos.map((p: any) => ({
          id: p.id.substring(0, 8),
          monto: p.monto,
          tipo: p.tipo,
          status: p.status,
          fechaActivacion: p.fechaActivacion
        })),
        inactivos: packsInactivos.map((p: any) => ({
          id: p.id.substring(0, 8),
          monto: p.monto,
          tipo: p.tipo,
          status: p.status,
          fechaActivacion: p.fechaActivacion
        })),
        totalActivos: packsActivos.length,
        totalInactivos: packsInactivos.length,
        inversionTotal: inversionTotal
      },
      ganancias: {
        rendimientos: {
          cantidad: rendimientos.length,
          total: parseFloat(totalRendimientos.toFixed(2))
        },
        comisionDirecta: {
          cantidad: comisionesDirectas.length,
          total: parseFloat(totalDirectas.toFixed(2))
        },
        comisionReferido: {
          cantidad: comisionesReferido.length,
          total: parseFloat(totalReferido.toFixed(2))
        },
        comisionMatriz: {
          cantidad: comisionesMatriz.length,
          total: parseFloat(totalMatriz.toFixed(2))
        },
        comisionRango: {
          cantidad: comisionesRango.length,
          total: parseFloat(totalRango.toFixed(2))
        },
        totalComisiones: parseFloat(totalComisiones.toFixed(2)),
        gananciaTotal: parseFloat(gananciaTotalAcumulada.toFixed(2)),
        rentabilidadPorcentaje: inversionTotal > 0 ? parseFloat(((gananciaTotalAcumulada / inversionTotal) * 100).toFixed(2)) : 0
      },
      referidos: {
        directos: referidosConPacks,
        totalDirectos: referidosDirectos.length,
        volumenEquipo: parseFloat(volumenEquipo.toFixed(2))
      },
      matrizBinaria: {
        izquierda: matrizIzquierda.length,
        derecha: matrizDerecha.length,
        balanceado: matrizIzquierda.length === matrizDerecha.length
      },
      diagnostico: {
        inversionEsperada: inversionTotal,
        inversionMostrada: '¿Cuánto muestra el frontend?',
        diferenciaDetectada: '¿Hay diferencia?'
      }
    });
    
  } catch (error: any) {
    console.error('❌ Error en diagnóstico de usuario:', error);
    return c.json({ 
      error: "Error al realizar diagnóstico",
      details: error?.message || String(error)
    }, 500);
  }
});

// ==========================================
// 🔍 ENDPOINT DE ANÁLISIS ULTRA-DETALLADO DE RENDIMIENTOS
// ==========================================
app.get("/make-server-9f68532a/admin/analizar-rendimientos-usuario/:idUnico", async (c) => {
  try {
    const idUnico = c.req.param('idUnico');
    console.log(`\n🔍 ========== ANÁLISIS DETALLADO RENDIMIENTOS - ${idUnico} ==========`);
    
    const usuarios = await getCachedUsuarios();
    const usuario = usuarios.find((u: any) => u.id_unico === idUnico);
    
    if (!usuario) {
      return c.json({ error: "Usuario no encontrado" }, 404);
    }
    
    const packs = await crm.getPacksByUserId(usuario.id);
    const todasComisiones = await getCachedComisiones();
    const comisionesUsuario = todasComisiones.filter((c: any) => c.userId === usuario.id);
    const rendimientos = comisionesUsuario.filter((c: any) => c.tipo === 'rendimiento');
    
    const rendimientosPorPack = new Map<string, any[]>();
    const rendimientosSinPack = [];
    
    for (const rend of rendimientos) {
      if (rend.packId) {
        if (!rendimientosPorPack.has(rend.packId)) {
          rendimientosPorPack.set(rend.packId, []);
        }
        rendimientosPorPack.get(rend.packId)!.push(rend);
      } else {
        rendimientosSinPack.push(rend);
      }
    }
    
    const analisisPacks = packs.map((pack: any) => {
      const rendsPack = rendimientosPorPack.get(pack.id) || [];
      const totalRends = rendsPack.reduce((sum, r) => sum + (r.monto || 0), 0);
      
      return {
        packId: pack.id.substring(0, 8),
        packIdCompleto: pack.id,
        monto: pack.monto,
        tipo: pack.tipo,
        status: pack.status,
        rendimientos: {
          cantidad: rendsPack.length,
          total: totalRends,
          detalle: rendsPack.map(r => ({
            fecha: r.fecha,
            monto: r.monto,
            descripcion: r.descripcion
          }))
        }
      };
    });
    
    const packIdsActuales = new Set(packs.map((p: any) => p.id));
    const rendimientosHuerfanos = [];
    
    for (const [packId, rends] of rendimientosPorPack.entries()) {
      if (!packIdsActuales.has(packId)) {
        rendimientosHuerfanos.push({
          packIdAntiguo: packId.substring(0, 8),
          packIdCompletoAntiguo: packId,
          cantidad: rends.length,
          total: rends.reduce((sum, r) => sum + (r.monto || 0), 0),
          rendimientos: rends.map(r => ({
            fecha: r.fecha,
            monto: r.monto,
            descripcion: r.descripcion
          }))
        });
      }
    }
    
    const totalRendimientos = rendimientos.reduce((sum, r) => sum + (r.monto || 0), 0);
    
    return c.json({
      success: true,
      usuario: {
        id: usuario.id,
        nombre: `${usuario.nombre} ${usuario.apellido}`,
        idUnico: usuario.id_unico
      },
      resumen: {
        packsActuales: packs.length,
        totalRendimientos: rendimientos.length,
        montoTotalRendimientos: totalRendimientos,
        rendimientosAsociados: rendimientos.filter(r => r.packId).length,
        rendimientosSinPack: rendimientosSinPack.length,
        rendimientosHuerfanos: rendimientosHuerfanos.reduce((sum, h) => sum + h.cantidad, 0)
      },
      packsActuales: analisisPacks,
      rendimientosHuerfanos: rendimientosHuerfanos,
      rendimientosSinPackId: rendimientosSinPack.map(r => ({
        fecha: r.fecha,
        monto: r.monto,
        descripcion: r.descripcion
      }))
    });
    
  } catch (error: any) {
    console.error('❌ Error en análisis de rendimientos:', error);
    return c.json({ 
      error: "Error al analizar rendimientos",
      details: error?.message || String(error)
    }, 500);
  }
});

// ==========================================
// 🔧 ENDPOINT DE REPARACIÓN DE RENDIMIENTOS SIN PACK ID
// ==========================================
app.post("/make-server-9f68532a/admin/reparar-rendimientos-huerfanos/:idUnico", async (c) => {
  try {
    const idUnico = c.req.param('idUnico');
    console.log(`\n🔧 ========== REPARACIÓN RENDIMIENTOS HUÉRFANOS - ${idUnico} ==========`);
    
    const usuarios = await getCachedUsuarios();
    const usuario = usuarios.find((u: any) => u.id_unico === idUnico);
    
    if (!usuario) {
      return c.json({ error: "Usuario no encontrado" }, 404);
    }
    
    // Obtener packs y comisiones
    const packs = await crm.getPacksByUserId(usuario.id);
    const todasComisiones = await getCachedComisiones();
    const comisionesUsuario = todasComisiones.filter((c: any) => c.userId === usuario.id);
    const rendimientos = comisionesUsuario.filter((c: any) => c.tipo === 'rendimiento');
    
    // Filtrar rendimientos sin packId
    const rendimientosSinPack = rendimientos.filter((r: any) => !r.packId);
    
    console.log(`📊 Rendimientos sin packId: ${rendimientosSinPack.length}`);
    console.log(`📦 Packs del usuario: ${packs.length}`);
    
    if (rendimientosSinPack.length === 0) {
      return c.json({
        success: true,
        mensaje: "No hay rendimientos huérfanos para reparar",
        reparados: 0
      });
    }
    
    // Ordenar packs por fecha de activación
    const packsOrdenados = [...packs].sort((a, b) => {
      const fechaA = new Date(a.fechaActivacion || a.fechaCompra || 0).getTime();
      const fechaB = new Date(b.fechaActivacion || b.fechaCompra || 0).getTime();
      return fechaA - fechaB;
    });
    
    let rendimientosReparados = 0;
    const detallesReparacion = [];
    
    for (const rendimiento of rendimientosSinPack) {
      // Extraer el monto del pack de la descripción
      // Ejemplo: "Rendimiento diario 0.5% sobre $200.00"
      const match = rendimiento.descripcion.match(/sobre\s+\$?(\d+\.?\d*)/);
      const montoEnDescripcion = match ? parseFloat(match[1]) : null;
      
      if (!montoEnDescripcion) {
        console.log(`��️ No se pudo extraer monto de descripción: ${rendimiento.descripcion}`);
        continue;
      }
      
      const fechaRendimiento = new Date(rendimiento.fecha).getTime();
      
      // Buscar el pack correspondiente:
      // 1. Mismo monto
      // 2. Fecha de rendimiento >= fecha de activación del pack
      let packCorrespondiente = null;
      
      for (const pack of packsOrdenados) {
        const fechaPack = new Date(pack.fechaActivacion || pack.fechaCompra || 0).getTime();
        
        if (Math.abs(pack.monto - montoEnDescripcion) < 0.01 && fechaRendimiento >= fechaPack) {
          packCorrespondiente = pack;
          // No hacer break - queremos el más reciente que cumpla las condiciones
        }
      }
      
      if (packCorrespondiente) {
        // Actualizar la comisión agregando el packId
        await kv.set(`comision:${rendimiento.id}`, {
          ...rendimiento,
          packId: packCorrespondiente.id
        });
        
        rendimientosReparados++;
        detallesReparacion.push({
          rendimientoId: rendimiento.id.substring(0, 8),
          monto: rendimiento.monto,
          descripcion: rendimiento.descripcion,
          fecha: rendimiento.fecha,
          packIdAsignado: packCorrespondiente.id.substring(0, 8),
          packMonto: packCorrespondiente.monto
        });
        
        console.log(`✅ Rendimiento ${rendimiento.id.substring(0, 8)} ($${rendimiento.monto}) asociado a pack ${packCorrespondiente.id.substring(0, 8)} ($${packCorrespondiente.monto})`);
      } else {
        console.log(`⚠️ No se encontró pack para rendimiento de $${rendimiento.monto} (monto en descripción: $${montoEnDescripcion})`);
      }
    }
    
    // Invalidar caché de comisiones
    invalidateCache();
    
    console.log(`✅ Reparación completada: ${rendimientosReparados} rendimientos asociados`);
    
    return c.json({
      success: true,
      usuario: {
        nombre: `${usuario.nombre} ${usuario.apellido}`,
        idUnico: usuario.id_unico
      },
      rendimientosTotalesSinPack: rendimientosSinPack.length,
      rendimientosReparados: rendimientosReparados,
      detalles: detallesReparacion.slice(0, 20) // Mostrar primeros 20
    });
    
  } catch (error: any) {
    console.error('❌ Error en reparación de rendimientos:', error);
    return c.json({ 
      error: "Error al reparar rendimientos",
      details: error?.message || String(error)
    }, 500);
  }
});

// ==========================================
// 🔍 ENDPOINT DE ANÁLISIS DETALLADO DE PACKS
// ==========================================
app.get("/make-server-9f68532a/admin/analizar-packs-usuario/:idUnico", async (c) => {
  try {
    const idUnico = c.req.param('idUnico');
    console.log(`\n🔍 ========== ANÁLISIS DETALLADO - ${idUnico} ==========`);
    
    const usuarios = await getCachedUsuarios();
    const usuario = usuarios.find((u: any) => u.id_unico === idUnico);
    
    if (!usuario) {
      return c.json({ error: "Usuario no encontrado" }, 404);
    }
    
    const packs = await crm.getPacksByUserId(usuario.id);
    const todosDepositos = await crm.getAllDepositos();
    const depositosUsuario = todosDepositos.filter((d: any) => d.userId === usuario.id);
    const todasComisiones = await getCachedComisiones();
    const comisionesUsuario = todasComisiones.filter((c: any) => c.userId === usuario.id);
    
    const analisis = packs.map((pack: any) => {
      const rendimientosPack = comisionesUsuario.filter((c: any) => 
        c.packId === pack.id && c.tipo === 'rendimiento'
      );
      const rendimientoTotal = rendimientosPack.reduce((sum: number, c: any) => sum + (c.monto || 0), 0);
      const limiteRendimiento = pack.monto * 2;
      
      const depositoVerificado = depositosUsuario.find((d: any) => 
        d.estado === 'verificado' && Math.abs(d.monto - pack.monto) < 0.01
      );
      const depositoRechazado = depositosUsuario.find((d: any) => 
        d.estado === 'rechazado' && Math.abs(d.monto - pack.monto) < 0.01
      );
      
      return {
        id: pack.id.substring(0, 8),
        tipo: pack.tipo,
        monto: pack.monto,
        status: pack.status,
        fechaActivacion: pack.fechaActivacion,
        rendimientoDiario: pack.rendimientoDiario,
        rendimientos: {
          total: rendimientoTotal,
          limite: limiteRendimiento,
          porcentaje: (rendimientoTotal / pack.monto) * 100,
          llegaA200: rendimientoTotal >= limiteRendimiento,
          cantidad: rendimientosPack.length
        },
        deposito: {
          verificado: depositoVerificado ? {
            id: depositoVerificado.id.substring(0, 8),
            monto: depositoVerificado.monto,
            fecha: depositoVerificado.fecha
          } : null,
          rechazado: depositoRechazado ? {
            id: depositoRechazado.id.substring(0, 8),
            monto: depositoRechazado.monto,
            fecha: depositoRechazado.fecha
          } : null
        },
        estadoCorrectoDebe: depositoVerificado && rendimientoTotal < limiteRendimiento ? 'activo' : 'inactivo',
        requiereCorreccion: pack.status !== (depositoVerificado && rendimientoTotal < limiteRendimiento ? 'activo' : 'inactivo')
      };
    });
    
    return c.json({
      success: true,
      usuario: {
        id: usuario.id,
        nombre: `${usuario.nombre} ${usuario.apellido}`,
        idUnico: usuario.id_unico
      },
      totalPacks: packs.length,
      totalDepositos: depositosUsuario.length,
      depositosVerificados: depositosUsuario.filter((d: any) => d.estado === 'verificado').length,
      depositosRechazados: depositosUsuario.filter((d: any) => d.estado === 'rechazado').length,
      packsQueRequierenCorreccion: analisis.filter(a => a.requiereCorreccion).length,
      analisis: analisis
    });
    
  } catch (error: any) {
    console.error('❌ Error en análisis:', error);
    return c.json({ 
      error: "Error al analizar packs",
      details: error?.message || String(error)
    }, 500);
  }
});

// ==========================================
// 🔧 ENDPOINT DE REPARACIÓN COMPLETA DE PACKS
// ==========================================
app.post("/make-server-9f68532a/admin/reparar-packs-usuario/:idUnico", async (c) => {
  try {
    const idUnico = c.req.param('idUnico');
    console.log(`\n🔧 ========== REPARACIÓN COMPLETA DE PACKS - ${idUnico} ==========`);
    
    // 1️⃣ Obtener el usuario desde caché
    const usuarios = await getCachedUsuarios();
    const usuario = usuarios.find((u: any) => u.id_unico === idUnico);
    
    if (!usuario) {
      return c.json({ error: "Usuario no encontrado" }, 404);
    }
    
    console.log(`👤 Usuario encontrado: ${usuario.nombre} ${usuario.apellido}`);
    
    // 2️⃣ Obtener TODOS los packs del usuario
    const packs = await crm.getPacksByUserId(usuario.id);
    console.log(`📦 Total de packs: ${packs.length}`);
    
    // 3️⃣ Obtener TODOS los depósitos del usuario (verificados, rechazados, pendientes)
    const todosDepositos = await crm.getAllDepositos();
    const depositosUsuario = todosDepositos.filter((d: any) => d.userId === usuario.id);
    const depositosVerificados = depositosUsuario.filter((d: any) => d.estado === 'verificado');
    const depositosRechazados = depositosUsuario.filter((d: any) => d.estado === 'rechazado');
    
    console.log(`💰 Total depósitos: ${depositosUsuario.length}`);
    console.log(`✅ Depósitos verificados: ${depositosVerificados.length}`);
    console.log(`❌ Depósitos rechazados: ${depositosRechazados.length}`);
    
    // 4️⃣ Obtener TODAS las comisiones para calcular rendimientos
    const todasComisiones = await getCachedComisiones();
    const comisionesUsuario = todasComisiones.filter((c: any) => c.userId === usuario.id);
    
    // 5️⃣ Crear mapeo de depósitos verificados por monto
    // Agrupar depósitos verificados por monto (puede haber varios del mismo monto)
    const depositosPorMonto = new Map<number, any[]>();
    for (const dep of depositosVerificados) {
      const montoKey = Math.round(dep.monto * 100) / 100; // Redondear a 2 decimales
      if (!depositosPorMonto.has(montoKey)) {
        depositosPorMonto.set(montoKey, []);
      }
      depositosPorMonto.get(montoKey)!.push(dep);
    }
    
    // Ordenar dep��sitos por fecha (más antiguos primero)
    depositosPorMonto.forEach((deps) => {
      deps.sort((a, b) => new Date(a.fecha).getTime() - new Date(b.fecha).getTime());
    });
    
    // 6️⃣ Crear mapeo de depósitos rechazados por monto
    const depositosRechazadosPorMonto = new Map<number, any[]>();
    for (const dep of depositosRechazados) {
      const montoKey = Math.round(dep.monto * 100) / 100;
      if (!depositosRechazadosPorMonto.has(montoKey)) {
        depositosRechazadosPorMonto.set(montoKey, []);
      }
      depositosRechazadosPorMonto.get(montoKey)!.push(dep);
    }
    
    // 7️⃣ Ordenar packs por fecha de creación
    const packsOrdenados = [...packs].sort((a, b) => {
      const fechaA = a.fechaActivacion || a.fecha || new Date(0).toISOString();
      const fechaB = b.fechaActivacion || b.fecha || new Date(0).toISOString();
      return new Date(fechaA).getTime() - new Date(fechaB).getTime();
    });
    
    // 8️⃣ Contador para tracking de depósitos usados
    const depositosUsados = new Map<string, boolean>();
    
    // 9️⃣ Procesar cada pack
    const reparaciones = [];
    
    for (const pack of packsOrdenados) {
      console.log(`\n🔧 Procesando pack ${pack.id.substring(0, 8)}...`);
      console.log(`   Monto: $${pack.monto}`);
      console.log(`   Status actual: ${pack.status}`);
      
      const montoKey = Math.round(pack.monto * 100) / 100;
      const actualizaciones: any = {};
      
      // Reconstruir el tipo basado en el monto
      if (!pack.tipo || pack.tipo === '') {
        actualizaciones.tipo = `Pack ${pack.monto}`;
        console.log(`   ✏️ Tipo reconstruido: ${actualizaciones.tipo}`);
      }
      
      // 🔍 Buscar depósito verificado correspondiente (que no haya sido usado)
      let depositoCorrespondiente = null;
      const depositosDisponibles = depositosPorMonto.get(montoKey) || [];
      
      for (const dep of depositosDisponibles) {
        if (!depositosUsados.has(dep.id)) {
          depositoCorrespondiente = dep;
          depositosUsados.set(dep.id, true);
          break;
        }
      }
      
      // 🔍 Verificar si tiene depósito rechazado
      const tieneDepositoRechazado = (depositosRechazadosPorMonto.get(montoKey) || []).length > 0;
      
      // 💰 Calcular rendimiento total del pack
      const rendimientosPack = comisionesUsuario.filter((c: any) => 
        c.packId === pack.id && c.tipo === 'rendimiento'
      );
      const rendimientoTotal = rendimientosPack.reduce((sum: number, c: any) => sum + (c.monto || 0), 0);
      const limiteRendimiento = pack.monto * 2; // 200%
      const yaLlegoA200 = rendimientoTotal >= limiteRendimiento;
      
      console.log(`   📊 Rendimiento acumulado: $${rendimientoTotal.toFixed(2)} / $${limiteRendimiento.toFixed(2)}`);
      console.log(`   🎯 ¿Llegó al 200%? ${yaLlegoA200 ? 'SÍ' : 'NO'}`);
      
      // ✅ LÓGICA DE ACTIVACIÓN:
      // Un pack debe estar ACTIVO solo si:
      // 1. Tiene un depósito verificado Y
      // 2. NO ha llegado al 200% de rendimiento
      
      let nuevoStatus = 'inactivo';
      let razon = '';
      
      if (depositoCorrespondiente) {
        if (yaLlegoA200) {
          nuevoStatus = 'inactivo';
          razon = 'ya llegó al 200% de rendimiento';
          console.log(`   ⚠️ Pack inactivo: ${razon}`);
        } else {
          nuevoStatus = 'activo';
          razon = 'tiene depósito verificado y no ha llegado al 200%';
          console.log(`   ✅ Pack activo: ${razon}`);
        }
      } else {
        nuevoStatus = 'inactivo';
        if (tieneDepositoRechazado) {
          razon = 'depósito fue rechazado';
        } else {
          razon = 'sin depósito verificado';
        }
        console.log(`   ❌ Pack inactivo: ${razon}`);
      }
      
      // Aplicar actualizaciones
      actualizaciones.status = nuevoStatus;
      actualizaciones.activo = nuevoStatus === 'activo';
      
      // Establecer fecha de activación solo si tiene depósito verificado
      if (depositoCorrespondiente) {
        actualizaciones.fechaActivacion = depositoCorrespondiente.fechaProcesado || depositoCorrespondiente.fecha;
        console.log(`   📅 Fecha activación: ${actualizaciones.fechaActivacion}`);
      } else if (!pack.fechaActivacion) {
        // Si no tiene depósito verificado y tampoco tiene fecha, dejar en blanco
        actualizaciones.fechaActivacion = null;
      }
      
      // Asegurar que tiene rendimiento diario
      if (!pack.rendimientoDiario || pack.rendimientoDiario === 0) {
        actualizaciones.rendimientoDiario = pack.monto * 0.01; // 1% diario
        console.log(`   💵 Rendimiento diario: $${actualizaciones.rendimientoDiario}`);
      }
      
      // Actualizar el pack si hay cambios
      const hayActualizaciones = Object.keys(actualizaciones).length > 0;
      const cambioStatus = pack.status !== nuevoStatus;
      
      if (hayActualizaciones || cambioStatus) {
        await crm.updatePack(pack.id, actualizaciones);
        console.log(`   ✅ Pack ${pack.id.substring(0, 8)} actualizado`);
        
        reparaciones.push({
          packId: pack.id.substring(0, 8),
          monto: pack.monto,
          statusAnterior: pack.status,
          statusNuevo: nuevoStatus,
          razon: razon,
          rendimientoTotal: rendimientoTotal,
          depositoEncontrado: !!depositoCorrespondiente,
          actualizaciones: actualizaciones
        });
      } else {
        console.log(`   ℹ️ Pack ${pack.id.substring(0, 8)} sin cambios necesarios`);
      }
    }
    
    // 🔟 Invalidar caché
    invalidateCache();
    invalidateUserDashboard(usuario.id);
    
    console.log(`\n✅ Reparación completada: ${reparaciones.length} packs actualizados`);
    console.log('========== FIN REPARACIÓN ==========\n');
    
    return c.json({
      success: true,
      usuario: {
        id: usuario.id,
        nombre: `${usuario.nombre} ${usuario.apellido}`,
        idUnico: usuario.id_unico
      },
      packsRevisados: packs.length,
      packsActualizados: reparaciones.length,
      reparaciones: reparaciones,
      depositosVerificados: depositosVerificados.length,
      depositosRechazados: depositosRechazados.length
    });
    
  } catch (error: any) {
    console.error('❌ Error en reparación de packs:', error);
    return c.json({ 
      error: "Error al reparar packs",
      details: error?.message || String(error)
    }, 500);
  }
});

// ==========================================
// 🔍 DIAGNÓSTICO DE PACK ESPECÍFICO
// ==========================================
app.get("/make-server-9f68532a/admin/diagnostico-pack/:packId", async (c) => {
  try {
    const packId = c.req.param('packId');
    
    const allPacks = await crm.getAllPacks();
    const pack = allPacks.find((p: any) => p.id.startsWith(packId));
    
    if (!pack) {
      return c.json({ error: 'Pack no encontrado' }, 404);
    }
    
    const analisis = {
      id: pack.id,
      nombre: pack.nombre,
      monto: pack.monto,
      activo: pack.activo,
      activoTipo: typeof pack.activo,
      activoStrictTrue: pack.activo === true,
      depositoVerificado: pack.depositoVerificado,
      depositoVerificadoTipo: typeof pack.depositoVerificado,
      fechaCompra: pack.fechaCompra,
      userId: pack.userId,
      pasaFiltroActivo: pack.activo === true,
      pasaFiltroDeposito: pack.depositoVerificado === true || pack.depositoVerificado === undefined,
      pasaFiltroCompleto: (pack.activo === true) && (pack.depositoVerificado === true || pack.depositoVerificado === undefined),
      razonRechazo: pack.activo !== true ? 'Pack inactivo' : pack.depositoVerificado === false ? 'Depósito rechazado' : 'Debería procesarse'
    };
    
    return c.json({ success: true, pack: pack, analisis: analisis });
    
  } catch (error: any) {
    return c.json({ error: "Error al diagnosticar pack", details: error?.message || String(error) }, 500);
  }
});

// ==========================================
// 🔓 ACTIVAR PACK ESPECÍFICO
// ==========================================
app.post("/make-server-9f68532a/admin/activar-pack/:packId", async (c) => {
  try {
    const packId = c.req.param('packId');
    
    console.log(`\n🔓 [ACTIVAR PACK] Iniciando activación para pack: ${packId}`);
    
    const allPacks = await crm.getAllPacks();
    const pack = allPacks.find((p: any) => p.id.startsWith(packId));
    
    if (!pack) {
      return c.json({ error: 'Pack no encontrado' }, 404);
    }
    
    console.log(`📦 Pack encontrado: ${pack.nombre} ($${pack.monto})`);
    console.log(`   - Estado actual: ${pack.status}`);
    console.log(`   - activo: ${pack.activo}`);
    console.log(`   - depositoVerificado: ${pack.depositoVerificado}`);
    
    // Activar el pack
    const actualizaciones: any = {
      status: 'activo',
      activo: true,
      depositoVerificado: pack.depositoVerificado !== false ? true : true, // Activar depositoVerificado también
    };
    
    // Si no tiene fecha de activación, agregarla
    if (!pack.fechaActivacion) {
      actualizaciones.fechaActivacion = new Date().toISOString();
      console.log(`   ➕ Agregando fechaActivacion: ${actualizaciones.fechaActivacion}`);
    }
    
    // Limpiar campos de desactivación si existen
    if (pack.fechaDesactivacion) {
      actualizaciones.fechaDesactivacion = null;
      actualizaciones.motivoDesactivacion = null;
      console.log(`   🗑️ Limpiando fechaDesactivacion y motivoDesactivacion`);
    }
    
    await crm.updatePack(pack.id, actualizaciones);
    
    console.log(`✅ Pack ${pack.id} activado correctamente`);
    console.log(`   - Nuevo estado: activo`);
    console.log(`   - depositoVerificado: true`);
    
    // Obtener pack actualizado
    const allPacksActualizados = await crm.getAllPacks();
    const packActualizado = allPacksActualizados.find((p: any) => p.id === pack.id);
    
    return c.json({ 
      success: true, 
      mensaje: `Pack ${pack.nombre} activado correctamente`,
      packAnterior: {
        status: pack.status,
        activo: pack.activo,
        depositoVerificado: pack.depositoVerificado
      },
      packActualizado: {
        id: packActualizado.id,
        nombre: packActualizado.nombre,
        monto: packActualizado.monto,
        status: packActualizado.status,
        activo: packActualizado.activo,
        depositoVerificado: packActualizado.depositoVerificado,
        fechaActivacion: packActualizado.fechaActivacion
      }
    });
    
  } catch (error: any) {
    console.error('❌ Error al activar pack:', error);
    return c.json({ error: "Error al activar pack", details: error?.message || String(error) }, 500);
  }
});

// ==========================================
// 🛠️ CORREGIR RENDIMIENTOS HISTÓRICOS FALTANTES
// ==========================================
app.post("/make-server-9f68532a/admin/corregir-rendimientos-historicos/:userId", async (c) => {
  try {
    const userId = c.req.param('userId');
    
    console.log(`\n🚀🚀🚀 ========================================`);
    console.log(`🚀🚀🚀 VERSIÓN 2.0 - CÓDIGO ACTUALIZADO`);
    console.log(`🚀����🚀 ========================================`);
    console.log(`🔧 [CORRECCIÓN] Iniciando corrección de rendimientos históricos para usuario ${userId}`);
    
    // 1. Obtener todos los packs del usuario (SOLO ACTIVOS)
    const allPacks = await crm.getAllPacks();
    const allUserPacks = allPacks.filter((p: any) => p.userId === userId);
    
    // 🔍 DEBUG SUPER DETALLADO: Ver el valor exacto de "activo" y "status"
    console.log(`\n🔍 DEBUG DETALLADO - Valor de "activo" y "status" en cada pack:`);
    allUserPacks.forEach((pack: any, idx: number) => {
      console.log(`  ${idx + 1}. ${pack.nombre} (ID: ${pack.id})`);
      console.log(`     - activo (valor): ${pack.activo}`);
      console.log(`     - activo (tipo): ${typeof pack.activo}`);
      console.log(`     - status: ${pack.status}`);
      console.log(`     - activo === true: ${pack.activo === true}`);
      console.log(`     - status === 'activo': ${pack.status === 'activo'}`);
      console.log(`     - depositoVerificado: ${pack.depositoVerificado}`);
      console.log(`     - fechaCompra: ${pack.fechaCompra}`);
    });
    
    // ✅ FILTRO CORREGIDO: Usar status === 'activo' en lugar de activo === true
    // NOTA: depositoVerificado puede ser undefined en packs antiguos, eso es OK
    const userPacks = allUserPacks.filter((p: any) => 
      p.status === 'activo' && (p.depositoVerificado === true || p.depositoVerificado === undefined)
    );
    const inactivePacks = allUserPacks.filter((p: any) => 
      p.status !== 'activo' || (p.depositoVerificado === false)
    );
    
    console.log(`\n📦 Resumen de packs:`);
    console.log(`   - Total: ${allUserPacks.length}`);
    console.log(`   - Activos para corregir: ${userPacks.length}`);
    console.log(`   - Inactivos o rechazados: ${inactivePacks.length} (serán ignorados)`);
    
    console.log(`\n✅ PACKS QUE SE VAN A PROCESAR:`);
    userPacks.forEach((pack: any, idx: number) => {
      console.log(`  ${idx + 1}. ${pack.nombre} ($${pack.monto}) - ID: ${pack.id}`);
      console.log(`     - depositoVerificado: ${pack.depositoVerificado}`);
    });
    
    console.log(`\n❌ PACKS QUE SERÁN IGNORADOS:`);
    inactivePacks.forEach((pack: any, idx: number) => {
      console.log(`  ${idx + 1}. ${pack.nombre} ($${pack.monto}) - ID: ${pack.id}`);
      console.log(`     - status: ${pack.status}`);
      console.log(`     - Razón: ${pack.status !== 'activo' ? 'Pack inactivo' : 'Depósito rechazado explícitamente'}`);
    });
    
    if (userPacks.length === 0) {
      return c.json({ 
        error: 'Usuario sin packs activos',
        mensaje: `El usuario tiene ${allUserPacks.length} pack(s) total, pero ninguno está activo.`
      }, 404);
    }
    
    console.log(`\n📦 Procesando ${userPacks.length} pack(s) ACTIVO(S)`);
    
    // 2. Obtener todas las comisiones del usuario
    const allComisiones = await crm.getAllComisiones();
    const userComisiones = allComisiones.filter((com: any) => com.userId === userId);
    
    console.log(`💰 Comisiones existentes: ${userComisiones.length}`);
    
    // 2.1 LIMPIAR correcciones históricas previas para evitar duplicados
    const correccionesAnteriores = userComisiones.filter((c: any) => 
      c.tipo === 'rendimiento' && c.descripcion?.includes('Corrección histórica')
    );
    
    if (correccionesAnteriores.length > 0) {
      console.log(`🗑️ Eliminando ${correccionesAnteriores.length} correcciones históricas anteriores...`);
      for (const corr of correccionesAnteriores) {
        await crm.deleteComision(corr.id);
      }
      console.log(`✅ Correcciones anteriores eliminadas`);
      
      // Refrescar la lista de comisiones
      const allComisionesRefrescadas = await crm.getAllComisiones();
      userComisiones.length = 0;
      userComisiones.push(...allComisionesRefrescadas.filter((com: any) => com.userId === userId));
    }
    
    // 3. Analizar cada pack para determinar rendimientos faltantes
    const correcionesRealizadas: any[] = [];
    
    for (const pack of userPacks) {
      // ✅ TRIPLE VERIFICACIÓN: status === 'activo' (campo correcto)
      if (pack.status !== 'activo') {
        console.log(`⏭️ Pack ${pack.nombre} (${pack.id}) está INACTIVO (status: ${pack.status}), saltando...`);
        continue;
      }
      
      // Solo verificar depositoVerificado si existe y es explícitamente false
      if (pack.depositoVerificado === false) {
        console.log(`⏭️ Pack ${pack.nombre} (${pack.id}) con depósito rechazado, saltando...`);
        continue;
      }
      
      // Saltar packs sin fecha de compra
      if (!pack.fechaCompra) {
        console.log(`⏭️ Pack ${pack.nombre} (${pack.id}) sin fecha de compra, saltando...`);
        continue;
      }
      
      console.log(`\n✅ PROCESANDO PACK: ${pack.nombre} (ID: ${pack.id})`);
      
      // Calcular rendimientos registrados para este pack
      // IMPORTANTE: NO contar correcciones históricas previas para evitar duplicados
      const rendimientosDelPack = userComisiones.filter((c: any) => 
        c.tipo === 'rendimiento' && 
        c.packId === pack.id &&
        !c.descripcion?.includes('Corrección histórica')
      );
      
      const rendimientoRegistrado = rendimientosDelPack.reduce((sum: number, c: any) => sum + (c.monto || 0), 0);
      const limiteRendimiento = pack.monto * 2; // 200%
      const rendimientoFaltante = limiteRendimiento - rendimientoRegistrado;
      
      console.log(`📊 Análisis Pack ${pack.nombre} ($${pack.monto}):`);
      console.log(`   - Pack ID: ${pack.id}`);
      console.log(`   - Estado activo: ${pack.activo} (${typeof pack.activo})`);
      console.log(`   - Depósito verificado: ${pack.depositoVerificado}`);
      console.log(`   - Fecha compra: ${pack.fechaCompra}`);
      console.log(`   - Rendimientos encontrados para este pack: ${rendimientosDelPack.length}`);
      console.log(`   - Rendimiento registrado (sin correcciones): $${rendimientoRegistrado.toFixed(2)}`);
      console.log(`   - Límite 200%: $${limiteRendimiento.toFixed(2)}`);
      console.log(`   - Faltante: $${rendimientoFaltante.toFixed(2)}`);
      
      // Solo corregir si falta una cantidad significativa (más de $50)
      if (rendimientoFaltante >= 50) {
        console.log(`   🔧 Corrigiendo rendimientos faltantes...`);
        
        // Crear comisión de corrección
        const fechaCorreccion = new Date().toISOString();
        const comisionCorreccion = {
          id: crypto.randomUUID(),
          userId: userId,
          packId: pack.id,
          tipo: 'rendimiento',
          monto: rendimientoFaltante,
          descripcion: `Corrección histórica: Rendimientos ${pack.nombre} (completar 200%)`,
          fecha: fechaCorreccion,
          estado: 'completado'
        };
        
        // Guardar en la base de datos
        console.log(`   💾 Intentando guardar comisión de corrección...`);
        console.log(`   💰 Monto a guardar: $${rendimientoFaltante.toFixed(2)}`);
        console.log(`   📦 Pack ID: ${pack.id}`);
        const comisionGuardada = await crm.createComision(comisionCorreccion);
        console.log(`   ✅ Comisión guardada exitosamente:`, comisionGuardada);
        
        correcionesRealizadas.push({
          pack: pack.nombre,
          packId: pack.id,
          monto: pack.monto,
          rendimientoAnterior: rendimientoRegistrado,
          rendimientoAgregado: rendimientoFaltante,
          nuevoTotal: limiteRendimiento
        });
      } else if (rendimientoFaltante > 0) {
        console.log(`   ℹ️ Faltante menor a $50 ($${rendimientoFaltante.toFixed(2)}), no se requiere corrección automática`);
      } else {
        console.log(`   ✅ Pack completo (200% alcanzado)`);
      }
    }
    
    // 4. Invalidar caché del dashboard
    cacheDashboards.delete(userId);
    console.log(`\n🔄 Caché del usuario invalidado`);
    
    // 5. Recalcular totales
    const allComisionesActualizadas = await crm.getAllComisiones();
    const userComisionesActualizadas = allComisionesActualizadas.filter((com: any) => com.userId === userId);
    const totalCorregido = userComisionesActualizadas.reduce((sum: number, c: any) => sum + (c.monto || 0), 0);
    
    // 🔍 DEBUG: Verificar correcciones guardadas
    const correccionesGuardadas = userComisionesActualizadas.filter((c: any) => 
      c.descripcion?.includes('Corrección histórica')
    );
    console.log(`\n🔍 DEBUG - Correcciones guardadas en BD: ${correccionesGuardadas.length}`);
    correccionesGuardadas.forEach((corr: any, idx: number) => {
      console.log(`  ${idx + 1}. $${corr.monto} - ${corr.descripcion} (Pack ID: ${corr.packId})`);
    });
    
    console.log(`\n📋 Resumen de correcciones realizadas:`);
    correcionesRealizadas.forEach((c: any, idx: number) => {
      console.log(`  ${idx + 1}. ${c.pack} (ID: ${c.packId}) - Agregado: $${c.rendimientoAgregado.toFixed(2)}`);
    });
    
    console.log(`\n✅ [CORRECCIÓN] Proceso completado`);
    console.log(`   - Correcciones realizadas: ${correcionesRealizadas.length}`);
    console.log(`   - Total comisiones ANTES: $${userComisiones.reduce((sum: number, c: any) => sum + (c.monto || 0), 0).toFixed(2)}`);
    console.log(`   - Total comisiones DESPUÉS: $${totalCorregido.toFixed(2)}`);
    
    return c.json({
      success: true,
      correccionesRealizadas: correcionesRealizadas,
      totalComisionesAntes: userComisiones.reduce((sum: number, c: any) => sum + (c.monto || 0), 0),
      totalComisionesDespues: totalCorregido,
      mensaje: correcionesRealizadas.length > 0 
        ? `Se corrigieron ${correcionesRealizadas.length} packs` 
        : 'No se encontraron correcciones necesarias'
    });
    
  } catch (error: any) {
    console.error('❌ Error en corrección de rendimientos:', error);
    return c.json({ 
      error: "Error al corregir rendimientos",
      details: error?.message || String(error)
    }, 500);
  }
});

// ⚡ PRE-CALENTAR CACHÉ AL INICIO DEL SERVIDOR (para reducir primera carga)
console.log('🔥 [INIT] Iniciando servidor de Liberty Finance...');
console.log('🔥 [INIT] Pre-calentamiento de caché en background (puede tardar 60-90 segundos)...');
const preloadStartTime = Date.now();

// ✅ DESACTIVAR MANTENIMIENTO AL INICIAR SERVIDOR
kv.set('config:mantenimiento', { activo: false, ultimaActualizacion: new Date().toISOString() })
  .then(() => console.log('✅ [INIT] Mantenimiento desactivado'))
  .catch(err => console.warn('⚠️ [INIT] Error desactivando mantenimiento:', err.message));

// ✅ CRÍTICO: Iniciar servidor INMEDIATAMENTE, caché en background
Deno.serve(app.fetch);

// Ejecutar limpieza de locks y caché en paralelo (en background, no bloqueante)
Promise.all([
  limpiarLocksAntiguos().catch(err => {
    console.warn('⚠️ [INIT] Error limpiando locks:', err.message);
    return null;
  }),
  getCachedUsuarios().catch(err => {
    console.warn('⚠️ [INIT] Error cargando usuarios:', err.message);
    return [];
  }),
  getCachedPacks().catch(err => {
    console.warn('⚠️ [INIT] Error cargando packs:', err.message);
    return [];
  }),
  getCachedComisiones().catch(err => {
    console.warn('⚠️ [INIT] Error cargando comisiones:', err.message);
    return [];
  })
])
  .then(() => {
    const totalTime = Date.now() - preloadStartTime;
    console.log(`✅ [INIT] Caché pre-calentado completamente en ${(totalTime/1000).toFixed(1)}s`);
    console.log(`🚀 [INIT] Sistema completamente operativo`);
  })
  .catch(err => {
    console.warn('⚠️ [INIT] Error en inicialización (no crítico):', err.message);
    console.warn('⚠️ [INIT] El sistema se inicializará con la primera petición');
  });