import * as kv from "./kv_store.tsx";
import { createClient } from "npm:@supabase/supabase-js@2";

// ==========================================
// TIPOS DE DATOS DEL CRM
// ==========================================

export interface User {
  id: string;
  id_unico: string;
  nombre: string;
  apellido: string;
  email: string;
  telefono: string;
  ciudad?: string; // Opcional
  wallet?: string; // Opcional
  password: string;
  referralCode: string;
  referidoPor?: string; // ID del usuario que lo refirió
  fechaRegistro: string;
  activo: boolean;
  rango?: string; // Rango del usuario (Silver, Gold, etc) - default "Sin Rango"
}

export interface Pack {
  id: string;
  userId: string;
  nombre: string; // Pack 50, Pack 100, etc.
  monto: number;
  fechaCompra: string;
  activo: boolean;
  rendimientoDiario: number;
  matrizPadre?: string; // ID del usuario que es el padre en la matriz (para spillover)
  matrizNivel?: number; // Nivel en la matriz del patrocinador
  matrizPosicion?: number; // Posición en ese nivel
}

export interface Comision {
  id: string;
  userId: string;
  tipo: 'red' | 'patrocinio' | 'rendimiento';
  monto: number;
  nivel?: number; // Para comisiones de red
  referidoId?: string; // ID del referido que generó la comisión
  fecha: string;
  descripcion: string;
}

export interface Cobro {
  id: string;
  userId: string;
  monto: number;
  wallet: string;
  estado: 'pendiente' | 'aprobado' | 'rechazado' | 'completado';
  fecha: string;
  fechaProcesado?: string;
  txHash?: string;
  metodo?: string; // Método de cobro (ej: "Compra con Wallet", "Retiro USDT")
  walletDestino?: string; // Wallet de destino (puede ser "Sistema Interno")
  descripcion?: string; // Descripción del cobro
}

export interface Rendimiento {
  id: string;
  userId: string;
  monto: number;
  porcentaje: number;
  fecha: string;
}

export interface Deposito {
  id: string;
  userId: string;
  packNombre: string;
  monto: number;
  walletDestino: string; // Wallet del admin donde depositó
  comprobante?: string; // URL del comprobante de pago o payment_id de NOWPayments
  estado: 'pendiente' | 'verificado' | 'rechazado';
  fecha: string;
  fechaProcesado?: string;
  procesadoPor?: string; // ID del admin que procesó
  metodoPago?: 'manual' | 'nowpayments'; // Método de pago usado
  paymentId?: string; // ID del pago de NOWPayments
  txHash?: string; // Hash de transacción para depósitos manuales
}

export interface ConfiguracionAdmin {
  walletPrincipal: string;
  walletsSecundarios?: string[];
  comisionReferidoDirecto: number; // Default 10%
  qrCodeUrl?: string; // URL o base64 del código QR
  rendimientoActivo?: boolean; // Control manual del rendimiento diario
  porcentajeRendimiento?: number; // Porcentaje personalizado del rendimiento diario
  ultimaActualizacion: string;
}

export interface Producto {
  id: string;
  nombre: string;
  descripcion: string;
  precio: number; // En USDT
  imagen?: string;
  stock: number;
  activo: boolean;
}

export interface Rango {
  id: string;
  nombre: string;
  directos: number; // Número de referidos directos requeridos
  volumen: number; // Volumen de red requerido en USDT
  premio: string; // Descripción del premio
  color: string; // Color del rango (para UI)
  gradient: string; // Gradiente Tailwind
  icon: string; // Emoji o icono
  imagen: string; // URL de imagen de fondo
}

export interface CompraProducto {
  id: string;
  userId: string;
  productoId: string;
  cantidad: number;
  precioTotal: number;
  fecha: string;
  estado: 'pendiente' | 'enviado' | 'entregado';
}

export interface PuntosUsuario {
  userId: string;
  puntos: number;
  ultimaActualizacion: string;
}

export interface RuletaHistorial {
  id: string;
  userId: string;
  premio: string;
  puntos?: number;
  fecha: string;
}

export interface GastoRuleta {
  id: string;
  userId: string;
  monto: number;
  fecha: string;
}

// ==========================================
// FUNCIONES DE USUARIOS
// ==========================================

export async function createUser(userData: Omit<User, 'id' | 'fechaRegistro' | 'activo'>): Promise<User> {
  const id = crypto.randomUUID();
  const user: User = {
    ...userData,
    id,
    fechaRegistro: new Date().toISOString(),
    activo: true, // Usuario se activa automáticamente al registrarse
    rango: userData.rango || 'Sin Rango' // Establecer "Sin Rango" por defecto
  };
  
  await kv.set(`user:${id}`, user);
  await kv.set(`user:email:${userData.email}`, id);
  await kv.set(`user:idUnico:${userData.id_unico}`, id);
  
  return user;
}

export async function getUserById(userId: string): Promise<User | null> {
  return await kv.get(`user:${userId}`);
}

export async function getUserByEmail(email: string): Promise<User | null> {
  const userId = await kv.get(`user:email:${email}`);
  if (!userId) return null;
  return await getUserById(userId);
}

export async function getUserByIdUnico(id_unico: string): Promise<User | null> {
  const userId = await kv.get(`user:idUnico:${id_unico}`);
  if (!userId) return null;
  return await getUserById(userId);
}

export async function getAllUsers(): Promise<User[]> {
  // Usar paginación para obtener TODOS los registros (sin límite de 1000)
  const supabase = createClient(
    Deno.env.get('SUPABASE_URL'),
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')
  );
  
  console.log('🚀 getAllUsers - USANDO PAGINACIÓN SIN LÍMITES');
  
  let allRawData: any[] = [];
  let pageSize = 200; // Reducido de 300 a 200 para evitar sobrecarga
  let currentPage = 0;
  let hasMore = true;
  
  // RETRY LOGIC: Configuración
  const MAX_RETRIES = 7; // Aumentado a 7 para manejar errores 500
  const RETRY_DELAY_MS = 3000; // Aumentado a 3 segundos para evitar sobrecarga
  
  // Helper function para retry con exponential backoff
  async function fetchPageWithRetry(page: number, attempt = 0): Promise<any[]> {
    try {
      const { data: pageData, error } = await supabase
        .from('kv_store_9f68532a')
        .select('key, value')
        .like('key', 'user:%')
        .range(page * pageSize, (page + 1) * pageSize - 1);
      
      if (error) {
        throw error;
      }
      
      return pageData || [];
    } catch (error: any) {
      // Si es un error de conexión/gateway y aún tenemos retries disponibles
      const shouldRetry = attempt < MAX_RETRIES && (
        error.message?.includes('connection') || 
        error.message?.includes('reset') ||
        error.message?.includes('timeout') ||
        error.message?.includes('reading a body') ||
        error.message?.includes('500') ||
        error.message?.includes('502 Bad Gateway') ||
        error.message?.includes('503 Service Unavailable') ||
        error.message?.includes('504 Gateway Timeout') ||
        error.message?.includes('Internal server error') ||
        error.message?.includes('<html>') // HTML error responses de Cloudflare
      );
      
      if (shouldRetry) {
        const delay = RETRY_DELAY_MS * Math.pow(2, attempt); // Exponential backoff
        console.warn(`⚠️ Error de conexión/gateway en página ${page + 1}, reintentando en ${delay}ms (intento ${attempt + 1}/${MAX_RETRIES})...`);
        
        // Esperar antes de reintentar
        await new Promise(resolve => setTimeout(resolve, delay));
        
        // Reintentar
        return fetchPageWithRetry(page, attempt + 1);
      }
      
      // Si agotamos los retries o es otro tipo de error
      console.error('❌ Error al obtener usuarios (página', page, '):', error);
      throw error;
    }
  }
  
  // Paginar hasta obtener todos los registros
  while (hasMore) {
    const pageData = await fetchPageWithRetry(currentPage);
    
    if (!pageData || pageData.length === 0) {
      hasMore = false;
    } else {
      allRawData = [...allRawData, ...pageData];
      console.log(`   📄 Página ${currentPage + 1}: ${pageData.length} registros (Total acumulado: ${allRawData.length})`);
      
      // Si recibimos menos registros que el tamaño de página, es la última página
      if (pageData.length < pageSize) {
        hasMore = false;
      } else {
        // Delay entre páginas para evitar sobrecarga (aumentado a 1 segundo)
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
      
      currentPage++;
    }
  }
  
  const rawData = allRawData;
  
  console.log('🔍 getAllUsers - Total items con prefijo user:', rawData?.length || 0);
  console.log('🚀 CÓDIGO DESPLEGADO - PAGINACIÓN COMPLETA ACTIVA'); // ← Confirmar despliegue
  
  // DEBUG: Buscar los 3 usuarios problemáticos en datos RAW POR SU UUID
  const usuariosProblematicos = [
    { idUnico: 'LF1765918120109793', uuid: '939da466-e00d-441f-8e17-d6e4b202ec34' },
    { idUnico: 'LF1766081702464905', uuid: '5b5b40d0-f38d-46fe-8b18-2342d8f27517' },
    { idUnico: 'LF1766035063633662', uuid: 'eadd906b-868f-46b6-98e3-b1699b5e56c8' }
  ];
  
  usuariosProblematicos.forEach(({ idUnico, uuid }) => {
    // Buscar por la KEY exacta: user:UUID
    const usuarioRaw = (rawData || []).find((row: any) => row.key === `user:${uuid}`);
    
    if (usuarioRaw) {
      console.log(`\n🔍 USUARIO ${idUnico} (${uuid}) EN RAWDATA:`, {
        key: usuarioRaw.key,
        valueType: typeof usuarioRaw.value,
        valueIsObject: typeof usuarioRaw.value === 'object',
        valueIsNull: usuarioRaw.value === null,
        id_unico: usuarioRaw.value?.id_unico,
        nombre: usuarioRaw.value?.nombre,
        nombreType: typeof usuarioRaw.value?.nombre,
        nombreIsString: typeof usuarioRaw.value?.nombre === 'string',
        email: usuarioRaw.value?.email,
        emailType: typeof usuarioRaw.value?.email,
        emailIsString: typeof usuarioRaw.value?.email === 'string',
        hasNombreCheck: !!(usuarioRaw.value?.nombre && typeof usuarioRaw.value?.nombre === 'string'),
        hasEmailCheck: !!(usuarioRaw.value?.email && typeof usuarioRaw.value?.email === 'string'),
        pasariaFiltroCompleto: !!(
          usuarioRaw.value &&
          typeof usuarioRaw.value === 'object' &&
          (
            (usuarioRaw.value?.nombre && typeof usuarioRaw.value?.nombre === 'string') ||
            (usuarioRaw.value?.email && typeof usuarioRaw.value?.email === 'string')
          )
        )
      });
    } else {
      console.log(`\n❌ USUARIO ${idUnico} (user:${uuid}) NO ENCONTRADO EN RAWDATA`);
      
      // Buscar si existe con otra key
      const cualquierOtra = (rawData || []).find((row: any) => 
        row.value?.id_unico === idUnico ||
        row.key?.includes(uuid)
      );
      if (cualquierOtra) {
        console.log(`   ⚠️ PERO SÍ EXISTE CON KEY: ${cualquierOtra.key}`);
      }
    }
  });
  
  // Filtrar y mapear usuarios, agregando el ID desde la key
  const users = (rawData || [])
    .filter((row: any) => {
      // Solo registros con value como objeto
      if (!row.value || typeof row.value !== 'object') {
        return false;
      }
      
      const key = row.key as string;
      
      // SOLO aceptar registros con formato exacto: user:{UUID}
      // Excluir:
      // - Mapeos: user:email:xxx, user:idUnico:xxx
      // - Sub-colecciones: user:xxx:comision:xxx, user:xxx:rendimiento:xxx, etc.
      if (!key.startsWith('user:')) {
        return false;
      }
      
      // Remover el prefijo "user:"
      const afterPrefix = key.substring(5);
      
      // Verificar que NO tenga más ":" (lo que indicaría mapeos o sub-colecciones)
      if (afterPrefix.includes(':')) {
        return false;
      }
      
      // Verificar que sea un UUID válido (36 caracteres con guiones)
      const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
      if (!uuidRegex.test(afterPrefix)) {
        return false;
      }
      
      // Verificar que tiene estructura de usuario
      const hasNombre = row.value.nombre && typeof row.value.nombre === 'string';
      const hasEmail = row.value.email && typeof row.value.email === 'string';
      
      return hasNombre || hasEmail; // Al menos uno debe existir
    })
    .map((row: any) => {
      // Extraer el ID desde la key (user:UUID -> UUID)
      const id = row.key.replace('user:', '');
      
      return {
        ...row.value,
        id // Agregar el campo id que falta
      };
    });
  
  console.log('✅ getAllUsers - Usuarios válidos encontrados:', users.length);
  if (users.length > 0) {
    console.log('  - Primer usuario:', users[0].nombre, users[0].apellido, users[0].id);
  }
  
  // 🔧 FIX: Búsqueda exhaustiva de usuarios perdidos
  // Buscar TODOS los registros con formato user:UUID (sin sub-keys)
  const todosLosUUIDs = (rawData || [])
    .filter((row: any) => {
      const key = row.key as string;
      if (!key?.startsWith('user:')) return false;
      const afterPrefix = key.substring(5);
      // Solo UUIDs puros (sin :)
      if (afterPrefix.includes(':')) return false;
      // Validar formato UUID
      const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
      return uuidRegex.test(afterPrefix);
    })
    .map((row: any) => {
      const id = row.key.replace('user:', '');
      return {
        ...row.value,
        id,
        __source: 'exhaustive_search'
      };
    });
  
  console.log(`🔍 Búsqueda exhaustiva encontró ${todosLosUUIDs.length} registros user:UUID`);
  
  // Encontrar usuarios que estén en todosLosUUIDs pero NO en users
  const usuariosPerdidos = todosLosUUIDs.filter((uuid: any) => {
    // Verificar que tenga nombre O email
    const tieneNombre = uuid.nombre && typeof uuid.nombre === 'string' && uuid.nombre.trim().length > 0;
    const tieneEmail = uuid.email && typeof uuid.email === 'string' && uuid.email.trim().length > 0;
    if (!tieneNombre && !tieneEmail) return false;
    
    // Verificar que NO esté ya en users
    const yaExiste = users.some((u: any) => u.id === uuid.id);
    return !yaExiste;
  });
  
  if (usuariosPerdidos.length > 0) {
    console.log(`⚠️ ENCONTRADOS ${usuariosPerdidos.length} USUARIOS PERDIDOS POR EL FILTRO:`);
    usuariosPerdidos.forEach((u: any) => {
      console.log(`   - ${u.nombre} ${u.apellido} (${u.id_unico}) - ${u.email}`);
    });
    
    // Agregar los usuarios perdidos al resultado
    users.push(...usuariosPerdidos);
    console.log(`✅ Usuarios totales después de recuperación: ${users.length}`);
  }
  
  return users;
}

export async function updateUser(userId: string, updates: Partial<User>): Promise<User | null> {
  const user = await getUserById(userId);
  if (!user) return null;
  
  const updatedUser = { ...user, ...updates };
  await kv.set(`user:${userId}`, updatedUser);
  
  return updatedUser;
}

export async function deleteUser(userId: string): Promise<boolean> {
  const user = await getUserById(userId);
  if (!user) return false;
  
  // Eliminar el usuario de la base de datos
  await kv.del(`user:${userId}`);
  
  // Eliminar índices
  if (user.email) {
    await kv.del(`user:email:${user.email}`);
  }
  if (user.id_unico) {
    await kv.del(`user:idUnico:${user.id_unico}`);
  }
  if (user.referralCode) {
    await kv.del(`user:referralCode:${user.referralCode}`);
  }
  
  return true;
}

// ==========================================
// FUNCIONES DE PACKS
// ==========================================

export async function createPack(packData: Omit<Pack, 'id' | 'fechaCompra' | 'activo'>): Promise<Pack> {
  const id = crypto.randomUUID();
  const pack: Pack = {
    ...packData,
    id,
    fechaCompra: new Date().toISOString(),
    activo: true
  };
  
  await kv.set(`pack:${id}`, pack);
  await kv.set(`user:${packData.userId}:pack:${id}`, pack);
  
  return pack;
}

export async function getPacksByUserId(userId: string): Promise<Pack[]> {
  const packs = await kv.getByPrefix(`user:${userId}:pack:`);
  return packs;
}

export async function getAllPacks(): Promise<Pack[]> {
  const packs = await kv.getByPrefix('pack:');
  return packs.filter((p: any) => p && p.id && !p.id.includes(':'));
}

export async function updatePack(packId: string, updates: Partial<Pack>): Promise<Pack | null> {
  const pack = await kv.get(`pack:${packId}`);
  if (!pack) return null;
  
  const updatedPack = { ...pack, ...updates };
  await kv.set(`pack:${packId}`, updatedPack);
  await kv.set(`user:${pack.userId}:pack:${packId}`, updatedPack);
  
  return updatedPack;
}

// ==========================================
// FUNCIONES DE COMISIONES
// ==========================================

export async function createComision(comisionData: Omit<Comision, 'id' | 'fecha'>): Promise<Comision> {
  // ✅ VALIDACIÓN ANTI-DUPLICADOS CON LOCK ATÓMICO: Si es rendimiento, usar sistema de bloqueo
  if (comisionData.tipo === 'rendimiento') {
    const hoy = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
    const lockKey = `rendimiento:lock:${comisionData.userId}:${hoy}`;
    
    // 🔒 Intentar adquirir lock atómico
    const existeLock = await kv.get(lockKey);
    
    if (existeLock) {
      console.log(`⚠️ [ANTI-DUPLICADO] Lock ya existe para usuario ${comisionData.userId} hoy (${hoy}). Rendimiento ya procesado.`);
      // Retornar el rendimiento existente
      const comisionesUsuario = await getComisionesByUserId(comisionData.userId);
      const rendimientoHoy = comisionesUsuario.find((c: Comision) => {
        const fechaComision = new Date(c.fecha).toISOString().split('T')[0];
        return c.tipo === 'rendimiento' && fechaComision === hoy;
      });
      
      if (rendimientoHoy) {
        return rendimientoHoy;
      }
      
      // Si no encontramos el rendimiento pero existe el lock, hay inconsistencia
      console.warn(`⚠️ Lock existe pero no encontramos rendimiento. Procediendo con creación.`);
    }
    
    // 🔐 Crear lock ANTES de verificar/crear (ATOMICIDAD)
    await kv.set(lockKey, {
      userId: comisionData.userId,
      fecha: hoy,
      timestamp: new Date().toISOString(),
      locked: true
    });
    
    console.log(`🔒 Lock adquirido para usuario ${comisionData.userId} en ${hoy}`);
    
    // Verificar una vez más que no exista (por si acaso)
    const comisionesUsuario = await getComisionesByUserId(comisionData.userId);
    const rendimientoHoy = comisionesUsuario.find((c: Comision) => {
      const fechaComision = new Date(c.fecha).toISOString().split('T')[0];
      return c.tipo === 'rendimiento' && fechaComision === hoy;
    });
    
    if (rendimientoHoy) {
      console.log(`⚠️ [ANTI-DUPLICADO] Rendimiento creado entre lock y verificación. Retornando existente.`);
      return rendimientoHoy;
    }
  }
  
  const id = crypto.randomUUID();
  const comision: Comision = {
    ...comisionData,
    id,
    fecha: new Date().toISOString()
  };
  
  await kv.set(`comision:${id}`, comision);
  await kv.set(`user:${comisionData.userId}:comision:${id}`, comision);
  
  console.log(`✅ Comisión creada: ${comision.tipo} - $${comision.monto} para usuario ${comisionData.userId}`);
  
  return comision;
}

export async function getComisionesByUserId(userId: string): Promise<Comision[]> {
  const comisiones = await kv.getByPrefix(`user:${userId}:comision:`);
  
  // 🐛 DEBUG: Log detallado si está vacío
  if (!comisiones || comisiones.length === 0) {
    console.warn(`⚠️ getComisionesByUserId: No se encontraron comisiones para userId ${userId}`);
    console.warn(`🔍 Prefijo buscado: user:${userId}:comision:`);
    
    // Intentar buscar comisiones globales para este usuario
    const todasComisiones = await kv.getByPrefix('comision:');
    const comisionesDelUsuario = todasComisiones.filter((c: any) => c && c.userId === userId);
    
    console.warn(`🔍 Comisiones globales encontradas para este usuario: ${comisionesDelUsuario.length}`);
    
    if (comisionesDelUsuario.length > 0) {
      console.warn(`💡 Se encontraron ${comisionesDelUsuario.length} comisiones en el índice global pero no en el índice de usuario`);
      console.warn(`📋 Ejemplos:`, comisionesDelUsuario.slice(0, 3).map(c => ({ tipo: c.tipo, monto: c.monto, fecha: c.fecha })));
      
      // Retornar las comisiones encontradas en el índice global
      return comisionesDelUsuario;
    }
  }
  
  return comisiones;
}

export async function getAllComisiones(): Promise<Comision[]> {
  const comisiones = await kv.getByPrefix('comision:');
  return comisiones.filter((c: any) => c && c.id && !c.id.includes(':'));
}

export async function getTotalComisionesByUserId(userId: string): Promise<number> {
  const comisiones = await getComisionesByUserId(userId);
  return comisiones.reduce((total, c) => total + c.monto, 0);
}

export async function updateComision(comisionId: string, updates: Partial<Comision>): Promise<Comision | null> {
  // Buscar comisión globalmente (no hay getById directo para comision, usamos get directo a KV si conocemos la key)
  // Pero la key es `comision:${id}`
  const comision = await kv.get(`comision:${comisionId}`);
  
  if (!comision) {
     console.warn(`⚠️ Comisión ${comisionId} no encontrada para update`);
     return null;
  }
  
  const updatedComision = { ...comision, ...updates };
  
  // Actualizar en global
  await kv.set(`comision:${comisionId}`, updatedComision);
  
  // Actualizar en indice de usuario
  await kv.set(`user:${comision.userId}:comision:${comisionId}`, updatedComision);
  
  return updatedComision;
}

export async function deleteComision(comisionId: string): Promise<boolean> {
  try {
    // Buscar comisión para obtener userId
    const comision = await kv.get(`comision:${comisionId}`);
    
    if (!comision) {
      console.warn(`⚠️ Comisión ${comisionId} no encontrada para eliminar`);
      return false;
    }
    
    // Eliminar de índice global
    await kv.del(`comision:${comisionId}`);
    
    // Eliminar de índice de usuario
    await kv.del(`user:${comision.userId}:comision:${comisionId}`);
    
    console.log(`✅ Comisión ${comisionId} eliminada correctamente`);
    return true;
  } catch (error) {
    console.error(`❌ Error eliminando comisión ${comisionId}:`, error);
    return false;
  }
}

export async function liberarComisionesRetenidas(userId: string): Promise<void> {
  const comisiones = await getComisionesByUserId(userId);
  // Filtrar comisiones retenidas (tipo excedente_retenido o similar)
  // NOTA: Usamos 'excedente_retenido' como tipo temporal
  const retenidas = comisiones.filter((c: any) => c.tipo === 'excedente_retenido');
  
  if (retenidas.length === 0) return;
  
  console.log(`🔓 Liberando ${retenidas.length} comisiones retenidas para usuario ${userId}`);
  
  const now = new Date().toISOString();
  
  for (const com of retenidas) {
     // Determinar tipo original basado en descripción o usar 'patrocinio' por defecto si no se sabe
     const nuevoTipo = com.descripcion.includes('Red') ? 'red' : 'patrocinio';
     
     await updateComision(com.id, { 
       tipo: nuevoTipo, 
       fecha: now, // Actualizar fecha para que cuente en el nuevo ciclo
       descripcion: com.descripcion.replace('Retenida: ', 'Recuperado: ') + ' (Liberado por reinversión)'
     });
  }
}

// ==========================================
// FUNCIONES DE COBROS
// ==========================================

export async function createCobro(cobroData: Omit<Cobro, 'id' | 'fecha' | 'estado'>): Promise<Cobro> {
  const id = crypto.randomUUID();
  const cobro: Cobro = {
    ...cobroData,
    id,
    fecha: new Date().toISOString(),
    estado: 'pendiente'
  };
  
  await kv.set(`cobro:${id}`, cobro);
  await kv.set(`user:${cobroData.userId}:cobro:${id}`, cobro);
  
  return cobro;
}

export async function getCobrosByUserId(userId: string): Promise<Cobro[]> {
  const cobros = await kv.getByPrefix(`user:${userId}:cobro:`);
  return cobros.sort((a: Cobro, b: Cobro) => 
    new Date(b.fecha).getTime() - new Date(a.fecha).getTime()
  );
}

export async function getAllCobros(): Promise<Cobro[]> {
  const cobros = await kv.getByPrefix('cobro:');
  return cobros.filter((c: any) => c && c.id && !c.id.includes(':'));
}

export async function updateCobro(cobroId: string, updates: Partial<Cobro>): Promise<Cobro | null> {
  const cobro = await kv.get(`cobro:${cobroId}`);
  if (!cobro) return null;
  
  const updatedCobro = { 
    ...cobro, 
    ...updates,
    fechaProcesado: updates.estado ? new Date().toISOString() : cobro.fechaProcesado
  };
  
  await kv.set(`cobro:${cobroId}`, updatedCobro);
  await kv.set(`user:${cobro.userId}:cobro:${cobroId}`, updatedCobro);
  
  return updatedCobro;
}

// ==========================================
// FUNCIONES DE RENDIMIENTOS
// ==========================================

export async function createRendimiento(rendimientoData: Omit<Rendimiento, 'id'>): Promise<Rendimiento> {
  const id = crypto.randomUUID();
  const rendimiento: Rendimiento = {
    ...rendimientoData,
    id
  };
  
  await kv.set(`rendimiento:${id}`, rendimiento);
  await kv.set(`user:${rendimientoData.userId}:rendimiento:${id}`, rendimiento);
  
  return rendimiento;
}

export async function getRendimientosByUserId(userId: string): Promise<Rendimiento[]> {
  const rendimientos = await kv.getByPrefix(`user:${userId}:rendimiento:`);
  return rendimientos.sort((a: Rendimiento, b: Rendimiento) => 
    new Date(b.fecha).getTime() - new Date(a.fecha).getTime()
  );
}

export async function getAllRendimientos(): Promise<Rendimiento[]> {
  const rendimientos = await kv.getByPrefix('rendimiento:');
  return rendimientos.filter((r: any) => r && r.id && !r.id.includes(':'));
}

export async function getTotalRendimientosByUserId(userId: string): Promise<number> {
  const rendimientos = await getRendimientosByUserId(userId);
  return rendimientos.reduce((total, r) => total + r.monto, 0);
}

// ==========================================
// FUNCIONES DE DEPÓSITOS
// ==========================================

export async function createDeposito(depositoData: Omit<Deposito, 'id' | 'fecha' | 'estado'>): Promise<Deposito> {
  const id = crypto.randomUUID();
  const deposito: Deposito = {
    ...depositoData,
    id,
    fecha: new Date().toISOString(),
    estado: 'pendiente'
  };
  
  await kv.set(`deposito:${id}`, deposito);
  await kv.set(`user:${depositoData.userId}:deposito:${id}`, deposito);
  
  return deposito;
}

export async function getDepositosByUserId(userId: string): Promise<Deposito[]> {
  const depositos = await kv.getByPrefix(`user:${userId}:deposito:`);
  return depositos.sort((a: Deposito, b: Deposito) => 
    new Date(b.fecha).getTime() - new Date(a.fecha).getTime()
  );
}

export async function getAllDepositos(): Promise<Deposito[]> {
  const depositos = await kv.getByPrefix('deposito:');
  return depositos.filter((d: any) => d && d.id && !d.id.includes(':'));
}

export async function getDepositoById(depositoId: string): Promise<Deposito | null> {
  const deposito = await kv.get(`deposito:${depositoId}`);
  return deposito || null;
}

export async function updateDeposito(depositoId: string, updates: Partial<Deposito>): Promise<Deposito | null> {
  const deposito = await kv.get(`deposito:${depositoId}`);
  if (!deposito) return null;
  
  const updatedDeposito = { 
    ...deposito, 
    ...updates,
    fechaProcesado: updates.estado ? new Date().toISOString() : deposito.fechaProcesado
  };
  
  await kv.set(`deposito:${depositoId}`, updatedDeposito);
  await kv.set(`user:${deposito.userId}:deposito:${depositoId}`, updatedDeposito);
  
  return updatedDeposito;
}

// ==========================================
// FUNCIONES DE CONFIGURACIÓN DE ADMIN
// ==========================================

export async function getConfiguracionAdmin(): Promise<ConfiguracionAdmin | null> {
  return await kv.get(`configuracionAdmin`);
}

export async function setConfiguracionAdmin(config: ConfiguracionAdmin): Promise<void> {
  await kv.set(`configuracionAdmin`, config);
}

// ==========================================
// FUNCIONES DE PRODUCTOS
// ==========================================

export async function createProducto(productoData: Omit<Producto, 'id' | 'activo'>): Promise<Producto> {
  const id = crypto.randomUUID();
  const producto: Producto = {
    ...productoData,
    id,
    activo: true
  };
  
  await kv.set(`producto:${id}`, producto);
  
  return producto;
}

export async function getProductoById(productoId: string): Promise<Producto | null> {
  return await kv.get(`producto:${productoId}`);
}

export async function getAllProductos(): Promise<Producto[]> {
  const productos = await kv.getByPrefix('producto:');
  return productos.filter((p: any) => p && p.id && p.activo);
}

export async function updateProducto(productoId: string, updates: Partial<Producto>): Promise<Producto | null> {
  const producto = await getProductoById(productoId);
  if (!producto) return null;
  
  const updatedProducto = { ...producto, ...updates };
  await kv.set(`producto:${productoId}`, updatedProducto);
  
  return updatedProducto;
}

export async function deleteProducto(productoId: string): Promise<void> {
  await kv.del(`producto:${productoId}`);
}

// Inicializar productos por defecto si no existen
export async function initProductosDefecto(): Promise<Producto[]> {
  const productosExistentes = await getAllProductos();
  
  // Si ya hay productos, no hacer nada
  if (productosExistentes.length > 0) {
    return productosExistentes;
  }
  
  // Productos por defecto del sistema (Packs de inversión)
  const productosDefecto = [
    {
      nombre: 'Pack 50',
      precio: 50,
      descripcion: 'Pack inicial de $50 USDT con 100% de rentabilidad + comisiones de red',
      imagen: 'https://images.unsplash.com/photo-1559526324-593bc073d938?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbnZlc3RtZW50JTIwZ3Jvd3RofGVufDF8fHx8MTc2MzI0Njk1N3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      stock: 999,
      activo: true
    },
    {
      nombre: 'Pack 100',
      precio: 100,
      descripcion: 'Pack popular de $100 USDT con 100% de rentabilidad + comisiones de red',
      imagen: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaW5hbmNpYWwlMjBncm93dGglMjBjaGFydHxlbnwxfHx8fDE3NjMyNDY5NTd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      stock: 999,
      activo: true
    },
    {
      nombre: 'Pack 200',
      precio: 200,
      descripcion: 'Pack intermedio de $200 USDT con 100% de rentabilidad + comisiones de red',
      imagen: 'https://images.unsplash.com/photo-1579621970795-87facc2f976d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb25leSUyMGdyb3d0aCUyMHN1Y2Nlc3N8ZW58MXx8fHwxNzYzMjQ2OTU4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      stock: 999,
      activo: true
    },
    {
      nombre: 'Pack 300',
      precio: 300,
      descripcion: 'Pack avanzado de $300 USDT con 100% de rentabilidad + comisiones de red',
      imagen: 'https://images.unsplash.com/photo-1633158829875-e5316a358c6f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcnlwdG8lMjBpbnZlc3RtZW50fGVufDF8fHx8MTc2MzI0Njk1OHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      stock: 999,
      activo: true
    },
    {
      nombre: 'Pack 500',
      precio: 500,
      descripcion: 'Pack profesional de $500 USDT con 100% de rentabilidad + comisiones de red',
      imagen: 'https://images.unsplash.com/photo-1640340434855-6084b1f4901c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcnlwdG8lMjBzdWNjZXNzfGVufDF8fHx8MTc2MzI0Njk1OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      stock: 999,
      activo: true
    },
    {
      nombre: 'Pack 1k',
      precio: 1000,
      descripcion: 'Pack destacado de $1,000 USDT con 100% de rentabilidad + comisiones de red',
      imagen: 'https://images.unsplash.com/photo-1621761191319-c6fb62004040?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnb2xkJTIwaW52ZXN0bWVudHxlbnwxfHx8fDE3NjMyNDY5NTl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      stock: 999,
      activo: true
    },
    {
      nombre: 'Pack 5k',
      precio: 5000,
      descripcion: 'Pack premium de $5,000 USDT con 100% de rentabilidad + comisiones de red',
      imagen: 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBpbnZlc3RtZW50fGVufDF8fHx8MTc2MzI0Njk2MHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      stock: 999,
      activo: true
    },
    {
      nombre: 'Pack 10k',
      precio: 10000,
      descripcion: 'Pack élite de $10,000 USDT con 100% de rentabilidad + comisiones de red',
      imagen: 'https://images.unsplash.com/photo-1605792657660-596af9009e82?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmVtaXVtJTIwaW52ZXN0bWVudHxlbnwxfHx8fDE3NjMyNDY5NjB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      stock: 999,
      activo: true
    }
  ];
  
  // Crear todos los productos por defecto
  const productosCreados = [];
  for (const producto of productosDefecto) {
    const productoCreado = await createProducto(producto);
    productosCreados.push(productoCreado);
  }
  
  console.log(`✅ Inicializados ${productosCreados.length} productos por defecto`);
  return productosCreados;
}

// ==========================================
// FUNCIONES DE RANGOS
// ==========================================

// Calcular y actualizar el rango de un usuario basándose en sus métricas
export async function actualizarRangoUsuario(userId: string): Promise<User | null> {
  const startTime = Date.now();
  
  const user = await getUserById(userId);
  if (!user) {
    console.log(`⚠️ Usuario no encontrado: ${userId}`);
    return null;
  }
  
  console.log(`📊 Calculando rango para ${user.nombre} ${user.apellido}...`);
  
  // ⚡ OPTIMIZACIÓN: Cargar datos en paralelo con timeout
  let todosLosDirectos, allPacks, allUsers;
  try {
    [todosLosDirectos, allPacks, allUsers] = await Promise.race([
      Promise.all([
        getReferidosDirectos(userId),
        getAllPacks(),
        getAllUsers()
      ]),
      new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Timeout cargando datos')), 35000)
      )
    ]) as any;
  } catch (error) {
    console.error('❌ Error o timeout cargando datos para rango:', error);
    // Devolver usuario sin cambios si hay error
    return user;
  }
  
  console.log(`  ⏱️ Datos cargados en ${Date.now() - startTime}ms`);
  
  // IMPORTANTE: Para el conteo de directos, contar SOLO los que tienen PACK ACTIVO
  // (no contar inversión histórica, solo packs actualmente activos)
  const directosConPackActivo = todosLosDirectos.filter(directo => {
    return allPacks.some(p => p.userId === directo.id && p.activo);
  });
  
  const directos = directosConPackActivo;
  console.log(`  - Directos CON PACK ACTIVO: ${directos.length} (Total registrados: ${todosLosDirectos.length})`);
  
  // Calcular volumen del usuario
  // CAMBIO: No incluir volumen personal para el rango, solo volumen de red
  // let volumenTotal = allPacks.filter(p => p.userId === userId).reduce((sum, p) => sum + p.monto, 0);
  let volumenTotal = 0;
  
  // ⚡ OPTIMIZACIÓN: Pre-indexar usuarios por referidoPor para búsqueda O(1)
  const usuariosPorPadre = new Map<string, any[]>();
  allUsers.forEach(u => {
    if (u.referidoPor) {
      if (!usuariosPorPadre.has(u.referidoPor)) {
        usuariosPorPadre.set(u.referidoPor, []);
      }
      usuariosPorPadre.get(u.referidoPor)!.push(u);
    }
  });
  
  // ⚡ OPTIMIZACIÓN: Pre-indexar packs activos por userId
  const packsActivosPorUsuario = new Map<string, number>();
  allPacks.forEach(p => {
    if (p.activo) {
      const current = packsActivosPorUsuario.get(p.userId) || 0;
      packsActivosPorUsuario.set(p.userId, current + p.monto);
    }
  });
  
  // Función OPTIMIZADA para obtener todos los referidos hasta 10 niveles
  // IMPORTANTE: Ahora esta función construye la red GENEALÓGICA (Referidos Directos + sus descendientes),
  // no la red matricial (Spillover). Para cálculo de rangos, solo cuenta la red que nace de tus directos.
  const getAllReferidosRecursive = (parentId: string, currentLevel: number, visited: Set<string>): string[] => {
    if (currentLevel > 10 || visited.has(parentId)) return [];
    visited.add(parentId);
    
    // ⚡ Usar índice pre-calculado en lugar de filtrar
    const directRefs = usuariosPorPadre.get(parentId) || [];
    let allRefs = directRefs.map(r => r.id);
    
    // ⚡ Límite de iteraciones para evitar loops infinitos
    let iteraciones = 0;
    const maxIteraciones = 5000;
    
    for (const ref of directRefs) {
      if (iteraciones++ > maxIteraciones) {
        console.warn(`⚠️ Límite de iteraciones alcanzado en cálculo de red`);
        break;
      }
      allRefs.push(...getAllReferidosRecursive(ref.id, currentLevel + 1, visited));
    }
    
    return allRefs;
  };
  
  // Obtener todos los IDs de la red GENEALÓGICA
  const todosReferidosIds = getAllReferidosRecursive(userId, 1, new Set());
  
  // ⚡ OPTIMIZACIÓN: Usar índice pre-calculado en lugar de filtrar
  for (const refId of todosReferidosIds) {
    volumenTotal += packsActivosPorUsuario.get(refId) || 0;
  }
  
  console.log(`  - Volumen total (solo packs activos): $${volumenTotal}`);
  console.log(`  - Referidos en red: ${todosReferidosIds.length}`);
  
  // Obtener rangos ordenados por volumen (menor a mayor)
  const rangos = await getAllRangos();
  console.log(`  - Total rangos configurados: ${rangos.length}`);
  
  // Encontrar el rango más alto que cumple los requisitos
  let nuevoRango = 'Sin Rango';
  for (let i = rangos.length - 1; i >= 0; i--) {
    const rango = rangos[i];
    const cumpleDirectos = directos.length >= rango.directos;
    const cumpleVolumen = volumenTotal >= rango.volumen;
    console.log(`  - Evaluando ${rango.nombre}: directos ${directos.length}/${rango.directos} ${cumpleDirectos ? '✅' : '❌'}, volumen $${volumenTotal}/$${rango.volumen} ${cumpleVolumen ? '✅' : '❌'}`);
    if (directos.length >= rango.directos && volumenTotal >= rango.volumen) {
      nuevoRango = rango.nombre;
      console.log(`  ✅ Cumple requisitos para ${nuevoRango}`);
      break;
    }
  }
  
  // Actualizar rango del usuario si cambió
  if (user.rango !== nuevoRango) {
    console.log(`📊 ✅ Actualizando rango de ${user.nombre}: "${user.rango || 'Sin Rango'}" → "${nuevoRango}"`);
    return await updateUser(userId, { rango: nuevoRango });
  } else {
    console.log(`  - Rango sin cambios: ${nuevoRango}`);
  }
  
  return user;
}

export async function createRango(rangoData: Omit<Rango, 'id'>): Promise<Rango> {
  const id = crypto.randomUUID();
  const rango: Rango = {
    ...rangoData,
    id
  };
  
  await kv.set(`rango:${id}`, rango);
  
  return rango;
}

export async function getRangoById(rangoId: string): Promise<Rango | null> {
  return await kv.get(`rango:${rangoId}`);
}

export async function getAllRangos(): Promise<Rango[]> {
  const rangos = await kv.getByPrefix('rango:');
  
  if (!Array.isArray(rangos)) {
    console.warn('⚠️ getAllRangos: kv.getByPrefix no devolvió un array', rangos);
    return [];
  }
  
  // Ordenar por volumen requerido (menor a mayor)
  return rangos
    .filter((r: any) => r && r.id)
    .sort((a: Rango, b: Rango) => (a.volumen || 0) - (b.volumen || 0));
}

export async function updateRango(rangoId: string, updates: Partial<Rango>): Promise<Rango | null> {
  const rango = await getRangoById(rangoId);
  if (!rango) return null;
  
  const updatedRango = { ...rango, ...updates };
  await kv.set(`rango:${rangoId}`, updatedRango);
  
  return updatedRango;
}

export async function deleteRango(rangoId: string): Promise<void> {
  await kv.del(`rango:${rangoId}`);
}

// Inicializar rangos por defecto si no existen
export async function initRangosDefecto(): Promise<Rango[]> {
  const rangosExistentes = await getAllRangos();
  
  // Si ya hay rangos, no hacer nada
  if (rangosExistentes.length > 0) {
    return rangosExistentes;
  }
  
  // Rangos por defecto del sistema
  const rangosDefecto = [
    {
      nombre: 'Silver',
      directos: 3,
      volumen: 10000,
      premio: 'Reconocimientos',
      color: 'slate',
      gradient: 'from-slate-400 to-slate-600',
      icon: '🥈',
      imagen: 'https://images.unsplash.com/photo-1762345127396-ac4a970436c3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzaWx2ZXIlMjB0cm9waHklMjBhd2FyZHxlbnwxfHx8fDE3NjMyNDY5NTV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
    },
    {
      nombre: 'Golden',
      directos: 5,
      volumen: 25000,
      premio: '250',
      color: 'yellow',
      gradient: 'from-yellow-400 to-yellow-600',
      icon: '🥇',
      imagen: 'https://images.unsplash.com/photo-1687148223592-c967e6968d25?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnb2xkJTIwbHV4dXJ5JTIwdHJvcGh5fGVufDF8fHx8MTc2MzI0Njk1NXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
    },
    {
      nombre: 'Esmeralda',
      directos: 5,
      volumen: 100000,
      premio: 'Ticket Aéreo',
      color: 'emerald',
      gradient: 'from-emerald-400 to-emerald-600',
      icon: '💎',
      imagen: 'https://images.unsplash.com/photo-1599707367072-cd6ad66acc40?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHxlbWVyYWxkJTIwZ2Vtc3RvbmV8ZW58MXx8fHwxNzYzMjg2NzIwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
    },
    {
      nombre: 'Rubi',
      directos: 7,
      volumen: 120000,
      premio: 'Ticket Aéreo',
      color: 'red',
      gradient: 'from-red-500 to-red-700',
      icon: '🎖️',
      imagen: 'https://images.unsplash.com/photo-1761754642919-207d8dd8d1e2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxydWJ5JTIwZ2Vtc3RvbmUlMjBsdXh1cnl8ZW58MXx8fHwxNzYzMTc4ODA4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
    },
    {
      nombre: 'Platino',
      directos: 7,
      volumen: 250000,
      premio: 'Viaje a Dubái',
      color: 'cyan',
      gradient: 'from-cyan-400 to-cyan-600',
      icon: '🏅',
      imagen: 'https://images.unsplash.com/photo-1743819458014-f5cf74f175e3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkdWJhaSUyMGx1eHVyeSUyMHNreWxpbmV8ZW58MXx8fHwxNzYzMjQ2OTU2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
    },
    {
      nombre: 'Diamante',
      directos: 8,
      volumen: 500000,
      premio: 'Bono Carro',
      color: 'blue',
      gradient: 'from-blue-500 to-blue-700',
      icon: '🎖️',
      imagen: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaWFtb25kJTIwamV3ZWxyeSUyMGx1eHVyeXxlbnwxfHx8fDE3NjMyNDY5NTZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
    },
    {
      nombre: 'Black',
      directos: 10,
      volumen: 1000000,
      premio: 'Bono Carro',
      color: 'gray',
      gradient: 'from-gray-700 to-gray-900',
      icon: '🥇',
      imagen: 'https://images.unsplash.com/photo-1742056024244-02a093dae0b5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBzcG9ydHMlMjBjYXJ8ZW58MXx8fHwxNzYzMTk1MzI1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
    },
    {
      nombre: 'Crown Black',
      directos: 10,
      volumen: 3000000,
      premio: 'Bono Departamento',
      color: 'purple',
      gradient: 'from-purple-700 to-purple-900',
      icon: '🏅',
      imagen: 'https://images.unsplash.com/photo-1762732793012-8bdab3af00b4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBwZW50aG91c2UlMjBhcGFydG1lbnR8ZW58MXx8fHwxNzYzMjExMTE4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
    }
  ];
  
  // Crear todos los rangos por defecto
  const rangosCreados = [];
  for (const rango of rangosDefecto) {
    const rangoCreado = await createRango(rango);
    rangosCreados.push(rangoCreado);
  }
  
  console.log(`✅ Inicializados ${rangosCreados.length} rangos por defecto`);
  return rangosCreados;
}

// Función para corregir rangos existentes (Migración/Fix)
export async function fixRanks(): Promise<any> {
  console.log('🛠️ Iniciando corrección de rangos...');
  const rangos = await getAllRangos();
  const result: any[] = [];
  
  for (const rango of rangos) {
    let updated = false;
    let updates: any = {};
    
    // Caso 1: Convertir "Emprendedora" a "Esmeralda"
    if (rango.nombre === 'Emprendedora') {
      updates = {
        nombre: 'Esmeralda',
        volumen: 100000, // Corregir volumen a 100k
        color: 'emerald',
        gradient: 'from-emerald-400 to-emerald-600',
        icon: '💎',
        imagen: 'https://images.unsplash.com/photo-1599707367072-cd6ad66acc40?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHxlbWVyYWxkJTIwZ2Vtc3RvbmV8ZW58MXx8fHwxNzYzMjg2NzIwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
      };
      updated = true;
      console.log('✅ Convirtiendo Emprendedora -> Esmeralda');
    }
    
    // Caso 2: Corregir volumen de "Esmeralda" si ya existe pero tiene volumen incorrecto
    else if (rango.nombre === 'Esmeralda') {
      if (rango.volumen !== 100000) {
        updates.volumen = 100000;
        updated = true;
        console.log(`✅ Corrigiendo volumen Esmeralda: ${rango.volumen} -> 100000`);
      }
      // Asegurar otros atributos visuales si faltan
      if (rango.color !== 'emerald') {
         updates.color = 'emerald';
         updates.gradient = 'from-emerald-400 to-emerald-600';
         updates.icon = '💎';
         updated = true;
      }
    }
    
    if (updated) {
      const r = await updateRango(rango.id, updates);
      result.push(r);
    }
  }
  
  return result;
}

// ==========================================
// FUNCIONES DE COMPRAS DE PRODUCTOS
// ==========================================

export async function createCompraProducto(compraData: Omit<CompraProducto, 'id' | 'fecha' | 'estado'>): Promise<CompraProducto> {
  const id = crypto.randomUUID();
  const compra: CompraProducto = {
    ...compraData,
    id,
    fecha: new Date().toISOString(),
    estado: 'pendiente'
  };
  
  await kv.set(`compra:${id}`, compra);
  await kv.set(`user:${compraData.userId}:compra:${id}`, compra);
  
  return compra;
}

export async function getComprasByUserId(userId: string): Promise<CompraProducto[]> {
  const compras = await kv.getByPrefix(`user:${userId}:compra:`);
  return compras;
}

// ==========================================
// FUNCIONES DE PUNTOS
// ==========================================

export async function getPuntos(userId: string): Promise<number> {
  const puntos = await kv.get(`puntos:${userId}`);
  return puntos?.puntos || 0;
}

export async function setPuntos(userId: string, puntos: number): Promise<void> {
  const puntosData: PuntosUsuario = {
    userId,
    puntos,
    ultimaActualizacion: new Date().toISOString()
  };
  await kv.set(`puntos:${userId}`, puntosData);
}

export async function addPuntos(userId: string, puntos: number): Promise<number> {
  const currentPuntos = await getPuntos(userId);
  const newPuntos = currentPuntos + puntos;
  await setPuntos(userId, newPuntos);
  return newPuntos;
}

export async function deductPuntos(userId: string, puntos: number): Promise<number> {
  const currentPuntos = await getPuntos(userId);
  if (currentPuntos < puntos) {
    throw new Error('Puntos insuficientes');
  }
  const newPuntos = currentPuntos - puntos;
  await setPuntos(userId, newPuntos);
  return newPuntos;
}

// ==========================================
// FUNCIONES DE RULETA
// ==========================================

export async function getGlobalSpinCount(): Promise<number> {
  const count = await kv.get('global:spinCount');
  return count || 0;
}

export async function incrementGlobalSpinCount(): Promise<number> {
  const count = await getGlobalSpinCount();
  const newCount = count + 1;
  await kv.set('global:spinCount', newCount);
  return newCount;
}

export async function createRuletaHistorial(historialData: Omit<RuletaHistorial, 'id' | 'fecha'>): Promise<RuletaHistorial> {
  const id = crypto.randomUUID();
  const historial: RuletaHistorial = {
    ...historialData,
    id,
    fecha: new Date().toISOString()
  };
  
  await kv.set(`ruleta:${id}`, historial);
  await kv.set(`user:${historialData.userId}:ruleta:${id}`, historial);
  
  return historial;
}

export async function getRuletaHistorialByUserId(userId: string): Promise<RuletaHistorial[]> {
  const historial = await kv.getByPrefix(`user:${userId}:ruleta:`);
  return historial.sort((a: RuletaHistorial, b: RuletaHistorial) => 
    new Date(b.fecha).getTime() - new Date(a.fecha).getTime()
  );
}

export async function createGastoRuleta(gastoData: Omit<GastoRuleta, 'id' | 'fecha'>): Promise<GastoRuleta> {
  const id = crypto.randomUUID();
  const gasto: GastoRuleta = {
    ...gastoData,
    id,
    fecha: new Date().toISOString()
  };
  
  await kv.set(`gastoRuleta:${id}`, gasto);
  await kv.set(`user:${gastoData.userId}:gastoRuleta:${id}`, gasto);
  
  return gasto;
}

export async function getGastosRuletaByUserId(userId: string): Promise<GastoRuleta[]> {
  const gastos = await kv.getByPrefix(`user:${userId}:gastoRuleta:`);
  return gastos;
}

export async function getTotalGastosRuletaByUserId(userId: string): Promise<number> {
  const gastos = await getGastosRuletaByUserId(userId);
  return gastos.reduce((total, g) => total + g.monto, 0);
}

// ==========================================
// FUNCIONES DE RED MULTINIVEL
// ==========================================

export async function getReferidosDirectos(userId: string): Promise<User[]> {
  const allUsers = await getAllUsers();
  return allUsers.filter(u => u.referidoPor === userId);
}

export async function getReferidosPorNivel(userId: string, nivel: number): Promise<User[]> {
  if (nivel === 1) {
    return await getReferidosDirectos(userId);
  }
  
  const referidosNivelAnterior = await getReferidosPorNivel(userId, nivel - 1);
  const referidosNivel: User[] = [];
  
  for (const ref of referidosNivelAnterior) {
    const directos = await getReferidosDirectos(ref.id);
    referidosNivel.push(...directos);
  }
  
  return referidosNivel;
}

export async function calcularPosicionMatriz(userId: string): Promise<{ matrizPadre?: string, matrizNivel?: number, matrizPosicion?: number }> {
  const usuario = await getUserById(userId);
  let matrizPadre = usuario?.referidoPor;
  let matrizNivel = 1;
  let matrizPosicion = 0;

  // PASO 0: Verificar si el usuario YA tiene una posición histórica en la matriz
  // La posición es ÚNICA por usuario, independientemente de cuántos packs tenga o si están activos
  const userPacks = await getPacksByUserId(userId);
  const existingPack = userPacks.find(p => p.matrizPadre); // Buscar cualquier pack que ya tenga posición

  if (existingPack) {
    console.log(`✅ Usuario ${userId} ya tiene posición en matriz (Padre: ${existingPack.matrizPadre}). Manteniendo estructura.`);
    return {
      matrizPadre: existingPack.matrizPadre,
      matrizNivel: existingPack.matrizNivel,
      matrizPosicion: existingPack.matrizPosicion
    };
  }

  if (usuario && usuario.referidoPor) {
    // Obtener todos los usuarios y packs para calcular la matriz completa
    const todosLosUsuarios = await getAllUsers();
    const todosLosPacks = await Promise.all(
      todosLosUsuarios.map(u => getPacksByUserId(u.id))
    ).then(results => results.flat());
    
    // IMPORTANTE: Para mantener la estructura estable, consideramos TODOS los packs (activos e inactivos).
    // Si un usuario compró un pack alguna vez, ocupa un lugar en la matriz para siempre.
    const allPacks = todosLosPacks;
    
    // Función para encontrar hueco BFS (Breadth-First Search)
    const encontrarHuecoEnMatriz = (raizId: string) => {
      const queue: Array<{ id: string, nivel: number }> = [{ id: raizId, nivel: 0 }];
      const visitados = new Set<string>();
      visitados.add(raizId);
      
      while (queue.length > 0) {
        const current = queue.shift();
        if (!current) continue;
        
        // Buscar packs que tengan a 'current.id' como matrizPadre
        const packsHijos = allPacks.filter((p: any) => p.matrizPadre === current.id);
        
        // Filtrar USUARIOS únicos. Un usuario cuenta como 1 hijo, aunque tenga 10 packs.
        // Esto evita que un usuario llene su propia matriz con reinversiones (si no se detectara arriba).
        const hijosUnicosIds = [...new Set(packsHijos.map((p: any) => p.userId))];
        
        // Si tiene menos de 3 hijos (USUARIOS), ¡encontramos un hueco!
        if (hijosUnicosIds.length < 3) {
          return {
            padreId: current.id,
            nivelRelativo: current.nivel + 1,
            posicion: hijosUnicosIds.length // 0, 1 o 2
          };
        }
        
        // Si está lleno, agregar los hijos (USUARIOS) a la cola para seguir buscando abajo
        for (const hijoId of hijosUnicosIds) {
          if (!visitados.has(hijoId)) {
            visitados.add(hijoId);
            queue.push({ id: hijoId, nivel: current.nivel + 1 });
          }
        }
        
        // Protección contra ciclos infinitos
        if (visitados.size > 5000) break; 
      }
      
      return { padreId: raizId, nivelRelativo: 1, posicion: 0 };
    };
    
    const hueco = encontrarHuecoEnMatriz(usuario.referidoPor);
    matrizPadre = hueco.padreId;
    matrizNivel = 1; 
    matrizPosicion = hueco.posicion;
    
    console.log(`✅ Matriz calculada para ${usuario.nombre}: Padre=${matrizPadre}, Pos=${matrizPosicion}`);
  }
  
  return { matrizPadre, matrizNivel, matrizPosicion };
}

export async function calcularComisionesRed(referidoId: string, montoInversion: number): Promise<void> {
  // Niveles de comisión según especificación (Matriz Forzada 3x10)
  const nivelesComision = [
    { nivel: 1, porcentaje: 0.08 },  // 8% (Padre directo en matriz)
    { nivel: 2, porcentaje: 0.06 },  // 6% (Abuelo en matriz)
    { nivel: 3, porcentaje: 0.04 },  // 4%
    { nivel: 4, porcentaje: 0.02 },  // 2%
    { nivel: 5, porcentaje: 0.01 },  // 1%
    { nivel: 6, porcentaje: 0.01 },  // 1%
    { nivel: 7, porcentaje: 0.01 },  // 1%
    { nivel: 8, porcentaje: 0.01 },  // 1%
    { nivel: 9, porcentaje: 0.005 }, // 0.5%
    { nivel: 10, porcentaje: 0.005 } // 0.5%
  ];
  
  const referido = await getUserById(referidoId);
  if (!referido) return;

  // 1. Obtener el Pack Activo más reciente del usuario para determinar su posición en la matriz
  const packsUsuario = await getPacksByUserId(referidoId);
  const packActual = packsUsuario.filter(p => p.activo).sort((a, b) => new Date(b.fechaCompra).getTime() - new Date(a.fechaCompra).getTime())[0];
  
  if (!packActual) {
    console.error(`❌ No se encontró pack activo para usuario ${referidoId} al calcular comisiones`);
    return;
  }

  console.log(`🧮 Calculando comisiones MATRIZ para ${referido.nombre} (Padre Matriz: ${packActual.matrizPadre || 'Ninguno'})`);

  // COMISIONES DE RED (Matriz 3x10 - Spillover)
  // Se sube por la estructura de la matriz (matrizPadre), NO por la de referidos (referidoPor)
  
  let currentMatrizPadreId = packActual.matrizPadre;
  
  for (const { nivel, porcentaje } of nivelesComision) {
    if (!currentMatrizPadreId) break;
    
    const beneficiario = await getUserById(currentMatrizPadreId);
    if (!beneficiario) break;
    
      // ====================================
    // VERIFICAR LÍMITE DEL 200%
    // ====================================
    
    // Obtener packs activos del beneficiario
    const beneficiarioPacks = await getPacksByUserId(currentMatrizPadreId);
    // Buscar el pack del beneficiario para seguir subiendo en la próxima iteración
    // Y para calcular el límite actual
    const packBeneficiario = beneficiarioPacks.filter(p => p.activo).sort((a, b) => new Date(b.fechaCompra).getTime() - new Date(a.fechaCompra).getTime())[0];
    // Buscar cualquier pack (activo o no) para mantener la cadena de la matriz si el usuario no tiene pack activo
    const ultimoPackCualquiera = beneficiarioPacks.sort((a, b) => new Date(b.fechaCompra).getTime() - new Date(a.fechaCompra).getTime())[0];

    if (packBeneficiario) {
        const inversionPack = packBeneficiario.monto;
        const limiteGanancias = inversionPack * 2;
        const fechaInicioPack = new Date(packBeneficiario.fechaCompra).getTime();

        const comisiones = await getComisionesByUserId(currentMatrizPadreId);
        
        // CORRECCIÓN CRÍTICA: Solo contar ganancias generadas DURANTE el ciclo de este pack
        const gananciasCicloActual = comisiones
          .filter(c => new Date(c.fecha).getTime() >= fechaInicioPack)
          .reduce((sum, c) => sum + c.monto, 0);
        
        if (gananciasCicloActual >= limiteGanancias) {
          console.log(`🔒 Beneficiario ${beneficiario.nombre} (Nivel Matriz ${nivel}) tope alcanzado en ciclo actual. Comisión bloqueada.`);
        } else {
          let montoComision = montoInversion * porcentaje;
          const gananciasDisponibles = limiteGanancias - gananciasCicloActual;
          
          if (montoComision > gananciasDisponibles) {
            montoComision = gananciasDisponibles;
          }
          
          if (montoComision > 0) {
            await createComision({
              userId: currentMatrizPadreId,
              tipo: 'red',
              monto: montoComision,
              nivel,
              referidoId,
              descripcion: `Comisión Red Nivel ${nivel} (Matriz) por ${referido.nombre} ${referido.apellido}`
            });
            console.log(`✅ Comisión Red Nivel ${nivel} pagada a ${beneficiario.nombre}: $${montoComision}`);
          }
          
          // MANEJO DE EXCEDENTE RETENIDO
          const montoOriginal = montoInversion * porcentaje;
          if (montoComision < montoOriginal) {
              const excedente = montoOriginal - montoComision;
              if (excedente > 0) {
                  await createComision({
                    userId: currentMatrizPadreId,
                    tipo: 'excedente_retenido' as any, // Cast para permitir nuevo tipo temporalmente
                    monto: excedente,
                    nivel,
                    referidoId,
                    descripcion: `Retenida: Comisi��n Red Nivel ${nivel} (Tope 200%) por ${referido.nombre} ${referido.apellido}`
                  });
                  console.log(`🔒 Excedente retenido para ${beneficiario.nombre}: $${excedente}`);
              }
          }
        }
    }
    
    // Subir al siguiente nivel en la matriz
    // Si el beneficiario tiene pack activo, usar su matrizPadre
    // Si no tiene pack activo, usar el del último pack histórico para no romper la cadena de referidos
    currentMatrizPadreId = packBeneficiario?.matrizPadre || ultimoPackCualquiera?.matrizPadre;
  }
  
  // BONO DE PATROCINIO (Directo - Unilevel)
  // Este SÍ se paga al patrocinador directo (referidoPor), sin importar la matriz
  if (referido.referidoPor) {
    const patrocinador = await getUserById(referido.referidoPor);
    if (patrocinador) {
      const patrocinadorPacks = await getPacksByUserId(referido.referidoPor);
      const packActivoPatrocinador = patrocinadorPacks.filter(p => p.activo).sort((a, b) => new Date(b.fechaCompra).getTime() - new Date(a.fechaCompra).getTime())[0];
      
      if (packActivoPatrocinador) {
        const inversionPack = packActivoPatrocinador.monto;
        const limiteGanancias = inversionPack * 2;
        const fechaInicioPack = new Date(packActivoPatrocinador.fechaCompra).getTime();
        
        const comisiones = await getComisionesByUserId(referido.referidoPor);
        
        // CORRECCIÓN CRÍTICA: Solo contar ganancias generadas DURANTE el ciclo de este pack
        const gananciasCicloActual = comisiones
            .filter(c => new Date(c.fecha).getTime() >= fechaInicioPack)
            .reduce((sum, c) => sum + c.monto, 0);
        
        if (gananciasCicloActual < limiteGanancias) {
          let bonoPatrocinio = montoInversion * 0.10; // 10% Bono Directo
          const gananciasDisponibles = limiteGanancias - gananciasCicloActual;
          
          if (bonoPatrocinio > gananciasDisponibles) {
            bonoPatrocinio = gananciasDisponibles;
          }
          
          if (bonoPatrocinio > 0) {
            await createComision({
              userId: referido.referidoPor,
              tipo: 'patrocinio',
              monto: bonoPatrocinio,
              nivel: 1, // Nivel genealógico directo
              referidoId,
              descripcion: `Bono Directo por ${referido.nombre} ${referido.apellido}`
            });
            console.log(`✅ Bono Directo pagado a ${patrocinador.nombre}: $${bonoPatrocinio}`);
          }
          
          // MANEJO DE EXCEDENTE RETENIDO (BONO DIRECTO)
          const bonoOriginal = montoInversion * 0.10;
          if (bonoPatrocinio < bonoOriginal) {
              const excedente = bonoOriginal - bonoPatrocinio;
              if (excedente > 0) {
                  await createComision({
                    userId: referido.referidoPor,
                    tipo: 'excedente_retenido' as any,
                    monto: excedente,
                    nivel: 1,
                    referidoId,
                    descripcion: `Retenida: Bono Directo (Tope 200%) por ${referido.nombre} ${referido.apellido}`
                  });
                  console.log(`🔒 Excedente Bono Directo retenido para ${patrocinador.nombre}: $${excedente}`);
              }
          }
        }
      }
    }
  }
}

// ==========================================
// ESTADÍSTICAS GENERALES
// ==========================================

export async function getEstadisticasGenerales() {
  const usuarios = await getAllUsers();
  const packs = await getAllPacks();
  const cobros = await getAllCobros();
  
  const totalUsuarios = usuarios.length;
  const usuariosActivos = usuarios.filter(u => u.activo).length;
  const totalInversiones = packs.reduce((sum, p) => sum + p.monto, 0);
  const totalCobros = cobros
    .filter(c => c.estado === 'completado')
    .reduce((sum, c) => sum + c.monto, 0);
  const cobrosPendientes = cobros.filter(c => c.estado === 'pendiente').length;
  
  return {
    totalUsuarios,
    usuariosActivos,
    totalInversiones,
    totalCobros,
    cobrosPendientes,
    packsPorTipo: getPorcentajePacks(packs)
  };
}

function getPorcentajePacks(packs: Pack[]) {
  const conteo: Record<string, number> = {};
  packs.forEach(p => {
    conteo[p.nombre] = (conteo[p.nombre] || 0) + 1;
  });
  return conteo;
}

// ==========================================
// RETIROS
// ==========================================

export interface Retiro {
  id: string;
  userId: string;
  monto: number;
  tipo: 'rendimiento' | 'red' | 'patrocinio';
  walletDestino: string;
  estado: 'pendiente' | 'aprobado' | 'rechazado';
  txHash?: string;
  notas?: string;
  createdAt: string;
  updatedAt: string;
}

export async function createRetiro(data: {
  userId: string;
  monto: number;
  tipo: 'rendimiento' | 'red' | 'patrocinio';
  walletDestino: string;
}): Promise<Retiro> {
  const id = `RET${Date.now()}${Math.floor(Math.random() * 1000)}`;
  const now = new Date().toISOString();
  
  const retiro: Retiro = {
    id,
    userId: data.userId,
    monto: data.monto,
    tipo: data.tipo,
    walletDestino: data.walletDestino,
    estado: 'pendiente',
    createdAt: now,
    updatedAt: now
  };
  
  await kv.set(`retiro:${id}`, retiro);
  
  // Agregar a la lista de retiros del usuario
  const userRetiros = await kv.get(`user:${data.userId}:retiros`) || [];
  userRetiros.push(id);
  await kv.set(`user:${data.userId}:retiros`, userRetiros);
  
  return retiro;
}

export async function getAllRetiros(): Promise<Retiro[]> {
  const allData = await kv.getByPrefix('retiro:');
  return allData.map(item => item.value as Retiro);
}

export async function getRetiroById(id: string): Promise<Retiro | null> {
  return await kv.get(`retiro:${id}`);
}

export async function getRetirosByUser(userId: string): Promise<Retiro[]> {
  const retiroIds = await kv.get(`user:${userId}:retiros`) || [];
  const retiros = await Promise.all(
    retiroIds.map(async (id: string) => await getRetiroById(id))
  );
  return retiros.filter(r => r !== null) as Retiro[];
}

export async function updateRetiro(id: string, updates: Partial<Retiro>): Promise<Retiro | null> {
  const retiro = await getRetiroById(id);
  if (!retiro) return null;
  
  const updatedRetiro = {
    ...retiro,
    ...updates,
    updatedAt: new Date().toISOString()
  };
  
  await kv.set(`retiro:${id}`, updatedRetiro);
  return updatedRetiro;
}

// ==========================================
// 🚀 FUNCIONES OPTIMIZADAS PARA CONSULTAS RÁPIDAS
// ==========================================

/**
 * 🚀 OPTIMIZADO: Obtiene referidos directos sin cargar todos los usuarios
 * Usa consulta directa de Supabase con filtro WHERE en lugar de cargar todo y filtrar en memoria
 */
export async function getReferidosDirectosOptimizado(userId: string): Promise<User[]> {
  const supabase = createClient(
    Deno.env.get('SUPABASE_URL'),
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')
  );
  
  try {
    // Consulta SQL directa: buscar todos los registros donde value->>'referidoPor' = userId
    const { data, error } = await supabase
      .from('kv_store_9f68532a')
      .select('key, value')
      .like('key', 'user:%')
      .filter('value->>referidoPor', 'eq', userId);
    
    if (error) {
      console.error('Error en getReferidosDirectosOptimizado:', error);
      return [];
    }
    
    // Filtrar solo registros válidos (user:UUID, no mapeos)
    const usuarios = (data || [])
      .filter((row: any) => {
        const key = row.key as string;
        const afterPrefix = key.substring(5); // Remover 'user:'
        
        // Solo user:UUID (sin más ':')
        if (afterPrefix.includes(':')) return false;
        
        // Verificar UUID válido
        const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
        return uuidRegex.test(afterPrefix);
      })
      .map((row: any) => {
        const id = row.key.replace('user:', '');
        return {
          ...row.value,
          id
        };
      });
    
    console.log(`✅ [OPTIMIZADO] Encontrados ${usuarios.length} referidos directos para ${userId}`);
    return usuarios;
  } catch (error) {
    console.error('Error en getReferidosDirectosOptimizado:', error);
    return [];
  }
}

/**
 * 🚀 OPTIMIZADO: Calcula red genealógica con límites balanceados
 * 10 niveles (suficiente para MLM) y 1000 usuarios máximo
 */
export async function calcularRedGenealogicaOptimizada(
  userId: string, 
  maxNiveles: number = 10,
  maxNodos: number = 1000
): Promise<any[]> {
  const allPacks = await getAllPacks();
  let nodosCalculados = 0;
  const visitados = new Set<string>();
  
  async function calcularNivel(parentId: string, nivel: number): Promise<any[]> {
    if (nivel > maxNiveles || visitados.has(parentId) || nodosCalculados >= maxNodos) {
      return [];
    }
    
    visitados.add(parentId);
    
    const hijos = await getReferidosDirectosOptimizado(parentId);
    
    let red: any[] = [];
    
    for (const hijo of hijos) {
      if (nodosCalculados >= maxNodos) {
        console.log(`⚠️ [RED] Límite de ${maxNodos} nodos alcanzado`);
        break;
      }
      
      nodosCalculados++;
      const hijoPacks = allPacks.filter((p: any) => p.userId === hijo.id);
      const hijoPackActivo = hijoPacks.find((p: any) => p.activo);
      const hijoInversion = hijoPacks.reduce((sum, p) => sum + p.monto, 0);
      
      red.push({
        id: hijo.id_unico,
        nombre: hijo.nombre,
        apellido: hijo.apellido,
        nivel: nivel,
        pack: hijoPackActivo?.nombre || 'Sin Pack',
        inversion: hijoInversion,
        activo: hijo.activo
      });
      
      if (nivel < maxNiveles && nodosCalculados < maxNodos) {
        const redHijo = await calcularNivel(hijo.id, nivel + 1);
        red = red.concat(redHijo);
      }
    }
    
    return red;
  }
  
  const startTime = Date.now();
  console.log(`🌐 [RED] Calculando red para ${userId} (max: ${maxNiveles} niveles, ${maxNodos} nodos)...`);
  const redCompleta = await calcularNivel(userId, 1);
  const loadTime = Date.now() - startTime;
  console.log(`✅ [RED] ${redCompleta.length} usuarios en ${loadTime}ms (${nodosCalculados} nodos procesados)`);
  
  return redCompleta;
}

/**
 * 🚀 OPTIMIZADO: Obtiene datos de dashboard sin cargar todos los usuarios
 */
export async function getDashboardDataOptimizado(userId: string) {
  console.log(`⚡ [OPTIMIZADO] Cargando dashboard para ${userId}...`);
  const startTime = Date.now();
  
  // 1. Cargar datos específicos del usuario en paralelo
  const [
    user,
    userPacks,
    userComisiones,
    userCobros,
    userRendimientos,
    userGastosRuleta,
    allPacks // Solo necesitamos packs globales para cálculos de red
  ] = await Promise.all([
    getUserById(userId),
    getPacksByUserId(userId),
    getComisionesByUserId(userId),
    getCobrosByUserId(userId),
    getRendimientosByUserId(userId),
    getGastosRuletaByUserId(userId),
    getAllPacks()
  ]);
  
  if (!user) {
    throw new Error('Usuario no encontrado');
  }
  
  // 2. Obtener referidos directos de forma optimizada
  const referidosDirectos = await getReferidosDirectosOptimizado(userId);
  
  // 3. Filtrar directos con pack activo
  const directosConPack = referidosDirectos.filter((ref: any) => {
    const refPacks = allPacks.filter((p: any) => p.userId === ref.id);
    return refPacks.some((p: any) => p.activo);
  });
  
  // 4. Calcular red genealógica completa (SIN LÍMITES)
  const redCompleta = await calcularRedGenealogicaOptimizada(userId);
  
  // 5. Calcular datos financieros
  const inversionTotal = userPacks.reduce((sum, p) => sum + p.monto, 0);
  
  // 🔥 LÓGICA INTELIGENTE DE PACK ACTIVO
  // Un pack debe estar activo SOLO si:
  // 1. Tiene un depósito verificado (fechaCompra existe)
  // 2. NO ha llegado al 200% de rendimiento acumulado
  
  const comisionesArray = Array.isArray(userComisiones) ? userComisiones : [];
  const totalGanado = comisionesArray.reduce((sum, c) => sum + (c?.monto || 0), 0);
  
  // Calcular rendimientos acumulados POR PACK (usando packId)
  const rendimientosPorPack = new Map<string, number>();
  comisionesArray.forEach((c: any) => {
    if (c.tipo === 'rendimiento' && c.packId) {
      const actual = rendimientosPorPack.get(c.packId) || 0;
      rendimientosPorPack.set(c.packId, actual + (c.monto || 0));
    }
  });
  
  // Determinar pack activo CORRECTO
  let packActivo = null;
  
  // Ordenar packs por fecha de compra (más reciente primero)
  const packsOrdenados = [...userPacks]
    .filter(p => p.fechaCompra) // Solo packs con depósito verificado
    .sort((a, b) => new Date(b.fechaCompra).getTime() - new Date(a.fechaCompra).getTime());
  
  for (const pack of packsOrdenados) {
    const rendimientosAcumulados = rendimientosPorPack.get(pack.id) || 0;
    const limite200 = pack.monto * 2;
    const progreso = (rendimientosAcumulados / limite200) * 100;
    
    console.log(`🔍 [Pack ${pack.id}] ${pack.nombre} - Rendimientos: $${rendimientosAcumulados.toFixed(2)} / $${limite200} (${progreso.toFixed(1)}%)`);
    
    // Si este pack NO ha llegado al 200%, es el pack activo
    if (rendimientosAcumulados < limite200) {
      packActivo = pack;
      
      // Actualizar estado en la base de datos si es necesario
      if (!pack.activo) {
        console.log(`✅ [Pack ${pack.id}] Activando pack ${pack.nombre}`);
        await updatePack(pack.id, { activo: true });
        pack.activo = true;
      }
      break;
    } else {
      // Este pack YA llegó al 200%, debe estar inactivo
      if (pack.activo) {
        console.log(`🔴 [Pack ${pack.id}] Desactivando pack ${pack.nombre} (llegó al 200%)`);
        await updatePack(pack.id, { activo: false });
        pack.activo = false;
      }
    }
  }
  
  console.log(`📦 Pack activo final: ${packActivo ? packActivo.nombre : 'NINGUNO'}`);
  
  // 🔧 CORRECCIÓN: Separar rendimientos por día vs histórico
  const hoy = new Date();
  hoy.setHours(0, 0, 0, 0); // Inicio del día
  
  const comisionesPorTipo = {
    red: comisionesArray.filter((c: any) => c?.tipo === 'red').reduce((sum, c) => sum + (c?.monto || 0), 0),
    rendimiento: comisionesArray.filter((c: any) => c?.tipo === 'rendimiento').reduce((sum, c) => sum + (c?.monto || 0), 0),
    rendimientoHoy: comisionesArray
      .filter((c: any) => c?.tipo === 'rendimiento' && c?.fecha && new Date(c.fecha) >= hoy)
      .reduce((sum, c) => sum + (c?.monto || 0), 0),
    patrocinio: comisionesArray.filter((c: any) => c?.tipo === 'patrocinio').reduce((sum, c) => sum + (c?.monto || 0), 0),
    rangos: comisionesArray.filter((c: any) => c?.tipo === 'rangos').reduce((sum, c) => sum + (c?.monto || 0), 0)
  };
  const totalRetirado = (Array.isArray(userCobros) ? userCobros : [])
    .filter((c: any) => c?.estado === 'completado' || c?.estado === 'pendiente')
    .reduce((sum, c) => sum + (c?.monto || 0), 0);
  const totalGastadoRuleta = (Array.isArray(userGastosRuleta) ? userGastosRuleta : [])
    .reduce((sum, g) => sum + (g?.monto || 0), 0);
  const saldoDisponible = Math.max(0, totalGanado - totalRetirado - totalGastadoRuleta);
  const limiteRetiro = (packActivo?.monto || 0) * 2;
  const packCompletado = packActivo ? (totalGanado >= limiteRetiro) : false;
  
  // 🆕 CONSTRUIR HISTORIAL UNIFICADO DE TODAS LAS TRANSACCIONES
  const historialCompleto: any[] = [];
  
  // Agregar comisiones (rendimientos, red, patrocinio, rangos)
  comisionesArray.forEach((c: any) => {
    historialCompleto.push({
      fecha: c.fecha,
      concepto: c.descripcion || `Comisión ${c.tipo}`,
      tipo: c.tipo, // 'rendimiento', 'red', 'patrocinio', 'rangos'
      monto: c.monto,
      id: c.id,
      categoria: 'ganancia'
    });
  });
  
  // Agregar retiros
  const cobrosArray = Array.isArray(userCobros) ? userCobros : [];
  cobrosArray.forEach((cobro: any) => {
    historialCompleto.push({
      fecha: cobro.fecha || cobro.createdAt,
      concepto: `Retiro ${cobro.estado === 'pendiente' ? '(Pendiente)' : cobro.estado === 'completado' ? '(Completado)' : '(Rechazado)'}`,
      tipo: 'retiro',
      monto: cobro.monto,
      id: cobro.id,
      estado: cobro.estado,
      categoria: 'egreso'
    });
  });
  
  // Agregar gastos de ruleta
  const gastosRuletaArray = Array.isArray(userGastosRuleta) ? userGastosRuleta : [];
  gastosRuletaArray.forEach((gasto: any) => {
    historialCompleto.push({
      fecha: gasto.fecha || gasto.createdAt,
      concepto: 'Gasto en Ruleta',
      tipo: 'ruleta_gasto',
      monto: gasto.monto,
      id: gasto.id,
      categoria: 'egreso'
    });
  });
  
  // Agregar compras de packs (depósitos verificados)
  const packsArray = Array.isArray(userPacks) ? userPacks : [];
  packsArray.forEach((pack: any) => {
    if (pack.fechaCompra) {
      historialCompleto.push({
        fecha: pack.fechaCompra,
        concepto: `Compra de ${pack.nombre}`,
        tipo: 'compra_pack',
        monto: pack.monto,
        id: pack.id,
        categoria: 'inversion'
      });
    }
  });
  
  // Ordenar por fecha descendente (más reciente primero)
  historialCompleto.sort((a: any, b: any) => {
    const fechaA = new Date(a.fecha).getTime();
    const fechaB = new Date(b.fecha).getTime();
    return fechaB - fechaA;
  });
  
  // 🔥 NUEVO: Calcular ganancia_acumulada SOLO del pack activo
  let gananciaAcumuladaPackActivo = 0;
  if (packActivo) {
    const fechaInicioPack = new Date(packActivo.fechaCompra).getTime();
    
    // 🐛 DEBUG: Logs detallados para identificar qué se está filtrando
    console.log(`\n🔍 [DEBUG GANANCIA] Analizando comisiones para pack activo:`);
    console.log(`   📅 Fecha de compra del pack: ${packActivo.fechaCompra}`);
    console.log(`   🔢 Timestamp de inicio: ${fechaInicioPack}`);
    console.log(`   📊 Total de comisiones a revisar: ${comisionesArray.length}`);
    
    const comisionesDelPack = comisionesArray.filter(c => {
      if (c.monto <= 0) return false;
      
      const fechaComision = new Date(c.fecha).getTime();
      const esValida = !isNaN(fechaComision);
      const esPosterior = fechaComision >= fechaInicioPack;
      
      // Log de cada comisión inválida
      if (!esValida) {
        console.log(`   ⚠️ Comisión con fecha inválida: ${c.tipo} - $${c.monto} - fecha: ${c.fecha}`);
      }
      
      return esValida && esPosterior;
    });
    
    console.log(`   ✅ Comisiones válidas desde el pack: ${comisionesDelPack.length}`);
    
    // Desglose por tipo
    const desglosePorTipo: any = {};
    comisionesDelPack.forEach(c => {
      if (!desglosePorTipo[c.tipo]) {
        desglosePorTipo[c.tipo] = { cantidad: 0, total: 0 };
      }
      desglosePorTipo[c.tipo].cantidad++;
      desglosePorTipo[c.tipo].total += c.monto;
    });
    
    console.log(`   📋 Desglose por tipo:`);
    Object.entries(desglosePorTipo).forEach(([tipo, data]: any) => {
      console.log(`      - ${tipo}: ${data.cantidad} comisiones, $${data.total.toFixed(2)}`);
    });
    
    // Sumar TODAS las comisiones (rendimientos + red + patrocinio + rangos) desde que se activó el pack
    gananciaAcumuladaPackActivo = comisionesDelPack.reduce((sum, c) => sum + c.monto, 0);
    
    console.log(`💰 [Pack Activo] Ganancia acumulada desde ${packActivo.fechaCompra}: $${gananciaAcumuladaPackActivo.toFixed(2)}`);
    console.log(`   - Inversión: $${packActivo.monto}`);
    console.log(`   - Límite 200%: $${(packActivo.monto * 2).toFixed(2)}`);
    console.log(`   - Progreso: ${((gananciaAcumuladaPackActivo / packActivo.monto) * 100).toFixed(2)}%`);
    
    // 🔥 COMPARACIÓN CON TOTAL HISTÓRICO
    console.log(`\n💰 [DEBUG GANANCIA] Comparación:`);
    console.log(`   comisiones.total (HISTÓRICO): ${totalGanado.toFixed(2)}`);
    console.log(`   comisiones.gananciaAcumulada (PACK ACTIVO): ${gananciaAcumuladaPackActivo.toFixed(2)}`);
    console.log(`   Diferencia (ganancias de packs anteriores): ${(totalGanado - gananciaAcumuladaPackActivo).toFixed(2)}\n`);
  }
  
  const loadTime = Date.now() - startTime;
  const volumenTotal = redCompleta.reduce((sum, r) => sum + (r.inversion || 0), 0);
  
  console.log(`✅ [OPTIMIZADO] Dashboard cargado en ${loadTime}ms`);
  console.log(`  📊 Transacciones: ${historialCompleto.length}`);
  console.log(`  👥 Red completa: ${redCompleta.length} usuarios`);
  console.log(`  💰 Volumen total: $${volumenTotal.toFixed(2)}`);
  
  if (redCompleta.length >= 1000) {
    console.warn(`⚠️ [RED] Límite de 1000 usuarios alcanzado - puede haber más usuarios en la red`);
  }
  
  return {
    usuario: {
      id: user.id,
      id_unico: user.id_unico,
      nombre: user.nombre,
      apellido: user.apellido,
      email: user.email,
      telefono: user.telefono,
      ciudad: user.ciudad,
      wallet: user.wallet,
      activo: user.activo,
      rango: user.rango || 'Sin Rango',
      referralCode: user.referralCode
    },
    pack: {
      activo: packActivo,
      todosLosPacks: userPacks,
      inversionTotal,
      completado: packCompletado
    },
    comisiones: {
      historial: historialCompleto, // ✅ Ahora incluye TODAS las transacciones (comisiones, retiros, ruleta, packs)
      historialComisiones: comisionesArray, // Mantener solo comisiones por compatibilidad
      porTipo: comisionesPorTipo,
      total: totalGanado, // 🔴 Total histórico de TODOS los packs
      gananciaAcumulada: gananciaAcumuladaPackActivo // 🔥 NUEVO: Ganancia SOLO del pack activo actual
    },
    wallet: {
      saldoDisponible,
      limiteRetiro,
      totalRetirado,
      totalGastadoRuleta
    },
    red: {
      directos: {
        total: referidosDirectos.length,
        conPack: directosConPack.length,
        lista: referidosDirectos.map((r: any) => ({
          id: r.id_unico,
          nombre: r.nombre,
          apellido: r.apellido,
          pack: allPacks.find((p: any) => p.userId === r.id && p.activo)?.nombre || 'Sin Pack',
          inversion: allPacks.filter((p: any) => p.userId === r.id).reduce((sum, p) => sum + p.monto, 0),
          activo: r.activo
        }))
      },
      completa: {
        total: redCompleta.length,
        lista: redCompleta,
        volumen: redCompleta.reduce((sum, r) => sum + (r.inversion || 0), 0)
      }
    },
    _meta: {
      loadTime,
      optimizado: true,
      timestamp: Date.now()
    }
  };
}