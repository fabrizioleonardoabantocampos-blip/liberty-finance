// 🔧 MÓDULO: Reparar cuenta de Israel (ULTRA-OPTIMIZADO con carga específica por usuario)
import * as kv from "./kv_store.tsx";

// ⚡ NUEVA FUNCIÓN: Cargar solo datos de un usuario específico (sin cargar TODO)
async function cargarDatosUsuario(userId: string) {
  console.log(`📥 Cargando datos específicos del usuario ${userId}...`);
  
  // ⚡ OPTIMIZACIÓN CRÍTICA: Cargar en paralelo pero con timeout individual
  const timeout = 30000; // 30 segundos por operación
  
  const cargarConTimeout = async <T,>(promesa: Promise<T>, nombre: string): Promise<T> => {
    const timeoutPromise = new Promise<never>((_, reject) => {
      setTimeout(() => reject(new Error(`Timeout cargando ${nombre} después de ${timeout}ms`)), timeout);
    });
    
    return Promise.race([promesa, timeoutPromise]);
  };
  
  try {
    const [allPacks, allComisiones] = await Promise.all([
      cargarConTimeout(kv.getByPrefix(`pack:`), 'packs'),
      cargarConTimeout(kv.getByPrefix(`comision:`), 'comisiones')
    ]);
    
    console.log(`📊 Total registros: ${allPacks.length} packs, ${allComisiones.length} comisiones`);
    
    // Filtrar de forma eficiente
    const userPacks = allPacks.filter((p: any) => p?.userId === userId);
    const userComisiones = allComisiones.filter((c: any) => c?.userId === userId);
    
    console.log(`✅ Cargados ${userPacks.length} packs y ${userComisiones.length} comisiones del usuario`);
    
    return { userPacks, userComisiones };
  } catch (error) {
    console.error('❌ Error cargando datos del usuario:', error);
    throw new Error(`Error al cargar datos: ${error instanceof Error ? error.message : String(error)}`);
  }
}

export async function repararCuentaIsrael() {
  const israelId = 'cf09eadf-d218-4590-93ff-447fd031cd42';
  const startTime = Date.now();
  console.log(`🔧 [${new Date().toISOString()}] Iniciando reparación...`);
  
  try {
    // ⚡ PASO 1: Cargar solo datos de Israel (optimizado)
    console.log(`📥 [+${((Date.now() - startTime) / 1000).toFixed(1)}s] Cargando datos...`);
    const { userPacks: israelPacksViejos, userComisiones: comisiones } = await cargarDatosUsuario(israelId);
    
    console.log(`📦 Packs a eliminar: ${israelPacksViejos.length}`);
    console.log(`💰 Comisiones: ${comisiones.length}`);
    
    // ⚡ PASO 2: Eliminar packs viejos en batch
    if (israelPacksViejos.length > 0) {
      console.log(`🗑️ [+${((Date.now() - startTime) / 1000).toFixed(1)}s] Eliminando ${israelPacksViejos.length} packs...`);
      const packKeys = israelPacksViejos.map((p: any) => `pack:${p.id}`);
      await kv.mdel(packKeys);
      console.log(`✅ [+${((Date.now() - startTime) / 1000).toFixed(1)}s] Packs eliminados`);
    }
    
    // ⚡ PASO 3: Ordenar comisiones por fecha
    console.log(`📊 [+${((Date.now() - startTime) / 1000).toFixed(1)}s] Ordenando ${comisiones.length} comisiones...`);
    const comisionesOrdenadas = comisiones.sort((a, b) => 
      new Date(a.fecha).getTime() - new Date(b.fecha).getTime()
    );
    
    const totalComisiones = comisionesOrdenadas.reduce((sum, c) => sum + (c.monto || 0), 0);
    console.log(`💵 [+${((Date.now() - startTime) / 1000).toFixed(1)}s] Total comisiones: $${totalComisiones.toFixed(2)}`);
    
    // ⚡ PASO 4: Crear packs EN MEMORIA
    console.log(`🏗️ [+${((Date.now() - startTime) / 1000).toFixed(1)}s] Creando nuevos packs...`);
    const packsInfo = [
      { nombre: 'Pack Liberty $50', monto: 50, limite: 100 },
      { nombre: 'Pack Liberty $100', monto: 100, limite: 200 },
      { nombre: 'Pack Liberty $200', monto: 200, limite: 400 }
    ];
    
    const packs: any[] = packsInfo.map(info => ({
      id: crypto.randomUUID(),
      userId: israelId,
      nombre: info.nombre,
      monto: info.monto,
      limite: info.limite,
      activo: true,
      status: 'activo',
      fechaCompra: new Date().toISOString(),
      rendimientoAcumulado: 0,
      comisiones: []
    }));
    
    // ⚡ PASO 5: Distribuir comisiones
    console.log(`🔄 [+${((Date.now() - startTime) / 1000).toFixed(1)}s] Distribuyendo comisiones entre packs...`);
    let packIndex = 0;
    const comisionesActualizadas: any[] = [];
    
    for (let i = 0; i < comisionesOrdenadas.length; i++) {
      const comision = comisionesOrdenadas[i];
      
      if (packIndex >= packs.length) {
        console.log(`⚠️ Todos los packs llenos, ${comisionesOrdenadas.length - i} comisiones restantes`);
        break;
      }
      
      const pack = packs[packIndex];
      const espacio = pack.limite - pack.rendimientoAcumulado;
      
      if (espacio >= (comision.monto || 0)) {
        pack.rendimientoAcumulado += (comision.monto || 0);
        pack.comisiones.push(comision);
        comision.packId = pack.id;
        comisionesActualizadas.push(comision);
        
        // Si el pack llegó al límite, marcarlo como inactivo
        if (pack.rendimientoAcumulado >= pack.limite) {
          pack.activo = false;
          pack.status = 'inactivo';
          console.log(`📦 Pack ${pack.nombre} completado (${pack.rendimientoAcumulado}/${pack.limite})`);
          packIndex++;
        }
      } else {
        // Pack lleno, pasar al siguiente
        pack.activo = false;
        pack.status = 'inactivo';
        console.log(`📦 Pack ${pack.nombre} marcado como inactivo (espacio insuficiente)`);
        packIndex++;
        i--; // Reintentar con el siguiente pack
      }
      
      // Log de progreso cada 10 comisiones
      if ((i + 1) % 10 === 0) {
        console.log(`📊 Progreso: ${i + 1}/${comisionesOrdenadas.length} comisiones procesadas`);
      }
    }
    
    console.log(`✅ [+${((Date.now() - startTime) / 1000).toFixed(1)}s] ${comisionesActualizadas.length} comisiones redistribuidas`);
    
    // ⚡ PASO 6: Guardar en lotes pequeños (5 items por batch para mayor seguridad)
    const BATCH_SIZE = 5;
    
    // Guardar packs
    console.log(`💾 [+${((Date.now() - startTime) / 1000).toFixed(1)}s] Guardando ${packs.length} packs...`);
    const packsToSave = packs.map(p => ({
      id: p.id,
      userId: p.userId,
      nombre: p.nombre,
      monto: p.monto,
      activo: p.activo,
      status: p.status,
      fechaCompra: p.fechaCompra,
      rendimientoAcumulado: p.rendimientoAcumulado
    }));
    
    for (let i = 0; i < packsToSave.length; i += BATCH_SIZE) {
      const batch = packsToSave.slice(i, i + BATCH_SIZE);
      const keys = batch.map(p => `pack:${p.id}`);
      await kv.mset(keys, batch);
      console.log(`💾 Guardados ${batch.length} packs (lote ${Math.floor(i/BATCH_SIZE) + 1})`);
    }
    
    // Guardar comisiones
    console.log(`💾 [+${((Date.now() - startTime) / 1000).toFixed(1)}s] Guardando ${comisionesActualizadas.length} comisiones...`);
    for (let i = 0; i < comisionesActualizadas.length; i += BATCH_SIZE) {
      const batch = comisionesActualizadas.slice(i, i + BATCH_SIZE);
      const keys = batch.map(c => `comision:${c.id}`);
      await kv.mset(keys, batch);
      
      if ((i + BATCH_SIZE) % 20 === 0) {
        const progress = Math.min(i + BATCH_SIZE, comisionesActualizadas.length);
        const tiempo = ((Date.now() - startTime) / 1000).toFixed(1);
        console.log(`💾 [+${tiempo}s] Progreso: ${progress}/${comisionesActualizadas.length} comisiones guardadas`);
      }
    }
    
    console.log(`✅ [+${((Date.now() - startTime) / 1000).toFixed(1)}s] Todas las comisiones guardadas`);
    
    // ⚡ PASO 7: Resumen detallado
    const resumen = packs.map(p => ({
      nombre: p.nombre,
      monto: p.monto,
      limite: p.limite,
      rendimientoAcumulado: parseFloat(p.rendimientoAcumulado.toFixed(2)),
      porcentaje: parseFloat(((p.rendimientoAcumulado / p.monto) * 100).toFixed(2)),
      activo: p.activo,
      comisiones: p.comisiones.length,
      montoEnComisiones: parseFloat(p.comisiones.reduce((sum: number, c: any) => sum + (c.monto || 0), 0).toFixed(2))
    }));
    
    const totalTime = ((Date.now() - startTime) / 1000).toFixed(2);
    console.log(`🎉 [${new Date().toISOString()}] Reparación completada exitosamente en ${totalTime}s`);
    
    return {
      success: true,
      mensaje: 'Reparación completada exitosamente',
      packsEliminados: israelPacksViejos.length,
      packsCreados: packs.length,
      comisionesReasignadas: comisionesActualizadas.length,
      comisionesTotales: comisionesOrdenadas.length,
      totalMonto: totalComisiones.toFixed(2),
      montoAsignado: parseFloat(comisionesActualizadas.reduce((sum, c) => sum + (c.monto || 0), 0).toFixed(2)),
      packsDetalle: resumen,
      timestamp: new Date().toISOString()
    };
    
  } catch (error) {
    console.error(`❌ [${new Date().toISOString()}] Error en reparación:`, error);
    throw error;
  }
}