// NUEVO ALGORITMO DE RECALCULO DE MATRIZ - Copia este código y reemplaza el endpoint existente

// Recalcular y asignar posiciones de matriz para TODOS los packs (RESETEA TODO)
app.post("/make-server-9f68532a/admin/recalcular-matriz", async (c) => {
  try {
    console.log(`🔄 RECALCULANDO MATRIZ COMPLETA - RESETEANDO TODAS LAS POSICIONES...`);
    
    const allUsers = await crm.getAllUsers();
    const allPacks = await crm.getAllPacks();
    
    let packsActualizados = 0;
    let errores = 0;
    
    // 🔥 PASO 1: RESETEAR todas las posiciones de matriz a null para empezar desde cero
    console.log(`🧹 PASO 1: Reseteando todas las posiciones de matriz...`);
    for (const pack of allPacks) {
      if (pack.matrizPadre || pack.matrizNivel || pack.matrizPosicion) {
        await crm.updatePack(pack.id, {
          matrizPadre: undefined,
          matrizNivel: undefined,
          matrizPosicion: undefined
        });
      }
    }
    console.log(`✅ Todas las posiciones reseteadas`);
    
    // 🔥 PASO 2: Agrupar packs por usuario para asignar UNA posición por usuario
    const packsPorUsuario = new Map();
    for (const pack of allPacks) {
      if (!packsPorUsuario.has(pack.userId)) {
        packsPorUsuario.set(pack.userId, []);
      }
      packsPorUsuario.get(pack.userId).push(pack);
    }
    
    // 🔥 PASO 3: Ordenar usuarios por la fecha del PRIMER pack (más antiguo primero)
    const usuariosConPacks = Array.from(packsPorUsuario.entries()).map(([userId, packs]) => {
      const user = allUsers.find(u => u.id === userId);
      const primerPack = packs.sort((a, b) => 
        new Date(a.fechaCompra).getTime() - new Date(b.fechaCompra).getTime()
      )[0];
      return {
        userId,
        user,
        packs,
        primerPackFecha: primerPack.fechaCompra,
        referidoPor: user?.referidoPor
      };
    });
    
    // Ordenar por fecha del primer pack (más antiguo primero)
    usuariosConPacks.sort((a, b) => 
      new Date(a.primerPackFecha).getTime() - new Date(b.primerPackFecha).getTime()
    );
    
    console.log(`📊 Total de usuarios con packs: ${usuariosConPacks.length}`);
    
    // 🔥 PASO 4: Asignar posiciones MANUALMENTE siguiendo la lógica de matriz 3x3
    const matrizOcupada = new Map(); // matrizPadre -> [userId1, userId2, userId3]
    
    for (const { userId, user, packs, referidoPor } of usuariosConPacks) {
      if (!referidoPor) {
        console.log(`  ⚠️ Usuario ${user?.id_unico || userId} sin patrocinador, omitiendo...`);
        continue;
      }
      
      try {
        let matrizPadreAsignado = referidoPor;
        let nivelAsignado = 1;
        let posicionAsignada = 1;
        
        // BFS para encontrar hueco
        const queue = [{ padreId: referidoPor, nivel: 1 }];
        const visitados = new Set();
        let encontrado = false;
        
        while (queue.length > 0 && !encontrado) {
          const current = queue.shift();
          if (!current) continue;
          
          const { padreId, nivel } = current;
          
          if (visitados.has(padreId)) continue;
          visitados.add(padreId);
          
          const hijosActuales = matrizOcupada.get(padreId) || [];
          
          if (hijosActuales.length < 3) {
            matrizPadreAsignado = padreId;
            nivelAsignado = nivel;
            posicionAsignada = hijosActuales.length + 1;
            
            hijosActuales.push(userId);
            matrizOcupada.set(padreId, hijosActuales);
            encontrado = true;
          } else {
            for (const hijoId of hijosActuales) {
              queue.push({ padreId: hijoId, nivel: nivel + 1 });
            }
          }
          
          if (visitados.size > 1000) break;
        }
        
        // Actualizar TODOS los packs del usuario con la misma posición
        for (const pack of packs) {
          await crm.updatePack(pack.id, {
            matrizPadre: matrizPadreAsignado,
            matrizNivel: nivelAsignado,
            matrizPosicion: posicionAsignada
          });
          packsActualizados++;
        }
        
        const padreUsuario = allUsers.find(u => u.id === matrizPadreAsignado);
        console.log(`  ✅ ${user?.id_unico || userId}: Nivel ${nivelAsignado}, Pos ${posicionAsignada}, Padre: ${padreUsuario?.id_unico || matrizPadreAsignado}`);
      } catch (error) {
        console.error(`  ❌ Error al asignar posición a ${userId}:`, error);
        errores++;
      }
    }
    
    console.log(`✅ RECALCULO COMPLETADO: ${packsActualizados} packs actualizados, ${errores} errores`);
    
    return c.json({
      success: true,
      packsActualizados,
      errores,
      message: `Matriz recalculada: ${packsActualizados} packs actualizados`
    });
  } catch (error) {
    console.error('Error al recalcular matriz:', error);
    return c.json({ error: "Error al recalcular matriz" }, 500);
  }
});
