// Herramientas de administración para Liberty Finance
import * as crm from './crm.tsx';

/**
 * Recalcula los rangos de TODOS los usuarios del sistema
 * Útil para actualizar rangos después de cambios en la lógica o requisitos
 */
export async function recalcularTodosLosRangos() {
  console.log('🔄 Iniciando recálculo de rangos para TODOS los usuarios...');
  
  const todosLosUsuarios = await crm.getAllUsers();
  const resultados = [];
  
  for (const usuario of todosLosUsuarios) {
    try {
      const rangoAnterior = usuario.rango || 'Sin Rango';
      const updatedUser = await crm.actualizarRangoUsuario(usuario.id);
      const rangoNuevo = updatedUser?.rango || 'Sin Rango';
      
      resultados.push({
        id_unico: usuario.id_unico,
        nombre: `${usuario.nombre} ${usuario.apellido}`,
        rangoAnterior,
        rangoNuevo,
        cambio: rangoAnterior !== rangoNuevo
      });
    } catch (error) {
      console.error(`❌ Error recalculando rango de ${usuario.id_unico}:`, error);
      resultados.push({
        id_unico: usuario.id_unico,
        nombre: `${usuario.nombre} ${usuario.apellido}`,
        error: String(error)
      });
    }
  }
  
  const totalCambios = resultados.filter(r => r.cambio).length;
  console.log(`✅ Recálculo completado: ${totalCambios} cambios de ${todosLosUsuarios.length} usuarios`);
  
  return {
    success: true,
    totalUsuarios: todosLosUsuarios.length,
    totalCambios,
    resultados
  };
}
