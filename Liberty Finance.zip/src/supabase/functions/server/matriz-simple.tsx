// 🚀 ENDPOINT SIMPLIFICADO DE MATRIZ - Sin timeout
// Este endpoint NO carga todos los usuarios/packs del sistema
// Solo carga datos del usuario específico y sus descendientes directos

import type { Context } from 'npm:hono';
import * as crm from './crm.tsx';

// Nota: No podemos importar getCachedUsuarios/getCachedPacks desde index.tsx
// porque causaría dependencias circulares. En su lugar, usaremos las funciones
// de crm.tsx que ya están optimizadas.

export async function getMatrizSimple(c: Context) {
  const startTime = Date.now();
  try {
    const userId = c.req.param('userId');
    
    console.log(`🔍 [SIMPLE] Cargando matriz para ${userId}...`);
    
    // 1. Cargar solo datos del usuario
    const usuario = await crm.getUserById(userId);
    if (!usuario) {
      return c.json({ error: 'Usuario no encontrado' }, 404);
    }
    
    // 2. Cargar packs del usuario
    const packs = await crm.getPacksByUserId(userId);
    const totalInversion = packs.reduce((sum, p) => sum + p.monto, 0);
    const packActivo = packs.find(p => p.activo);
    
    // 3. Cargar solo referidos directos (nivel 1)
    const referidosDirectos = await crm.getReferidosDirectos(userId);
    
    // 3.5 Cargar TODOS los packs en una sola operación usando getAllPacks
    const todosLosPacks = await crm.getAllPacks();
    const packsMap = new Map<string, any[]>();
    
    // Agrupar packs por userId
    todosLosPacks.forEach((pack: any) => {
      // getAllPacks ya retorna los packs directamente, no { value: pack }
      if (!pack || !pack.userId) return;
      
      if (!packsMap.has(pack.userId)) {
        packsMap.set(pack.userId, []);
      }
      packsMap.get(pack.userId)!.push(pack);
    });
    
    console.log(`📦 Packs cargados para ${packsMap.size} usuarios`);
    
    // 4. Crear matriz con solo nivel 1
    const cycle: any = {
      level1: [null, null, null]
    };
    
    // 5. Llenar nivel 1 con los primeros 3 referidos que tengan pack en la matriz
    let posicionados = 0;
    for (const ref of referidosDirectos) {
      if (posicionados >= 3) break;
      
      const refPacks = packsMap.get(ref.id) || [];
      const refPackActivo = refPacks.find(p => p.activo);
      
      // Verificar si el referido tiene un pack con matrizPadre === userId
      const packEnMatriz = refPacks.find(p => p.matrizPadre === userId);
      
      if (packEnMatriz) {
        const refInversion = refPacks.reduce((sum, p) => sum + p.monto, 0);
        
        // Determinar posición en la matriz (convertir de base-1 a base-0)
        let posicion = packEnMatriz.matrizPosicion ? packEnMatriz.matrizPosicion - 1 : posicionados;
        if (posicion < 0 || posicion >= 3) posicion = posicionados;
        
        // Buscar primera posición vacía si ya está ocupada
        if (cycle.level1[posicion] !== null) {
          posicion = cycle.level1.findIndex((p: any) => p === null);
        }
        
        if (posicion !== -1 && posicion < 3) {
          cycle.level1[posicion] = {
            id: ref.id_unico,
            internalId: ref.id,
            nombre: ref.nombre,
            apellido: ref.apellido,
            pack: refPackActivo?.nombre || 'Sin Pack',
            estatus: ref.activo ? 'activo' : 'inactivo',
            inversion: refInversion
          };
          posicionados++;
        }
      }
    }
    
    // 6. Formatear referidos directos para la lista
    const directosFormateados = referidosDirectos.slice(0, 20).map((ref) => {
      const refPacks = packsMap.get(ref.id) || [];
      const refInversion = refPacks.reduce((sum, p) => sum + p.monto, 0);
      const refPackActivo = refPacks.find(p => p.activo);
      
      return {
        id: ref.id_unico,
        nombre: ref.nombre,
        apellido: ref.apellido,
        nivel: 1,
        pack: refPackActivo?.nombre || 'Sin pack',
        estatus: ref.activo ? 'activo' : 'inactivo',
        inversion: refInversion
      };
    });
    
    const elapsed = Date.now() - startTime;
    console.log(`✅ [SIMPLE] Matriz generada en ${elapsed}ms`);
    
    return c.json({
      cycle,
      directos: directosFormateados,
      inversion: totalInversion,
      pack: packActivo?.nombre || 'Sin pack'
    });
    
  } catch (error) {
    const elapsed = Date.now() - startTime;
    console.error(`❌ [SIMPLE] Error en matriz (${elapsed}ms):`, error);
    return c.json({ 
      error: "Error al obtener matriz",
      details: error instanceof Error ? error.message : String(error)
    }, 500);
  }
}