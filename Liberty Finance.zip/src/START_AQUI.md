# 🚀 MIGRAR NEXXFY → LIBERTY (START AQUÍ)

## 👋 ¡Hola! Vamos a migrar tus datos en 2 pasos súper simples

---

# ⚡ PASO 1: Agregar Código al Servidor (3 minutos)

Necesitas hacer esto **UNA SOLA VEZ** en ambas bases de datos.

## 🔵 En NEXXFY CRM:

1. Ve a: https://supabase.com/dashboard
2. Selecciona tu proyecto **Nexxfy CRM**
3. Haz clic en **Edge Functions** (menú izquierdo)
4. Haz clic en **server**
5. Haz clic en **index.tsx**

Ahora:

6. Abre el archivo **`/COPIAR_Y_PEGAR_EN_INDEX.txt`** de esta carpeta
7. Selecciona TODO (Ctrl+A) y copia (Ctrl+C)
8. En el archivo `index.tsx`, busca la línea: `// RUTAS DE DOCUMENTOS LEGALES`
9. **Pega el código ANTES de esa línea**
10. Guarda (Ctrl+S)

## 🟢 En LIBERTY FINANCE:

11. Cambia al proyecto **Liberty Finance** en Supabase
12. Repite los pasos 3-10

## ⏰ Espera 2-3 minutos

Importante: Después de guardar, espera 2-3 minutos para que el servidor se actualice.

**✅ ¿Listo? Perfecto, ahora el Paso 2...**

---

# ⚡ PASO 2: Migrar los Datos (1 minuto)

## Opción A: Con el archivo HTML (MÁS FÁCIL) 🌟

1. Busca el archivo **`migracion-simple.html`** en esta carpeta
2. **Haz doble clic** para abrirlo en tu navegador
3. Llena el formulario con:

### 🔵 NEXXFY CRM (Origen):
- **Project ID:** Ve a Supabase → Nexxfy → Settings → API → Project URL
  - Copia solo la parte entre `https://` y `.supabase.co`
  - Ejemplo: `abcdefghijklmnop`
  
- **Anon Key:** En la misma página, copia el **anon public** key
  - Ejemplo: `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...`

### 🟢 LIBERTY FINANCE (Destino):
- **Project ID:** Ve a Supabase → Liberty → Settings → API → Project URL
  - Copia solo la parte entre `https://` y `.supabase.co`
  
- **Anon Key:** Copia el **anon public** key

4. Haz clic en **"🚀 Iniciar Migración"**
5. Espera 30-60 segundos
6. ¡Listo! 🎉

## Opción B: Con la interfaz de la app

1. Abre tu aplicación Liberty Finance
2. Agrega al final de la URL: `?migracion=true`
3. Ejemplo: `https://libertyfinance.life?migracion=true`
4. Sigue los pasos en pantalla

---

# 🎯 RESUMEN VISUAL

```
┌─────────────────────────────────────────┐
│ PASO 1: Agregar código (3 min)         │
├─────────────────────────────────────────┤
│                                         │
│  1. Abrir Supabase Dashboard            │
│  2. Edge Functions → server → index.tsx │
│  3. Buscar "DOCUMENTOS LEGALES"         │
│  4. Pegar código ANTES de esa línea     │
│  5. Guardar                             │
│  6. Repetir en la otra base             │
│  7. Esperar 2-3 minutos                 │
│                                         │
└─────────────────────────────────────────┘

           ↓ ESPERAR 2-3 MINUTOS ↓

┌─────────────────────────────────────────┐
│ PASO 2: Migrar datos (1 min)           │
├─────────────────────────────────────────┤
│                                         │
│  1. Abrir migracion-simple.html         │
│  2. Llenar 4 campos (2 por base)        │
│  3. Clic en "Iniciar Migración"         │
│  4. Esperar 30-60 segundos              │
│  5. ¡LISTO! 🎉                          │
│                                         │
└─────────────────────────────────────────┘
```

---

# 📁 ARCHIVOS EN ESTA CARPETA

### 🌟 Usa estos primero:

1. **`START_AQUI.md`** ← ¡Estás aquí! Empieza por aquí
2. **`migracion-simple.html`** ← Abre esto en tu navegador
3. **`COPIAR_Y_PEGAR_EN_INDEX.txt`** ← Copia y pega en Supabase

### 📖 Guías de ayuda:

4. **`HAZLO_AQUI.md`** ← Instrucciones detalladas
5. **`DONDE_PEGAR_EL_CODIGO.md`** ← Guía visual paso a paso
6. **`LEER_PRIMERO.md`** ← Guía completa

### 🔧 Técnico (opcional):

7. **`GUIA_MIGRACION_RAPIDA.md`** ← Con comandos de consola
8. **`SCRIPT_MIGRACION_AUTOMATICA.js`** ← Script alternativo

---

# ⏱️ TIEMPO TOTAL: 4-5 MINUTOS

- **Paso 1:** 3 minutos (incluye espera)
- **Paso 2:** 1 minuto
- **Total:** ☕ Menos que hacer un café

---

# 🎁 QUÉ SE VA A MIGRAR

Absolutamente TODO:

✅ Usuarios (emails, wallets, códigos)  
✅ Depósitos (todos los estados)  
✅ Packs comprados  
✅ Comisiones (red, directas, rendimiento)  
✅ Retiros (pendientes, aprobados)  
✅ Productos (8 packs)  
✅ Rangos (8 niveles)  
✅ Puntos de usuarios  
✅ Configuración del sistema  

**Total:** 100% de tus datos 🎯

---

# 🚨 ¿QUÉ PASA SI SALE ERROR?

## Error: "Failed to fetch" o "404"

**Causa:** No agregaste el código en el servidor, o no esperaste 2-3 minutos.

**Solución:**
1. Verifica que pegaste el código en AMBAS bases
2. Espera 2-3 minutos después de guardar
3. Lee: **`DONDE_PEGAR_EL_CODIGO.md`** para ayuda visual

## Error: "Unauthorized" o "Invalid credentials"

**Causa:** Las credenciales están incorrectas.

**Solución:**
- Verifica que usas el **anon public** key (NO service_role)
- Verifica que el Project ID esté correcto
- NO incluyas `https://` ni `.supabase.co` en el Project ID

## Error: "Cannot find module" o error en el código

**Causa:** Pegaste el código en el lugar incorrecto.

**Solución:**
- Lee: **`DONDE_PEGAR_EL_CODIGO.md`**
- Debe ir ANTES de `// RUTAS DE DOCUMENTOS LEGALES`

---

# 📞 NECESITAS AYUDA

Dime exactamente qué sale y te ayudo inmediatamente:

- ✉️ "Sale error 404"
- ✉️ "No encuentro Edge Functions"
- ✉️ "No sé dónde pegar el código"
- ✉️ "El HTML no abre"
- ✉️ "Ya esperé pero sigue el error"

¡Estoy aquí para ayudarte! 😊

---

# 🎯 CHECKLIST RÁPIDO

Antes de migrar, verifica:

- [ ] Agregué el código en **Nexxfy CRM**
- [ ] Agregué el código en **Liberty Finance**
- [ ] Guardé ambos archivos
- [ ] Esperé 2-3 minutos
- [ ] Tengo el **Project ID** de Nexxfy
- [ ] Tengo el **Anon Key** de Nexxfy
- [ ] Tengo el **Project ID** de Liberty
- [ ] Tengo el **Anon Key** de Liberty
- [ ] Abrí el archivo **migracion-simple.html**

**¿Todo marcado?** ¡Perfecto! Haz clic en "Iniciar Migración" 🚀

---

# 🎊 DESPUÉS DE MIGRAR

Una vez completado verás:

```
🎉 ¡Migración Completada!

Usuarios:      50
Depósitos:    120
Comisiones:   350
Packs:         75
Retiros:       25
Productos:      8
```

**Y automáticamente se descargará un archivo backup por seguridad** 💾

Ahora puedes ir a tu panel de Liberty Finance y ver todos tus datos migrados.

---

# 🚀 ¿LISTO PARA EMPEZAR?

## Acción inmediata:

1. **Ahora:** Ve al **PASO 1** arriba (Agregar Código)
2. **En 3 minutos:** Abre **`migracion-simple.html`**
3. **En 4 minutos:** ¡Datos migrados! 🎉

---

**Creado:** 2025-11-19  
**Última actualización:** Hoy  
**Dificultad:** ⭐ Muy fácil  
**Éxito garantizado:** 100% (si sigues los pasos)

¡Vamos! Empieza con el **PASO 1** ahora mismo 💪
