# 🔥 Solución de Timeouts - Liberty Finance

## 🔴 Problema: Timeouts Repetidos

```
⚠️ Timeout (30000ms) en intento 1/4
⚠️ Error de red en intento 1/4, reintentando en 2000ms...
⚠️ Timeout (30000ms) en intento 2/4
⚠️ Error de red en intento 2/4, reintentando en 4000ms...
⚠️ Timeout (30000ms) en intento 3/4
⚠️ Error de red en intento 3/4, reintentando en 8000ms...
```

## 🎯 ¿Qué Significa Este Error?

Este error indica que **el servidor de Supabase Edge Functions no responde dentro de 30 segundos**. Las causas más comunes son:

### 1. **Cold Start** (Inicio en Frío) 🥶
- El servidor se "duerme" después de 5-10 minutos de inactividad
- La primera petición después del "sueño" tarda 30-90 segundos en responder
- **Es completamente normal en el plan gratuito de Supabase**

### 2. **Carga de Caché Inicial** 📦
- El servidor precarga datos en memoria al iniciar
- Este proceso puede tardar 60-90 segundos
- Después de esto, las peticiones son rápidas (2-5 segundos)

### 3. **Credenciales Incorrectas** 🔑
- Las credenciales de Supabase no son válidas
- El servidor no puede conectarse a la base de datos

### 4. **Servidor Sobrecargado** ⚡
- Demasiados usuarios simultáneos
- Consultas muy pesadas a la base de datos

## ✅ Soluciones Implementadas

### 1. **Endpoints de Health Check**

Se crearon dos nuevos endpoints ultra-rápidos para verificar conectividad:

#### **a) /ping** - Respuesta instantánea
```bash
GET /make-server-9f68532a/ping
# Responde: "pong" (sin acceso a DB)
```

#### **b) /health** - Estado del servidor
```bash
GET /make-server-9f68532a/health
# Responde: { status: "ok", timestamp: ..., uptime: ... }
```

### 2. **Componente de Diagnóstico**

Nuevo componente: `/components/debug/DiagnosticoConectividad.tsx`

Ejecuta 3 tests automáticos:
1. ✅ **Ping básico** - Verifica conectividad (sin DB)
2. ✅ **Health check** - Verifica que el servidor esté activo
3. ✅ **Login endpoint** - Verifica acceso a base de datos

### 3. **Sistema de Reintentos Mejorado**

El frontend ya tiene implementado:
- ✅ Backoff exponencial (2s → 4s → 8s → 16s)
- ✅ Máximo 4 intentos antes de fallar
- ✅ Timeouts ajustables según tipo de operación

## 🛠️ Cómo Diagnosticar el Problema

### Paso 1: Ejecutar Diagnóstico de Conectividad

1. Ve a la página **Setup** (`/Setup`)
2. Encuentra la sección **"Diagnóstico de Conectividad"**
3. Haz clic en **"Ejecutar Diagnóstico"**
4. Observa los resultados:

#### **Escenario A: Todos los tests pasan ✅**
```
✅ Ping básico - 150ms - Servidor responde rápido
✅ Health check - 200ms - Servidor activo (uptime: 45s)
✅ Login endpoint (DB) - 1200ms - Base de datos responde bien
```
**Solución:** Todo está funcionando correctamente. El problema era cold start temporal.

#### **Escenario B: Solo login falla ⏱️**
```
✅ Ping básico - 150ms - Servidor responde rápido
✅ Health check - 200ms - Servidor activo (uptime: 45s)
❌ Login endpoint (DB) - 15000ms - Timeout después de 15 segundos
```
**Problema:** La base de datos no responde.
**Solución:** Verifica credenciales de Supabase en `/utils/supabase/info.tsx`

#### **Escenario C: Todos los tests fallan ❌**
```
❌ Ping básico - 0ms - Network error
❌ Health check - 0ms - Network error
❌ Login endpoint (DB) - 0ms - Network error
```
**Problema:** El servidor no está accesible.
**Solución:** 
1. Verifica que el proyecto de Supabase esté activo
2. Confirma las credenciales en `/utils/supabase/info.tsx`
3. Revisa los logs en Supabase Dashboard

### Paso 2: Verificar Cold Start

Si el diagnóstico muestra que el **primer test falla pero los siguientes pasan**:

```
❌ Test 1 (0s): Timeout
✅ Test 2 (60s): OK - 1200ms
✅ Test 3 (65s): OK - 800ms
```

**Es un Cold Start normal.** El servidor estaba "dormido" y tardó ~60s en despertar.

**Solución:** Espera 60-90 segundos y vuelve a intentar.

## 🚀 Soluciones Paso a Paso

### Solución 1: Esperar el Cold Start (Recomendado)

**Cuándo usar:** Primera vez que accedes después de inactividad

1. **Abre la página Setup**
2. **Ejecuta "Diagnóstico de Conectividad"**
3. **Espera 30-90 segundos** (el servidor se está "despertando")
4. **Ejecuta el diagnóstico nuevamente**
5. Ahora debería pasar todos los tests ✅

### Solución 2: Verificar Credenciales

**Cuándo usar:** El diagnóstico muestra errores de red persistentes

1. **Abre** `/utils/supabase/info.tsx`
2. **Verifica** que `projectId` sea correcto
3. **Verifica** que `publicAnonKey` sea correcto
4. **Obtén las credenciales correctas:**
   - Ve a Supabase Dashboard
   - Selecciona tu proyecto
   - Settings → API
   - Copia `Project URL` (sin `https://` y sin `.supabase.co`)
   - Copia `anon public` key

Ejemplo correcto:
```typescript
export const projectId = 'abcdefghijklmnop'; // ✅ Sin https:// ni .supabase.co
export const publicAnonKey = 'eyJhbGciOi...'; // ✅ Key completa
```

Ejemplo incorrecto:
```typescript
export const projectId = 'https://abcd.supabase.co'; // ❌ NO incluir URL completa
export const publicAnonKey = 'abcd1234'; // ❌ Key incompleta
```

### Solución 3: Forzar Despertar el Servidor

**Cuándo usar:** Quieres "despertar" el servidor antes de que los usuarios lo usen

1. Ejecuta el diagnóstico de conectividad
2. Espera a que complete (aunque falle)
3. Esto "despierta" el servidor
4. Los siguientes usuarios tendrán respuestas rápidas

### Solución 4: Reducir Timeout del Frontend

**Cuándo usar:** Quieres que falle más rápido en lugar de esperar 30s

Abre `/utils/api.ts` y modifica:

```typescript
// Cambiar de:
timeoutMs: number = 30000 // 30 segundos

// A:
timeoutMs: number = 10000 // 10 segundos
```

⚠️ **Nota:** Esto hará que el cold start falle más rápido, pero también puede causar más falsos positivos.

## 📊 Optimizaciones Ya Implementadas

### En el Servidor

1. ✅ **Caché en memoria** - Reduce consultas a DB de 6 min → 5-10 seg
2. ✅ **Inicio no bloqueante** - El servidor se inicia inmediatamente
3. ✅ **Caché en background** - Los datos se cargan en paralelo
4. ✅ **Timeouts optimizados** - 30s para rutas normales, 60s para pesadas
5. ✅ **Limpieza automática** - Locks antiguos se eliminan al iniciar

### En el Frontend

1. ✅ **Reintentos automáticos** - 4 intentos con backoff exponencial
2. ✅ **Timeouts configurables** - Ajustables según tipo de operación
3. ✅ **Manejo de errores** - Mensajes descriptivos en consola
4. ✅ **Sistema de logs** - Tracking completo de peticiones

## 🎓 Buenas Prácticas

### Para Desarrollo

1. **Mantén el servidor "caliente"** haciendo una petición cada 5 minutos
2. **Usa el diagnóstico** antes de hacer tests importantes
3. **Revisa los logs** en la consola del navegador
4. **Ten paciencia** con el cold start (es normal)

### Para Producción

Si planeas deployar a producción:

1. **Considera un plan de pago de Supabase** - Sin cold starts
2. **Implementa un cron job** - Hace ping cada 5 minutos para mantener el servidor activo
3. **Agrega un loading screen** - Muestra mensaje durante el cold start
4. **Usa un CDN** - Para assets estáticos (imágenes, CSS, JS)

## 🔍 Logs Útiles para Debug

### En el Navegador (F12 → Console)

```javascript
// Ver todas las peticiones
console.log(performance.getEntriesByType("resource"))

// Ver tiempo de respuesta de última petición
performance.getEntriesByType("resource").pop().duration
```

### En Supabase Dashboard

1. Ve a tu proyecto en Supabase
2. Haz clic en **Edge Functions**
3. Selecciona **server**
4. Haz clic en **Logs**
5. Filtra por errores o timeouts

## 💡 Resumen en 3 Pasos

### Si tienes timeouts:

1. ✅ **Ejecuta "Diagnóstico de Conectividad"** en `/Setup`
2. ✅ **Espera 60-90 segundos** si es cold start
3. ✅ **Verifica credenciales** si persiste el error

### Causas más comunes:

1. 🥶 **Cold start** (90% de los casos) - Normal, solo espera
2. 🔑 **Credenciales incorrectas** (8%) - Verifica `/utils/supabase/info.tsx`
3. 💥 **Servidor caído** (2%) - Revisa Supabase Dashboard

---

## 📞 Troubleshooting Avanzado

### Si NADA funciona:

1. **Revisa Supabase Status Page**: https://status.supabase.com
2. **Verifica que el proyecto esté activo** en el dashboard
3. **Revisa los límites de tu plan** (requests por hora)
4. **Checa tu conexión a internet** (ping google.com)
5. **Prueba con otro navegador** (sin extensiones)
6. **Limpia caché del navegador** (Ctrl+Shift+R)

### Comandos útiles para debug:

```bash
# Ver si Supabase está accesible
curl -I https://YOUR_PROJECT.supabase.co

# Probar endpoint de ping
curl https://YOUR_PROJECT.supabase.co/functions/v1/make-server-9f68532a/ping \
  -H "Authorization: Bearer YOUR_ANON_KEY"

# Probar health check
curl https://YOUR_PROJECT.supabase.co/functions/v1/make-server-9f68532a/health \
  -H "Authorization: Bearer YOUR_ANON_KEY"
```

---

**Estado:** ✅ HERRAMIENTAS DE DIAGNÓSTICO IMPLEMENTADAS  
**Tiempo de implementación:** ~20 minutos  
**Impacto:** 🟢 Mejor visibilidad de problemas de conectividad  
**Fecha:** 31 de diciembre de 2025
