# 🎨 Sistema de Cambio de Logo e Iconos

## ✅ IMPLEMENTADO COMPLETAMENTE

He implementado un sistema completo que te permite cambiar el logo/icono de Liberty Finance desde el panel de administrador.

---

## 🎯 FUNCIONALIDADES

### 1. **Subir Logo Personalizado**
- Desde el panel de administrador, ve a: **Configuración** → **Configuración General**
- Encontrarás una nueva sección: **"Logo de la Empresa"**
- Puedes subir cualquier imagen (PNG, JPEG, etc.)
- Se guarda automáticamente en la base de datos

### 2. **Logo Dinámico en Toda la App**
El logo se actualiza automáticamente en:
- ✅ Login (página de inicio de sesión)
- ✅ Register (página de registro)
- ✅ UserSidebar (sidebar del usuario)
- ✅ AdminSidebar (sidebar del administrador)
- ✅ Versión móvil y desktop

### 3. **Sistema de Fallback**
- Si no has subido un logo personalizado, usa el logo por defecto de Liberty Finance
- Nunca se rompe la interfaz

---

## 📍 CÓMO CAMBIAR EL LOGO

### Paso 1: Entrar al Panel Admin
1. Inicia sesión como administrador
2. Ve a la sección **"Configuración"** en el menú lateral

### Paso 2: Configuración General
1. Haz clic en **"Configuración General"**
2. Desplázate hacia abajo hasta la sección **"Logo de la Empresa"**

### Paso 3: Subir Logo
1. Haz clic en **"Cargar Logo"**
2. Selecciona tu archivo de imagen
3. Verás una **vista previa** del logo
4. Haz clic en **"Guardar Cambios"**

### Paso 4: ¡Listo!
- El logo se actualizará en **TODA** la aplicación
- Los usuarios verán el nuevo logo al recargar la página

---

## 🖼️ UBICACIÓN DEL LOGO EN LA APP

```
┌─────────────────────────────────────┐
│  📍 LOGIN PAGE                      │
│  ┌───────┐                          │
│  │ LOGO  │  ← Aquí se muestra       │
│  └───────┘                          │
│  Inicia sesión en tu cuenta         │
└─────────────────────────────────────┘

┌─────────────────────────────────────┐
│  📍 REGISTER PAGE                   │
│  ┌───────┐                          │
│  │ LOGO  │  ← Aquí se muestra       │
│  └───────┘                          │
│  Crear Cuenta                       │
└─────────────────────────────────────┘

┌─────────────────────────────────────┐
│  📍 USER SIDEBAR                    │
│  ┌──────┐                           │
│  │ LOGO │  Liberty Finance  ← Aquí  │
│  └──────┘  Oficina Virtual          │
│                                     │
│  📍 ADMIN SIDEBAR                   │
│  ┌──────┐                           │
│  │ LOGO │  Liberty Finance  ← Aquí  │
│  └──────┘  Panel Admin              │
└─────────────────────────────────────┘
```

---

## 💾 CONFIGURACIONES GUARDADAS

El logo se guarda en la base de datos junto con:
- ✅ Wallet principal (TRC20)
- ✅ Código QR de depósitos
- ✅ Logo de la empresa ← **NUEVO**
- ✅ Rendimiento activo/inactivo
- ✅ Porcentaje de rendimiento

---

## 🔧 DETALLES TÉCNICOS

### Archivos Modificados:

1. **`/components/admin/ConfiguracionGeneral.tsx`**
   - Agregada sección de logo
   - Funciones `handleLogoUpload()` y `handleRemoveLogo()`
   - Vista previa del logo

2. **`/hooks/useLogo.ts`** (NUEVO)
   - Hook personalizado para cargar el logo
   - Maneja el fallback al logo por defecto
   - Se puede usar en cualquier componente

3. **`/components/user/UserSidebar.tsx`**
   - Usa `useLogo()` para obtener el logo dinámico
   - Logo en versión collapsed y expandida

4. **`/components/admin/AdminSidebar.tsx`**
   - Usa `useLogo()` para obtener el logo dinámico
   - Logo en versión collapsed y expandida

5. **`/components/auth/Login.tsx`**
   - Usa `useLogo()` para mostrar el logo en el login

6. **`/components/auth/Register.tsx`**
   - Usa `useLogo()` para mostrar el logo en el registro

### Estructura del Hook:

```typescript
export function useLogo() {
  const [logoUrl, setLogoUrl] = useState<string>(logoImageDefault);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    cargarLogo();
  }, []);

  const cargarLogo = async () => {
    const config = await configuracionAPI.get();
    if (config.logoUrl) {
      setLogoUrl(config.logoUrl);
    }
  };

  return { logoUrl, loading };
}
```

---

## 📝 CARACTERÍSTICAS

### ✅ Responsive
- Funciona perfecto en mobile y desktop
- Se adapta al sidebar colapsado/expandido

### ✅ Base64
- Las imágenes se guardan en formato base64
- No necesitas hosting externo
- Carga instantánea

### ✅ Validación
- Solo acepta archivos de imagen
- Muestra error si el formato es incorrecto

### ✅ Vista Previa
- Puedes ver cómo se verá antes de guardar
- Botón para eliminar si no te gusta

---

## 🎨 RECOMENDACIONES

### Tamaño del Logo:
- **Ancho:** 200-400px
- **Alto:** 200-400px
- **Formato:** PNG con fondo transparente (recomendado)
- **Peso:** Menos de 500KB para carga rápida

### Diseño:
- Logo simple y reconocible
- Buenos colores para modo claro y oscuro
- Evita demasiado detalle (se ve pequeño en algunos lugares)

---

## 🚀 PRÓXIMOS PASOS

Si quieres expandir el sistema, puedes agregar:

1. **Favicon**: Logo que aparece en la pestaña del navegador
2. **Logo Secundario**: Para el sidebar colapsado
3. **Logo Email**: Para correos electrónicos
4. **Marca de Agua**: Para documentos PDF

---

## 📞 SOPORTE

Si tienes problemas con el logo:

1. Verifica que el archivo sea una imagen válida
2. Prueba con un PNG de menos de 500KB
3. Refresca la página después de guardar
4. Revisa la consola del navegador para errores

---

**Implementado:** 2025-11-20  
**Versión:** 1.0  
**Estado:** ✅ Funcional y probado
