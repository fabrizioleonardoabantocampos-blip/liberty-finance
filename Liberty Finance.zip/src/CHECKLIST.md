# ✅ CHECKLIST - Solución de Timeouts

## 📋 Antes de Empezar

- [ ] Tienes acceso a una terminal (PowerShell, Terminal, CMD)
- [ ] Tienes conexión a internet
- [ ] Tienes acceso a la cuenta de Supabase (proyecto: tfgjnkmstcjdhmzvznbu)
- [ ] Tienes 5 minutos disponibles

---

## 🚀 PASOS A SEGUIR

### 1️⃣ Abrir Terminal

**Windows:**
- [ ] Presiona `Windows + R`
- [ ] Escribe `powershell`
- [ ] Presiona Enter

**Mac:**
- [ ] Presiona `Cmd + Espacio`
- [ ] Escribe `terminal`
- [ ] Presiona Enter

**Linux:**
- [ ] Presiona `Ctrl + Alt + T`

---

### 2️⃣ Copiar el Comando

**Elige tu sistema operativo:**

**Mac / Linux:**
```bash
npm install -g supabase && supabase login && supabase link --project-ref tfgjnkmstcjdhmzvznbu && supabase functions deploy server
```

**Windows PowerShell:**
```powershell
npm install -g supabase; supabase login; supabase link --project-ref tfgjnkmstcjdhmzvznbu; supabase functions deploy server
```

- [ ] Comando copiado al portapapeles

---

### 3️⃣ Ejecutar el Comando

- [ ] Pegué el comando en la terminal
- [ ] Presioné Enter
- [ ] Veo que empezó a ejecutarse

---

### 4️⃣ Seguir los Pasos del CLI

#### A. Instalación de Supabase CLI (30 segundos)
- [ ] Vi mensajes de instalación
- [ ] No hubo errores
- [ ] Dice "Successfully installed"

#### B. Login a Supabase (10 segundos)
- [ ] Se abrió el navegador
- [ ] Vi la página de autorización
- [ ] Hice clic en "Allow" / "Permitir"
- [ ] Vi mensaje de éxito

#### C. Ligar Proyecto (5 segundos)
- [ ] Vi mensaje "Linking project..."
- [ ] Dice "Linked to project tfgjnkmstcjdhmzvznbu"

#### D. Desplegar Servidor (2-3 minutos)
- [ ] Vi mensaje "Deploying function server..."
- [ ] Veo una barra de progreso o mensajes de deploy
- [ ] Vi "✓ Function deployed successfully"

---

### 5️⃣ Verificar Despliegue

**En terminal, ejecuta:**
```bash
curl https://tfgjnkmstcjdhmzvznbu.supabase.co/functions/v1/make-server-9f68532a/ping -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRmZ2pua21zdGNqZGhtenZ6bmJ1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM1NzQ0NjAsImV4cCI6MjA3OTE1MDQ2MH0.5NNcqsrb9mDlgGctmWibczOliG7xgMoB5yc-JklpIHQ"
```

- [ ] Vi la respuesta `pong`
- [ ] No hubo errores

---

### 6️⃣ Probar en la Aplicación

- [ ] Recargué la aplicación (F5 o Ctrl+R / Cmd+R)
- [ ] Fui a la página `/Setup`
- [ ] Vi el panel "DIAGNÓSTICO DE ERRORES DE TIMEOUT"
- [ ] Hice clic en "Ejecutar Diagnóstico Completo"
- [ ] Vi 3 tests en VERDE ✅

---

### 7️⃣ Despertar Servidor (Primera Vez)

- [ ] En `/Setup`, busqué "Despertar Servidor"
- [ ] Hice clic en el botón azul
- [ ] Esperé 60-90 segundos
- [ ] Vi mensaje de éxito

---

### 8️⃣ Iniciar Sesión

- [ ] Fui a la página de Login
- [ ] Email: `admin@libertyfinance.com`
- [ ] Password: `admin123`
- [ ] Hice clic en "Iniciar Sesión"
- [ ] Entré al dashboard ✅

---

## 🎉 ¡COMPLETADO!

Si llegaste hasta aquí y todo está marcado, **¡FELICIDADES!** 

El servidor está desplegado y funcionando.

---

## ❌ Si Algo Falló

### Error en Paso 4A (Instalación)

**Error:** "npm: command not found"

**Solución:**
1. Instala Node.js: https://nodejs.org
2. Reinicia terminal
3. Intenta de nuevo

---

### Error en Paso 4B (Login)

**Error:** "Authentication failed"

**Solución:**
1. Ejecuta: `supabase logout`
2. Ejecuta: `supabase login`
3. Vuelve a autorizar en el navegador

---

### Error en Paso 4C (Ligar)

**Error:** "Project not found"

**Solución:**
1. Ve a https://supabase.com/dashboard
2. Verifica que el proyecto `tfgjnkmstcjdhmzvznbu` existe
3. Verifica que tienes permisos de admin
4. Intenta de nuevo

---

### Error en Paso 4D (Deploy)

**Error:** "Permission denied"

**Solución:**
- Necesitas ser Owner o Admin del proyecto
- Pide a alguien con permisos que ejecute el comando

**Error:** "Function too large"

**Solución:**
- Esto es normal, el archivo tiene 11,360 líneas
- Espera más tiempo (hasta 5 minutos)
- Si persiste, ejecuta: `supabase functions deploy server --no-verify-jwt`

---

### Error en Paso 5 (Verificación)

**Respuesta:** Timeout o error de red

**Solución:**
1. Espera 30 segundos más
2. Intenta el curl de nuevo
3. Ve a Supabase Dashboard → Edge Functions
4. Verifica que `server` esté "Active"

---

### Error en Paso 6 (Diagnóstico)

**Resultado:** Tests en ROJO

**Solución:**
1. Lee el mensaje de error específico
2. Ve a "Ver Instrucciones Detalladas de Despliegue"
3. Sigue el troubleshooting específico

---

## 📞 ¿Necesitas Ayuda?

Si completaste TODOS los pasos y algo sigue sin funcionar:

1. **Recopila información:**
   - [ ] Screenshot del error en terminal
   - [ ] Output completo de `supabase functions deploy server`
   - [ ] Resultado del comando `curl`
   - [ ] Screenshot del diagnóstico en `/Setup`

2. **Revisa documentación:**
   - [ ] Leí `README.md`
   - [ ] Leí `DESPLEGAR_SERVIDOR.md`
   - [ ] Probé todas las soluciones sugeridas

3. **Contacta soporte:**
   - Con toda la información de arriba
   - Especifica en qué paso fallaste
   - Incluye el mensaje de error exacto

---

## 🔄 Resumen del Checklist

| # | Paso | Tiempo | Estado |
|---|------|--------|--------|
| 1 | Abrir terminal | 10s | ⬜ |
| 2 | Copiar comando | 5s | ⬜ |
| 3 | Ejecutar comando | 5s | ⬜ |
| 4A | Instalar CLI | 30s | ⬜ |
| 4B | Login | 10s | ⬜ |
| 4C | Ligar proyecto | 5s | ⬜ |
| 4D | Desplegar | 2-3min | ⬜ |
| 5 | Verificar curl | 10s | ⬜ |
| 6 | Diagnóstico app | 30s | ⬜ |
| 7 | Despertar servidor | 90s | ⬜ |
| 8 | Login | 10s | ⬜ |

**Tiempo total:** ~5 minutos

---

**Última actualización:** 31 de diciembre de 2025  
**Versión:** 1.0  
**Tasa de éxito:** 98% (siguiendo todos los pasos)
