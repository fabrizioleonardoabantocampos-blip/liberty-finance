# 🗄️ BACKUP COMPLETO - ESTRUCTURA BASE DE DATOS LIBERTY FINANCE
## Fecha de Backup: 2025-11-19

---

## 📋 RESUMEN EJECUTIVO

Este documento contiene la estructura completa de la base de datos de Liberty Finance implementada en Supabase usando el sistema KV Store. Incluye todos los prefijos, estructuras de datos, relaciones y lógica de negocio.

---

## 🔑 PREFIJOS DE LA BASE DE DATOS (KV Store)

### **Usuarios**
- `user:{userId}` - Datos del usuario
- `user:email:{email}` - Mapeo email -> userId
- `user:id_unico:{id_unico}` - Mapeo id_unico -> userId
- `users:all` - Lista de todos los userIds

### **Packs**
- `pack:{packId}` - Datos del pack
- `user:{userId}:packs` - Lista de packIds del usuario
- `packs:all` - Lista de todos los packIds

### **Comisiones**
- `comision:{comisionId}` - Datos de la comisión
- `user:{userId}:comisiones` - Lista de comisionIds del usuario
- `comisiones:all` - Lista de todas las comisionIds

### **Cobros (Retiros)**
- `cobro:{cobroId}` - Datos del cobro
- `user:{userId}:cobros` - Lista de cobroIds del usuario
- `cobros:all` - Lista de todos los cobroIds

### **Rendimientos**
- `rendimiento:{rendimientoId}` - Datos del rendimiento
- `user:{userId}:rendimientos` - Lista de rendimientoIds del usuario
- `rendimientos:all` - Lista de todos los rendimientoIds

### **Depósitos**
- `deposito:{depositoId}` - Datos del depósito
- `user:{userId}:depositos` - Lista de depositoIds del usuario
- `depositos:all` - Lista de todos los depositoIds

### **Productos**
- `producto:{productoId}` - Datos del producto
- `productos:all` - Lista de todos los productoIds

### **Rangos**
- `rango:{rangoId}` - Datos del rango
- `rangos:all` - Lista de todos los rangoIds

### **Ruleta**
- `ruleta:{historialId}` - Historial de giro
- `user:{userId}:ruleta` - Lista de historialIds del usuario

### **Configuración**
- `config:admin` - Configuración del administrador
- `config:wallets` - Wallets configuradas
- `config:nowpayments` - Configuración de NOWPayments

---

## 📊 ESTRUCTURAS DE DATOS

### **User**
```typescript
interface User {
  id: string;                    // UUID único
  id_unico: string;              // Código único tipo "LF1234567890123"
  nombre: string;
  apellido: string;
  email: string;
  telefono: string;
  ciudad?: string;
  wallet?: string;               // Wallet USDT TRC20
  password: string;              // En producción: hashear
  referralCode: string;
  referidoPor?: string;          // ID del usuario referidor
  fechaRegistro: string;         // ISO 8601
  activo: boolean;               // false hasta primer depósito verificado
  rango?: string;                // "Sin Rango", "Silver", "Gold", etc.
  createdAt?: string;            // Para ordenamiento
}
```

### **Pack**
```typescript
interface Pack {
  id: string;
  userId: string;
  nombre: string;                // "Pack 50", "Pack 100", etc.
  monto: number;                 // Monto en USDT
  fechaCompra: string;
  activo: boolean;               // Solo 1 pack activo por usuario
  rendimientoDiario: number;     // Monto diario (monto * 0.01 = 1%)
}
```

### **Comision**
```typescript
interface Comision {
  id: string;
  userId: string;                // Usuario que RECIBE la comisión
  tipo: 'red' | 'patrocinio' | 'rendimiento';
  monto: number;
  nivel?: number;                // 1-10 para comisiones de red
  referidoId?: string;           // ID del usuario que generó la comisión
  fecha: string;
  descripcion: string;
}
```

### **Cobro (Retiro)**
```typescript
interface Cobro {
  id: string;
  userId: string;
  monto: number;
  wallet: string;                // Wallet destino del usuario
  estado: 'pendiente' | 'aprobado' | 'rechazado' | 'completado';
  fecha: string;
  fechaProcesado?: string;
  txHash?: string;               // Hash de transacción en blockchain
}
```

### **Rendimiento**
```typescript
interface Rendimiento {
  id: string;
  userId: string;
  monto: number;                 // Monto del rendimiento
  porcentaje: number;            // Siempre 1% (0.01)
  fecha: string;
}
```

### **Deposito**
```typescript
interface Deposito {
  id: string;
  userId: string;
  packNombre: string;
  monto: number;
  walletDestino: string;         // Wallet del admin
  comprobante?: string;          // URL o payment_id
  estado: 'pendiente' | 'verificado' | 'rechazado';
  fecha: string;
  fechaProcesado?: string;
  procesadoPor?: string;         // ID del admin
  metodoPago?: 'manual' | 'nowpayments';
  paymentId?: string;            // ID de NOWPayments
}
```

### **Producto**
```typescript
interface Producto {
  id: string;
  nombre: string;
  descripcion: string;
  precio: number;                // En USDT
  imagen?: string;
  stock: number;
  activo: boolean;
}
```

### **Rango**
```typescript
interface Rango {
  id: string;
  nombre: string;                // "Silver", "Gold", etc.
  nivel: number;                 // 1-8
  directosRequeridos: number;
  volumenRequerido: number;      // En USDT
  bonoPorcentaje: number;        // % adicional
  imagen?: string;
  color: string;                 // Color hex
  descripcion: string;
}
```

### **RuletaHistorial**
```typescript
interface RuletaHistorial {
  id: string;
  userId: string;
  premio: string;                // Nombre del premio
  puntos: number;                // Puntos ganados (USDT)
  fecha: string;
}
```

### **ConfiguracionAdmin**
```typescript
interface ConfiguracionAdmin {
  walletPrincipal: string;
  walletsSecundarios?: string[];
  comisionReferidoDirecto: number;   // Default: 0.10 (10%)
  qrCodeUrl?: string;
  rendimientoActivo?: boolean;       // Control on/off
  porcentajeRendimiento?: number;    // Default: 0.01 (1%)
  ultimaActualizacion: string;
}
```

---

## 🔄 LÓGICA DE NEGOCIO CRÍTICA

### **1. Flujo de Registro y Activación**

```
1. Usuario se registra con código de referido (opcional)
   └─> Se crea User con activo=false
   └─> Se genera id_unico único (LF + timestamp + random)
   └─> Se asigna referidoPor si el código es válido

2. Usuario solicita depósito
   └─> Se crea Deposito con estado='pendiente'
   └─> Usuario puede pagar con:
       a) Transferencia manual + comprobante
       b) NOWPayments (crypto automático)

3. Admin verifica depósito
   └─> Actualiza Deposito a estado='verificado'
   └─> SE EJECUTA AUTOMÁTICAMENTE:
       a) Crear Pack activo=true
       b) Activar usuario (activo=true)
       c) Calcular comisiones de red (10 niveles)
       d) Calcular bono directo (10%)
       e) Actualizar rangos de toda la línea ascendente
```

### **2. Sistema de Comisiones Multinivel (10 niveles)**

```typescript
PORCENTAJES POR NIVEL:
Nivel 1 (Directos):    10% + Bono Directo 10% = 20% TOTAL
Nivel 2:               4%
Nivel 3:               3%
Nivel 4:               2%
Nivel 5:               2%
Nivel 6:               2%
Nivel 7:               1%
Nivel 8:               1%
Nivel 9:               1%
Nivel 10:              1%
─────────────────────
TOTAL:                 27% distribuido en la red
```

**Ejemplo:** Usuario compra Pack $1,000
```
Patrocinador (Nivel 1):  $100 (10% comisión) + $100 (10% bono directo) = $200
Nivel 2:                 $40  (4%)
Nivel 3:                 $30  (3%)
Nivel 4-6:               $20  (2% cada uno) = $60
Nivel 7-10:              $10  (1% cada uno) = $40
───────────────────────────────
Total distribuido:       $370 (37%)
```

### **3. Matriz 3x3 con Cross Spillover**

```
Estructura:
- Nivel 1: 3 posiciones (directos)
- Nivel 2: 9 posiciones (3^2)
- Nivel 3: 27 posiciones (3^3)
- ...
- Nivel 10: 59,049 posiciones (3^10)

REGLA SPILLOVER:
- Si un usuario tiene más de 3 directos activos
- Los excedentes se colocan en la primera posición libre
- Se recorren todos los niveles hasta encontrar espacio
- Esto beneficia a toda la red
```

### **4. Sistema de Retiros**

```
REGLAS DE RETIRO:

ANTES del 100% de ROI:
✅ Puede retirar SOLO ganancias
✅ Capital bloqueado
✅ Comisión del 10% en todos los retiros
❌ NO puede retirar capital

AL 100% de ROI:
✅ Puede retirar ganancias (hasta 100% del capital)
✅ Puede retirar TODO el capital
✅ Comisión del 10% en todos los retiros
⚠️  Ganancias superiores al 100% se bloquean
⚠️  Debe comprar nuevo pack para desbloquear excedentes

DESPUÉS del 100% de ROI:
❌ Rendimiento diario se detiene
✅ Comisiones de red siguen activas
✅ Puede retirar hasta capital + 100% de ganancias
```

**Ejemplo:**
```
Inversión: $2,000
Ganancias: $2,500 (125%)

Disponible para retiro:
- Capital: $2,000
- Ganancias: $2,000 (límite 100%)
- TOTAL: $4,000

Bloqueado: $500 (excedente del 100%)
Para desbloquear: Comprar nuevo pack
```

### **5. Cálculo de Rangos (Automático)**

```typescript
REQUISITOS POR RANGO:

Sin Rango:      0 directos,  $0 volumen
Silver:         3 directos,  $5,000 volumen
Gold:           5 directos,  $15,000 volumen
Platinum:       8 directos,  $50,000 volumen
Ruby:           12 directos, $150,000 volumen
Emerald:        20 directos, $500,000 volumen
Diamante:       30 directos, $1,500,000 volumen
Black:          50 directos, $5,000,000 volumen
Crown Black:    100 directos, $15,000,000 volumen

BENEFICIOS:
- Cada rango tiene un bono % adicional
- Los rangos se actualizan automáticamente
- Al verificar un depósito, se actualizan rangos de toda la línea
```

### **6. Rendimiento Diario Automático**

```
CÁLCULO:
- Rendimiento = Capital * 1% diario
- Se acumula automáticamente
- Se detiene al alcanzar 100% de ROI
- Admin puede pausar/reactivar globalmente

EJEMPLO:
Pack $1,000:
- Día 1: $10
- Día 2: $10
- Día 3: $10
- ...
- Día 100: $10 (se detiene, alcanzó $1,000 = 100%)
```

---

## 🔒 USUARIOS ESPECIALES

### **Admin Principal**
```typescript
{
  id_unico: 'LF-ADMIN-001',
  email: 'admin@libertyfinance.com',
  password: 'admin123',
  nombre: 'Admin',
  apellido: 'Liberty',
  activo: true,
  // Se crea automáticamente en primer login
}
```

---

## 📦 PRODUCTOS POR DEFECTO

```typescript
const PRODUCTOS_DEFECTO = [
  {
    nombre: "Pack 50",
    descripcion: "Pack de inversión inicial",
    precio: 50,
    stock: 9999,
    activo: true
  },
  {
    nombre: "Pack 100",
    descripcion: "Pack de inversión básico",
    precio: 100,
    stock: 9999,
    activo: true
  },
  {
    nombre: "Pack 200",
    descripcion: "Pack de inversión intermedio",
    precio: 200,
    stock: 9999,
    activo: true
  },
  {
    nombre: "Pack 500",
    descripcion: "Pack de inversión avanzado",
    precio: 500,
    stock: 9999,
    activo: true
  },
  {
    nombre: "Pack 1k",
    descripcion: "Pack de inversión profesional",
    precio: 1000,
    stock: 9999,
    activo: true
  },
  {
    nombre: "Pack 2k",
    descripcion: "Pack de inversión premium",
    precio: 2000,
    stock: 9999,
    activo: true
  },
  {
    nombre: "Pack 5k",
    descripcion: "Pack de inversión exclusivo",
    precio: 5000,
    stock: 9999,
    activo: true
  },
  {
    nombre: "Pack 10k",
    descripcion: "Pack de inversión VIP",
    precio: 10000,
    stock: 9999,
    activo: true
  }
];
```

---

## 🎯 RANGOS POR DEFECTO

```typescript
const RANGOS_DEFECTO = [
  {
    nombre: "Sin Rango",
    nivel: 0,
    directosRequeridos: 0,
    volumenRequerido: 0,
    bonoPorcentaje: 0,
    color: "#94a3b8",
    descripcion: "Usuario nuevo"
  },
  {
    nombre: "Silver",
    nivel: 1,
    directosRequeridos: 3,
    volumenRequerido: 5000,
    bonoPorcentaje: 2,
    color: "#94a3b8",
    descripcion: "3 directos y $5K en ventas"
  },
  {
    nombre: "Gold",
    nivel: 2,
    directosRequeridos: 5,
    volumenRequerido: 15000,
    bonoPorcentaje: 3,
    color: "#eab308",
    descripcion: "5 directos y $15K en ventas"
  },
  {
    nombre: "Platinum",
    nivel: 3,
    directosRequeridos: 8,
    volumenRequerido: 50000,
    bonoPorcentaje: 4,
    color: "#06b6d4",
    descripcion: "8 directos y $50K en ventas"
  },
  {
    nombre: "Ruby",
    nivel: 4,
    directosRequeridos: 12,
    volumenRequerido: 150000,
    bonoPorcentaje: 5,
    color: "#dc2626",
    descripcion: "12 directos y $150K en ventas"
  },
  {
    nombre: "Emerald",
    nivel: 5,
    directosRequeridos: 20,
    volumenRequerido: 500000,
    bonoPorcentaje: 6,
    color: "#10b981",
    descripcion: "20 directos y $500K en ventas"
  },
  {
    nombre: "Diamante",
    nivel: 6,
    directosRequeridos: 30,
    volumenRequerido: 1500000,
    bonoPorcentaje: 7,
    color: "#3b82f6",
    descripcion: "30 directos y $1.5M en ventas"
  },
  {
    nombre: "Black",
    nivel: 7,
    directosRequeridos: 50,
    volumenRequerido: 5000000,
    bonoPorcentaje: 8,
    color: "#1f2937",
    descripcion: "50 directos y $5M en ventas"
  },
  {
    nombre: "Crown Black",
    nivel: 8,
    directosRequeridos: 100,
    volumenRequerido: 15000000,
    bonoPorcentaje: 10,
    color: "#581c87",
    descripcion: "100 directos y $15M en ventas"
  }
];
```

---

## 🔐 SEGURIDAD Y VALIDACIONES

### **Validaciones Críticas**

1. **Email único** - No permitir duplicados
2. **id_unico único** - Generar con timestamp + random
3. **Pack activo único** - Solo 1 pack activo por usuario
4. **Validación de referidos** - Verificar que el código existe
5. **Estado de usuario** - Solo usuarios activos pueden referir
6. **Límites de retiro** - No exceder saldo disponible
7. **Comisión obligatoria** - 10% en TODOS los retiros
8. **ROI máximo** - Bloquear ganancias >100% hasta nuevo pack

### **Reglas de Negocio**

1. **Usuario inactivo** hasta primer depósito verificado
2. **Un solo pack activo** por usuario a la vez
3. **Comisiones se calculan** al verificar depósito
4. **Rangos se actualizan** en toda la línea ascendente
5. **Rendimiento se detiene** al 100% de ROI
6. **Capital bloqueado** hasta alcanzar 100% de ROI

---

## 📡 ENDPOINTS PRINCIPALES

### **Autenticación**
- `POST /make-server-9f68532a/auth/register` - Registro
- `POST /make-server-9f68532a/auth/login` - Login

### **Usuarios**
- `GET /make-server-9f68532a/users` - Todos
- `GET /make-server-9f68532a/users/:userId` - Por ID
- `PUT /make-server-9f68532a/users/:userId` - Actualizar
- `GET /make-server-9f68532a/users/:userId/packs` - Packs del usuario
- `GET /make-server-9f68532a/users/:userId/comisiones` - Comisiones
- `GET /make-server-9f68532a/users/:userId/referidos` - Referidos directos
- `GET /make-server-9f68532a/users/:userId/matriz` - Matriz completa

### **Depósitos**
- `POST /make-server-9f68532a/depositos` - Crear
- `GET /make-server-9f68532a/depositos` - Todos
- `PUT /make-server-9f68532a/depositos/:depositoId` - Verificar/Rechazar

### **Cobros**
- `POST /make-server-9f68532a/cobros` - Solicitar retiro
- `GET /make-server-9f68532a/cobros` - Todos
- `PUT /make-server-9f68532a/cobros/:cobroId` - Aprobar/Rechazar

### **Productos**
- `GET /make-server-9f68532a/productos` - Todos
- `POST /make-server-9f68532a/productos` - Crear
- `PUT /make-server-9f68532a/productos/:productoId` - Actualizar
- `DELETE /make-server-9f68532a/productos/:productoId` - Eliminar

### **Rangos**
- `GET /make-server-9f68532a/rangos` - Todos
- `POST /make-server-9f68532a/rangos` - Crear
- `PUT /make-server-9f68532a/rangos/:rangoId` - Actualizar

---

## 💾 VARIABLES DE ENTORNO REQUERIDAS

```bash
SUPABASE_URL=https://[PROJECT_ID].supabase.co
SUPABASE_ANON_KEY=[ANON_KEY]
SUPABASE_SERVICE_ROLE_KEY=[SERVICE_ROLE_KEY]
SUPABASE_DB_URL=[DATABASE_URL]
NOWPAYMENTS_API_KEY=[API_KEY]
NOWPAYMENTS_PUBLIC_KEY=[PUBLIC_KEY]
```

---

## 🚀 INSTRUCCIONES DE MIGRACIÓN

### **Paso 1: Crear nuevo proyecto Supabase**
1. Ir a https://supabase.com/dashboard
2. Crear nuevo proyecto
3. Copiar las credenciales (URL, ANON_KEY, SERVICE_ROLE_KEY)

### **Paso 2: Actualizar variables de entorno**
1. Actualizar `.env` con las nuevas credenciales
2. Actualizar `/utils/supabase/info.tsx` con nuevo projectId

### **Paso 3: Desplegar el servidor**
1. Los archivos del servidor están en `/supabase/functions/server/`
2. Supabase CLI desplegará automáticamente al hacer push
3. No es necesario crear tablas SQL (usa KV Store)

### **Paso 4: Verificar funcionamiento**
1. Visitar: `https://[PROJECT_ID].supabase.co/functions/v1/make-server-9f68532a/health`
2. Debe responder: `{"status":"ok"}`
3. Hacer login con admin@libertyfinance.com / admin123
4. Usuario admin se creará automáticamente

### **Paso 5: Inicializar datos**
1. Los productos se crean automáticamente al consultarlos
2. Los rangos se crean automáticamente si no existen
3. Crear wallet principal en configuración admin

---

## ✅ CHECKLIST DE MIGRACIÓN

- [ ] Nuevo proyecto Supabase creado
- [ ] Variables de entorno actualizadas
- [ ] Servidor desplegado y respondiendo
- [ ] Endpoint /health funciona
- [ ] Login de admin funciona
- [ ] Productos cargados automáticamente
- [ ] Rangos cargados automáticamente
- [ ] Wallet configurada
- [ ] Primer usuario de prueba registrado
- [ ] Depósito de prueba creado y verificado
- [ ] Comisiones calculadas correctamente
- [ ] Matriz visualizándose correctamente
- [ ] Retiros funcionando

---

## 📞 SOPORTE

Para cualquier problema durante la migración, revisar los logs del servidor en:
Supabase Dashboard > Edge Functions > make-server-9f68532a > Logs

---

**FIN DEL BACKUP DE ESTRUCTURA**
**Versión:** 1.0
**Última actualización:** 2025-11-19
