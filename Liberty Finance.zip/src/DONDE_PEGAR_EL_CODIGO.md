# 📍 DÓNDE PEGAR EL CÓDIGO (Guía Visual)

## 🎯 Objetivo

Necesitas agregar el código de backup en el archivo **`index.tsx`** de tus Edge Functions en Supabase.

---

## 📂 PASO 1: Abrir el archivo

1. Ve a: https://supabase.com/dashboard
2. Selecciona tu proyecto **Nexxfy CRM**
3. En el menú izquierdo, haz clic en **Edge Functions**
4. Haz clic en la función **`server`**
5. Haz clic en **`index.tsx`**

Verás algo así:

```
supabase
└── functions
    └── server
        └── index.tsx  ← Este archivo
```

---

## 📍 PASO 2: Encontrar DÓNDE pegar

Busca esta sección en el archivo (está cerca de la línea 1094):

```typescript
  } catch (error) {
    console.error('❌ Error al crear/verificar admin:', error);
    return c.json({ 
      success: false,
      error: "Error al crear/verificar admin",
      details: error.message 
    }, 500);
  }
});                                          ← Línea 1092

                                            ← Línea 1093 (vacía)
// ==========================================
// RUTAS DE DOCUMENTOS LEGALES (PDFs)       ← Línea 1094
// ==========================================
```

**IMPORTANTE:** Vas a pegar el código **ENTRE** la línea 1092 y la línea 1094.

---

## 📋 PASO 3: Copiar el código

1. Abre el archivo: **`/COPIAR_Y_PEGAR_EN_INDEX.txt`**
2. **Selecciona TODO** (Ctrl+A o Cmd+A)
3. **Copia** (Ctrl+C o Cmd+C)

---

## 📌 PASO 4: Pegar el código

En el archivo `index.tsx`:

1. Coloca el cursor al **final de la línea 1092** (después de `});`)
2. Presiona **Enter** dos veces para crear espacio
3. **Pega** el código (Ctrl+V o Cmd+V)

### ANTES:

```typescript
  });
});

// ==========================================
// RUTAS DE DOCUMENTOS LEGALES (PDFs)
// ==========================================
```

### DESPUÉS:

```typescript
  });
});

// ==========================================
// RUTAS DE EXPORTACIÓN E IMPORTACIÓN DE DATOS
// ==========================================

app.get("/make-server-9f68532a/backup/export", async (c) => {
  // ... código de exportación ...
});

app.post("/make-server-9f68532a/backup/import", async (c) => {
  // ... código de importación ...
});

// ==========================================
// RUTAS DE DOCUMENTOS LEGALES (PDFs)
// ==========================================
```

---

## ✅ PASO 5: Guardar

1. Presiona **Ctrl+S** (Windows/Linux) o **Cmd+S** (Mac)
2. O haz clic en el botón **"Save"** o **"Guardar"**
3. **Espera 2-3 minutos** para que el servidor se actualice

---

## 🔄 PASO 6: Repetir en Liberty Finance

**IMPORTANTE:** Debes hacer lo mismo en el proyecto de **Liberty Finance**:

1. Cambia al proyecto **Liberty Finance** en Supabase
2. Ve a **Edge Functions** → **server** → **index.tsx**
3. Pega el MISMO código en el MISMO lugar
4. Guarda y espera 2-3 minutos

---

## 🎯 REFERENCIA RÁPIDA

### Busca esta línea:
```
// RUTAS DE DOCUMENTOS LEGALES
```

### Pega el código ANTES de esa línea:
```
[Tu código pegado aquí]

// RUTAS DE DOCUMENTOS LEGALES
```

---

## 📸 AYUDA VISUAL

```
Línea 1088: ...
Línea 1089:       details: error.message 
Línea 1090:     }, 500);
Línea 1091:   }
Línea 1092: });
Línea 1093: 
Línea 1094: // ========================================== ← ¡Pega ANTES de aquí!
Línea 1095: // RUTAS DE DOCUMENTOS LEGALES (PDFs)
Línea 1096: // ==========================================
```

**Posición exacta:** Entre la línea 1092 y 1094

---

## ✅ ¿Cómo saber si lo hiciste bien?

Después de pegar, deberías ver:

```typescript
});  // ← Final del endpoint create-admin

// ==========================================
// RUTAS DE EXPORTACIÓN E IMPORTACIÓN DE DATOS  ← Nuevo
// ==========================================

app.get("/make-server-9f68532a/backup/export", ...  ← Nuevo
app.post("/make-server-9f68532a/backup/import", ...  ← Nuevo

// ==========================================
// RUTAS DE DOCUMENTOS LEGALES (PDFs)  ← Existente (se movió hacia abajo)
// ==========================================
```

---

## 🚨 ERRORES COMUNES

### ❌ No encuentro "RUTAS DE DOCUMENTOS LEGALES"

**Solución:** Usa la búsqueda (Ctrl+F o Cmd+F) y busca: `DOCUMENTOS LEGALES`

### ❌ El código está en otro lado

**Solución:** Busca esta línea específica:
```typescript
app.post("/make-server-9f68532a/documentos/upload-pdf", async (c) => {
```

Y pega el código **ANTES** de ella.

### ❌ No puedo guardar

**Solución:** Verifica que tienes permisos de edición en Supabase. Intenta recargar la página.

---

## ⏱️ DESPUÉS DE PEGAR

1. **Guarda** el archivo
2. **Espera 2-3 minutos** (importante!)
3. El servidor se actualizará automáticamente
4. Ahora puedes usar el archivo **`migracion-simple.html`**

---

## 📞 ¿Todavía tienes dudas?

Dime:
- "No encuentro el archivo index.tsx"
- "No sé dónde está Edge Functions"
- "No encuentro la línea DOCUMENTOS LEGALES"
- "Ya pegué el código pero sale error"

¡Te ayudaré paso a paso! 😊

---

**RECUERDA:** Debes hacer esto en **AMBAS** bases de datos:
- ✅ Nexxfy CRM (origen)
- ✅ Liberty Finance (destino)
