# 🚨 EMPIEZA AQUÍ - Liberty Finance

## ⚠️ ¿Ves Este Error?

```
⚠️ Timeout (30000ms) en intento 1/4
⚠️ Error de red en intento 1/4, reintentando en 2000ms...
```

## 🔴 El Problema Real

Tu archivo de credenciales (`/utils/supabase/info.tsx`) **está CORRECTO**.

El problema es que **el servidor NO está desplegado en Supabase**.

---

## ✅ SOLUCIÓN (5 minutos)

### Paso 1: Instalar Supabase CLI

Elige tu sistema operativo:

**macOS / Linux:**
```bash
npm install -g supabase
```

**Windows:**
```powershell
npm install -g supabase
```

### Paso 2: Login a Supabase

```bash
supabase login
```

Esto abrirá tu navegador. Haz clic en **"Allow"**.

### Paso 3: Ligar el Proyecto

```bash
supabase link --project-ref tfgjnkmstcjdhmzvznbu
```

Si te pide confirmación, escribe `y` y Enter.

### Paso 4: Desplegar el Servidor

```bash
supabase functions deploy server
```

Verás:
```
Deploying function server...
✓ Function deployed successfully
```

**Espera 2-3 minutos** (es un archivo grande: 11,360 líneas).

### Paso 5: Verificar

```bash
curl https://tfgjnkmstcjdhmzvznbu.supabase.co/functions/v1/make-server-9f68532a/ping \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRmZ2pua21zdGNqZGhtenZ6bmJ1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM1NzQ0NjAsImV4cCI6MjA3OTE1MDQ2MH0.5NNcqsrb9mDlgGctmWibczOliG7xgMoB5yc-JklpIHQ"
```

Respuesta esperada: `pong`

### Paso 6: Probar en la Aplicación

1. Recarga tu app (F5)
2. Ve a `/Setup`
3. Haz clic en **"⚡ 2. Despertar Servidor"**
4. Espera 60 segundos
5. Login: `admin@libertyfinance.com` / `admin123`

---

## 📖 Documentación Completa

**Instrucciones detalladas:** [DESPLEGAR_SERVIDOR.md](/DESPLEGAR_SERVIDOR.md)

Incluye:
- Scripts automatizados (Linux/Mac y Windows)
- Troubleshooting completo
- Qué hacer si el deploy falla

---

## 🆘 Si No Tienes CLI / No Puedes Desplegar

### Opción A: Pedir a Alguien con Acceso

Comparte este documento con alguien que tenga:
- Acceso al proyecto de Supabase
- Permisos de administrador
- Supabase CLI instalado

### Opción B: Verificar en Dashboard

1. Ve a: https://supabase.com/dashboard/project/tfgjnkmstcjdhmzvznbu/functions
2. ¿Ves la función `server`?
   - ✅ **SÍ:** Puede estar pausada, actívala
   - ❌ **NO:** Debes desplegarla (ver arriba)

---

## ⚡ Script Rápido (Copia y Pega)

### Linux/Mac:

```bash
npm install -g supabase && \
supabase login && \
supabase link --project-ref tfgjnkmstcjdhmzvznbu && \
supabase functions deploy server && \
echo "✅ ¡Desplegado! Ahora recarga tu app (F5)"
```

### Windows (PowerShell):

```powershell
npm install -g supabase; supabase login; supabase link --project-ref tfgjnkmstcjdhmzvznbu; supabase functions deploy server; Write-Host "✅ ¡Desplegado! Ahora recarga tu app (F5)" -ForegroundColor Green
```

---

## 📋 Checklist

- [ ] Instalé Supabase CLI
- [ ] Hice login con `supabase login`
- [ ] Ligué el proyecto con `supabase link`
- [ ] Desplegué con `supabase functions deploy server`
- [ ] Esperé 2-3 minutos para que complete
- [ ] Verifiqué con el comando `curl`
- [ ] Recargué la aplicación (F5)
- [ ] Probé login en `/Setup`

---

## 🎯 Después del Deploy

### Primera Vez (Cold Start)

1. Ve a `/Setup`
2. Haz clic en **"⚡ Despertar Servidor"**
3. Espera **60-90 segundos**
4. Ahora el servidor responde rápido (2-5 segundos)

### Login

```
Email:    admin@libertyfinance.com
Password: admin123
```

### Herramientas en /Setup

1. 🔴 **Verificar Credenciales** - Ya no necesitas (están bien)
2. ⚡ **Despertar Servidor** - Úsalo después del deploy
3. 🔍 **Diagnóstico** - Verifica que todo funcione
4. 🔑 **Crear Admin** - Si "usuario no encontrado"
5. 🔐 **Reset Password** - Si "contraseña incorrecta"

---

## 💡 Resumen Ultra-Rápido

```
1. npm install -g supabase
2. supabase login
3. supabase link --project-ref tfgjnkmstcjdhmzvznbu
4. supabase functions deploy server
5. Esperar 2-3 minutos
6. Recargar app (F5)
7. /Setup → Despertar Servidor
8. Login
```

**Tiempo total:** 5-10 minutos (incluyendo esperas)

---

## 🔍 Verificación Post-Deploy

### Test 1: Health Check

Abre en navegador:
```
https://tfgjnkmstcjdhmzvznbu.supabase.co/functions/v1/make-server-9f68532a/health
```

Deberías ver JSON con `"status": "ok"`

### Test 2: Diagnóstico en App

1. Ve a `/Setup`
2. Sección **"🔍 3. Diagnóstico de Conectividad"**
3. Clic en "Ejecutar Diagnóstico"
4. Deberías ver **3 tests en VERDE** ✅

### Test 3: Login Real

1. Ve a la página de Login
2. Email: `admin@libertyfinance.com`
3. Password: `admin123`
4. Deberías entrar al dashboard 🎉

---

## ❓ FAQ

### ¿Por qué no usar el dashboard web?

El archivo del servidor tiene **11,360 líneas**. El editor web de Supabase no puede manejar archivos tan grandes. **DEBES usar CLI**.

### ¿Cuánto tarda el deploy?

- Subir código: ~30 segundos
- Instalar deps: ~1-2 minutos
- Inicializar: ~30 segundos
- **Total: 2-5 minutos**

### ¿Y después del deploy?

El servidor estará activo 24/7. Solo tendrás **cold starts** después de 5-10 minutos de inactividad (30-90s para despertar).

### ¿Qué si el deploy falla?

Lee: [DESPLEGAR_SERVIDOR.md](/DESPLEGAR_SERVIDOR.md) - Sección "Troubleshooting"

---

## 📞 Soporte

**Antes de pedir ayuda:**

1. ✅ Ejecuté los 4 comandos arriba
2. ✅ Esperé 2-3 minutos después del deploy
3. ✅ Verifiqué con el comando `curl`
4. ✅ Recargué la aplicación (F5)
5. ✅ Revisé logs en Supabase Dashboard

**Al reportar problemas:**

- Incluye output completo de `supabase functions deploy server`
- Incluye resultado del comando `curl`
- Screenshot de Supabase Dashboard → Edge Functions
- Logs del servidor (si están disponibles)

---

**🎉 ¡Una vez desplegado, todo funcionará perfectamente!**

**Tiempo estimado:** 5-10 minutos  
**Dificultad:** Fácil (solo 4 comandos)  
**Costo:** $0 (incluido en plan gratuito)

---

**Última actualización:** 31 de diciembre de 2025  
**Estado:** ✅ Credenciales correctas, solo falta deploy  
**Acción:** Ejecutar los 4 comandos arriba
