# 🚀 GUÍA DE MIGRACIÓN PASO A PASO
## Liberty Finance - Nueva Base de Datos Supabase

---

## 📋 TABLA DE CONTENIDOS

1. [Preparación Pre-Migración](#1-preparación-pre-migración)
2. [Crear Nuevo Proyecto Supabase](#2-crear-nuevo-proyecto-supabase)
3. [Actualizar Variables de Entorno](#3-actualizar-variables-de-entorno)
4. [Verificar Configuración](#4-verificar-configuración)
5. [Pruebas Post-Migración](#5-pruebas-post-migración)
6. [Rollback (Plan B)](#6-rollback-plan-b)

---

## 1. PREPARACIÓN PRE-MIGRACIÓN

### ✅ Checklist Inicial

- [ ] **Backup de Datos Actuales** (CRÍTICO)
  - Exportar todos los usuarios actuales
  - Exportar todos los depósitos pendientes
  - Exportar todos los cobros pendientes
  - Exportar configuración de wallets

- [ ] **Documentar Estado Actual**
  - Anotar cantidad total de usuarios
  - Anotar cantidad de usuarios activos
  - Anotar total invertido en la plataforma
  - Anotar retiros pendientes de aprobación

- [ ] **Notificar a Usuarios** (RECOMENDADO)
  - Avisar mantenimiento programado
  - Estimar tiempo de inactividad (15-30 min)
  - Guardar capturas de pantalla de saldos críticos

### 📦 Archivos de Backup Incluidos

Los siguientes archivos contienen toda la información necesaria:

1. **`BACKUP_DATABASE_STRUCTURE.md`**
   - Estructura completa de datos
   - Lógica de negocio
   - Prefijos de KV Store
   - Endpoints y flujos

2. **`BACKUP_SQL_SCHEMA.sql`**
   - Esquema SQL equivalente (OPCIONAL)
   - Solo si decides migrar a SQL tradicional
   - Incluye triggers y funciones

3. **`GUIA_MIGRACION_PASO_A_PASO.md`** (este archivo)
   - Instrucciones detalladas
   - Comandos exactos
   - Troubleshooting

### 🔍 Verificar Archivos Críticos

Asegúrate de tener estos archivos listos:

```
/supabase/functions/server/
├── index.tsx          ✅ Servidor principal
├── crm.tsx            ✅ Lógica de negocio
└── kv_store.tsx       ✅ PROTEGIDO - No modificar

/utils/supabase/
└── info.tsx           ⚠️ Actualizar projectId
```

---

## 2. CREAR NUEVO PROYECTO SUPABASE

### Paso 2.1: Ir al Dashboard de Supabase

1. Abre tu navegador
2. Ve a: https://supabase.com/dashboard
3. Inicia sesión con tu cuenta

### Paso 2.2: Crear Nuevo Proyecto

1. Haz clic en **"New Project"**
2. Llena el formulario:

   ```
   Organization:     [Tu organización]
   Name:            Liberty Finance Production
   Database Password: [Genera una contraseña segura]
   Region:           [Selecciona la más cercana a tus usuarios]
                     Recomendado: South America (Sao Paulo) o US East
   Pricing Plan:     [Selecciona según tu presupuesto]
   ```

3. Haz clic en **"Create new project"**
4. ⏳ Espera 2-3 minutos mientras se crea el proyecto

### Paso 2.3: Obtener Credenciales

Una vez creado el proyecto:

1. Ve a **Settings** (⚙️ icono en la barra lateral)
2. Haz clic en **API**
3. Copia las siguientes credenciales:

   ```bash
   # Project URL
   SUPABASE_URL=https://xxxxxxxxxxxxx.supabase.co
   
   # Project API Keys
   SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
   
   # Service Role Key (¡MANTENER EN SECRETO!)
   SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
   ```

4. Ve a **Settings** > **Database**
5. Copia la **Connection String**:

   ```bash
   SUPABASE_DB_URL=postgresql://postgres:[YOUR-PASSWORD]@db.xxxxxxxxxxxxx.supabase.co:5432/postgres
   ```

### Paso 2.4: Habilitar Edge Functions

1. Ve a **Edge Functions** en la barra lateral
2. Si no está habilitado, haz clic en **"Enable Edge Functions"**
3. Confirma la acción

---

## 3. ACTUALIZAR VARIABLES DE ENTORNO

### Paso 3.1: Actualizar Archivo `.env` Local

Si tienes un archivo `.env` local, actualízalo:

```bash
# Supabase Configuration - ACTUALIZADO
SUPABASE_URL=https://[TU-NUEVO-PROJECT-ID].supabase.co
SUPABASE_ANON_KEY=[TU-NUEVO-ANON-KEY]
SUPABASE_SERVICE_ROLE_KEY=[TU-NUEVO-SERVICE-ROLE-KEY]
SUPABASE_DB_URL=[TU-NUEVO-DB-URL]

# NOWPayments - MANTENER IGUAL (si ya está configurado)
NOWPAYMENTS_API_KEY=[TU-API-KEY]
NOWPAYMENTS_PUBLIC_KEY=[TU-PUBLIC-KEY]
```

### Paso 3.2: Actualizar Variables en Supabase Dashboard

1. Ve a **Edge Functions** > **make-server-9f68532a**
2. Haz clic en **Settings**
3. En **Environment Variables**, agrega:

   ```
   SUPABASE_URL               = [valor copiado]
   SUPABASE_ANON_KEY          = [valor copiado]
   SUPABASE_SERVICE_ROLE_KEY  = [valor copiado]
   SUPABASE_DB_URL            = [valor copiado]
   NOWPAYMENTS_API_KEY        = [si aplica]
   NOWPAYMENTS_PUBLIC_KEY     = [si aplica]
   ```

4. Haz clic en **Save**

### Paso 3.3: Actualizar `info.tsx`

Abre el archivo `/utils/supabase/info.tsx` y actualiza:

```typescript
// ⚠️ ACTUALIZAR ESTOS VALORES
export const projectId = "[TU-NUEVO-PROJECT-ID]"; // Ejemplo: "abcdefghijk"
export const publicAnonKey = "[TU-NUEVO-ANON-KEY]";
```

**IMPORTANTE:** El `projectId` es la primera parte de tu SUPABASE_URL:
- Si tu URL es: `https://abcdefghijk.supabase.co`
- Entonces `projectId = "abcdefghijk"`

---

## 4. VERIFICAR CONFIGURACIÓN

### Paso 4.1: Verificar Servidor (Health Check)

1. Abre tu navegador
2. Ve a: `https://[TU-PROJECT-ID].supabase.co/functions/v1/make-server-9f68532a/health`
3. Deberías ver:

   ```json
   {"status":"ok"}
   ```

Si ves este mensaje, ¡el servidor está funcionando! ✅

### Paso 4.2: Verificar Login de Admin

1. Abre tu aplicación web
2. Ve a la página de login
3. Intenta iniciar sesión con:

   ```
   Email:    admin@libertyfinance.com
   Password: admin123
   ```

4. El usuario admin se creará automáticamente en el primer login
5. Deberías ver el dashboard de admin

### Paso 4.3: Verificar Productos

1. Ve a la sección de **Productos** en el panel admin
2. Los productos deberían cargarse automáticamente
3. Deberías ver los 8 packs (50, 100, 200, 500, 1k, 2k, 5k, 10k)

### Paso 4.4: Verificar Rangos

1. Ve a la sección de **Rangos** en el panel admin
2. Los rangos deberían cargarse automáticamente
3. Deberías ver los 9 rangos (Sin Rango, Silver, Gold, etc.)

---

## 5. PRUEBAS POST-MIGRACIÓN

### ✅ Test 1: Registro de Usuario

1. Cierra sesión del admin
2. Regístrate como nuevo usuario:
   ```
   Nombre:         Test
   Apellido:       Usuario
   Email:          test@ejemplo.com
   Teléfono:       +51999999999
   Ciudad:         Lima
   Wallet:         TTestWalletAddress123
   Contraseña:     test123
   Código Referido: [dejar vacío o usar código de otro usuario]
   ```
3. Verifica que el registro sea exitoso
4. Verifica que puedas iniciar sesión

### ✅ Test 2: Solicitar Depósito

1. Inicia sesión como usuario test
2. Ve a **Productos**
3. Selecciona **Pack 50**
4. Completa el formulario de depósito:
   ```
   Monto:      50 USDT
   Wallet:     [copia la wallet mostrada]
   Comprobante: [sube una imagen de prueba]
   ```
5. Envía la solicitud
6. Verifica que aparezca como "Pendiente"

### ✅ Test 3: Verificar Depósito (Como Admin)

1. Inicia sesión como admin
2. Ve a **Depósitos Pendientes**
3. Encuentra el depósito de test@ejemplo.com
4. Haz clic en **Verificar**
5. Verifica que:
   - El depósito cambie a "Verificado"
   - El usuario se active (activo = true)
   - Se cree el pack
   - Se calculen comisiones (si tiene referidor)

### ✅ Test 4: Verificar Panel Usuario

1. Inicia sesión como test@ejemplo.com
2. Verifica que veas:
   ```
   ✅ Pack Actual: Pack 50
   ✅ Inversión: $50.00
   ✅ Rendimiento Diario: $0.50 (1%)
   ✅ Progreso: 0%
   ```

### ✅ Test 5: Matriz y Referidos

1. Regístrate con otro usuario usando el código de test@ejemplo.com
2. Verifica depósito del nuevo usuario
3. Inicia sesión como test@ejemplo.com
4. Ve a **Mi Red**
5. Verifica que veas:
   - 1 referido directo
   - Comisión de red calculada
   - Bono directo (10%)

### ✅ Test 6: Solicitar Retiro

1. Como usuario test, ve a **Retiros**
2. Solicita un retiro:
   ```
   Monto:  5 USDT
   Wallet: TTestWalletAddress123
   ```
3. Verifica que:
   - Se calcule la comisión del 10% (descuento de $0.50)
   - Monto neto a recibir: $4.50
   - Estado: Pendiente

### ✅ Test 7: Aprobar Retiro (Como Admin)

1. Inicia sesión como admin
2. Ve a **Retiros Pendientes**
3. Encuentra el retiro de test@ejemplo.com
4. Aprueba el retiro
5. Opcionalmente agrega un TX Hash

---

## 6. ROLLBACK (PLAN B)

### 🚨 Si Algo Sale Mal

Si encuentras problemas críticos durante la migración:

### Opción A: Revertir Variables de Entorno

1. Abre `/utils/supabase/info.tsx`
2. Restaura los valores anteriores:
   ```typescript
   export const projectId = "[PROJECT-ID-ANTERIOR]";
   export const publicAnonKey = "[ANON-KEY-ANTERIOR]";
   ```
3. Reinicia la aplicación

### Opción B: Mantener Ambos Proyectos

Puedes mantener ambos proyectos Supabase activos:

1. **Proyecto Anterior:** Para usuarios actuales (modo lectura)
2. **Proyecto Nuevo:** Para nuevos usuarios y testing

Esto te permite migrar usuarios gradualmente.

### Opción C: Contactar Soporte

Si los problemas persisten:

1. Revisa los logs del servidor:
   - Dashboard > Edge Functions > make-server-9f68532a > Logs
2. Busca errores específicos
3. Consulta el archivo `BACKUP_DATABASE_STRUCTURE.md`

---

## 📊 MÉTRICAS DE ÉXITO

Al finalizar la migración, verifica:

- [ ] ✅ Health check responde correctamente
- [ ] ✅ Login de admin funciona
- [ ] ✅ Productos cargados (8 packs)
- [ ] ✅ Rangos cargados (9 rangos)
- [ ] ✅ Registro de nuevo usuario exitoso
- [ ] ✅ Depósito creado y verificado
- [ ] ✅ Pack activado correctamente
- [ ] ✅ Comisiones calculadas
- [ ] ✅ Matriz visualizándose
- [ ] ✅ Retiro solicitado y aprobado
- [ ] ✅ Todos los endpoints respondiendo

---

## 🔧 TROUBLESHOOTING COMÚN

### Error: "Failed to fetch"

**Causa:** URL de Supabase incorrecta

**Solución:**
1. Verifica que `SUPABASE_URL` en `.env` coincida con el dashboard
2. Verifica que `projectId` en `info.tsx` sea correcto
3. Asegúrate de que no haya espacios ni comillas extras

### Error: "Unauthorized" o 401

**Causa:** API Key incorrecta

**Solución:**
1. Verifica `SUPABASE_ANON_KEY` en `.env`
2. Verifica `publicAnonKey` en `info.tsx`
3. Regenera las keys en Supabase Dashboard si es necesario

### Error: "User not found" en login

**Causa:** Base de datos vacía

**Solución:**
1. El admin se crea automáticamente en primer login
2. Intenta login con admin@libertyfinance.com / admin123
3. Revisa logs del servidor para ver si hay errores

### Error: "Productos no cargan"

**Causa:** Función de inicialización no se ejecutó

**Solución:**
1. Ve a: `https://[PROJECT-ID].supabase.co/functions/v1/make-server-9f68532a/productos`
2. Esto inicializará los productos automáticamente
3. Recarga la página de productos

### Error: Edge Function no responde

**Causa:** Variables de entorno no configuradas

**Solución:**
1. Ve a Dashboard > Edge Functions > Settings
2. Verifica que todas las variables estén configuradas
3. Haz un redeploy de la función

---

## 📞 CONTACTO Y SOPORTE

### Recursos Útiles

- **Supabase Docs:** https://supabase.com/docs
- **Supabase Status:** https://status.supabase.com
- **Community Support:** https://github.com/supabase/supabase/discussions

### Logs Importantes

Para debugging, revisa:

1. **Logs del Navegador:**
   - F12 > Console
   - Busca errores en rojo

2. **Logs del Servidor:**
   - Dashboard > Edge Functions > make-server-9f68532a > Logs
   - Busca líneas que empiecen con ❌ o 🚫

3. **Network Tab:**
   - F12 > Network
   - Busca requests fallidos (en rojo)

---

## ✅ CHECKLIST FINAL

Antes de considerar la migración completa:

### Pre-Migración
- [ ] Backup de datos actuales realizado
- [ ] Usuarios notificados del mantenimiento
- [ ] Archivos de backup revisados
- [ ] Credenciales antiguas guardadas (por si acaso)

### Durante Migración
- [ ] Nuevo proyecto Supabase creado
- [ ] Variables de entorno actualizadas
- [ ] `info.tsx` actualizado
- [ ] Health check exitoso

### Post-Migración
- [ ] Todos los tests pasados (7/7)
- [ ] Admin puede acceder
- [ ] Usuarios pueden registrarse
- [ ] Depósitos funcionan
- [ ] Retiros funcionan
- [ ] Comisiones se calculan
- [ ] Matriz se visualiza

### Limpieza
- [ ] Proyecto antiguo deshabilitado (opcional)
- [ ] Documentación actualizada
- [ ] Equipo notificado del cambio
- [ ] Monitoreo activo primeras 24h

---

## 🎉 ¡MIGRACIÓN COMPLETADA!

Si llegaste hasta aquí y todos los checks están en ✅:

**¡Felicitaciones! La migración fue exitosa.** 🚀

Tu nueva base de datos está lista y funcionando correctamente.

### Próximos Pasos Recomendados:

1. **Monitorear:** Revisa los logs durante las próximas 24-48 horas
2. **Optimizar:** Considera configurar alertas en Supabase
3. **Backup:** Configura backups automáticos en Supabase
4. **Escalar:** Ajusta el plan según el crecimiento

---

**Última actualización:** 2025-11-19  
**Versión del documento:** 1.0  
**Autor:** Sistema Liberty Finance
