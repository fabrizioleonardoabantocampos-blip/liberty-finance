# 🚀 MIGRAR TUS DATOS EN 2 PASOS SIMPLES

## ✨ ¡TODO ESTÁ LISTO!

He creado una página visual donde solo tienes que:
1. Llenar 2 campos
2. Hacer clic en 2 botones
3. ¡Listo!

---

## 📍 PASO 1: Abrir la Página de Migración

### Opción A: Usando la URL directamente (MÁS FÁCIL)

Abre tu navegador y ve a:

```
TU-URL-DE-LA-APP?migracion=true
```

Por ejemplo:
```
https://tu-app.com?migracion=true
```

O si estás en local:
```
http://localhost:5173?migracion=true
```

### Opción B: Desde el código

Si la URL no funciona, agrega este botón temporal a tu página de login:

```tsx
<Button onClick={() => window.location.href = '?migracion=true'}>
  Migrar Datos
</Button>
```

---

## 📍 PASO 2: Llenar el Formulario

Una vez en la página, verás un formulario muy visual. Solo necesitas:

### 1. **Datos de tu BASE ANTERIOR**

Necesitas 2 cosas de tu Supabase anterior:

#### a) Project ID
- Ve a: https://supabase.com/dashboard
- Selecciona tu proyecto ANTERIOR
- En Settings > General > Reference ID
- Copia el ID (ejemplo: `abcdefghijklmnop`)

#### b) Anon Key
- En el mismo proyecto
- Ve a Settings > API
- Busca "anon" key (public)
- Copia la key completa (empieza con `eyJ...`)

### 2. **Pega los datos en el formulario**

- Project ID Anterior: [pega aquí]
- Anon Key Anterior: [pega aquí]

### 3. **Haz clic en "Exportar Datos"**

- Se descargará automáticamente un archivo `.json`
- Verás un resumen: X usuarios, Y depósitos, Z comisiones

### 4. **Haz clic en "Importar Ahora"**

- Los datos se copiarán a tu base NUEVA
- Verás un resumen de lo que se copió
- ¡Listo! 🎉

---

## 🎯 LO QUE VERÁS EN LA PANTALLA

```
┌─────────────────────────────────────┐
│  MIGRACIÓN DE DATOS                 │
│  (1) → (2) → (✓)                    │
└─────────────────────────────────────┘

┌─────────────────────────────────────┐
│  📍 Base NUEVA (Destino)            │
│  Project ID: [auto-completado]      │
│  Anon Key: [auto-completado]        │
└─────────────────────────────────────┘

┌─────────────────────────────────────┐
│  PASO 1: Exportar                   │
│                                     │
│  Project ID Anterior: [  tu input  ]│
│  Anon Key Anterior:   [  tu input  ]│
│                                     │
│  [  Exportar Datos  ]               │
└─────────────────────────────────────┘

Después de exportar...

┌─────────────────────────────────────┐
│  ✅ Exportación completada!         │
│  👥 50 usuarios                     │
│  💵 120 depósitos                   │
│  💰 350 comisiones                  │
└─────────────────────────────────────┘

┌─────────────────────────────────────┐
│  PASO 2: Importar                   │
│                                     │
│  [  Importar Ahora  ]               │
│  O subir archivo .json              │
└─────────────────────────────────────┘

Después de importar...

┌─────────────────────────────────────┐
│  🎉 ¡MIGRACIÓN COMPLETADA!          │
│                                     │
│  [  Ir al Panel de Admin  ]         │
└─────────────────────────────────────┘
```

---

## ⚠️ SOLUCIÓN DE PROBLEMAS

### Error: "Failed to fetch" al exportar

**Causa:** La base ANTERIOR no tiene las rutas de backup

**Solución:** Necesitas agregar las rutas al servidor de la base ANTERIOR

1. Ve a tu proyecto ANTERIOR en Supabase
2. Edge Functions > server > index.tsx
3. Copia el código de `/INSERT_BACKUP_ROUTES.txt` de ESTA app
4. Pégalo antes de la línea `// RUTAS DE DOCUMENTOS LEGALES`
5. Guarda
6. Espera 1-2 minutos
7. Intenta exportar de nuevo

### Error: "Failed to fetch" al importar

**Causa:** La base NUEVA no tiene las rutas de backup

**Solución:** Mismo proceso pero en la base NUEVA

### No encuentro la página de migración

**Solución:** Usa la URL directa:
```
?migracion=true
```

Agrega esto al final de tu URL actual

---

## 📝 RESUMEN ULTRA RÁPIDO

1. **Abre:** `tu-url?migracion=true`
2. **Llena:** Project ID + Anon Key de la base anterior
3. **Clic:** "Exportar Datos"
4. **Clic:** "Importar Ahora"
5. **¡Listo!** Todos tus datos migrados ✅

**Tiempo:** 2-3 minutos  
**Dificultad:** ⭐ Muy fácil  
**Riesgo:** Cero (no se borra nada)

---

## 🎁 BONUS: Si prefieres hacerlo desde la consola

Si eres más técnico y prefieres copiar y pegar en la consola del navegador, puedes usar los scripts de `/GUIA_MIGRACION_RAPIDA.md`.

Pero la interfaz visual es MUCHO más fácil 😊

---

## ✅ CUANDO TERMINES

Verás un mensaje de éxito con el resumen:

- ✅ X usuarios migrados
- ✅ Y depósitos migrados
- ✅ Z comisiones migradas
- ✅ Todos los packs migrados
- ✅ Todos los retiros migrados

Haz clic en "Ir al Panel de Admin" y verifica que todo esté ahí.

---

**Creado:** 2025-11-19  
**Versión:** 1.0 (Interfaz Visual)  
**Estado:** ✅ Listo para usar

**¿Necesitas ayuda?** Solo dime "no funciona exportar" o "no funciona importar" y te ayudaré específicamente con ese paso.
