# 🔧 Troubleshooting: Error de WebAssembly

## Si el Error Persiste Después de las Optimizaciones

Si todavía experimentas el error `WebAssembly compilation aborted`, sigue estos pasos en orden:

## 🔍 Diagnóstico Paso a Paso

### Paso 1: Verificar Consola del Navegador

Abre **DevTools (F12) → Console** y busca:

```
🔄 [Intento 1/3]
🔄 [Intento 2/3]
🔄 [Intento 3/3]
```

**¿Ves estos mensajes?**
- ✅ **SÍ** → El sistema de reintentos está funcionando. Continúa al Paso 2.
- ❌ **NO** → Hay un problema con la integración. Ve al Paso 5.

### Paso 2: Verificar Duración de la Operación

En los logs del servidor (Supabase Functions), busca:

```
🎉 Reparación completada en XX.XXs
```

**¿Cuánto tiempo toma?**
- ✅ **< 30 segundos** → Normal, continúa al Paso 3
- ⚠️ **30-60 segundos** → Aceptable, pero puede mejorar
- ❌ **> 60 segundos** → Ve al Paso 4 (optimización adicional)

### Paso 3: Limpiar Completamente el Navegador

Ejecuta estos pasos EN ORDEN:

1. **Limpiar caché manualmente:**
   - Chrome: Ctrl+Shift+Del → Últimas 24 horas → Borrar
   - Firefox: Ctrl+Shift+Del → Todo → Borrar ahora
   - Safari: Cmd+Option+E

2. **Deshabilitar extensiones del navegador:**
   - Algunas extensiones (AdBlock, Privacy Badger) pueden interferir
   - Prueba en modo incógnito/privado

3. **Refrescar la página con bypass de caché:**
   - Ctrl+F5 (Windows/Linux)
   - Cmd+Shift+R (Mac)

4. **Reintentar la operación**

**¿Funciona ahora?**
- ✅ **SÍ** → El problema era caché local. ¡Resuelto!
- ❌ **NO** → Continúa al Paso 4

### Paso 4: Optimización Adicional del Servidor

Si la operación toma >60 segundos, implementa estas optimizaciones:

#### A. Reducir Batch Size

Edita `/supabase/functions/server/reparar-israel.tsx`:

```typescript
// Cambiar de:
const BATCH_SIZE = 5;

// A:
const BATCH_SIZE = 3; // Más lento pero más seguro
```

#### B. Aumentar Timeout Individual

Edita `/supabase/functions/server/reparar-israel.tsx`:

```typescript
// Cambiar de:
const timeout = 30000; // 30 segundos

// A:
const timeout = 45000; // 45 segundos
```

#### C. Dividir en Múltiples Endpoints

Considera dividir la operación en pasos separados:
- Endpoint 1: Eliminar packs viejos
- Endpoint 2: Distribuir comisiones
- Endpoint 3: Guardar nuevos packs

### Paso 5: Verificar Integración del Sistema de Reintentos

Revisa que estos archivos existan y tengan el contenido correcto:

```bash
# 1. Verificar utilidad
/utils/wasm-fix.ts ✅

# 2. Verificar importación en AdminUsers
/components/admin/AdminUsers.tsx
Línea ~10: import { ejecutarConReintentos, obtenerMensajeError } from '../../utils/wasm-fix';
```

Si falta algún archivo, revisa la documentación en `/SOLUCION_ERROR_WEBASSEMBLY.md`.

### Paso 6: Verificar Headers del Servidor

En **DevTools → Network**, selecciona la petición a `/admin/reparar-cuenta-israel` y verifica:

**Response Headers (debe incluir):**
```
Cache-Control: no-cache, no-store, must-revalidate
Connection: keep-alive
X-Accel-Buffering: no
```

**¿Están presentes?**
- ✅ **SÍ** → Continúa al Paso 7
- ❌ **NO** → Revisa `/supabase/functions/server/index.tsx` línea ~1473

### Paso 7: Aumentar Timeout del Frontend

Si después de todo el error persiste, aumenta el timeout:

Edita `/components/admin/AdminUsers.tsx` línea ~768:

```typescript
// Cambiar de:
() => fetchAPI('/admin/reparar-cuenta-israel', { method: 'POST' }, 150000),

// A:
() => fetchAPI('/admin/reparar-cuenta-israel', { method: 'POST' }, 200000), // 3.3 minutos
```

### Paso 8: Solución de Último Recurso

Si NADA funciona, implementa un sistema de "job queue":

1. El frontend inicia la operación
2. El servidor retorna inmediatamente un `jobId`
3. El frontend hace polling cada 5 segundos para verificar el estado
4. Cuando termina, muestra los resultados

**Implementación:**

```typescript
// Frontend
const jobId = await fetchAPI('/admin/reparar-cuenta-israel/start', { method: 'POST' });

let completed = false;
while (!completed) {
  await new Promise(r => setTimeout(r, 5000)); // Esperar 5s
  const status = await fetchAPI(`/admin/reparar-cuenta-israel/status/${jobId}`);
  
  if (status.completed) {
    completed = true;
    // Mostrar resultados
  }
}
```

## 🌐 Problemas Específicos del Navegador

### Chrome/Edge
- Problema: WebAssembly timeout después de 90s
- Solución: Usar el sistema de reintentos (ya implementado)

### Firefox
- Problema: Caché agresivo
- Solución: Limpiar caché manualmente antes de operar

### Safari
- Problema: Límites estrictos de memoria WebAssembly
- Solución: Reducir batch size a 3

## 📞 Soporte Adicional

Si después de seguir TODOS los pasos el error persiste:

1. **Recopila esta información:**
   - Navegador y versión
   - Logs completos de la consola
   - Logs del servidor (Supabase Functions)
   - Tiempo exacto que toma la operación
   - Cuántos reintentos se ejecutaron

2. **Verifica:**
   - ¿El error ocurre SIEMPRE o solo a veces?
   - ¿Ocurre con otros usuarios o solo con Israel?
   - ¿Ocurre en diferentes navegadores?

3. **Prueba en modo depuración:**
   - Ejecuta el script paso a paso usando debugger
   - Identifica exactamente en qué punto falla

## ✅ Verificación Final

Antes de reportar un problema, verifica:

- [ ] Seguí TODOS los pasos en orden
- [ ] Limpié completamente el caché del navegador
- [ ] Probé en modo incógnito sin extensiones
- [ ] Verifiqué que los archivos nuevos existan
- [ ] Revisé los logs del servidor
- [ ] Intenté en un navegador diferente
- [ ] La operación toma >60 segundos consistentemente
- [ ] El sistema de reintentos está configurado correctamente

Si todos los checks están ✅ y el problema persiste, entonces es un problema de infraestructura/red que requiere investigación más profunda.

---

**Última actualización:** 31 de diciembre de 2025
