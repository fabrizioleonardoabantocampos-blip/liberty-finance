# 🚀 GUÍA RÁPIDA DE MIGRACIÓN DE DATOS

## 📦 MIGRAR TODOS TUS DATOS A LA NUEVA BASE

Esta guía te permitirá copiar TODOS tus datos (usuarios, depósitos, comisiones, etc.) de tu base de datos anterior a la nueva.

---

## ⚡ MÉTODO RÁPIDO (RECOMENDADO)

### Paso 1: Agregar las Rutas de Backup al Servidor

1. **Abre el archivo:** `/supabase/functions/server/index.tsx`

2. **Busca la línea 1092** (después del endpoint `create-admin`)

3. **Copia y pega** el código del archivo `/INSERT_BACKUP_ROUTES.txt`

4. **Debe quedar así:**
   ```typescript
   });  // ← Fin del endpoint create-admin
   
   // ==========================================
   // RUTAS DE EXPORTACIÓN E IMPORTACIÓN DE DATOS
   // ==========================================
   
   app.get("/make-server-9f68532a/backup/export", async (c) => {
     // ... código de exportación
   });
   
   app.post("/make-server-9f68532a/backup/import", async (c) => {
     // ... código de importación
   });
   
   // ==========================================
   // RUTAS DE DOCUMENTOS LEGALES (PDFs)  ← Debe estar después
   // ==========================================
   ```

5. **Guarda el archivo** y espera que el servidor se actualice

---

### Paso 2: Exportar Datos de la Base Anterior

#### **Opción A: Desde el Navegador**

1. Abre tu navegador
2. Ve a la consola (F12 > Console)
3. Copia y pega este código (REEMPLAZA las credenciales):

```javascript
// IMPORTANTE: Reemplaza con las credenciales de tu BASE ANTERIOR
const BASE_ANTERIOR_PROJECT_ID = 'tu-project-id-anterior';
const BASE_ANTERIOR_ANON_KEY = 'tu-anon-key-anterior';

fetch(`https://${BASE_ANTERIOR_PROJECT_ID}.supabase.co/functions/v1/make-server-9f68532a/backup/export`, {
  method: 'GET',
  headers: {
    'Authorization': `Bearer ${BASE_ANTERIOR_ANON_KEY}`
  }
})
.then(res => res.json())
.then(data => {
  console.log('✅ Datos exportados:', data);
  
  // Descargar automáticamente como archivo
  const blob = new Blob([JSON.stringify(data.backup, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `liberty-backup-${new Date().toISOString().split('T')[0]}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  
  console.log('📥 Archivo descargado. Ahora ve al Paso 3.');
  
  // Guardar en variable global para uso inmediato
  window.backupData = data.backup;
})
.catch(error => {
  console.error('❌ Error:', error);
});
```

4. Presiona Enter
5. Se descargará un archivo JSON con todos tus datos
6. Verás en consola: "✅ Datos exportados" con el resumen

#### **Opción B: Usando la URL directamente**

Abre en tu navegador (reemplaza las credenciales):
```
https://[TU-PROJECT-ID-ANTERIOR].supabase.co/functions/v1/make-server-9f68532a/backup/export
```

Esto te mostrará el JSON completo que puedes copiar.

---

### Paso 3: Importar Datos a la Base Nueva

#### **Opción A: Desde la Consola (si acabas de exportar)**

1. En la misma consola del navegador
2. Copia y pega este código:

```javascript
// Si acabas de exportar, usa el backup guardado
const backupData = window.backupData;

if (!backupData) {
  console.error('❌ No hay datos de backup. Primero exporta (Paso 2)');
} else {
  // IMPORTANTE: Usa las credenciales de tu BASE NUEVA
  const BASE_NUEVA_PROJECT_ID = 'tu-project-id-nuevo';
  const BASE_NUEVA_ANON_KEY = 'tu-anon-key-nuevo';

  fetch(`https://${BASE_NUEVA_PROJECT_ID}.supabase.co/functions/v1/make-server-9f68532a/backup/import`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${BASE_NUEVA_ANON_KEY}`
    },
    body: JSON.stringify({ backup: backupData })
  })
  .then(res => res.json())
  .then(data => {
    console.log('✅ Datos importados:', data);
    console.log(`👥 Usuarios: ${data.resultado.usuarios}`);
    console.log(`💵 Depósitos: ${data.resultado.depositos}`);
    console.log(`💰 Comisiones: ${data.resultado.comisiones}`);
    console.log('🎉 ¡Migración completada!');
  })
  .catch(error => {
    console.error('❌ Error:', error);
  });
}
```

3. Presiona Enter
4. Verás: "✅ Datos importados" con el resumen

#### **Opción B: Subir el archivo JSON descargado**

1. Abre tu página de admin en la nueva base
2. Ve a la sección "Migración de Datos" (si la agregamos)
3. Haz clic en "Subir Archivo de Backup"
4. Selecciona el archivo `.json` que descargaste en el Paso 2
5. ¡Listo!

#### **Opción C: Usar CURL (Terminal)**

```bash
# Reemplaza las credenciales
PROJECT_ID_NUEVO="tu-project-id-nuevo"
ANON_KEY_NUEVO="tu-anon-key-nuevo"

# Asegúrate de que el archivo backup.json esté en el directorio actual
curl -X POST \
  "https://${PROJECT_ID_NUEVO}.supabase.co/functions/v1/make-server-9f68532a/backup/import" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ${ANON_KEY_NUEVO}" \
  -d @backup.json
```

---

## 📊 QUÉ SE MIGRA AUTOMÁTICAMENTE

### ✅ Datos de Usuarios
- Todos los usuarios registrados
- Emails, nombres, teléfonos
- Wallets, referral codes
- Rangos y estados (activo/inactivo)
- Puntos acumulados

### ✅ Datos Financieros
- Todos los depósitos (pendientes, aprobados, rechazados)
- Todos los packs comprados
- Todas las comisiones generadas (red, patrocinio, rendimiento)
- Todos los retiros/cobros (pendientes, aprobados, completados)

### ✅ Configuración del Sistema
- Productos (los 8 packs)
- Rangos (los 8 niveles)
- Configuración general (wallet principal, etc.)

---

## 🔍 VERIFICAR QUE TODO FUNCIONÓ

### Test 1: Usuarios Migrados

```javascript
fetch('https://[TU-PROJECT-ID-NUEVO].supabase.co/functions/v1/make-server-9f68532a/users', {
  headers: { 'Authorization': 'Bearer [TU-ANON-KEY-NUEVO]' }
})
.then(res => res.json())
.then(data => {
  console.log(`✅ ${data.length} usuarios en la nueva base`);
});
```

### Test 2: Depósitos Migrados

```javascript
fetch('https://[TU-PROJECT-ID-NUEVO].supabase.co/functions/v1/make-server-9f68532a/depositos', {
  headers: { 'Authorization': 'Bearer [TU-ANON-KEY-NUEVO]' }
})
.then(res => res.json())
.then(data => {
  console.log(`✅ ${data.length} depósitos en la nueva base`);
});
```

### Test 3: Login de Usuario Real

1. Inicia sesión con un usuario que tenías en la base anterior
2. Verifica que sus datos estén completos
3. Verifica que sus comisiones estén ahí
4. Verifica que sus depósitos estén ahí

---

## 📝 RESUMEN DE COMANDOS COMPLETOS

### Todo en uno - Exportar de la Anterior

```javascript
const ANTERIOR_ID = 'project-id-anterior';
const ANTERIOR_KEY = 'anon-key-anterior';

fetch(`https://${ANTERIOR_ID}.supabase.co/functions/v1/make-server-9f68532a/backup/export`, {
  headers: { 'Authorization': `Bearer ${ANTERIOR_KEY}` }
})
.then(r => r.json())
.then(d => {
  console.log('✅ Exportado:', d.resumen);
  window.backup = d.backup;
  const blob = new Blob([JSON.stringify(d.backup, null, 2)], {type: 'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'backup.json';
  a.click();
});
```

### Todo en uno - Importar a la Nueva

```javascript
const NUEVA_ID = 'project-id-nuevo';
const NUEVA_KEY = 'anon-key-nuevo';

fetch(`https://${NUEVA_ID}.supabase.co/functions/v1/make-server-9f68532a/backup/import`, {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${NUEVA_KEY}`
  },
  body: JSON.stringify({ backup: window.backup })
})
.then(r => r.json())
.then(d => {
  console.log('✅ Importado:', d.resultado);
});
```

---

## ⚠️ PROBLEMAS COMUNES

### Error: "Failed to fetch"
**Causa:** URL incorrecta o servidor no actualizado  
**Solución:**
1. Verifica que hayas agregado las rutas de backup al `index.tsx`
2. Espera 1-2 minutos a que Supabase actualice el servidor
3. Verifica la URL en la consola del navegador

### Error: "Formato de backup inválido"
**Causa:** El JSON del backup está corrupto  
**Solución:**
1. Exporta de nuevo desde la base anterior
2. Verifica que el archivo JSON sea válido (abrelo en un editor de texto)

### Error: "User already exists"
**Causa:** Normal, significa que algunos usuarios ya existen  
**Solución:**
- No es un error real, el sistema no duplica usuarios
- La importación continuará con el resto de datos

### No aparecen todos los datos
**Causa:** La exportación no se completó  
**Solución:**
1. Ve a Supabase Dashboard > Edge Functions > Logs
2. Busca errores en la exportación
3. Ejecuta la exportación de nuevo

---

## 🎯 CHECKLIST DE MIGRACIÓN

### Antes de empezar:
- [ ] Tienes las credenciales de la base ANTERIOR (PROJECT_ID y ANON_KEY)
- [ ] Tienes las credenciales de la base NUEVA (PROJECT_ID y ANON_KEY)
- [ ] Agregaste las rutas de backup al archivo `index.tsx`
- [ ] El servidor se actualizó correctamente

### Durante la migración:
- [ ] Exportar datos de la base anterior
- [ ] Descargar archivo JSON de backup
- [ ] Importar datos a la base nueva
- [ ] Verificar que no hubo errores

### Después de la migración:
- [ ] Verificar usuarios migrados
- [ ] Verificar depósitos migrados
- [ ] Verificar comisiones migradas
- [ ] Hacer login con un usuario real
- [ ] Verificar que todo funciona correctamente

---

## 🎉 ¡LISTO!

Una vez completada la migración:

✅ Todos tus usuarios estarán en la nueva base  
✅ Todos los depósitos estarán copiados  
✅ Todas las comisiones estarán copiadas  
✅ Todos los retiros estarán copiados  
✅ La configuración estará copiada  

**Tiempo estimado:** 5-10 minutos  
**Dificultad:** ⭐⭐ Fácil (solo copiar y pegar)  
**Riesgo:** Cero (la base anterior NO se modifica)

---

**Creado:** 2025-11-19  
**Versión:** 1.0  
**Estado:** ✅ Listo para usar
