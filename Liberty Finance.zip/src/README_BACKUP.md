# 📚 BACKUP COMPLETO - LIBERTY FINANCE
## Sistema de Base de Datos Supabase

---

## 🎯 RESUMEN EJECUTIVO

Este directorio contiene el **backup completo** del sistema de base de datos de Liberty Finance. Incluye estructura de datos, lógica de negocio, scripts de migración y guías paso a paso.

**Fecha de Creación:** 2025-11-19  
**Versión del Sistema:** 1.0  
**Estado:** ✅ Completo y Funcional

---

## 📁 ARCHIVOS INCLUIDOS

### 1. **BACKUP_DATABASE_STRUCTURE.md** 📊
**Propósito:** Documentación completa de la estructura de datos

**Contenido:**
- ✅ Prefijos de KV Store (clave-valor)
- ✅ Estructuras de datos TypeScript
- ✅ Lógica de negocio crítica
- ✅ Sistema de comisiones (10 niveles)
- ✅ Matriz 3x3 con Cross Spillover
- ✅ Reglas de retiros (antes/después 100% ROI)
- ✅ Cálculo automático de rangos
- ✅ Productos y rangos por defecto
- ✅ Endpoints de API completos

**Cuándo usarlo:**
- Para entender la arquitectura del sistema
- Como referencia durante el desarrollo
- Para documentar nuevas funcionalidades
- Para onboarding de nuevos desarrolladores

---

### 2. **BACKUP_SQL_SCHEMA.sql** 🗄️
**Propósito:** Esquema SQL equivalente (OPCIONAL)

**Contenido:**
- ✅ Tablas SQL completas
- ✅ Índices optimizados
- ✅ Relaciones y constraints
- ✅ Vistas útiles para reportes
- ✅ Funciones almacenadas
- ✅ Triggers automáticos
- ✅ Datos iniciales (productos y rangos)

**Cuándo usarlo:**
- Si decides migrar a PostgreSQL/MySQL tradicional
- Para consultas SQL complejas
- Para reportes avanzados
- Como referencia de estructura relacional

**⚠️ IMPORTANTE:** Este archivo es OPCIONAL. El sistema actual funciona perfectamente con KV Store.

---

### 3. **GUIA_MIGRACION_PASO_A_PASO.md** 🚀
**Propósito:** Instrucciones detalladas de migración

**Contenido:**
- ✅ Preparación pre-migración
- ✅ Creación de nuevo proyecto Supabase
- ✅ Actualización de variables de entorno
- ✅ Verificación de configuración
- ✅ Pruebas post-migración (7 tests)
- ✅ Plan de rollback
- ✅ Troubleshooting común
- ✅ Checklist completo

**Cuándo usarlo:**
- Cuando necesites cambiar de base de datos
- Para migrar a un nuevo proyecto Supabase
- Para replicar el entorno en otro servidor
- Antes de cualquier mantenimiento mayor

---

### 4. **SCRIPTS_MIGRACION_DATOS.md** 📦
**Propósito:** Scripts de exportación/importación de datos

**Contenido:**
- ✅ Script de exportación de usuarios
- ✅ Script de exportación de depósitos
- ✅ Script de exportación de retiros
- ✅ Script de backup completo
- ✅ Script de importación de usuarios
- ✅ Script de importación de depósitos
- ✅ Script de migración automática completa

**Cuándo usarlo:**
- Para migrar datos existentes
- Para hacer backup antes de cambios mayores
- Para replicar datos en ambiente de prueba
- Para recuperación ante desastres

---

### 5. **README_BACKUP.md** 📖
**Propósito:** Este archivo - Índice y guía de uso

---

## 🎯 CASOS DE USO

### Caso 1: Migrar a Nuevo Proyecto Supabase

**Pasos:**
1. Leer `BACKUP_DATABASE_STRUCTURE.md` para entender el sistema
2. Seguir `GUIA_MIGRACION_PASO_A_PASO.md` paso por paso
3. Si hay datos existentes, usar `SCRIPTS_MIGRACION_DATOS.md`
4. Verificar con los 7 tests de la guía

**Tiempo estimado:** 30-60 minutos

---

### Caso 2: Migrar a Base de Datos SQL

**Pasos:**
1. Leer `BACKUP_DATABASE_STRUCTURE.md`
2. Usar `BACKUP_SQL_SCHEMA.sql` para crear las tablas
3. Exportar datos con scripts de `SCRIPTS_MIGRACION_DATOS.md`
4. Transformar y cargar datos en nuevas tablas SQL

**Tiempo estimado:** 2-4 horas

---

### Caso 3: Backup Preventivo

**Pasos:**
1. Usar scripts de `SCRIPTS_MIGRACION_DATOS.md`
2. Ejecutar `exportarBackupCompleto()`
3. Guardar archivo JSON descargado
4. Repetir periódicamente (semanal/mensual)

**Tiempo estimado:** 5-10 minutos

---

### Caso 4: Recuperación ante Desastres

**Pasos:**
1. Crear nuevo proyecto Supabase
2. Seguir `GUIA_MIGRACION_PASO_A_PASO.md`
3. Restaurar datos con `importarUsuarios()` y otros scripts
4. Verificar integridad de datos

**Tiempo estimado:** 1-2 horas

---

### Caso 5: Auditoría o Documentación

**Pasos:**
1. Revisar `BACKUP_DATABASE_STRUCTURE.md`
2. Entender la lógica de negocio
3. Consultar ejemplos y cálculos
4. Usar como referencia oficial

**Tiempo estimado:** Variable según necesidad

---

## ⚙️ TECNOLOGÍAS UTILIZADAS

### Backend
- **Supabase Edge Functions** - Servidor Hono
- **Deno Runtime** - Ejecución de TypeScript
- **KV Store** - Base de datos clave-valor

### Frontend
- **React + TypeScript** - Interfaz de usuario
- **Tailwind CSS** - Estilos
- **Shadcn UI** - Componentes

### Integraciones
- **NOWPayments** - Pagos con criptomonedas
- **USDT TRC20** - Moneda principal

---

## 🔐 INFORMACIÓN SENSIBLE

### ⚠️ Archivos que NO están incluidos (por seguridad)

- ❌ API Keys actuales
- ❌ Contraseñas de base de datos
- ❌ Wallets reales con fondos
- ❌ Datos personales de usuarios reales
- ❌ Comprobantes de pago

### ✅ Lo que SÍ está incluido

- ✅ Estructura de datos
- ✅ Lógica de negocio
- ✅ Scripts de migración
- ✅ Guías y procedimientos
- ✅ Ejemplos con datos de prueba

---

## 📊 ESTADÍSTICAS DEL SISTEMA

### Capacidad y Límites

| Concepto | Valor |
|----------|-------|
| **Usuarios** | Ilimitado |
| **Niveles de Matriz** | 10 niveles |
| **Posiciones por Nivel** | 3^N (exponencial) |
| **Packs Disponibles** | 8 ($50 a $10,000) |
| **Rangos** | 9 (Sin Rango a Crown Black) |
| **Comisión Red** | 10% nivel 1 + 4-1% niveles 2-10 |
| **Bono Directo** | 10% adicional |
| **Rendimiento Diario** | 1% hasta 100% ROI |
| **Comisión Retiro** | 10% sin excepciones |

### Prefijos de Base de Datos

**Total:** 15+ prefijos principales

| Categoría | Cantidad |
|-----------|----------|
| Usuarios | 4 prefijos |
| Packs | 3 prefijos |
| Comisiones | 3 prefijos |
| Transacciones | 6 prefijos |
| Configuración | 3+ prefijos |

---

## 🔄 FLUJOS CRÍTICOS

### Flujo 1: Registro y Activación

```
Usuario se registra (activo=false)
    ↓
Solicita depósito (pendiente)
    ↓
Admin verifica depósito
    ↓
Sistema AUTOMÁTICO:
    - Crea Pack activo
    - Activa usuario (activo=true)
    - Calcula comisiones (10 niveles)
    - Asigna bono directo (10%)
    - Actualiza rangos de la línea
```

### Flujo 2: Comisiones Multinivel

```
Usuario A compra Pack $1,000
    ↓
Sistema calcula:
    - Patrocinador: $100 (10%) + $100 (bono) = $200
    - Nivel 2: $40 (4%)
    - Nivel 3: $30 (3%)
    - Niveles 4-6: $20 c/u (2%) = $60
    - Niveles 7-10: $10 c/u (1%) = $40
    ↓
Total distribuido: $370 (37%)
```

### Flujo 3: Sistema de Retiros

```
Usuario solicita retiro de $100
    ↓
Sistema valida:
    - ¿Tiene saldo suficiente?
    - ¿Alcanzó 100% ROI?
    - ¿Es capital o ganancia?
    ↓
Aplica comisión: $100 - 10% = $90 neto
    ↓
Admin aprueba
    ↓
Usuario recibe: $90 USDT
```

---

## 📈 MÉTRICAS DE ÉXITO

### Indicadores Post-Migración

| Métrica | Objetivo |
|---------|----------|
| **Usuarios Migrados** | 100% |
| **Datos Íntegros** | 100% |
| **Tiempo de Inactividad** | < 30 min |
| **Errores Críticos** | 0 |
| **Tests Pasados** | 7/7 |
| **Health Check** | ✅ OK |

---

## 🚨 CONTINGENCIAS

### Si la Migración Falla

1. **Plan A:** Rollback a base de datos anterior
   - Restaurar variables de entorno
   - Verificar funcionamiento
   - Tiempo: 5 minutos

2. **Plan B:** Mantener ambas bases de datos
   - Antigua: Solo lectura
   - Nueva: Testing
   - Migración gradual

3. **Plan C:** Recuperación total
   - Crear nuevo proyecto
   - Restaurar desde backup
   - Importar datos con scripts

---

## ✅ CHECKLIST DE VERIFICACIÓN

### Antes de Cualquier Cambio

- [ ] Backup completo realizado
- [ ] Archivos de backup descargados
- [ ] Variables de entorno documentadas
- [ ] Plan de rollback definido
- [ ] Equipo notificado

### Durante el Cambio

- [ ] Logs monitoreados en tiempo real
- [ ] Tests ejecutándose correctamente
- [ ] Sin errores críticos
- [ ] Tiempo dentro del estimado

### Después del Cambio

- [ ] Todos los tests pasados (7/7)
- [ ] Usuarios pueden acceder
- [ ] Transacciones funcionan
- [ ] Comisiones se calculan
- [ ] Matriz visualiza correctamente
- [ ] Retiros procesables

---

## 📞 CONTACTO Y SOPORTE

### Recursos Oficiales

- **Supabase Docs:** https://supabase.com/docs
- **Supabase Status:** https://status.supabase.com
- **Supabase Community:** https://github.com/supabase/supabase/discussions

### Logs y Debugging

1. **Logs del Servidor:**
   - Dashboard > Edge Functions > Logs

2. **Logs del Cliente:**
   - F12 > Console
   - F12 > Network

3. **Base de Datos:**
   - Dashboard > Table Editor
   - Dashboard > SQL Editor

---

## 📚 DOCUMENTACIÓN ADICIONAL

### Archivos Relacionados

```
/supabase/functions/server/
├── index.tsx          - Servidor principal (rutas y lógica)
├── crm.tsx            - Funciones de negocio (CRUD)
└── kv_store.tsx       - Acceso a base de datos (PROTEGIDO)

/components/
├── admin/             - Componentes de administración
├── user/              - Componentes de usuario
└── ...                - Otros componentes

/utils/
├── api.tsx            - Cliente API
└── supabase/          - Configuración Supabase
```

### Diagramas (ASCII)

**Arquitectura del Sistema:**
```
┌─────────────┐
│   Frontend  │
│   (React)   │
└──────┬──────┘
       │ API Calls
       ↓
┌─────────────┐
│ Edge Function│
│   (Hono)    │
└──────┬──────┘
       │ KV Operations
       ↓
┌─────────────┐
│  KV Store   │
│  (Supabase) │
└─────────────┘
```

**Flujo de Comisiones:**
```
        Usuario A (Compra $1,000)
              ↓
    ┌─────────────────────┐
    │   Patrocinador      │
    │   +$200 (20%)       │
    └─────────────────────┘
              ↓
    ┌─────────────────────┐
    │   9 Niveles Más     │
    │   +$170 (17%)       │
    └─────────────────────┘
              ↓
    Total Distribuido: $370 (37%)
```

---

## 🎓 CAPACITACIÓN

### Para Nuevos Desarrolladores

1. **Día 1:** Leer `BACKUP_DATABASE_STRUCTURE.md`
2. **Día 2:** Entender flujos de negocio
3. **Día 3:** Probar con datos de prueba
4. **Día 4:** Hacer cambios en ambiente dev
5. **Día 5:** Code review y deployment

### Para Administradores

1. Entender estructura de datos
2. Conocer proceso de backup
3. Practicar migración en ambiente de prueba
4. Documentar procedimientos específicos

---

## 🔮 FUTURAS MEJORAS

### Sugerencias de Optimización

1. **Implementar Hashing de Contraseñas**
   - bcrypt o similar
   - Aumenta seguridad

2. **Agregar Índices Secundarios**
   - Mejorar velocidad de consultas
   - Reducir latencia

3. **Implementar Cache**
   - Redis para datos frecuentes
   - Reducir carga en DB

4. **Agregar Logging Avanzado**
   - Sentry para errores
   - Mixpanel para analytics

5. **Backup Automático**
   - Cron job diario
   - Exportar a S3 o similar

---

## 📜 HISTORIAL DE VERSIONES

| Versión | Fecha | Cambios |
|---------|-------|---------|
| **1.0** | 2025-11-19 | Versión inicial - Backup completo |

---

## 🏆 CRÉDITOS

**Sistema:** Liberty Finance  
**Base de Datos:** Supabase KV Store  
**Documentación:** Generada automáticamente  
**Mantenimiento:** Equipo de desarrollo

---

## 📄 LICENCIA Y USO

Este backup es **propiedad exclusiva** de Liberty Finance.

**Uso permitido:**
- ✅ Migración de base de datos
- ✅ Recuperación ante desastres
- ✅ Documentación interna
- ✅ Capacitación de equipo

**Uso NO permitido:**
- ❌ Distribución externa
- ❌ Uso comercial por terceros
- ❌ Modificación sin autorización
- ❌ Reverse engineering para competencia

---

## ✨ CONCLUSIÓN

Este backup representa el estado completo y funcional del sistema Liberty Finance al 2025-11-19. Incluye toda la información necesaria para:

- ✅ Entender la arquitectura
- ✅ Migrar a nueva base de datos
- ✅ Recuperar ante desastres
- ✅ Capacitar nuevo personal
- ✅ Auditar y documentar

**¡Mantén este backup en lugar seguro!** 🔐

---

**Última actualización:** 2025-11-19  
**Versión del documento:** 1.0  
**Estado:** ✅ Completo y Verificado
