import { useState } from 'react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { toast } from 'sonner@2.0.3';
import { LogIn, Loader2 } from 'lucide-react';
import { callServer } from '../../utils/api';

export function TestLogin() {
  const [email, setEmail] = useState('admin@libertyfinance.com');
  const [password, setPassword] = useState('admin123');
  const [loading, setLoading] = useState(false);
  const [resultado, setResultado] = useState<any>(null);

  const probarLogin = async () => {
    setLoading(true);
    setResultado(null);

    try {
      console.log(`🔍 Probando login con: ${email} / ${password}`);
      
      const response = await callServer('/auth/login', 'POST', { email, password });
      
      console.log('📥 Respuesta del servidor:', response);
      setResultado(response);
      
      if (response.success) {
        toast.success('✅ Login exitoso!', {
          description: `Bienvenido ${response.user.nombre} ${response.user.apellido}`
        });
      } else if (response.error) {
        toast.error('❌ Error en login', {
          description: response.error
        });
      }

    } catch (error) {
      console.error('❌ Error:', error);
      setResultado({ error: error instanceof Error ? error.message : 'Error desconocido' });
      toast.error('❌ Error al probar login', {
        description: error instanceof Error ? error.message : 'Error desconocido'
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="bg-blue-50 border-2 border-blue-200 rounded-xl p-4">
        <p className="text-sm text-blue-800 mb-2">
          <strong>🧪 Prueba de Login</strong>
        </p>
        <p className="text-sm text-blue-700">
          Verifica que las credenciales de administrador funcionen correctamente
        </p>
      </div>

      <div className="space-y-4">
        <div className="space-y-2">
          <Label>Email</Label>
          <Input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="admin@libertyfinance.com"
          />
        </div>

        <div className="space-y-2">
          <Label>Contraseña</Label>
          <Input
            type="text"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="admin123"
          />
        </div>

        <Button
          onClick={probarLogin}
          disabled={loading}
          className="w-full"
        >
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Probando Login...
            </>
          ) : (
            <>
              <LogIn className="w-4 h-4 mr-2" />
              Probar Login
            </>
          )}
        </Button>
      </div>

      {resultado && (
        <div className={`p-4 rounded-xl border-2 ${
          resultado.success 
            ? 'bg-green-50 border-green-200' 
            : 'bg-red-50 border-red-200'
        }`}>
          <p className={`text-sm mb-2 ${
            resultado.success ? 'text-green-800' : 'text-red-800'
          }`}>
            <strong>{resultado.success ? '✅ Resultado Exitoso' : '❌ Resultado con Error'}</strong>
          </p>
          <pre className={`text-xs overflow-auto max-h-64 ${
            resultado.success ? 'text-green-700' : 'text-red-700'
          }`}>
            {JSON.stringify(resultado, null, 2)}
          </pre>
        </div>
      )}
    </div>
  );
}
