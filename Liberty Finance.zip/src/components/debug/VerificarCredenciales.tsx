import { useState } from 'react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { toast } from 'sonner@2.0.3';
import { CheckCircle2, XCircle, AlertTriangle, Copy } from 'lucide-react';
import { projectId, publicAnonKey } from '../../utils/supabase/info';

export function VerificarCredenciales() {
  const [testProjectId, setTestProjectId] = useState(projectId);
  const [testAnonKey, setTestAnonKey] = useState(publicAnonKey.substring(0, 50) + '...');
  const [resultado, setResultado] = useState<any>(null);

  const verificarFormato = () => {
    const problemas: string[] = [];
    
    // Verificar projectId
    if (!testProjectId) {
      problemas.push('❌ projectId está vacío');
    } else if (testProjectId.includes('http')) {
      problemas.push('⚠️ projectId NO debe incluir "http://" o "https://"');
    } else if (testProjectId.includes('.supabase.co')) {
      problemas.push('⚠️ projectId NO debe incluir ".supabase.co"');
    } else if (testProjectId.length < 10 || testProjectId.length > 30) {
      problemas.push('⚠️ projectId parece tener longitud incorrecta');
    }
    
    // Verificar publicAnonKey
    if (!publicAnonKey) {
      problemas.push('❌ publicAnonKey está vacío');
    } else if (!publicAnonKey.startsWith('eyJ')) {
      problemas.push('⚠️ publicAnonKey NO parece ser un JWT válido (debe empezar con "eyJ")');
    } else if (publicAnonKey.length < 100) {
      problemas.push('⚠️ publicAnonKey parece estar incompleto (muy corto)');
    }
    
    return problemas;
  };

  const probarConexion = async () => {
    setResultado(null);
    
    const problemas = verificarFormato();
    
    if (problemas.length > 0) {
      setResultado({
        success: false,
        tipo: 'formato',
        problemas
      });
      toast.error('Problemas detectados en credenciales', {
        description: `${problemas.length} problema(s) encontrado(s)`
      });
      return;
    }
    
    // Intentar conexión
    try {
      const url = `https://${projectId}.supabase.co/functions/v1/make-server-9f68532a/ping`;
      console.log('🔍 Probando conexión a:', url);
      
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 5000);
      
      const response = await fetch(url, {
        method: 'GET',
        headers: { 'Authorization': `Bearer ${publicAnonKey}` },
        signal: controller.signal
      });
      
      clearTimeout(timeout);
      
      if (response.ok) {
        setResultado({
          success: true,
          tipo: 'conexion',
          mensaje: '✅ Credenciales correctas y servidor respondiendo'
        });
        toast.success('✅ Conexión exitosa', {
          description: 'Las credenciales son correctas'
        });
      } else {
        setResultado({
          success: false,
          tipo: 'http',
          status: response.status,
          statusText: response.statusText
        });
        toast.error(`Error HTTP ${response.status}`, {
          description: response.statusText
        });
      }
    } catch (error) {
      console.error('Error en conexión:', error);
      
      if (error instanceof Error && error.name === 'AbortError') {
        setResultado({
          success: false,
          tipo: 'timeout',
          mensaje: 'El servidor no respondió en 5 segundos. Posibles causas:',
          causas: [
            'El servidor está en cold start (esperando a despertar)',
            'Las credenciales de Supabase están incorrectas',
            'El proyecto de Supabase no existe o está pausado',
            'No hay conexión a internet'
          ]
        });
        toast.error('Timeout de conexión', {
          description: 'El servidor no responde'
        });
      } else {
        setResultado({
          success: false,
          tipo: 'error',
          mensaje: error instanceof Error ? error.message : 'Error desconocido'
        });
        toast.error('Error de conexión', {
          description: error instanceof Error ? error.message : 'Error desconocido'
        });
      }
    }
  };

  const copiarInstrucciones = () => {
    const instrucciones = `
INSTRUCCIONES PARA OBTENER CREDENCIALES DE SUPABASE:

1. Ve a: https://supabase.com/dashboard
2. Inicia sesión con tu cuenta
3. Selecciona tu proyecto "Liberty Finance" (o créalo si no existe)
4. En el menú lateral, ve a: Settings → API
5. Copia los siguientes valores:

   Project URL: https://XXXXX.supabase.co
   → Copia solo "XXXXX" (sin https:// ni .supabase.co)
   → Pega en: /utils/supabase/info.tsx → projectId
   
   anon public:
   → Copia la clave completa (empieza con "eyJ...")
   → Pega en: /utils/supabase/info.tsx → publicAnonKey

6. Guarda el archivo y recarga la aplicación

IMPORTANTE:
- NO incluyas "https://" en projectId
- NO incluyas ".supabase.co" en projectId
- La anon key debe ser la clave COMPLETA
- La anon key empieza con "eyJ"
    `.trim();
    
    navigator.clipboard.writeText(instrucciones);
    toast.success('Instrucciones copiadas', {
      description: 'Pégalas en un archivo de texto para referencia'
    });
  };

  const problemasFormato = verificarFormato();

  return (
    <div className="space-y-4">
      <div className="bg-blue-50 border-2 border-blue-200 rounded-xl p-4">
        <p className="text-sm text-blue-800 mb-2">
          <strong>🔍 Verificar Credenciales de Supabase</strong>
        </p>
        <p className="text-sm text-blue-700">
          Verifica que las credenciales en <code className="bg-blue-100 px-1 rounded">/utils/supabase/info.tsx</code> sean correctas
        </p>
      </div>

      {/* Mostrar credenciales actuales */}
      <div className="space-y-3">
        <div className="space-y-2">
          <Label className="text-xs text-slate-600">Project ID Actual</Label>
          <div className="flex items-center gap-2">
            <Input
              value={testProjectId}
              onChange={(e) => setTestProjectId(e.target.value)}
              className="font-mono text-xs"
              readOnly
            />
            {testProjectId && !testProjectId.includes('http') && !testProjectId.includes('.supabase.co') ? (
              <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0" />
            ) : (
              <XCircle className="w-5 h-5 text-red-600 flex-shrink-0" />
            )}
          </div>
        </div>

        <div className="space-y-2">
          <Label className="text-xs text-slate-600">Anon Key (primeros 50 caracteres)</Label>
          <div className="flex items-center gap-2">
            <Input
              value={testAnonKey}
              className="font-mono text-xs"
              readOnly
            />
            {publicAnonKey.startsWith('eyJ') ? (
              <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0" />
            ) : (
              <XCircle className="w-5 h-5 text-red-600 flex-shrink-0" />
            )}
          </div>
        </div>
      </div>

      {/* Problemas detectados */}
      {problemasFormato.length > 0 && (
        <div className="bg-red-50 border-2 border-red-200 rounded-xl p-4">
          <p className="text-sm text-red-800 mb-2">
            <strong>❌ Problemas Detectados:</strong>
          </p>
          <ul className="text-sm text-red-700 space-y-1">
            {problemasFormato.map((problema, i) => (
              <li key={i}>• {problema}</li>
            ))}
          </ul>
        </div>
      )}

      {/* Botones */}
      <div className="flex gap-3">
        <Button
          onClick={probarConexion}
          className="flex-1"
          variant={problemasFormato.length > 0 ? "destructive" : "default"}
        >
          Probar Conexión
        </Button>
        <Button
          onClick={copiarInstrucciones}
          variant="outline"
          className="flex-shrink-0"
        >
          <Copy className="w-4 h-4 mr-2" />
          Copiar Instrucciones
        </Button>
      </div>

      {/* Resultado */}
      {resultado && (
        <div className={`p-4 rounded-xl border-2 ${
          resultado.success 
            ? 'bg-green-50 border-green-200' 
            : 'bg-red-50 border-red-200'
        }`}>
          <div className="flex items-start gap-3">
            {resultado.success ? (
              <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
            ) : (
              <XCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
            )}
            <div className="flex-1">
              {resultado.tipo === 'formato' && (
                <>
                  <p className="text-sm text-red-800 mb-2">
                    <strong>Problemas de Formato Detectados</strong>
                  </p>
                  <ul className="text-sm text-red-700 space-y-1 mb-3">
                    {resultado.problemas.map((p: string, i: number) => (
                      <li key={i}>• {p}</li>
                    ))}
                  </ul>
                  <div className="bg-white rounded-lg p-3 text-xs text-red-700">
                    <p className="mb-2"><strong>💡 Cómo corregir:</strong></p>
                    <p>1. Abre <code className="bg-red-100 px-1 rounded">/utils/supabase/info.tsx</code></p>
                    <p>2. Haz clic en "Copiar Instrucciones" arriba</p>
                    <p>3. Sigue las instrucciones para obtener las credenciales correctas</p>
                  </div>
                </>
              )}
              
              {resultado.tipo === 'conexion' && (
                <>
                  <p className="text-sm text-green-800 mb-2">
                    <strong>{resultado.mensaje}</strong>
                  </p>
                  <p className="text-xs text-green-700">
                    El servidor está respondiendo correctamente. Si sigues experimentando timeouts, 
                    prueba usar "Despertar Servidor" arriba.
                  </p>
                </>
              )}
              
              {resultado.tipo === 'timeout' && (
                <>
                  <p className="text-sm text-red-800 mb-2">
                    <strong>Timeout de Conexión</strong>
                  </p>
                  <p className="text-sm text-red-700 mb-2">{resultado.mensaje}</p>
                  <ul className="text-sm text-red-700 space-y-1 mb-3">
                    {resultado.causas.map((causa: string, i: number) => (
                      <li key={i}>• {causa}</li>
                    ))}
                  </ul>
                  <div className="bg-white rounded-lg p-3 text-xs text-red-700">
                    <p className="mb-2"><strong>🔧 Qué hacer:</strong></p>
                    <p>1. Verifica que las credenciales sean correctas (usa "Copiar Instrucciones")</p>
                    <p>2. Ve a https://supabase.com y confirma que tu proyecto existe</p>
                    <p>3. Intenta "Despertar Servidor" y espera 60-90 segundos</p>
                    <p>4. Revisa https://status.supabase.com para ver si hay incidencias</p>
                  </div>
                </>
              )}
              
              {resultado.tipo === 'http' && (
                <>
                  <p className="text-sm text-red-800 mb-2">
                    <strong>Error HTTP {resultado.status}</strong>
                  </p>
                  <p className="text-sm text-red-700 mb-2">
                    {resultado.statusText}
                  </p>
                  {resultado.status === 401 && (
                    <div className="bg-white rounded-lg p-3 text-xs text-red-700">
                      <p><strong>401 = No autorizado</strong></p>
                      <p>La anon key es incorrecta. Verifica en Supabase Dashboard → Settings → API</p>
                    </div>
                  )}
                  {resultado.status === 404 && (
                    <div className="bg-white rounded-lg p-3 text-xs text-red-700">
                      <p><strong>404 = No encontrado</strong></p>
                      <p>El Edge Function "server" no existe o no está desplegado.</p>
                      <p>Ve a Supabase Dashboard → Edge Functions y verifica que "server" esté listado.</p>
                    </div>
                  )}
                </>
              )}
              
              {resultado.tipo === 'error' && (
                <>
                  <p className="text-sm text-red-800 mb-2">
                    <strong>Error de Conexión</strong>
                  </p>
                  <p className="text-sm text-red-700">{resultado.mensaje}</p>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Instrucciones para obtener credenciales */}
      <div className="bg-gradient-to-r from-purple-50 to-blue-50 border-2 border-purple-200 rounded-xl p-4">
        <p className="text-sm text-purple-800 mb-2">
          <strong>📚 ¿Dónde están las credenciales?</strong>
        </p>
        <div className="text-sm text-purple-700 space-y-1">
          <p>1. Ve a <a href="https://supabase.com/dashboard" target="_blank" rel="noopener" className="underline">supabase.com/dashboard</a></p>
          <p>2. Selecciona tu proyecto</p>
          <p>3. Settings → API</p>
          <p>4. Copia Project URL y anon public key</p>
          <p>5. Pégalas en <code className="bg-purple-100 px-1 rounded">/utils/supabase/info.tsx</code></p>
        </div>
      </div>
    </div>
  );
}
