import { useState } from 'react';
import { Button } from '../ui/button';
import { toast } from 'sonner@2.0.3';
import { KeyRound, Loader2 } from 'lucide-react';
import { projectId, publicAnonKey } from '../../utils/supabase/info';

export function ResetAdminPassword() {
  const [loading, setLoading] = useState(false);

  const resetPassword = async () => {
    setLoading(true);

    try {
      console.log('🔧 Reseteando contraseña del admin...');
      
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-9f68532a/debug/reset-admin-password`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`
          }
        }
      );

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Error: ${errorText}`);
      }

      const data = await response.json();
      console.log('✅ Contraseña reseteada:', data);
      
      if (data.success) {
        toast.success('Contraseña reseteada correctamente', {
          description: 'Email: admin@libertyfinance.com | Password: admin123'
        });
      } else {
        toast.error('Error al resetear contraseña', {
          description: data.error || 'Error desconocido'
        });
      }

    } catch (error) {
      console.error('❌ Error:', error);
      toast.error('Error al resetear contraseña', {
        description: error instanceof Error ? error.message : 'Error desconocido'
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="bg-yellow-50 border-2 border-yellow-200 rounded-xl p-4">
        <p className="text-sm text-yellow-800 mb-2">
          <strong>⚠️ ¿No puedes iniciar sesión con el admin?</strong>
        </p>
        <p className="text-sm text-yellow-700">
          Este botón reseteará la contraseña del administrador a <code className="bg-yellow-100 px-2 py-1 rounded">admin123</code>
        </p>
      </div>

      <Button
        onClick={resetPassword}
        disabled={loading}
        variant="destructive"
        size="sm"
        className="w-full"
      >
        {loading ? (
          <>
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            Reseteando...
          </>
        ) : (
          <>
            <KeyRound className="w-4 h-4 mr-2" />
            Resetear Contraseña del Admin
          </>
        )}
      </Button>

      <div className="bg-blue-50 border-2 border-blue-200 rounded-xl p-4">
        <p className="text-sm text-blue-800">
          <strong>🔐 Credenciales después del reset:</strong>
        </p>
        <div className="mt-2 space-y-1 text-sm">
          <div className="flex items-center justify-between bg-white rounded-lg p-2">
            <span className="text-slate-600">Email:</span>
            <code className="bg-blue-100 px-2 py-1 rounded text-blue-900">
              admin@libertyfinance.com
            </code>
          </div>
          <div className="flex items-center justify-between bg-white rounded-lg p-2">
            <span className="text-slate-600">Password:</span>
            <code className="bg-blue-100 px-2 py-1 rounded text-blue-900">
              admin123
            </code>
          </div>
        </div>
      </div>
    </div>
  );
}
