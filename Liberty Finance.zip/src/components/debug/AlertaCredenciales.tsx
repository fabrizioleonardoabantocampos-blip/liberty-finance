import { useState, useEffect } from 'react';
import { AlertTriangle, X, ExternalLink } from 'lucide-react';
import { Button } from '../ui/button';
import { projectId, publicAnonKey } from '../../utils/supabase/info';

export function AlertaCredenciales() {
  const [show, setShow] = useState(false);
  const [problemas, setProblemas] = useState<string[]>([]);

  useEffect(() => {
    const problemasDetectados: string[] = [];

    // Verificar projectId
    if (!projectId || projectId === 'YOUR_PROJECT_ID') {
      problemasDetectados.push('projectId no está configurado');
    } else if (projectId.includes('http')) {
      problemasDetectados.push('projectId incluye "http://" (debe ser solo el ID)');
    } else if (projectId.includes('.supabase.co')) {
      problemasDetectados.push('projectId incluye ".supabase.co" (debe ser solo el ID)');
    }

    // Verificar publicAnonKey
    if (!publicAnonKey || publicAnonKey === 'YOUR_ANON_KEY') {
      problemasDetectados.push('publicAnonKey no está configurado');
    } else if (!publicAnonKey.startsWith('eyJ')) {
      problemasDetectados.push('publicAnonKey no parece ser un JWT válido');
    } else if (publicAnonKey.length < 100) {
      problemasDetectados.push('publicAnonKey parece estar incompleto');
    }

    if (problemasDetectados.length > 0) {
      setProblemas(problemasDetectados);
      setShow(true);
    }
  }, []);

  if (!show) return null;

  return (
    <div className="fixed bottom-4 right-4 max-w-md bg-red-600 text-white rounded-xl shadow-2xl p-4 z-50 animate-in slide-in-from-bottom-5">
      <div className="flex items-start gap-3">
        <AlertTriangle className="w-6 h-6 flex-shrink-0 mt-0.5" />
        <div className="flex-1">
          <h3 className="font-semibold mb-2">⚠️ Credenciales NO Configuradas</h3>
          <p className="text-sm text-red-100 mb-2">
            Detectamos problemas en tus credenciales de Supabase:
          </p>
          <ul className="text-sm text-red-100 space-y-1 mb-3 list-disc list-inside">
            {problemas.map((problema, i) => (
              <li key={i}>{problema}</li>
            ))}
          </ul>
          <div className="flex gap-2">
            <Button
              size="sm"
              variant="secondary"
              onClick={() => window.location.href = '/Setup'}
              className="text-xs"
            >
              <ExternalLink className="w-3 h-3 mr-1" />
              Ir a Setup
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setShow(false)}
              className="text-xs text-white hover:text-white hover:bg-red-700"
            >
              <X className="w-3 h-3 mr-1" />
              Cerrar
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
