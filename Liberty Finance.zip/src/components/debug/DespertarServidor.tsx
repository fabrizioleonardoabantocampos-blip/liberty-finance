import { useState } from 'react';
import { Button } from '../ui/button';
import { toast } from 'sonner@2.0.3';
import { Zap, Loader2, CheckCircle2 } from 'lucide-react';
import { projectId, publicAnonKey } from '../../utils/supabase/info';

export function DespertarServidor() {
  const [loading, setLoading] = useState(false);
  const [resultado, setResultado] = useState<{ success: boolean; time: number } | null>(null);

  const despertar = async () => {
    setLoading(true);
    setResultado(null);

    try {
      console.log('⚡ Despertando servidor...');
      toast.info('⏳ Despertando servidor...', {
        description: 'Esto puede tardar 30-90 segundos en cold start'
      });

      const startTime = Date.now();

      // Hacer petición simple de ping para despertar el servidor
      // ⚡ TIMEOUT EXTENDIDO: 120 segundos para cold start
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 120000); // 2 minutos

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-9f68532a/ping`,
        {
          method: 'GET',
          headers: { 'Authorization': `Bearer ${publicAnonKey}` },
          signal: controller.signal
        }
      );

      clearTimeout(timeoutId);
      const totalTime = Date.now() - startTime;

      if (response.ok) {
        setResultado({ success: true, time: totalTime });
        console.log(`✅ Servidor despierto en ${totalTime}ms`);
        
        if (totalTime < 1000) {
          toast.success('✅ Servidor ya estaba despierto', {
            description: `Respondió en ${totalTime}ms`
          });
        } else if (totalTime < 10000) {
          toast.success('✅ Servidor despertado exitosamente', {
            description: `Tardó ${(totalTime / 1000).toFixed(1)} segundos`
          });
        } else {
          toast.success('✅ Servidor finalmente despertó', {
            description: `Cold start completado en ${(totalTime / 1000).toFixed(1)} segundos`
          });
        }
      } else {
        setResultado({ success: false, time: totalTime });
        toast.error('❌ Error al despertar servidor', {
          description: `HTTP ${response.status}`
        });
      }

    } catch (error) {
      const totalTime = Date.now();
      console.error('❌ Error:', error);
      setResultado({ success: false, time: totalTime });
      
      toast.error('❌ Error al despertar servidor', {
        description: error instanceof Error ? error.message : 'Error desconocido'
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="bg-gradient-to-r from-blue-50 to-purple-50 border-2 border-blue-200 rounded-xl p-6">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-xl bg-blue-500 flex items-center justify-center flex-shrink-0">
            <Zap className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1">
            <p className="text-sm text-blue-800 mb-2">
              <strong>⚡ ¿Servidor dormido?</strong>
            </p>
            <p className="text-sm text-blue-700 mb-3">
              Si experimentas timeouts, el servidor puede estar en "cold start" (dormido por inactividad).
              Este botón lo "despierta" haciendo una petición inicial.
            </p>
            <div className="bg-white/50 rounded-lg p-3 text-xs text-blue-600 space-y-1">
              <p>⏱️ <strong>Primera vez:</strong> Puede tardar 30-90 segundos</p>
              <p>⚡ <strong>Ya despierto:</strong> Responde en menos de 1 segundo</p>
              <p>💡 <strong>Truco:</strong> Úsalo antes de iniciar sesión</p>
            </div>
          </div>
        </div>
      </div>

      <Button
        onClick={despertar}
        disabled={loading}
        className="w-full h-14 text-lg bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
      >
        {loading ? (
          <>
            <Loader2 className="w-5 h-5 mr-2 animate-spin" />
            Despertando Servidor...
          </>
        ) : (
          <>
            <Zap className="w-5 h-5 mr-2" />
            ⚡ Despertar Servidor Ahora
          </>
        )}
      </Button>

      {resultado && (
        <div className={`p-4 rounded-xl border-2 ${
          resultado.success 
            ? 'bg-green-50 border-green-200' 
            : 'bg-red-50 border-red-200'
        }`}>
          <div className="flex items-start gap-3">
            {resultado.success && <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />}
            <div className="flex-1">
              <p className={`text-sm mb-1 ${
                resultado.success ? 'text-green-800' : 'text-red-800'
              }`}>
                <strong>
                  {resultado.success ? '✅ Servidor Despierto' : '❌ Error al Despertar'}
                </strong>
              </p>
              <p className={`text-xs ${
                resultado.success ? 'text-green-700' : 'text-red-700'
              }`}>
                Tiempo de respuesta: {resultado.time}ms ({(resultado.time / 1000).toFixed(2)}s)
              </p>
              {resultado.success && resultado.time > 10000 && (
                <p className="text-xs text-green-600 mt-2">
                  💡 El servidor estaba en cold start. Ahora debería responder rápido.
                </p>
              )}
            </div>
          </div>
        </div>
      )}

      {resultado?.success && (
        <div className="bg-green-50 border-2 border-green-200 rounded-xl p-4">
          <p className="text-sm text-green-800 mb-2">
            <strong>🎉 ¡Listo para usar!</strong>
          </p>
          <p className="text-sm text-green-700">
            El servidor está despierto y respondiendo. Ahora puedes:
          </p>
          <ul className="text-sm text-green-700 mt-2 space-y-1 list-disc list-inside">
            <li>Iniciar sesión sin timeouts</li>
            <li>Ejecutar el diagnóstico de conectividad</li>
            <li>Usar todas las funciones normalmente</li>
          </ul>
        </div>
      )}
    </div>
  );
}