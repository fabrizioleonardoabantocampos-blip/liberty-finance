import { useState, useEffect } from 'react';
import { Activity, Wifi, WifiOff, Loader2 } from 'lucide-react';

interface ServerStatusProps {
  showDetails?: boolean;
}

export function ServerStatus({ showDetails = false }: ServerStatusProps) {
  const [status, setStatus] = useState<'checking' | 'online' | 'offline' | 'slow'>('checking');
  const [ping, setPing] = useState<number | null>(null);
  const [lastCheck, setLastCheck] = useState<Date | null>(null);

  const checkServer = async () => {
    setStatus('checking');
    
    try {
      const startTime = Date.now();
      const response = await fetch(
        `https://${(await import('../../utils/supabase/info')).projectId}.supabase.co/functions/v1/make-server-9f68532a/ping`,
        {
          method: 'GET',
          headers: { 
            'Authorization': `Bearer ${(await import('../../utils/supabase/info')).publicAnonKey}` 
          },
          signal: AbortSignal.timeout(5000) // 5 segundos
        }
      );
      
      const pingTime = Date.now() - startTime;
      setPing(pingTime);
      setLastCheck(new Date());
      
      if (response.ok) {
        if (pingTime < 1000) {
          setStatus('online');
        } else {
          setStatus('slow');
        }
      } else {
        setStatus('offline');
      }
    } catch (error) {
      console.warn('Server check failed:', error);
      setStatus('offline');
      setPing(null);
      setLastCheck(new Date());
    }
  };

  useEffect(() => {
    checkServer();
    
    // Check every 30 seconds
    const interval = setInterval(checkServer, 30000);
    
    return () => clearInterval(interval);
  }, []);

  const getStatusColor = () => {
    switch (status) {
      case 'online':
        return 'bg-green-500';
      case 'slow':
        return 'bg-yellow-500';
      case 'offline':
        return 'bg-red-500';
      case 'checking':
        return 'bg-gray-400';
    }
  };

  const getStatusText = () => {
    switch (status) {
      case 'online':
        return 'En línea';
      case 'slow':
        return 'Lento';
      case 'offline':
        return 'Fuera de línea';
      case 'checking':
        return 'Verificando...';
    }
  };

  const getStatusIcon = () => {
    switch (status) {
      case 'online':
      case 'slow':
        return <Wifi className="w-4 h-4" />;
      case 'offline':
        return <WifiOff className="w-4 h-4" />;
      case 'checking':
        return <Loader2 className="w-4 h-4 animate-spin" />;
    }
  };

  if (!showDetails) {
    // Modo compacto - solo indicador
    return (
      <div className="flex items-center gap-2">
        <div className={`w-2 h-2 rounded-full ${getStatusColor()} animate-pulse`} />
        <span className="text-xs text-slate-600">{getStatusText()}</span>
      </div>
    );
  }

  // Modo detallado
  return (
    <div className="bg-white rounded-lg border border-slate-200 p-3 shadow-sm">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className={`w-3 h-3 rounded-full ${getStatusColor()} ${status === 'checking' ? 'animate-pulse' : ''}`} />
          <div>
            <div className="flex items-center gap-2">
              {getStatusIcon()}
              <span className="text-sm font-medium text-slate-800">
                Servidor: {getStatusText()}
              </span>
            </div>
            {ping !== null && status !== 'offline' && (
              <p className="text-xs text-slate-500 mt-1">
                Latencia: {ping}ms
              </p>
            )}
            {lastCheck && (
              <p className="text-xs text-slate-400 mt-1">
                Última verificación: {lastCheck.toLocaleTimeString()}
              </p>
            )}
          </div>
        </div>
        
        <button
          onClick={checkServer}
          disabled={status === 'checking'}
          className="text-xs text-blue-600 hover:text-blue-700 disabled:text-gray-400 flex items-center gap-1"
        >
          <Activity className="w-3 h-3" />
          Verificar
        </button>
      </div>
      
      {status === 'offline' && (
        <div className="mt-3 p-2 bg-red-50 rounded text-xs text-red-700 border border-red-200">
          ⚠️ El servidor no responde. Puede estar en cold start (30-90s).
        </div>
      )}
      
      {status === 'slow' && (
        <div className="mt-3 p-2 bg-yellow-50 rounded text-xs text-yellow-700 border border-yellow-200">
          ⚡ El servidor está respondiendo lentamente. Puede estar procesando otras peticiones.
        </div>
      )}
    </div>
  );
}
