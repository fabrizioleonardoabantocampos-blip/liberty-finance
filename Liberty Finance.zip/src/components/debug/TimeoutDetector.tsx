import { useEffect, useState } from 'react';
import { AlertTriangle, Zap } from 'lucide-react';
import { Button } from '../ui/button';
import { toast } from 'sonner@2.0.3';

export function TimeoutDetector() {
  const [timeoutCount, setTimeoutCount] = useState(0);
  const [showBanner, setShowBanner] = useState(false);

  useEffect(() => {
    // Interceptar console.warn para detectar timeouts
    const originalWarn = console.warn;
    
    console.warn = function(...args: any[]) {
      const message = args.join(' ');
      
      // Detectar mensajes de timeout
      if (message.includes('Timeout') || message.includes('timeout')) {
        setTimeoutCount(prev => {
          const newCount = prev + 1;
          
          // Mostrar banner después de 2 timeouts consecutivos
          if (newCount >= 2) {
            setShowBanner(true);
            
            // Mostrar toast con instrucciones
            toast.error('⚠️ Servidor en hibernación detectado', {
              description: 'Haz clic en el banner para despertar el servidor',
              duration: 10000
            });
          }
          
          return newCount;
        });
      }
      
      // Llamar al console.warn original
      originalWarn.apply(console, args);
    };

    // Cleanup
    return () => {
      console.warn = originalWarn;
    };
  }, []);

  // Reset contador después de 30 segundos sin timeouts
  useEffect(() => {
    if (timeoutCount > 0) {
      const timer = setTimeout(() => {
        setTimeoutCount(0);
        setShowBanner(false);
      }, 30000);
      
      return () => clearTimeout(timer);
    }
  }, [timeoutCount]);

  if (!showBanner) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-[9999] bg-gradient-to-r from-orange-600 via-red-600 to-pink-600 text-white shadow-2xl animate-in slide-in-from-bottom duration-300">
      <div className="max-w-5xl mx-auto px-4 py-4">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 flex-1">
            <AlertTriangle className="w-8 h-8 flex-shrink-0 animate-pulse" />
            <div className="flex-1">
              <p className="text-sm mb-1">
                <strong>⚠️ SERVIDOR EN HIBERNACIÓN DETECTADO</strong>
              </p>
              <p className="text-xs opacity-90">
                El servidor de Supabase está dormido. Necesitas despertarlo para continuar.
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Button
              onClick={() => {
                // Redirigir a Setup
                window.location.href = '/?setup=true';
              }}
              className="bg-white text-red-600 hover:bg-red-50 transition-colors h-10 px-6"
            >
              <Zap className="w-4 h-4 mr-2" />
              Despertar Servidor
            </Button>
            <button
              onClick={() => {
                setShowBanner(false);
                setTimeoutCount(0);
              }}
              className="p-2 hover:bg-white/20 rounded transition-colors"
              aria-label="Cerrar"
            >
              ✕
            </button>
          </div>
        </div>
        
        {/* Progress bar */}
        <div className="mt-3 bg-white/20 rounded-full h-1 overflow-hidden">
          <div 
            className="h-full bg-white transition-all duration-300"
            style={{ width: `${(timeoutCount / 3) * 100}%` }}
          />
        </div>
      </div>
    </div>
  );
}
