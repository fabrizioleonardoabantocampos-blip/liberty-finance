import { useState } from 'react';
import { AlertCircle, Terminal, Copy, ExternalLink, CheckCircle2 } from 'lucide-react';
import { Button } from '../ui/button';
import { toast } from 'sonner@2.0.3';

export function ServidorNoDeplegado() {
  const [copied, setCopied] = useState<string | null>(null);

  const comandos = [
    {
      id: 'install',
      titulo: '1. Instalar Supabase CLI',
      comando: 'npm install -g supabase',
      descripcion: 'Instala la herramienta de línea de comandos'
    },
    {
      id: 'login',
      titulo: '2. Login a Supabase',
      comando: 'supabase login',
      descripcion: 'Abrirá tu navegador para autorizar'
    },
    {
      id: 'link',
      titulo: '3. Ligar Proyecto',
      comando: 'supabase link --project-ref tfgjnkmstcjdhmzvznbu',
      descripcion: 'Conecta con tu proyecto de Supabase'
    },
    {
      id: 'deploy',
      titulo: '4. Desplegar Servidor',
      comando: 'supabase functions deploy server',
      descripcion: 'Sube el código del servidor (tarda 2-3 min)'
    }
  ];

  const comandoCompleto = comandos.map(c => c.comando).join(' && ');

  const copiar = (texto: string, id: string) => {
    navigator.clipboard.writeText(texto);
    setCopied(id);
    toast.success('Copiado al portapapeles');
    setTimeout(() => setCopied(null), 2000);
  };

  return (
    <div className="bg-gradient-to-br from-red-50 to-orange-50 border-2 border-red-300 rounded-xl p-6">
      <div className="flex items-start gap-4 mb-6">
        <div className="w-12 h-12 rounded-xl bg-red-600 flex items-center justify-center flex-shrink-0">
          <AlertCircle className="w-6 h-6 text-white" />
        </div>
        <div className="flex-1">
          <h3 className="text-xl text-red-900 mb-2">
            🚨 Servidor NO Desplegado
          </h3>
          <p className="text-sm text-red-800 mb-2">
            Tus credenciales están <strong>correctas</strong>, pero el Edge Function <code className="bg-red-100 px-1.5 py-0.5 rounded">server</code> no está desplegado en Supabase.
          </p>
          <p className="text-sm text-red-700">
            Por eso ves timeouts constantemente. Necesitas desplegarlo usando Supabase CLI.
          </p>
        </div>
      </div>

      {/* Instrucciones paso a paso */}
      <div className="space-y-4 mb-6">
        <p className="text-sm text-red-900 mb-3">
          <strong>Ejecuta estos 4 comandos en tu terminal:</strong>
        </p>

        {comandos.map((cmd, index) => (
          <div key={cmd.id} className="bg-white rounded-lg border border-red-200 p-4">
            <div className="flex items-start justify-between mb-2">
              <div className="flex-1">
                <p className="text-sm text-slate-800 mb-1">
                  <strong>{cmd.titulo}</strong>
                </p>
                <p className="text-xs text-slate-600 mb-3">
                  {cmd.descripcion}
                </p>
              </div>
              <div className="flex items-center gap-2 ml-4">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => copiar(cmd.comando, cmd.id)}
                  className="h-8 text-xs"
                >
                  {copied === cmd.id ? (
                    <>
                      <CheckCircle2 className="w-3 h-3 mr-1" />
                      Copiado
                    </>
                  ) : (
                    <>
                      <Copy className="w-3 h-3 mr-1" />
                      Copiar
                    </>
                  )}
                </Button>
              </div>
            </div>
            <div className="bg-slate-900 rounded-lg p-3 font-mono text-xs text-green-400 overflow-x-auto">
              <code>{cmd.comando}</code>
            </div>
          </div>
        ))}
      </div>

      {/* Script completo */}
      <div className="bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl p-4 mb-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1">
            <p className="text-white mb-1">
              <strong>⚡ Script Completo (Todo en uno)</strong>
            </p>
            <p className="text-xs text-blue-100">
              Copia y pega este comando para ejecutar todo de una vez:
            </p>
          </div>
          <Button
            size="sm"
            variant="secondary"
            onClick={() => copiar(comandoCompleto, 'completo')}
            className="ml-4"
          >
            {copied === 'completo' ? (
              <>
                <CheckCircle2 className="w-3 h-3 mr-1" />
                Copiado
              </>
            ) : (
              <>
                <Copy className="w-3 h-3 mr-1" />
                Copiar Todo
              </>
            )}
          </Button>
        </div>
        <div className="bg-slate-900 rounded-lg p-3 overflow-x-auto">
          <code className="font-mono text-xs text-green-400 block whitespace-pre">
            {comandoCompleto}
          </code>
        </div>
      </div>

      {/* Tiempo estimado */}
      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 mb-4">
        <p className="text-sm text-yellow-900 mb-1">
          <strong>⏱️ Tiempo Estimado:</strong>
        </p>
        <ul className="text-sm text-yellow-800 space-y-1 list-disc list-inside">
          <li>Instalar CLI: ~30 segundos</li>
          <li>Login: ~10 segundos (abre navegador)</li>
          <li>Ligar proyecto: ~5 segundos</li>
          <li>Desplegar: ~2-3 minutos (archivo grande)</li>
          <li><strong>Total: 3-5 minutos</strong></li>
        </ul>
      </div>

      {/* Después del deploy */}
      <div className="bg-green-50 border border-green-200 rounded-lg p-3 mb-4">
        <p className="text-sm text-green-900 mb-2">
          <strong>✅ Después del Deploy:</strong>
        </p>
        <ol className="text-sm text-green-800 space-y-1 list-decimal list-inside">
          <li>Recarga esta aplicación (F5)</li>
          <li>Ve a la sección <strong>"⚡ 2. Despertar Servidor"</strong></li>
          <li>Espera 60-90 segundos (cold start)</li>
          <li>Login con: <code className="bg-green-100 px-1 rounded">admin@libertyfinance.com</code> / <code className="bg-green-100 px-1 rounded">admin123</code></li>
        </ol>
      </div>

      {/* Enlaces útiles */}
      <div className="flex gap-3">
        <Button
          variant="outline"
          size="sm"
          onClick={() => window.open('https://supabase.com/docs/guides/cli', '_blank')}
          className="flex-1"
        >
          <Terminal className="w-4 h-4 mr-2" />
          Docs Supabase CLI
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={() => window.open('/DESPLEGAR_SERVIDOR.md', '_blank')}
          className="flex-1"
        >
          <ExternalLink className="w-4 h-4 mr-2" />
          Guía Detallada
        </Button>
      </div>

      {/* Nota importante */}
      <div className="mt-4 pt-4 border-t border-red-200">
        <p className="text-xs text-red-700">
          <strong>⚠️ Importante:</strong> No intentes copiar el código manualmente en el dashboard de Supabase. 
          El archivo tiene 11,360 líneas. <strong>DEBES usar Supabase CLI.</strong>
        </p>
      </div>
    </div>
  );
}
