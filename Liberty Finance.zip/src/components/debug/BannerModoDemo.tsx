import { AlertTriangle, Terminal, X } from 'lucide-react';
import { useState } from 'react';
import { isDemoMode } from '../../utils/demoMode';
import { Button } from '../ui/button';

export function BannerModoDemo() {
  const [cerrado, setCerrado] = useState(false);
  
  if (!isDemoMode() || cerrado) {
    return null;
  }

  return (
    <div className="fixed top-0 left-0 right-0 z-[9999] bg-gradient-to-r from-orange-600 via-red-600 to-pink-600 text-white shadow-2xl">
      <div className="max-w-7xl mx-auto px-4 py-3">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 flex-1">
            <AlertTriangle className="w-6 h-6 flex-shrink-0 animate-pulse" />
            <div className="flex-1">
              <p className="text-sm">
                <strong>MODO DEMOSTRACIÓN ACTIVADO</strong> - Esta es una versión temporal con datos simulados.
              </p>
              <p className="text-xs opacity-90 mt-0.5">
                Para usar la aplicación REAL, debes desplegar el servidor en Supabase (5 minutos).
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Button
              size="sm"
              variant="secondary"
              onClick={() => {
                // Abrir README con instrucciones
                window.open('/README.md', '_blank');
              }}
              className="text-xs whitespace-nowrap"
            >
              <Terminal className="w-3 h-3 mr-1" />
              Ver Instrucciones
            </Button>
            <button
              onClick={() => setCerrado(true)}
              className="p-1 hover:bg-white/20 rounded transition-colors"
              aria-label="Cerrar"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
