import { useState } from 'react';
import { Button } from '../ui/button';
import { AlertTriangle, CheckCircle2, XCircle, ExternalLink, Terminal, Copy } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { projectId, publicAnonKey } from '../../utils/supabase/info';

interface DiagnosticoResult {
  paso: string;
  estado: 'success' | 'error' | 'pending';
  mensaje: string;
  detalles?: string;
}

export function DiagnosticoFinal() {
  const [diagnosticando, setDiagnosticando] = useState(false);
  const [resultados, setResultados] = useState<DiagnosticoResult[]>([]);
  const [mostrarSolucion, setMostrarSolucion] = useState(false);

  const ejecutarDiagnostico = async () => {
    setDiagnosticando(true);
    setResultados([]);
    setMostrarSolucion(false);

    const tests: DiagnosticoResult[] = [];

    // Test 1: Verificar credenciales
    tests.push({
      paso: '1. Verificar Credenciales',
      estado: 'pending',
      mensaje: 'Verificando...'
    });
    setResultados([...tests]);

    await new Promise(resolve => setTimeout(resolve, 500));

    if (!projectId || projectId === 'YOUR_PROJECT_ID') {
      tests[0] = {
        paso: '1. Verificar Credenciales',
        estado: 'error',
        mensaje: 'projectId no configurado',
        detalles: 'Abre /utils/supabase/info.tsx y configura el projectId'
      };
      setResultados([...tests]);
      setDiagnosticando(false);
      setMostrarSolucion(true);
      return;
    }

    if (projectId.includes('http') || projectId.includes('.supabase.co')) {
      tests[0] = {
        paso: '1. Verificar Credenciales',
        estado: 'error',
        mensaje: 'projectId tiene formato incorrecto',
        detalles: 'Debe ser solo el ID, sin "https://" ni ".supabase.co"'
      };
      setResultados([...tests]);
      setDiagnosticando(false);
      setMostrarSolucion(true);
      return;
    }

    if (!publicAnonKey || !publicAnonKey.startsWith('eyJ')) {
      tests[0] = {
        paso: '1. Verificar Credenciales',
        estado: 'error',
        mensaje: 'publicAnonKey inválida',
        detalles: 'Debe ser un JWT que empiece con "eyJ"'
      };
      setResultados([...tests]);
      setDiagnosticando(false);
      setMostrarSolucion(true);
      return;
    }

    tests[0] = {
      paso: '1. Verificar Credenciales',
      estado: 'success',
      mensaje: '✅ Credenciales correctas',
      detalles: `Project ID: ${projectId}`
    };
    setResultados([...tests]);

    // Test 2: Ping endpoint
    tests.push({
      paso: '2. Probar Conexión (/ping)',
      estado: 'pending',
      mensaje: 'Conectando...'
    });
    setResultados([...tests]);

    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 10000);

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-9f68532a/ping`,
        {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`
          },
          signal: controller.signal
        }
      );

      clearTimeout(timeout);

      if (response.ok) {
        const text = await response.text();
        tests[1] = {
          paso: '2. Probar Conexión (/ping)',
          estado: 'success',
          mensaje: '✅ Servidor responde correctamente',
          detalles: `Respuesta: "${text}"`
        };
      } else {
        tests[1] = {
          paso: '2. Probar Conexión (/ping)',
          estado: 'error',
          mensaje: `❌ Error HTTP ${response.status}`,
          detalles: response.status === 404 
            ? 'El Edge Function NO existe en Supabase'
            : response.status === 401
            ? 'Anon key incorrecta'
            : response.statusText
        };
      }
    } catch (error: any) {
      if (error.name === 'AbortError') {
        tests[1] = {
          paso: '2. Probar Conexión (/ping)',
          estado: 'error',
          mensaje: '❌ Timeout después de 10 segundos',
          detalles: 'El servidor NO está respondiendo. Probablemente NO está desplegado.'
        };
      } else {
        tests[1] = {
          paso: '2. Probar Conexión (/ping)',
          estado: 'error',
          mensaje: '❌ Error de red',
          detalles: error.message
        };
      }
    }

    setResultados([...tests]);

    // Si el ping falló, ya sabemos que no está desplegado
    if (tests[1].estado === 'error') {
      setDiagnosticando(false);
      setMostrarSolucion(true);
      return;
    }

    // Test 3: Health endpoint
    tests.push({
      paso: '3. Verificar Health Check',
      estado: 'pending',
      mensaje: 'Verificando...'
    });
    setResultados([...tests]);

    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 10000);

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-9f68532a/health`,
        {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`
          },
          signal: controller.signal
        }
      );

      clearTimeout(timeout);

      if (response.ok) {
        const data = await response.json();
        tests[2] = {
          paso: '3. Verificar Health Check',
          estado: 'success',
          mensaje: '✅ Servidor saludable',
          detalles: `Uptime: ${data.uptime}s`
        };
      } else {
        tests[2] = {
          paso: '3. Verificar Health Check',
          estado: 'error',
          mensaje: `❌ Error HTTP ${response.status}`,
          detalles: response.statusText
        };
      }
    } catch (error: any) {
      tests[2] = {
        paso: '3. Verificar Health Check',
        estado: 'error',
        mensaje: '❌ Error en health check',
        detalles: error.message
      };
    }

    setResultados([...tests]);
    setDiagnosticando(false);

    // Si todos pasaron, no hay problema
    if (tests.every(t => t.estado === 'success')) {
      toast.success('✅ Todo funciona correctamente', {
        description: 'El servidor está operativo'
      });
    } else {
      setMostrarSolucion(true);
      toast.error('❌ Se encontraron problemas', {
        description: 'Revisa los resultados abajo'
      });
    }
  };

  const copiarComando = () => {
    const comando = 'npm install -g supabase && supabase login && supabase link --project-ref tfgjnkmstcjdhmzvznbu && supabase functions deploy server';
    navigator.clipboard.writeText(comando);
    toast.success('Comando copiado', {
      description: 'Pégalo en tu terminal y presiona Enter'
    });
  };

  return (
    <div className="space-y-4">
      <div className="bg-blue-50 border-2 border-blue-200 rounded-xl p-4">
        <p className="text-sm text-blue-800 mb-2">
          <strong>🔍 Diagnóstico Final</strong>
        </p>
        <p className="text-sm text-blue-700">
          Este test verificará si el servidor está desplegado y funcionando correctamente.
        </p>
      </div>

      <Button
        onClick={ejecutarDiagnostico}
        disabled={diagnosticando}
        className="w-full"
        size="lg"
      >
        {diagnosticando ? 'Diagnosticando...' : 'Ejecutar Diagnóstico Completo'}
      </Button>

      {/* Resultados */}
      {resultados.length > 0 && (
        <div className="space-y-3">
          {resultados.map((resultado, index) => (
            <div
              key={index}
              className={`p-4 rounded-lg border-2 ${
                resultado.estado === 'success'
                  ? 'bg-green-50 border-green-200'
                  : resultado.estado === 'error'
                  ? 'bg-red-50 border-red-200'
                  : 'bg-gray-50 border-gray-200'
              }`}
            >
              <div className="flex items-start gap-3">
                {resultado.estado === 'success' && (
                  <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                )}
                {resultado.estado === 'error' && (
                  <XCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                )}
                {resultado.estado === 'pending' && (
                  <div className="w-5 h-5 border-2 border-gray-400 border-t-transparent rounded-full animate-spin flex-shrink-0 mt-0.5" />
                )}
                <div className="flex-1">
                  <p className={`text-sm mb-1 ${
                    resultado.estado === 'success' ? 'text-green-900' :
                    resultado.estado === 'error' ? 'text-red-900' : 'text-gray-900'
                  }`}>
                    <strong>{resultado.paso}</strong>
                  </p>
                  <p className={`text-sm ${
                    resultado.estado === 'success' ? 'text-green-800' :
                    resultado.estado === 'error' ? 'text-red-800' : 'text-gray-800'
                  }`}>
                    {resultado.mensaje}
                  </p>
                  {resultado.detalles && (
                    <p className={`text-xs mt-1 ${
                      resultado.estado === 'success' ? 'text-green-700' :
                      resultado.estado === 'error' ? 'text-red-700' : 'text-gray-700'
                    }`}>
                      {resultado.detalles}
                    </p>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Solución */}
      {mostrarSolucion && (
        <div className="bg-gradient-to-br from-red-500 to-orange-600 text-white rounded-xl p-6 shadow-lg">
          <div className="flex items-start gap-4 mb-4">
            <AlertTriangle className="w-8 h-8 flex-shrink-0" />
            <div>
              <h3 className="text-xl mb-2">🚨 Servidor NO Desplegado</h3>
              <p className="text-sm text-red-50 mb-4">
                El Edge Function <code className="bg-red-700 px-1.5 py-0.5 rounded">server</code> NO existe en Supabase.
                Debes desplegarlo usando Supabase CLI.
              </p>
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 mb-4">
            <p className="text-sm mb-2">
              <strong>✅ SOLUCIÓN (4 pasos, 5 minutos):</strong>
            </p>
            <ol className="text-sm space-y-1 list-decimal list-inside mb-3">
              <li>Abre una terminal en tu computadora</li>
              <li>Copia el comando de abajo</li>
              <li>Pégalo en la terminal y presiona Enter</li>
              <li>Espera 2-3 minutos a que complete</li>
            </ol>
          </div>

          <div className="bg-slate-900 rounded-lg p-4 mb-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-slate-400">Copia y pega este comando:</span>
              <Button
                size="sm"
                variant="secondary"
                onClick={copiarComando}
              >
                <Copy className="w-3 h-3 mr-1" />
                Copiar
              </Button>
            </div>
            <code className="text-xs text-green-400 block break-all">
              npm install -g supabase && supabase login && supabase link --project-ref tfgjnkmstcjdhmzvznbu && supabase functions deploy server
            </code>
          </div>

          <div className="flex gap-3">
            <Button
              variant="secondary"
              size="sm"
              onClick={() => window.open('https://supabase.com/docs/guides/cli/getting-started', '_blank')}
              className="flex-1"
            >
              <Terminal className="w-4 h-4 mr-2" />
              Guía CLI
            </Button>
            <Button
              variant="secondary"
              size="sm"
              onClick={() => window.open('/DESPLEGAR_SERVIDOR.md', '_blank')}
              className="flex-1"
            >
              <ExternalLink className="w-4 h-4 mr-2" />
              Instrucciones Detalladas
            </Button>
          </div>

          <div className="mt-4 pt-4 border-t border-white/20">
            <p className="text-xs text-red-100">
              <strong>⚠️ Nota:</strong> No puedo desplegar el servidor automáticamente porque requiere
              acceso a tu cuenta de Supabase. Debes ejecutar los comandos manualmente.
            </p>
          </div>
        </div>
      )}

      {/* Ayuda adicional */}
      <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
        <p className="text-sm text-purple-900 mb-2">
          <strong>💡 ¿No tienes acceso a terminal?</strong>
        </p>
        <p className="text-sm text-purple-800 mb-3">
          Si no puedes ejecutar comandos en terminal, necesitas contactar a alguien con acceso
          al proyecto de Supabase para que despliegue el servidor.
        </p>
        <Button
          variant="outline"
          size="sm"
          onClick={() => window.open('https://supabase.com/dashboard/project/tfgjnkmstcjdhmzvznbu/functions', '_blank')}
          className="text-purple-700 border-purple-300 hover:bg-purple-100"
        >
          <ExternalLink className="w-4 h-4 mr-2" />
          Abrir Supabase Dashboard
        </Button>
      </div>
    </div>
  );
}
