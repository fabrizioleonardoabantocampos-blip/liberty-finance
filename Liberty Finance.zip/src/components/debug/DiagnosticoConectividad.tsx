import { useState } from 'react';
import { Button } from '../ui/button';
import { toast } from 'sonner@2.0.3';
import { Activity, Loader2, CheckCircle2, XCircle, AlertCircle } from 'lucide-react';
import { projectId, publicAnonKey } from '../../utils/supabase/info';

interface DiagnosticoResult {
  test: string;
  status: 'ok' | 'error' | 'slow' | 'timeout';
  time: number;
  message: string;
}

export function DiagnosticoConectividad() {
  const [loading, setLoading] = useState(false);
  const [resultados, setResultados] = useState<DiagnosticoResult[]>([]);

  const runDiagnostico = async () => {
    setLoading(true);
    setResultados([]);
    const tests: DiagnosticoResult[] = [];

    try {
      // Test 1: Ping simple (sin timeout)
      console.log('🔍 Test 1: Ping básico...');
      const pingStart = Date.now();
      try {
        const pingResponse = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-9f68532a/ping`,
          {
            method: 'GET',
            headers: { 'Authorization': `Bearer ${publicAnonKey}` }
          }
        );
        const pingTime = Date.now() - pingStart;
        
        if (pingResponse.ok) {
          tests.push({
            test: 'Ping básico',
            status: pingTime < 1000 ? 'ok' : 'slow',
            time: pingTime,
            message: pingTime < 1000 ? 'Servidor responde rápido' : 'Servidor lento'
          });
        } else {
          tests.push({
            test: 'Ping básico',
            status: 'error',
            time: pingTime,
            message: `Error HTTP ${pingResponse.status}`
          });
        }
      } catch (error) {
        tests.push({
          test: 'Ping básico',
          status: 'error',
          time: 0,
          message: error instanceof Error ? error.message : 'Error desconocido'
        });
      }

      // Test 2: Health check (sin acceso a DB)
      console.log('🔍 Test 2: Health check...');
      const healthStart = Date.now();
      try {
        const healthResponse = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-9f68532a/health`,
          {
            method: 'GET',
            headers: { 'Authorization': `Bearer ${publicAnonKey}` }
          }
        );
        const healthTime = Date.now() - healthStart;
        
        if (healthResponse.ok) {
          const data = await healthResponse.json();
          tests.push({
            test: 'Health check',
            status: healthTime < 2000 ? 'ok' : 'slow',
            time: healthTime,
            message: `Servidor activo (uptime: ${data.uptime}s)`
          });
        } else {
          tests.push({
            test: 'Health check',
            status: 'error',
            time: healthTime,
            message: `Error HTTP ${healthResponse.status}`
          });
        }
      } catch (error) {
        tests.push({
          test: 'Health check',
          status: 'error',
          time: 0,
          message: error instanceof Error ? error.message : 'Error desconocido'
        });
      }

      // Test 3: Login endpoint (con acceso a DB)
      console.log('🔍 Test 3: Login endpoint...');
      const loginStart = Date.now();
      try {
        const loginController = new AbortController();
        const loginTimeout = setTimeout(() => loginController.abort(), 15000); // 15 segundos
        
        const loginResponse = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-9f68532a/auth/login`,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${publicAnonKey}`
            },
            body: JSON.stringify({ email: 'admin@libertyfinance.com', password: 'admin123' }),
            signal: loginController.signal
          }
        );
        
        clearTimeout(loginTimeout);
        const loginTime = Date.now() - loginStart;
        
        if (loginResponse.ok || loginResponse.status === 401) {
          tests.push({
            test: 'Login endpoint (DB)',
            status: loginTime < 5000 ? 'ok' : 'slow',
            time: loginTime,
            message: loginTime < 5000 ? 'Base de datos responde bien' : 'Base de datos lenta'
          });
        } else {
          tests.push({
            test: 'Login endpoint (DB)',
            status: 'error',
            time: loginTime,
            message: `Error HTTP ${loginResponse.status}`
          });
        }
      } catch (error) {
        const loginTime = Date.now() - loginStart;
        if (error instanceof Error && error.name === 'AbortError') {
          tests.push({
            test: 'Login endpoint (DB)',
            status: 'timeout',
            time: loginTime,
            message: 'Timeout después de 15 segundos'
          });
        } else {
          tests.push({
            test: 'Login endpoint (DB)',
            status: 'error',
            time: loginTime,
            message: error instanceof Error ? error.message : 'Error desconocido'
          });
        }
      }

      setResultados(tests);

      // Mostrar resumen
      const todosOk = tests.every(t => t.status === 'ok');
      const hayTimeout = tests.some(t => t.status === 'timeout');
      const hayError = tests.some(t => t.status === 'error');

      if (todosOk) {
        toast.success('✅ Todos los tests pasaron', {
          description: 'La conexión con el servidor está funcionando correctamente'
        });
      } else if (hayTimeout) {
        toast.error('⏱️ Timeouts detectados', {
          description: 'El servidor no responde a tiempo. Puede estar sobrecargado o en cold start.'
        });
      } else if (hayError) {
        toast.error('❌ Errores detectados', {
          description: 'Hay problemas de conectividad o configuración'
        });
      } else {
        toast.warning('⚠️ Tests completados con advertencias', {
          description: 'El servidor responde pero está lento'
        });
      }

    } catch (error) {
      console.error('❌ Error en diagnóstico:', error);
      toast.error('Error al ejecutar diagnóstico', {
        description: error instanceof Error ? error.message : 'Error desconocido'
      });
    } finally {
      setLoading(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'ok':
        return <CheckCircle2 className="w-5 h-5 text-green-600" />;
      case 'slow':
        return <AlertCircle className="w-5 h-5 text-yellow-600" />;
      case 'timeout':
      case 'error':
        return <XCircle className="w-5 h-5 text-red-600" />;
      default:
        return <Activity className="w-5 h-5 text-gray-600" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'ok':
        return 'bg-green-50 border-green-200';
      case 'slow':
        return 'bg-yellow-50 border-yellow-200';
      case 'timeout':
      case 'error':
        return 'bg-red-50 border-red-200';
      default:
        return 'bg-gray-50 border-gray-200';
    }
  };

  return (
    <div className="space-y-4">
      <div className="bg-blue-50 border-2 border-blue-200 rounded-xl p-4">
        <p className="text-sm text-blue-800 mb-2">
          <strong>🔍 Diagnóstico de Conectividad</strong>
        </p>
        <p className="text-sm text-blue-700">
          Verifica la comunicación con el servidor de Supabase Edge Functions
        </p>
      </div>

      <Button
        onClick={runDiagnostico}
        disabled={loading}
        className="w-full"
        variant="outline"
      >
        {loading ? (
          <>
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            Ejecutando diagnóstico...
          </>
        ) : (
          <>
            <Activity className="w-4 h-4 mr-2" />
            Ejecutar Diagnóstico
          </>
        )}
      </Button>

      {resultados.length > 0 && (
        <div className="space-y-3 mt-4">
          <h3 className="text-sm font-semibold text-slate-800">Resultados:</h3>
          {resultados.map((resultado, index) => (
            <div
              key={index}
              className={`p-4 rounded-xl border-2 ${getStatusColor(resultado.status)}`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3 flex-1">
                  {getStatusIcon(resultado.status)}
                  <div className="flex-1">
                    <p className="text-sm font-medium text-slate-800 mb-1">
                      {resultado.test}
                    </p>
                    <p className="text-xs text-slate-600 mb-1">
                      {resultado.message}
                    </p>
                    <p className="text-xs text-slate-500">
                      Tiempo: {resultado.time}ms
                    </p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {resultados.some(r => r.status === 'timeout' || r.status === 'error') && (
        <div className="bg-orange-50 border-2 border-orange-200 rounded-xl p-4 mt-4">
          <p className="text-sm text-orange-800 mb-2">
            <strong>💡 Recomendaciones:</strong>
          </p>
          <ul className="text-sm text-orange-700 space-y-1 list-disc list-inside">
            {resultados.some(r => r.status === 'timeout') && (
              <>
                <li>El servidor puede estar en "cold start" (primera carga)</li>
                <li>Espera 30-60 segundos e intenta de nuevo</li>
                <li>Si persiste, verifica las credenciales de Supabase</li>
              </>
            )}
            {resultados.some(r => r.status === 'error') && (
              <>
                <li>Verifica que el proyecto de Supabase esté activo</li>
                <li>Confirma que las credenciales sean correctas</li>
                <li>Revisa los logs del servidor en Supabase Dashboard</li>
              </>
            )}
          </ul>
        </div>
      )}
    </div>
  );
}
