import { useState, useEffect } from 'react';
import { AlertTriangle, Zap, ExternalLink, X } from 'lucide-react';
import { Button } from '../ui/button';

interface TimeoutModalProps {
  show: boolean;
  onClose: () => void;
  onDespertar: () => void;
}

export function TimeoutModal({ show, onClose, onDespertar }: TimeoutModalProps) {
  if (!show) return null;

  return (
    <div className="fixed inset-0 z-[10000] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-auto">
        {/* Header */}
        <div className="bg-gradient-to-r from-orange-500 to-red-600 p-6 text-white relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 hover:bg-white/20 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          
          <div className="flex items-start gap-4">
            <div className="w-14 h-14 rounded-xl bg-white/20 flex items-center justify-center flex-shrink-0">
              <AlertTriangle className="w-8 h-8 animate-pulse" />
            </div>
            <div>
              <h2 className="text-2xl mb-2">
                ⚠️ Servidor en Hibernación
              </h2>
              <p className="text-white/90 text-sm">
                El servidor de Supabase está dormido por inactividad
              </p>
            </div>
          </div>
        </div>

        {/* Body */}
        <div className="p-6 space-y-6">
          {/* Explicación */}
          <div className="bg-blue-50 border-2 border-blue-200 rounded-xl p-4">
            <h3 className="text-lg text-blue-900 mb-2">
              📋 ¿Qué está pasando?
            </h3>
            <p className="text-sm text-blue-800 mb-3">
              Supabase pone los Edge Functions en "hibernación" después de períodos de inactividad 
              para ahorrar recursos. Esto es <strong>completamente normal</strong>.
            </p>
            <ul className="text-sm text-blue-700 space-y-1 list-disc list-inside">
              <li>El servidor <strong>SÍ está desplegado</strong> ✅</li>
              <li>Solo necesita ser "despertado" con una petición inicial</li>
              <li>Una vez despierto, responderá rápidamente</li>
            </ul>
          </div>

          {/* Solución rápida */}
          <div className="bg-gradient-to-br from-green-50 to-emerald-50 border-2 border-green-300 rounded-xl p-5">
            <h3 className="text-lg text-green-900 mb-3">
              ⚡ Solución Rápida (2 minutos)
            </h3>
            
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-green-500 text-white flex items-center justify-center flex-shrink-0 text-sm">
                  1
                </div>
                <div className="flex-1">
                  <p className="text-sm text-green-900 mb-1">
                    <strong>Haz clic en "Despertar Servidor"</strong>
                  </p>
                  <p className="text-xs text-green-700">
                    Esto enviará una petición inicial para activar el servidor
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-green-500 text-white flex items-center justify-center flex-shrink-0 text-sm">
                  2
                </div>
                <div className="flex-1">
                  <p className="text-sm text-green-900 mb-1">
                    <strong>Espera 30-90 segundos</strong>
                  </p>
                  <p className="text-xs text-green-700">
                    El cold start puede tardar un poco la primera vez
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-green-500 text-white flex items-center justify-center flex-shrink-0 text-sm">
                  3
                </div>
                <div className="flex-1">
                  <p className="text-sm text-green-900 mb-1">
                    <strong>¡Listo! Vuelve a intentar</strong>
                  </p>
                  <p className="text-xs text-green-700">
                    El servidor responderá rápidamente ahora
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-4 pt-4 border-t border-green-200">
              <Button
                onClick={onDespertar}
                className="w-full h-12 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700"
              >
                <Zap className="w-5 h-5 mr-2" />
                ⚡ Despertar Servidor Ahora
              </Button>
            </div>
          </div>

          {/* Información adicional */}
          <details className="bg-slate-50 border border-slate-200 rounded-lg overflow-hidden">
            <summary className="p-3 cursor-pointer hover:bg-slate-100 transition-colors text-sm text-slate-700">
              ℹ️ Más información técnica
            </summary>
            <div className="p-4 border-t border-slate-200 text-xs text-slate-600 space-y-2">
              <p>
                <strong>¿Por qué pasa esto?</strong><br />
                Supabase optimiza costos poniendo los Edge Functions inactivos en "sleep mode" 
                después de 5-10 minutos sin uso.
              </p>
              <p>
                <strong>¿Es un problema?</strong><br />
                No. Es el comportamiento esperado del plan gratuito de Supabase. 
                En producción con tráfico constante, esto no ocurre.
              </p>
              <p>
                <strong>¿Cómo evitarlo?</strong><br />
                Puedes configurar un "ping" automático cada 5 minutos, o usar el plan Pro de Supabase 
                que tiene menos restricciones de cold start.
              </p>
            </div>
          </details>

          {/* Botón para ir a Setup */}
          <div className="pt-4 border-t border-slate-200 flex gap-3">
            <Button
              variant="outline"
              onClick={onClose}
              className="flex-1"
            >
              Cerrar
            </Button>
            <Button
              onClick={() => {
                onClose();
                // Navegar a /Setup
                window.location.hash = 'setup';
              }}
              variant="secondary"
              className="flex-1"
            >
              <ExternalLink className="w-4 h-4 mr-2" />
              Ir a Herramientas de Setup
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

/**
 * Hook para detectar timeouts automáticamente
 */
export function useTimeoutDetector() {
  const [showModal, setShowModal] = useState(false);
  const [timeoutCount, setTimeoutCount] = useState(0);

  useEffect(() => {
    // Escuchar errores de timeout en la consola
    const originalConsoleWarn = console.warn;
    
    console.warn = function(...args) {
      const message = args.join(' ');
      
      // Detectar mensajes de timeout
      if (message.includes('Timeout') || message.includes('timeout')) {
        setTimeoutCount(prev => {
          const newCount = prev + 1;
          
          // Mostrar modal después de 2 timeouts
          if (newCount >= 2) {
            setShowModal(true);
          }
          
          return newCount;
        });
      }
      
      originalConsoleWarn.apply(console, args);
    };

    return () => {
      console.warn = originalConsoleWarn;
    };
  }, []);

  const resetTimeoutCount = () => {
    setTimeoutCount(0);
    setShowModal(false);
  };

  return {
    showModal,
    setShowModal,
    timeoutCount,
    resetTimeoutCount
  };
}
