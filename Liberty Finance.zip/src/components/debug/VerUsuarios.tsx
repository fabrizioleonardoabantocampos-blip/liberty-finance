import { useState } from 'react';
import { Button } from '../ui/button';
import { Eye, EyeOff } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { callServer } from '../../utils/api';

export function VerUsuarios() {
  const [usuarios, setUsuarios] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [mostrar, setMostrar] = useState(false);

  const cargarUsuarios = async () => {
    setLoading(true);
    try {
      const response = await callServer('/usuarios', 'GET');
      if (response.usuarios) {
        setUsuarios(response.usuarios);
        setMostrar(true);
        toast.success(`${response.usuarios.length} usuarios cargados`);
      }
    } catch (error) {
      console.error('Error al cargar usuarios:', error);
      toast.error('Error al cargar usuarios');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mt-4 space-y-2">
      <Button
        type="button"
        onClick={() => {
          if (mostrar) {
            setMostrar(false);
          } else {
            cargarUsuarios();
          }
        }}
        variant="outline"
        size="sm"
        className="w-full"
        disabled={loading}
      >
        {mostrar ? <EyeOff className="w-4 h-4 mr-2" /> : <Eye className="w-4 h-4 mr-2" />}
        {loading ? 'Cargando...' : mostrar ? 'Ocultar Usuarios' : 'Ver Usuarios Registrados'}
      </Button>

      {mostrar && usuarios.length > 0 && (
        <div className="max-h-64 overflow-y-auto bg-slate-900/50 rounded-lg p-3 space-y-2">
          {usuarios.map((usuario) => (
            <div
              key={usuario.id}
              className="bg-slate-800/50 rounded-lg p-3 text-xs"
            >
              <div className="flex items-start justify-between">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-white font-medium">
                      {usuario.nombre} {usuario.apellido}
                    </span>
                    {usuario.activo === false && (
                      <span className="text-red-400 text-[10px] bg-red-500/20 px-2 py-0.5 rounded">
                        INACTIVO
                      </span>
                    )}
                    {usuario.activo === true && (
                      <span className="text-green-400 text-[10px] bg-green-500/20 px-2 py-0.5 rounded">
                        ACTIVO
                      </span>
                    )}
                  </div>
                  <div className="text-blue-300">
                    📧 {usuario.email}
                  </div>
                  <div className="text-slate-400">
                    🔑 Password: {usuario.password}
                  </div>
                  <div className="text-slate-400">
                    🆔 {usuario.id_unico}
                  </div>
                  <div className="text-slate-400">
                    📱 {usuario.telefono || 'Sin teléfono'}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {mostrar && usuarios.length === 0 && (
        <div className="text-center text-slate-400 text-sm py-4">
          No hay usuarios registrados
        </div>
      )}
    </div>
  );
}
