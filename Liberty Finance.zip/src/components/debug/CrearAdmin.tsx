import { useState } from 'react';
import { Button } from '../ui/button';
import { toast } from 'sonner@2.0.3';
import { UserPlus, Loader2 } from 'lucide-react';
import { projectId, publicAnonKey } from '../../utils/supabase/info';

export function CrearAdmin() {
  const [loading, setLoading] = useState(false);

  const crearAdmin = async () => {
    setLoading(true);

    try {
      console.log('🔧 Creando usuario admin...');
      
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-9f68532a/debug/create-admin`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`
          }
        }
      );

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Error: ${errorText}`);
      }

      const data = await response.json();
      console.log('✅ Admin creado/verificado:', data);
      
      if (data.success) {
        toast.success('Usuario admin listo', {
          description: 'Ahora puedes iniciar sesión con admin@libertyfinance.com / admin123'
        });
      } else {
        toast.error('Error al crear admin', {
          description: data.error || 'Error desconocido'
        });
      }

    } catch (error) {
      console.error('❌ Error:', error);
      toast.error('Error al crear admin', {
        description: error instanceof Error ? error.message : 'Error desconocido'
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Button
      onClick={crearAdmin}
      disabled={loading}
      variant="outline"
      size="sm"
      className="mt-4"
    >
      {loading ? (
        <>
          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          Creando...
        </>
      ) : (
        <>
          <UserPlus className="w-4 h-4 mr-2" />
          Crear Usuario Admin
        </>
      )}
    </Button>
  );
}
