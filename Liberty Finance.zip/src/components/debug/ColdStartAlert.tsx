import { useState, useEffect } from 'react';
import { X, Zap, Clock } from 'lucide-react';
import { Button } from '../ui/button';

interface ColdStartAlertProps {
  onDismiss?: () => void;
  onWakeServer?: () => void;
}

export function ColdStartAlert({ onDismiss, onWakeServer }: ColdStartAlertProps) {
  const [show, setShow] = useState(false);
  const [countdown, setCountdown] = useState(60);

  useEffect(() => {
    // Mostrar alerta después de 2 segundos si sigue cargando
    const showTimer = setTimeout(() => {
      setShow(true);
    }, 2000);

    return () => clearTimeout(showTimer);
  }, []);

  useEffect(() => {
    if (!show) return;

    // Countdown de 60 a 0
    const interval = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) {
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [show]);

  const handleDismiss = () => {
    setShow(false);
    onDismiss?.();
  };

  const handleWakeServer = () => {
    setShow(false);
    onWakeServer?.();
  };

  if (!show) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-500 to-purple-600 p-6 text-white relative">
          <button
            onClick={handleDismiss}
            className="absolute top-4 right-4 text-white/80 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          
          <div className="flex items-center gap-3 mb-2">
            <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center">
              <Zap className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl">Cold Start Detectado</h2>
              <p className="text-blue-100 text-sm">El servidor está despertando...</p>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4">
          {/* Countdown */}
          <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl p-4 border-2 border-blue-200">
            <div className="flex items-center gap-3">
              <Clock className="w-8 h-8 text-blue-600" />
              <div className="flex-1">
                <p className="text-sm text-blue-800 mb-1">
                  <strong>Tiempo estimado restante:</strong>
                </p>
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl text-blue-600">
                    {countdown}
                  </span>
                  <span className="text-blue-600">segundos</span>
                </div>
              </div>
            </div>
            
            {/* Progress bar */}
            <div className="mt-3 h-2 bg-blue-200 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-blue-500 to-purple-600 transition-all duration-1000"
                style={{ width: `${((60 - countdown) / 60) * 100}%` }}
              />
            </div>
          </div>

          {/* Info */}
          <div className="space-y-3">
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                <span className="text-xs text-blue-600">1</span>
              </div>
              <div>
                <p className="text-sm text-slate-800 mb-1">
                  <strong>¿Qué está pasando?</strong>
                </p>
                <p className="text-sm text-slate-600">
                  El servidor estaba "dormido" (cold start) y está despertando. Esto es normal en el plan gratuito de Supabase.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="w-6 h-6 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                <span className="text-xs text-blue-600">2</span>
              </div>
              <div>
                <p className="text-sm text-slate-800 mb-1">
                  <strong>¿Cuánto tarda?</strong>
                </p>
                <p className="text-sm text-slate-600">
                  Primera vez del día: 30-90 segundos. Después: 2-5 segundos.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="w-6 h-6 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                <span className="text-xs text-blue-600">3</span>
              </div>
              <div>
                <p className="text-sm text-slate-800 mb-1">
                  <strong>¿Qué puedo hacer?</strong>
                </p>
                <p className="text-sm text-slate-600">
                  Espera unos segundos o ve a la página Setup para más opciones.
                </p>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-3 pt-2">
            <Button
              onClick={handleDismiss}
              variant="outline"
              className="flex-1"
            >
              Esperar Aquí
            </Button>
            {onWakeServer && (
              <Button
                onClick={handleWakeServer}
                className="flex-1 bg-gradient-to-r from-blue-500 to-purple-600"
              >
                <Zap className="w-4 h-4 mr-2" />
                Ir a Setup
              </Button>
            )}
          </div>

          {/* Footer tip */}
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 text-xs text-yellow-800">
            <strong>💡 Consejo:</strong> Para evitar esto, puedes usar UptimeRobot (gratis) para hacer ping cada 5 minutos.
          </div>
        </div>
      </div>
    </div>
  );
}
