import { useState, useEffect } from 'react';
import { AlertTriangle, Zap, Loader2, CheckCircle2, X, Coffee } from 'lucide-react';
import { Button } from '../ui/button';
import { toast } from 'sonner@2.0.3';
import { projectId, publicAnonKey } from '../../utils/supabase/info';

export function DespertarBanner() {
  const [mostrar, setMostrar] = useState(false);
  const [despertando, setDespertando] = useState(false);
  const [exito, setExito] = useState(false);
  const [tiempoRespuesta, setTiempoRespuesta] = useState(0);

  useEffect(() => {
    // Detectar timeouts automáticamente
    const originalWarn = console.warn;
    
    console.warn = function(...args: any[]) {
      const message = args.join(' ');
      
      if (message.includes('Timeout') || message.includes('timeout')) {
        // Mostrar banner después del primer timeout
        setTimeout(() => {
          setMostrar(true);
        }, 1000);
      }
      
      originalWarn.apply(console, args);
    };

    return () => {
      console.warn = originalWarn;
    };
  }, []);

  const despertar = async () => {
    setDespertando(true);
    setExito(false);

    try {
      console.log('⚡ Intentando despertar el servidor...');
      
      const startTime = Date.now();

      // Hacer ping con timeout de 2 minutos
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 120000);

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-9f68532a/ping`,
        {
          method: 'GET',
          headers: { 'Authorization': `Bearer ${publicAnonKey}` },
          signal: controller.signal
        }
      );

      clearTimeout(timeoutId);
      const tiempo = Date.now() - startTime;
      setTiempoRespuesta(tiempo);

      if (response.ok) {
        setExito(true);
        console.log(`✅ Servidor despierto en ${tiempo}ms`);
        
        toast.success('✅ Servidor despertado', {
          description: `Respondió en ${(tiempo / 1000).toFixed(1)} segundos. Ahora puedes continuar.`,
          duration: 5000
        });

        // Ocultar banner después de 5 segundos
        setTimeout(() => {
          setMostrar(false);
        }, 5000);
      } else {
        toast.error('Error al despertar servidor', {
          description: `HTTP ${response.status}`
        });
      }
    } catch (error) {
      console.error('❌ Error:', error);
      
      if ((error as Error).name === 'AbortError') {
        toast.error('Timeout al despertar servidor', {
          description: 'El servidor tardó más de 2 minutos. Intenta más tarde.',
          duration: 8000
        });
      } else {
        toast.error('Error de conexión', {
          description: 'Verifica tu conexión a internet',
          duration: 5000
        });
      }
    } finally {
      setDespertando(false);
    }
  };

  if (!mostrar) return null;

  return (
    <div className="fixed inset-0 z-[10000] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-300">
      <div className="bg-gradient-to-br from-orange-50 via-white to-blue-50 rounded-2xl shadow-2xl max-w-2xl w-full border-4 border-orange-400 relative overflow-hidden">
        {/* Pattern background */}
        <div className="absolute inset-0 opacity-5">
          <div className="absolute inset-0" style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23000000' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          }} />
        </div>

        {/* Close button */}
        <button
          onClick={() => setMostrar(false)}
          className="absolute top-4 right-4 p-2 hover:bg-white/50 rounded-lg transition-colors z-10"
        >
          <X className="w-5 h-5 text-slate-600" />
        </button>

        <div className="relative p-8">
          {/* Header */}
          <div className="text-center mb-6">
            <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-gradient-to-br from-orange-500 to-red-600 flex items-center justify-center animate-pulse">
              <Coffee className="w-10 h-10 text-white" />
            </div>
            
            <h2 className="text-3xl text-slate-800 mb-2">
              {exito ? '✅ ¡Servidor Despierto!' : '☕ Servidor Dormido'}
            </h2>
            
            <p className="text-slate-600 text-lg">
              {exito 
                ? 'Ya puedes continuar usando la aplicación'
                : 'El servidor de Supabase está en hibernación'
              }
            </p>
          </div>

          {!exito && (
            <>
              {/* Explicación */}
              <div className="bg-blue-50 border-2 border-blue-200 rounded-xl p-5 mb-6">
                <h3 className="text-blue-900 mb-2">
                  📋 ¿Por qué sucede esto?
                </h3>
                <p className="text-sm text-blue-800 mb-3">
                  Supabase pone los servidores en "sleep mode" después de 5-10 minutos sin actividad. 
                  Esto es <strong>completamente normal</strong> y no significa que haya un error.
                </p>
                <ul className="text-sm text-blue-700 space-y-1 list-disc list-inside">
                  <li>El servidor <strong>SÍ está desplegado</strong> ✅</li>
                  <li>Solo necesita una petición inicial para "despertar"</li>
                  <li>Tarda 30-90 segundos la primera vez</li>
                  <li>Después responde en menos de 1 segundo</li>
                </ul>
              </div>

              {/* Botón de acción */}
              <Button
                onClick={despertar}
                disabled={despertando}
                className="w-full h-16 text-xl bg-gradient-to-r from-orange-500 via-red-500 to-pink-600 hover:from-orange-600 hover:via-red-600 hover:to-pink-700 shadow-lg hover:shadow-xl transition-all"
              >
                {despertando ? (
                  <>
                    <Loader2 className="w-6 h-6 mr-3 animate-spin" />
                    Despertando... (esto puede tardar hasta 90s)
                  </>
                ) : (
                  <>
                    <Zap className="w-6 h-6 mr-3" />
                    ⚡ Despertar Servidor Ahora
                  </>
                )}
              </Button>

              {despertando && (
                <div className="mt-4 text-center">
                  <div className="flex items-center justify-center gap-2 text-sm text-slate-600">
                    <div className="flex gap-1">
                      <div className="w-2 h-2 rounded-full bg-orange-500 animate-bounce" style={{ animationDelay: '0s' }}></div>
                      <div className="w-2 h-2 rounded-full bg-red-500 animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                      <div className="w-2 h-2 rounded-full bg-pink-500 animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    </div>
                    <span>Espera un momento...</span>
                  </div>
                </div>
              )}
            </>
          )}

          {exito && (
            <div className="bg-green-50 border-2 border-green-300 rounded-xl p-6 text-center">
              <CheckCircle2 className="w-16 h-16 mx-auto mb-4 text-green-600" />
              <p className="text-lg text-green-900 mb-2">
                <strong>Tiempo de respuesta: {(tiempoRespuesta / 1000).toFixed(1)}s</strong>
              </p>
              <p className="text-sm text-green-700">
                El servidor ahora responderá rápidamente. Recarga la página o intenta de nuevo.
              </p>
            </div>
          )}

          {/* Footer info */}
          {!exito && (
            <div className="mt-6 pt-6 border-t border-slate-200">
              <details className="text-xs text-slate-600">
                <summary className="cursor-pointer hover:text-slate-800 transition-colors">
                  ℹ️ Información técnica
                </summary>
                <div className="mt-3 space-y-2 pl-4">
                  <p>
                    <strong>Cold Start:</strong> Primera petición después de hibernación. 
                    Puede tardar 30-90 segundos.
                  </p>
                  <p>
                    <strong>Warm Start:</strong> Servidor ya activo. Responde en menos de 1 segundo.
                  </p>
                  <p>
                    <strong>Plan Gratuito:</strong> Supabase hiberna servidores inactivos automáticamente.
                  </p>
                </div>
              </details>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
