import { Card } from './ui/card';
import { Button } from './ui/button';
import { Trophy, Star, Sparkles, Gift, DollarSign, TrendingUp, Wallet, Loader2 } from 'lucide-react';
import { useState, useEffect } from 'react';
import { toast } from 'sonner@2.0.3';
import { useCustomDialog } from './CustomDialog';
import { comisionesAPI, ruletaAPI, cobrosAPI } from '../utils/api';
import { UserData } from '../data/mockData';
import bgDots from "figma:asset/c7276b77fc7076b06a2a28060d005644f6f5b78e.png";

interface RuletaProps {
  userData?: UserData;
  onNavigate?: (section: string) => void;
}

export function Ruleta({ userData, onNavigate }: RuletaProps = {}) {
  // Obtener userId de userData o localStorage
  const getUserId = () => {
    if (userData?.id) return userData.id;
    const userStr = localStorage.getItem('currentUser');
    if (userStr) {
      const user = JSON.parse(userStr);
      return user.id;
    }
    return '';
  };
  
  const userId = getUserId();
  const [saldoWallet, setSaldoWallet] = useState(0); // Saldo disponible en wallet
  const [saldoRetirable, setSaldoRetirable] = useState(0); // Premios de ruleta ganados
  const [isSpinning, setIsSpinning] = useState(false);
  const [lastPrize, setLastPrize] = useState<string | null>(null);
  const [spinCount, setSpinCount] = useState(0);
  const [rotation, setRotation] = useState(0);
  const [totalGanado, setTotalGanado] = useState(0);
  const [loading, setLoading] = useState(true);
  
  const { showPrompt, showError, DialogComponent } = useCustomDialog();

  // 20 casillas según especificación
  const premios = [
    { id: 1, nombre: '$5 USDT', valor: 5, color: 'from-blue-400 to-blue-500', emoji: '💵', esPremio: true },
    { id: 2, nombre: 'Sigue Intentando', valor: 0, color: 'from-slate-600 to-slate-700', emoji: '🎯', esPremio: false },
    { id: 3, nombre: '$10 USDT', valor: 10, color: 'from-blue-500 to-blue-600', emoji: '💰', esPremio: true },
    { id: 4, nombre: 'Sigue Intentando', valor: 0, color: 'from-slate-600 to-slate-700', emoji: '🍀', esPremio: false },
    { id: 5, nombre: '$5 USDT', valor: 5, color: 'from-blue-400 to-blue-500', emoji: '💵', esPremio: true },
    { id: 6, nombre: '$50 USDT', valor: 50, color: 'from-purple-600 to-purple-700', emoji: '💎', esPremio: true },
    { id: 7, nombre: '$10 USDT', valor: 10, color: 'from-blue-500 to-blue-600', emoji: '💰', esPremio: true },
    { id: 8, nombre: 'Sigue Intentando', valor: 0, color: 'from-slate-600 to-slate-700', emoji: '🎯', esPremio: false },
    { id: 9, nombre: '$5 USDT', valor: 5, color: 'from-blue-400 to-blue-500', emoji: '💵', esPremio: true },
    { id: 10, nombre: '$100 USDT', valor: 100, color: 'from-indigo-600 to-indigo-700', emoji: '💎', esPremio: true },
    { id: 11, nombre: '$10 USDT', valor: 10, color: 'from-blue-500 to-blue-600', emoji: '💰', esPremio: true },
    { id: 12, nombre: 'Sigue Intentando', valor: 0, color: 'from-slate-600 to-slate-700', emoji: '🍀', esPremio: false },
    { id: 13, nombre: '$5 USDT', valor: 5, color: 'from-blue-400 to-blue-500', emoji: '💵', esPremio: true },
    { id: 14, nombre: '$200 USDT', valor: 200, color: 'from-pink-600 to-pink-700', emoji: '🌟', esPremio: true },
    { id: 15, nombre: '$10 USDT', valor: 10, color: 'from-blue-500 to-blue-600', emoji: '💰', esPremio: true },
    { id: 16, nombre: 'Sigue Intentando', valor: 0, color: 'from-slate-600 to-slate-700', emoji: '🎯', esPremio: false },
    { id: 17, nombre: '$50 USDT', valor: 50, color: 'from-purple-600 to-purple-700', emoji: '💎', esPremio: true },
    { id: 18, nombre: '$500 USDT', valor: 500, color: 'from-orange-600 to-orange-700', emoji: '🔥', esPremio: true },
    { id: 19, nombre: '$100 USDT', valor: 100, color: 'from-indigo-600 to-indigo-700', emoji: '💎', esPremio: true },
    { id: 20, nombre: '$1,000 JACKPOT', valor: 1000, color: 'from-yellow-400 to-yellow-600', emoji: '👑', esPremio: true }
  ];

  useEffect(() => {
    if (userId) {
      cargarDatos();
    } else {
      console.error('No se encontró userId');
      setLoading(false);
      toast.error('Error al cargar datos del usuario');
    }
  }, [userId, userData]); // Recargar si userData cambia

  const cargarDatos = async () => {
    if (!userId) return;
    
    setLoading(true);
    try {
      // 1. Calcular Saldo Wallet (Disponible)
      let saldoDisponible = 0;
      
      if (userData) {
        // Calcular ganancias totales usando el histórico total
        // Si no existe ganancia_total, usamos el fallback de sumar los componentes disponibles
        const gananciaTotal = userData.ganancia_total || ((userData.comisiones_red || 0) + (userData.comisiones_patrocinio || 0) + (userData.rendimiento_diario || 0));
        
        // Obtener retiros y compras (Cobros)
        const cobros = await cobrosAPI.getByUserId(userId) || [];
        
        // Sumar TODO lo que ha salido de la cuenta (Retiros + Compras con Wallet)
        // Incluir estados: completado, pendiente, aprobado
        const totalEgresos = cobros
          .filter((c: any) => c.estado === 'completado' || c.estado === 'pendiente' || c.estado === 'aprobado')
          .reduce((sum: number, c: any) => sum + c.monto, 0);
          
        // Obtener gastos de ruleta
        let totalGastosRuleta = 0;
        try {
          const gastos = await ruletaAPI.getGastos(userId);
          if (Array.isArray(gastos)) {
            totalGastosRuleta = gastos.reduce((sum: number, g: any) => sum + g.monto, 0);
          }
        } catch (err) {
          console.error('Error al cargar gastos de ruleta', err);
        }

        // Calcular saldo disponible: Total Ganado - (Retiros + Compras + Gastos Ruleta)
        saldoDisponible = Math.max(0, gananciaTotal - totalEgresos - totalGastosRuleta);
      }
      
      setSaldoWallet(saldoDisponible);
      
      // 2. Cargar historial de ruleta
      const historialRuleta = await ruletaAPI.getHistorial(userId);
      const totalPremios = historialRuleta
        .filter((item: any) => item.premio && item.puntos)
        .reduce((sum: number, item: any) => sum + (item.puntos || 0), 0);
      
      setSpinCount(historialRuleta.length);
      setSaldoRetirable(totalPremios);
      setTotalGanado(totalPremios);
    } catch (error) {
      console.error('Error al cargar datos:', error);
      toast.error('Error al cargar datos');
    } finally {
      setLoading(false);
    }
  };

  const costoPorGiro = 10; // $10 USD por giro

  const girarRuleta = async () => {
    if (saldoWallet < costoPorGiro) {
      toast.error('Saldo insuficiente en tu Wallet. Necesitas $10 USD');
      return;
    }

    if (isSpinning) return;

    setIsSpinning(true);
    setSaldoWallet(prev => Math.max(0, prev - costoPorGiro));

    try {
      // Llamada al servidor para determinar el premio
      const { projectId } = await import('../utils/supabase/info');
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f68532a/ruleta/play`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${(await import('../utils/supabase/info')).publicAnonKey}`
        },
        body: JSON.stringify({ userId })
      });
      
      const data = await response.json();
      
      if (data.error) {
        throw new Error(data.error);
      }
      
      const premioIndex = data.premioIndex;
      const premio = premios[premioIndex];

      // Calcular rotación visual
      const vueltasExtra = 5;
      const gradosPorPremio = 360 / premios.length;
      
      // El ángulo donde comienza el premio (index 0 en 0 grados)
      const anguloDelPremio = premioIndex * gradosPorPremio;
      
      // El centro del premio
      const centroSegmento = anguloDelPremio + (gradosPorPremio / 2);
      
      // Lógica de rotación corregida:
      // Queremos que la posición final sea -centroSegmento (mod 360) para que ese segmento quede arriba.
      // Calculamos el ajuste necesario desde la posición actual.
      const currentRotation = rotation;
      const remainder = currentRotation % 360;
      const targetRotation = -centroSegmento;
      
      // Calculamos cuánto falta para llegar al target en sentido horario (positivo)
      // (target - current) % 360, normalizado a positivo
      let adjustment = (targetRotation - remainder) % 360;
      if (adjustment <= 0) {
        adjustment += 360;
      }
      
      // Nueva rotación: actual + vueltas completas + ajuste para llegar al target
      const nuevaRotacion = currentRotation + (360 * vueltasExtra) + adjustment;
      
      setRotation(nuevaRotacion);

      // Esperar a que termine la animación
      setTimeout(() => {
        setIsSpinning(false);
        setLastPrize(premio.nombre);
        setSpinCount(data.userSpinCount);

        // Aplicar premio
        if (premio.esPremio && premio.valor > 0) {
          setSaldoRetirable(prev => prev + premio.valor);
          setTotalGanado(prev => prev + premio.valor);
          
          // Mensajes especiales para premios garantizados
          const currentSpin = data.userSpinCount;
          if (currentSpin % 12000 === 0) {
            toast.success(`🎉👑 ¡JACKPOT GARANTIZADO! ¡Ganaste ${premio.nombre}! (Giro ${currentSpin})`, { duration: 6000 });
          } else if (currentSpin % 6000 === 0) {
            toast.success(`🔥 ¡PREMIO GARANTIZADO! ¡Ganaste ${premio.nombre}! (Giro ${currentSpin})`, { duration: 5000 });
          } else if (currentSpin % 3000 === 0) {
            toast.success(`🌟 ¡PREMIO GARANTIZADO! ¡Ganaste ${premio.nombre}! (Giro ${currentSpin})`, { duration: 5000 });
          } else if (currentSpin % 1000 === 0) {
            toast.success(`💎 ¡PREMIO GARANTIZADO! ¡Ganaste ${premio.nombre}! (Giro ${currentSpin})`, { duration: 5000 });
          } else if (currentSpin % 500 === 0) {
            toast.success(`💎 ¡PREMIO GARANTIZADO! ¡Ganaste ${premio.nombre}! (Giro ${currentSpin})`, { duration: 4000 });
          } else if (currentSpin % 50 === 0) {
            toast.success(`💵 ¡PREMIO GARANTIZADO! ¡Ganaste ${premio.nombre}! (Giro ${currentSpin})`, { duration: 4000 });
          } else if (currentSpin % 5 === 0) {
            toast.success(`💰 ¡PREMIO GARANTIZADO! ¡Ganaste ${premio.nombre}! (Giro ${currentSpin})`, { duration: 4000 });
          } else {
            toast.success(`¡Ganaste ${premio.nombre}!`);
          }
        } else {
          toast.info(`${premio.nombre}`);
        }
      }, 4000);
      
    } catch (error) {
      console.error('Error al girar ruleta:', error);
      toast.error('Error al procesar el giro. Intenta nuevamente.');
      setIsSpinning(false);
      // Reembolsar si hubo error (optimista)
      setSaldoWallet(prev => prev + costoPorGiro);
    }
  };

  const retirarSaldo = () => {
    if (saldoRetirable <= 0) {
      toast.error('No tienes saldo disponible');
      return;
    }

    // Si se proporcionó la función de navegación, redirigir a Cobros
    if (onNavigate) {
      onNavigate('cobros');
      toast.info('Redirigiendo a Cobros para retirar saldo de premios...');
      return;
    }

    showPrompt(
      '¿Cuánto deseas retirar?',
      (value) => {
        const montoNum = parseFloat(value);
        
        if (isNaN(montoNum) || montoNum <= 0) {
          toast.error('Por favor ingresa un monto válido');
          return;
        }
        
        if (montoNum > saldoRetirable) {
          toast.error('No tienes suficiente saldo retirable');
          return;
        }
        
        setSaldoRetirable(prev => prev - montoNum);
        toast.success(`Retiro procesado: $${montoNum.toFixed(2)} USD`);
        // Aquí se debería llamar a la API de retiros real
      },
      {
        inputLabel: `Disponible: $${saldoRetirable.toFixed(2)}`,
        inputPlaceholder: 'Ingresa el monto en USD',
        confirmText: 'Retirar',
        cancelText: 'Cancelar'
      }
    );
  };

  // Obtener solo los premios reales para mostrar
  const premiosReales = premios.filter(p => p.esPremio);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <DialogComponent />
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-600 to-blue-700 flex items-center justify-center shadow-lg">
            <Trophy className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-slate-500">Ruleta de Premios</h1>
            <p className="text-slate-600 font-medium">Gira y gana USDT para retirar</p>
          </div>
        </div>
        
        {/* Saldos */}
        <div className="flex gap-3">
          <Card className="p-4 bg-gradient-to-br from-blue-600 to-blue-700 border-0 shadow-xl text-white">
            <div className="flex items-center gap-3">
              <Wallet className="w-6 h-6" />
              <div>
                <p className="text-white/80 text-xs">Saldo Wallet</p>
                <p className="text-xl">${saldoWallet.toFixed(2)}</p>
              </div>
            </div>
          </Card>
          <Card className="p-4 bg-gradient-to-br from-green-600 to-green-700 border-0 shadow-xl text-white">
            <div className="flex items-center gap-3">
              <TrendingUp className="w-6 h-6" />
              <div>
                <p className="text-white/80 text-xs">Saldo Retirable</p>
                <p className="text-xl">${saldoRetirable.toFixed(2)}</p>
              </div>
            </div>
          </Card>
        </div>
      </div>

      {/* Info Banner */}
      <Card className="p-6 bg-gradient-to-br from-slate-800 to-slate-900 border-0 shadow-xl text-white">
        <div className="flex items-start gap-4">
          <Sparkles className="w-8 h-8 flex-shrink-0" />
          <div>
            <h3 className="text-lg mb-2">🎲 Premios Garantizados</h3>
            <p className="text-white/80 text-sm mb-3">
              Cada giro cuesta ${costoPorGiro} USD (descontado de tu Wallet). 
              Los premios van directamente a tu <span className="text-green-400 font-semibold">Saldo Retirable</span>.
            </p>
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Wheel Section */}
        <div className="space-y-4">
          <Card className="p-8 border-slate-200 shadow-xl relative overflow-hidden">
            {/* Background Image Layer */}
            <div 
              className="absolute inset-0 z-0 opacity-10"
              style={{ 
                backgroundImage: `url(${bgDots})`,
                backgroundSize: 'cover',
                backgroundPosition: 'center',
                backgroundRepeat: 'no-repeat'
              }}
            />
            <div className="relative z-10 space-y-6">
              {/* Wheel Container */}
              <div className="relative mx-auto w-full max-w-[420px] aspect-square">
                {/* Indicator Arrow */}
                <div className="absolute -top-[5%] left-1/2 -translate-x-1/2 z-30 w-[10%] h-[12%]">
                  <div className="w-full h-full bg-gradient-to-b from-blue-600 to-blue-700 clip-path-arrow shadow-xl flex items-center justify-center" style={{ clipPath: 'polygon(50% 100%, 0 0, 100% 0)' }}>
                  </div>
                </div>

                {/* Main Wheel */}
                <div className="absolute inset-0 rounded-full bg-gradient-to-br from-slate-800 via-slate-900 to-black shadow-2xl p-[3%]">
                  {/* Decorative ring */}
                  <div className="absolute inset-[3%] rounded-full border-4 border-blue-500/30"></div>
                  
                  {/* Spinning wheel */}
                  <div
                    className="relative w-full h-full rounded-full overflow-hidden shadow-inner"
                    style={{
                      transform: `rotate(${rotation}deg)`,
                      transition: isSpinning ? 'transform 4s cubic-bezier(0.17, 0.67, 0.12, 0.99)' : 'none'
                    }}
                  >
                    {/* Layer 1: Background Segments */}
                    {premios.map((premio, index) => {
                      const segmentAngle = 360 / premios.length;
                      const startAngle = index * segmentAngle;
                      const endAngle = (index + 1) * segmentAngle;
                      
                      // Calculate segment path points
                      const startRad = (startAngle * Math.PI) / 180;
                      const endRad = (endAngle * Math.PI) / 180;
                      
                      const x1 = 50 + 50 * Math.sin(startRad);
                      const y1 = 50 - 50 * Math.cos(startRad);
                      const x2 = 50 + 50 * Math.sin(endRad);
                      const y2 = 50 - 50 * Math.cos(endRad);
                      
                      return (
                        <div
                          key={`bg-${premio.id}`}
                          className="absolute inset-0"
                          style={{
                            clipPath: `polygon(50% 50%, ${x1}% ${y1}%, ${x2}% ${y2}%)`
                          }}
                        >
                          {/* Segment background */}
                          <div className={`absolute inset-0 bg-gradient-to-br ${premio.color}`}></div>
                          
                          {/* Segment border */}
                          <div 
                            className="absolute inset-0 bg-black/20"
                            style={{
                              clipPath: `polygon(50% 50%, 50.5% 0%, 51% 0%, 50.5% 50%)`
                            }}
                          ></div>
                        </div>
                      );
                    })}

                    {/* Layer 2: Text/Icons (Separated to avoid clipping and easier positioning) */}
                    {premios.map((premio, index) => {
                      const segmentAngle = 360 / premios.length;
                      const startAngle = index * segmentAngle;
                      const angle = startAngle + segmentAngle / 2;
                      
                      return (
                        <div
                          key={`text-${premio.id}`}
                          className="absolute top-0 left-1/2 h-1/2 w-0 flex flex-col items-center justify-start pt-[2%]"
                          style={{
                            transformOrigin: 'bottom center',
                            transform: `translateX(-50%) rotate(${angle}deg)`
                          }}
                        >
                          <div 
                            className="flex flex-col items-center w-[60px] md:w-[80px]"
                          >
                            {/* Icon */}
                            <div className="text-lg md:text-3xl mb-0.5 md:mb-1 drop-shadow-2xl">
                              {premio.emoji}
                            </div>
                            
                            {/* Text */}
                            <div 
                              className="text-white font-bold text-center leading-tight"
                              style={{ 
                                fontSize: 'clamp(8px, 2.5vw, 10px)', // Responsive font size
                                textShadow: '0 2px 8px rgba(0,0,0,0.9), 0 0 20px rgba(0,0,0,0.6)',
                                letterSpacing: '0.2px'
                              }}
                            >
                              {premio.nombre.split(' ').map((word, i) => (
                                <div key={i}>{word}</div>
                              ))}
                            </div>
                          </div>
                        </div>
                      );
                    })}

                    {/* Center circle BUTTON */}
                    <div 
                      className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[30%] h-[30%] rounded-full shadow-2xl flex items-center justify-center border-[4px] md:border-8 border-white z-20 transition-transform active:scale-95 ${
                        isSpinning || saldoWallet < costoPorGiro 
                          ? 'bg-slate-400 cursor-not-allowed grayscale' 
                          : 'bg-gradient-to-br from-yellow-400 to-orange-500 cursor-pointer hover:scale-105'
                      }`}
                      onClick={girarRuleta}
                    >
                      <div className="text-center flex flex-col items-center justify-center">
                        {isSpinning ? (
                          <Loader2 className="w-6 h-6 md:w-10 md:h-10 text-white animate-spin" />
                        ) : (
                          <>
                            <div className="text-xl md:text-3xl mb-0.5 md:mb-1">🎲</div>
                            <div className="text-white text-[10px] md:text-sm font-bold tracking-wider drop-shadow-md leading-tight">GIRAR</div>
                            <div className="text-white/90 text-[9px] md:text-xs font-bold drop-shadow-md">${costoPorGiro}</div>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {lastPrize && !isSpinning && (
                <div className="mt-3 p-3 bg-gradient-to-r from-blue-50 to-blue-100 rounded-xl border border-blue-200">
                  <p className="text-blue-800 text-center text-sm">
                    ✨ Último Premio: <span className="font-semibold">{lastPrize}</span>
                  </p>
                </div>
              )}
            </div>
          </Card>
        </div>

        {/* Info Section */}
        <div className="space-y-4">
          {/* Premios List */}
          <Card className="p-4">
            <h3 className="text-slate-800 mb-3 flex items-center gap-2">
              <Gift className="w-4 h-4 text-blue-600" />
              Premios Disponibles
            </h3>
            <div className="space-y-2">
              {premiosReales.map((premio) => (
                <div
                  key={premio.id}
                  className={`p-2 bg-gradient-to-r ${premio.color} rounded-lg text-white flex items-center justify-between`}
                >
                  <div className="flex items-center gap-2">
                    <span className="text-base">{premio.emoji}</span>
                    <span className="text-xs">{premio.nombre}</span>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Estadísticas Grid */}
          <div className="grid grid-cols-2 gap-3">
            <Card className="p-4 bg-gradient-to-br from-blue-600 to-blue-700 border-0 shadow-xl text-white">
              <div className="flex items-center gap-2 mb-2">
                <Trophy className="w-5 h-5" />
                <p className="text-white/80 text-xs">Total Giros</p>
              </div>
              <p className="text-3xl">{spinCount}</p>
            </Card>

            <Card className="p-4 bg-gradient-to-br from-slate-700 to-slate-800 border-0 shadow-xl text-white">
              <div className="flex items-center gap-2 mb-2">
                <Star className="w-5 h-5" />
                <p className="text-white/80 text-xs">Giros Disp.</p>
              </div>
              <p className="text-3xl">{Math.floor(saldoWallet / costoPorGiro)}</p>
            </Card>
          </div>

          {/* Total Ganado */}
          <Card className="p-4 bg-gradient-to-br from-green-600 to-green-700 border-0 shadow-xl text-white">
            <div className="flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <TrendingUp className="w-5 h-5" />
                  <p className="text-white/80 text-xs">Total Ganado</p>
                </div>
                <p className="text-3xl">${totalGanado}</p>
                <p className="text-white/70 text-xs mt-1">Premios en USDT</p>
              </div>
            </div>
          </Card>

          {/* Gestión de Saldo Retirable */}
          <Card className="p-4 bg-slate-50 border-slate-200 shadow-lg">
            <h3 className="text-slate-800 mb-3 flex items-center gap-2">
              <Wallet className="w-4 h-4 text-blue-600" />
              Retirar Premios
            </h3>
            <div className="space-y-2">
              {/* Botón Retirar */}
              <Button
                onClick={retirarSaldo}
                disabled={saldoRetirable <= 0}
                className={`w-full py-3 text-sm flex items-center justify-center gap-2 ${
                  saldoRetirable <= 0
                    ? 'bg-slate-300 hover:bg-slate-300 cursor-not-allowed'
                    : 'bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800'
                } text-white`}
              >
                <Wallet className="w-4 h-4" />
                Retirar Saldo
              </Button>
            </div>
            <p className="text-slate-500 text-xs mt-3 text-center">
              {saldoRetirable > 0 
                ? `Tienes $${saldoRetirable.toFixed(2)} disponible para retirar` 
                : 'Gana premios en la ruleta para poder retirar'}
            </p>
          </Card>
        </div>
      </div>
    </div>
  );
}