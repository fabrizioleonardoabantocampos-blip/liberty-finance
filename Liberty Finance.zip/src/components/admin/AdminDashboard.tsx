import { useState, useEffect } from 'react';
import { AdminHome } from './AdminHome';
import { AdminUsers } from './AdminUsers';
import { GestionarRetiros } from './GestionarRetiros';
import { AdminDepositos } from './AdminDepositos';
import { AdminNetwork } from './AdminNetwork';
import { AdminSettings } from './AdminSettings';
import { GestionarProductos } from './GestionarProductos';
import { ConfiguracionGeneral } from './ConfiguracionGeneral';
import { GestionarRangos } from './GestionarRangos';
import { GestionarDocumentos } from './GestionarDocumentos';
import { AdminSidebar } from './AdminSidebar';
import { DiagnosticoServidorDebug } from './DiagnosticoServidorDebug';
import { DiagnosticoBD } from './DiagnosticoBD';
import { DiagnosticoEstructura } from './DiagnosticoEstructura';
import { UsuariosDuplicados } from './UsuariosDuplicados';
import DiagnosticoUsuario from './DiagnosticoUsuario';
import { LoadingScreen } from '../auth/LoadingScreen';
import { callServer } from '../../utils/api';
import { CacheManager } from '../../utils/cache';

interface AdminDashboardProps {
  onLogout: () => void;
}

// Contexto global para compartir datos pre-cargados entre componentes
interface AdminDataCache {
  dashboardStats?: any;
  users?: any[];
  depositos?: any[];
  timestamp: number;
}

let globalAdminCache: AdminDataCache | null = null;

export function AdminDashboard({ onLogout }: AdminDashboardProps) {
  const [activeSection, setActiveSection] = useState('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [dataCache, setDataCache] = useState<AdminDataCache | null>(null);

  // Pre-cargar todos los datos críticos en paralelo
  useEffect(() => {
    const preloadAllData = async () => {
      console.log('🚀 [AdminDashboard] Iniciando carga paralela de datos...');
      const startTime = Date.now();

      try {
        // Verificar si hay caché válido
        if (globalAdminCache && (Date.now() - globalAdminCache.timestamp < 2 * 60 * 1000)) {
          console.log('✅ [AdminDashboard] Usando caché global válido');
          setDataCache(globalAdminCache);
          setIsLoading(false);
          return;
        }

        // Cargar datos críticos en paralelo
        // Solo cargamos los endpoints que SÍ existen en el servidor
        const [dashboardStats, users, depositos] = await Promise.all([
          callServer('/admin/dashboard-stats', 'GET').catch(err => {
            console.error('Error cargando dashboard stats:', err);
            return null;
          }),
          callServer('/admin/users-complete', 'GET').catch(err => {
            console.error('Error cargando usuarios:', err);
            return [];
          }),
          callServer('/depositos', 'GET').catch(err => {
            console.error('Error cargando depositos:', err);
            return [];
          })
        ]);

        const cache: AdminDataCache = {
          dashboardStats,
          users,
          depositos,
          timestamp: Date.now()
        };

        // Guardar en caché global y local
        globalAdminCache = cache;
        setDataCache(cache);

        const loadTime = ((Date.now() - startTime) / 1000).toFixed(2);
        console.log(`✅ [AdminDashboard] Datos cargados en ${loadTime}s`);
        
        // Disparar evento para indicar que el dashboard está listo
        window.dispatchEvent(new Event('dashboardReady'));
        
      } catch (error) {
        console.error('❌ [AdminDashboard] Error en carga paralela:', error);
        // Disparar evento incluso si hay error para no quedar bloqueado
        window.dispatchEvent(new Event('dashboardReady'));
      } finally {
        setIsLoading(false);
      }
    };

    preloadAllData();
  }, []);

  // Función para invalidar el caché cuando sea necesario
  const invalidateCache = () => {
    globalAdminCache = null;
    setDataCache(null);
  };

  // No mostrar LoadingScreen interno si ya estamos mostrando el global desde App.tsx
  // El AdminDashboard simplemente espera a cargar los datos en segundo plano
  // if (isLoading) {
  //   return <LoadingScreen message="Cargando panel de administración..." />;
  // }

  const renderSection = () => {
    // Pasar datos pre-cargados a cada componente
    const commonProps = { 
      preloadedData: dataCache,
      onDataUpdate: invalidateCache 
    };

    switch (activeSection) {
      case 'dashboard':
        return <AdminHome {...commonProps} />;
      case 'users':
        return <AdminUsers {...commonProps} />;
      case 'withdrawals':
        return <GestionarRetiros {...commonProps} />;
      case 'depositos':
        return <AdminDepositos {...commonProps} />;
      case 'network':
        return <AdminNetwork {...commonProps} />;
      case 'productos':
        return <GestionarProductos {...commonProps} />;
      case 'configuracion':
        return <ConfiguracionGeneral {...commonProps} />;
      case 'rangos':
        return <GestionarRangos {...commonProps} />;
      case 'documentos':
        return <GestionarDocumentos {...commonProps} />;
      case 'settings':
        return <AdminSettings {...commonProps} />;
      case 'debug-servidor':
        return <DiagnosticoServidorDebug />;
      case 'database':
        return <DiagnosticoBD onNavigate={setActiveSection} />;
      case 'diagnostico-estructura':
        return <DiagnosticoEstructura />;
      case 'diagnostico-usuario':
        return <DiagnosticoUsuario />;
      case 'usuarios-duplicados':
        return <UsuariosDuplicados />;
      default:
        return <AdminHome {...commonProps} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 overflow-x-hidden relative">
      <div className="flex w-full relative">
        <AdminSidebar 
          activeSection={activeSection}
          setActiveSection={setActiveSection}
          onLogout={onLogout}
          collapsed={sidebarCollapsed}
          setCollapsed={setSidebarCollapsed}
        />
        <main className={`flex-1 min-w-0 w-full p-4 pt-24 md:p-8 md:pt-24 transition-all duration-300 ${
          sidebarCollapsed ? 'md:ml-20' : 'md:ml-72'
        }`}>
          <div className="max-w-7xl mx-auto w-full">
            {renderSection()}
          </div>
        </main>
      </div>
    </div>
  );
}