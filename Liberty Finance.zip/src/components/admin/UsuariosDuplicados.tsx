import { useState } from 'react';
import { AlertCircle, Trash2, Users, RefreshCw } from 'lucide-react';
import { Button } from '../ui/button';
import { Card } from '../ui/card';
import { toast } from 'sonner@2.0.3';
import { callServer } from '../../utils/api';

interface UsuarioDuplicado {
  email: string;
  cantidad: number;
  original: {
    id: string;
    id_unico: string;
    nombre: string;
    apellido: string;
    fechaRegistro: string;
  };
  copias: Array<{
    id: string;
    id_unico: string;
    nombre: string;
    apellido: string;
    fechaRegistro: string;
  }>;
}

export function UsuariosDuplicados() {
  const [loading, setLoading] = useState(false);
  const [duplicados, setDuplicados] = useState<UsuarioDuplicado[]>([]);
  const [stats, setStats] = useState<{
    totalUsuarios: number;
    emailsConDuplicados: number;
    totalCopias: number;
  } | null>(null);
  const [eliminando, setEliminando] = useState(false);

  const detectarDuplicados = async () => {
    setLoading(true);
    try {
      const response = await callServer('/admin/detectar-usuarios-duplicados', 'GET');
      
      if (response.error) {
        toast.error(response.error);
        return;
      }

      setDuplicados(response.duplicados || []);
      setStats({
        totalUsuarios: response.totalUsuarios,
        emailsConDuplicados: response.emailsConDuplicados,
        totalCopias: response.totalCopias
      });

      if (response.emailsConDuplicados === 0) {
        toast.success('✅ No se encontraron usuarios duplicados');
      } else {
        toast.warning(`⚠️ Se encontraron ${response.emailsConDuplicados} emails con duplicados`);
      }
    } catch (error) {
      console.error('Error detectando duplicados:', error);
      toast.error('Error al detectar usuarios duplicados');
    } finally {
      setLoading(false);
    }
  };

  const eliminarDuplicados = async () => {
    if (duplicados.length === 0) {
      toast.error('No hay duplicados para eliminar');
      return;
    }

    if (!confirm(`¿Estás seguro de eliminar ${stats?.totalCopias} usuarios duplicados? Esta acción NO se puede deshacer.`)) {
      return;
    }

    setEliminando(true);
    
    // ⚡ Mostrar toast de progreso
    const progressToast = toast.loading(`Eliminando ${stats?.totalCopias} usuarios... Esto puede tardar hasta 2 minutos.`);
    
    try {
      const emailsDuplicados = duplicados.map(d => d.email);
      
      console.log(`🗑️ Iniciando eliminación de ${emailsDuplicados.length} emails con duplicados...`);
      
      const response = await callServer('/admin/eliminar-usuarios-duplicados', 'POST', {
        emailsDuplicados
      });

      toast.dismiss(progressToast);

      if (response.error) {
        toast.error(response.error);
        return;
      }

      const tiempoSegundos = response.tiempoMs ? (response.tiempoMs / 1000).toFixed(1) : '?';
      toast.success(`✅ ${response.usuariosEliminados} usuarios eliminados en ${tiempoSegundos}s`);
      
      // Recargar la lista
      await detectarDuplicados();
    } catch (error) {
      toast.dismiss(progressToast);
      console.error('Error eliminando duplicados:', error);
      toast.error('Error al eliminar usuarios duplicados. Por favor intenta de nuevo.');
    } finally {
      setEliminando(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl text-slate-900 mb-2">🛡️ Gestión de Usuarios Duplicados</h1>
        <p className="text-slate-600">
          Detecta y elimina usuarios duplicados del sistema
        </p>
      </div>

      {/* Stats Cards */}
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="p-4 bg-blue-50 border-blue-200">
            <div className="flex items-center gap-3">
              <Users className="w-8 h-8 text-blue-600" />
              <div>
                <p className="text-sm text-slate-600">Total Usuarios</p>
                <p className="text-2xl text-slate-900">{stats.totalUsuarios}</p>
              </div>
            </div>
          </Card>

          <Card className="p-4 bg-yellow-50 border-yellow-200">
            <div className="flex items-center gap-3">
              <AlertCircle className="w-8 h-8 text-yellow-600" />
              <div>
                <p className="text-sm text-slate-600">Emails con Duplicados</p>
                <p className="text-2xl text-slate-900">{stats.emailsConDuplicados}</p>
              </div>
            </div>
          </Card>

          <Card className="p-4 bg-red-50 border-red-200">
            <div className="flex items-center gap-3">
              <Trash2 className="w-8 h-8 text-red-600" />
              <div>
                <p className="text-sm text-slate-600">Copias a Eliminar</p>
                <p className="text-2xl text-slate-900">{stats.totalCopias}</p>
              </div>
            </div>
          </Card>
        </div>
      )}

      {/* Actions */}
      <Card className="p-6">
        <div className="flex flex-col sm:flex-row gap-4">
          <Button
            onClick={detectarDuplicados}
            disabled={loading}
            className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
          >
            <RefreshCw className={`w-5 h-5 mr-2 ${loading ? 'animate-spin' : ''}`} />
            {loading ? 'Analizando...' : 'Detectar Duplicados'}
          </Button>

          {duplicados.length > 0 && (
            <Button
              onClick={eliminarDuplicados}
              disabled={eliminando}
              className="flex-1 bg-red-600 hover:bg-red-700 text-white"
            >
              <Trash2 className="w-5 h-5 mr-2" />
              {eliminando ? 'Eliminando...' : `Eliminar ${stats?.totalCopias} Duplicados`}
            </Button>
          )}
        </div>
      </Card>

      {/* Lista de duplicados */}
      {duplicados.length > 0 && (
        <div className="space-y-4">
          <h2 className="text-xl text-slate-900">Usuarios Duplicados Detectados</h2>
          
          {duplicados.map((dup, index) => (
            <Card key={index} className="p-6 border-l-4 border-l-yellow-500">
              <div className="space-y-4">
                {/* Email Header */}
                <div className="flex items-center justify-between border-b pb-3">
                  <div>
                    <h3 className="text-lg text-slate-900">📧 {dup.email}</h3>
                    <p className="text-sm text-slate-600">
                      {dup.cantidad} registros encontrados
                    </p>
                  </div>
                  <div className="px-3 py-1 bg-yellow-100 text-yellow-800 rounded-full text-sm">
                    {dup.copias.length} duplicados
                  </div>
                </div>

                {/* Original (se mantiene) */}
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="px-2 py-1 bg-green-600 text-white rounded text-xs">
                      ✓ ORIGINAL (SE MANTIENE)
                    </div>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                    <div>
                      <p className="text-slate-600">ID Único</p>
                      <p className="text-slate-900">{dup.original.id_unico}</p>
                    </div>
                    <div>
                      <p className="text-slate-600">Nombre</p>
                      <p className="text-slate-900">
                        {dup.original.nombre} {dup.original.apellido}
                      </p>
                    </div>
                    <div>
                      <p className="text-slate-600">Fecha Registro</p>
                      <p className="text-slate-900">
                        {new Date(dup.original.fechaRegistro).toLocaleDateString('es-MX')}
                      </p>
                    </div>
                    <div>
                      <p className="text-slate-600">UUID</p>
                      <p className="text-slate-900 text-xs truncate">{dup.original.id}</p>
                    </div>
                  </div>
                </div>

                {/* Copias (se eliminan) */}
                <div className="space-y-2">
                  <p className="text-sm text-slate-600">Copias a eliminar:</p>
                  {dup.copias.map((copia, idx) => (
                    <div key={idx} className="bg-red-50 border border-red-200 rounded-lg p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="px-2 py-1 bg-red-600 text-white rounded text-xs">
                          ✗ COPIA #{idx + 1} (SE ELIMINARÁ)
                        </div>
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                        <div>
                          <p className="text-slate-600">ID Único</p>
                          <p className="text-slate-900">{copia.id_unico}</p>
                        </div>
                        <div>
                          <p className="text-slate-600">Nombre</p>
                          <p className="text-slate-900">
                            {copia.nombre} {copia.apellido}
                          </p>
                        </div>
                        <div>
                          <p className="text-slate-600">Fecha Registro</p>
                          <p className="text-slate-900">
                            {new Date(copia.fechaRegistro).toLocaleDateString('es-MX')}
                          </p>
                        </div>
                        <div>
                          <p className="text-slate-600">UUID</p>
                          <p className="text-slate-900 text-xs truncate">{copia.id}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* Empty state */}
      {!loading && duplicados.length === 0 && stats && (
        <Card className="p-12 text-center">
          <Users className="w-16 h-16 text-slate-300 mx-auto mb-4" />
          <h3 className="text-xl text-slate-900 mb-2">No hay usuarios duplicados</h3>
          <p className="text-slate-600">
            Todos los usuarios tienen emails únicos en el sistema
          </p>
        </Card>
      )}
    </div>
  );
}
