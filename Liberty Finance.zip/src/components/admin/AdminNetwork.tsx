import { Card } from '../ui/card';
import { Network, Users, TrendingUp } from 'lucide-react';
import { useState, useEffect } from 'react';
import { callServer } from '../../utils/api';
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface UserWithStats {
  id: string;
  nombre: string;
  apellido: string;
  email: string;
  referidoPor?: string;
  referidosCount: number;
  totalComisiones: number;
}

export function AdminNetwork() {
  const [loading, setLoading] = useState(true);
  const [networkStats, setNetworkStats] = useState({
    totalRed: 0,
    nivel1: 0,
    nivel2: 0,
    nivel3Plus: 0,
    promedioReferidos: '0',
  });
  const [nivelesData, setNivelesData] = useState<any[]>([]);
  const [crecimientoData, setCrecimientoData] = useState<any[]>([]);
  const [distribucionData, setDistribucionData] = useState<any[]>([]);

  useEffect(() => {
    loadNetworkData();
  }, []);

  const loadNetworkData = async () => {
    try {
      setLoading(true);
      
      // Usar el endpoint optimizado
      const stats = await callServer('/admin/network-stats', 'GET');
      
      setNetworkStats({
        totalRed: stats.totalRed,
        nivel1: stats.nivel1,
        nivel2: stats.nivel2,
        nivel3Plus: stats.nivel3Plus,
        promedioReferidos: stats.promedioReferidos,
      });
      
      setNivelesData(stats.nivelData);
      setCrecimientoData(stats.mesData);
      
      // Datos para el gráfico circular
      setDistribucionData([
        { name: 'Nivel 1', value: stats.nivel1, color: '#3b82f6' },
        { name: 'Nivel 2', value: stats.nivel2, color: '#8b5cf6' },
        { name: 'Nivel 3+', value: stats.nivel3Plus, color: '#06b6d4' },
      ].filter(d => d.value > 0));
      
      setLoading(false);
    } catch (error) {
      console.error('Error al cargar datos de red:', error);
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl text-slate-800 mb-2">Red Global</h1>
        <p className="text-slate-600">Vista general de la estructura de la red multinivel</p>
      </div>

      {/* Stats */}
      {loading ? (
        <div className="text-center py-12">
          <p className="text-slate-600">Cargando datos de la red...</p>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="p-6 bg-gradient-to-br from-blue-500 to-blue-600 border-0 shadow-lg text-white">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center">
                  <Users className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-white/80 text-sm">Nivel 1</p>
                  <p className="text-2xl">{networkStats.nivel1.toLocaleString()}</p>
                </div>
              </div>
            </Card>

            <Card className="p-6 bg-gradient-to-br from-purple-500 to-purple-600 border-0 shadow-lg text-white">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center">
                  <Network className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-white/80 text-sm">Nivel 2</p>
                  <p className="text-2xl">{networkStats.nivel2.toLocaleString()}</p>
                </div>
              </div>
            </Card>

            <Card className="p-6 bg-gradient-to-br from-green-500 to-green-600 border-0 shadow-lg text-white">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center">
                  <TrendingUp className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-white/80 text-sm">Promedio Referidos</p>
                  <p className="text-2xl">
                    {networkStats.promedioReferidos} referidos
                  </p>
                </div>
              </div>
            </Card>
          </div>

          {/* Network Visualization */}
          <Card className="p-6 bg-white border-0 shadow-lg">
            <h3 className="text-slate-800 mb-6">Estructura de Red Multinivel</h3>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Gráfico de Barras - Usuarios por Nivel */}
              <div className="bg-gradient-to-br from-blue-50 to-cyan-50 p-6 rounded-xl">
                <h4 className="text-slate-800 mb-4 flex items-center gap-2">
                  <Network className="w-5 h-5 text-blue-600" />
                  Distribución por Nivel
                </h4>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart
                    data={nivelesData}
                    margin={{
                      top: 20,
                      right: 30,
                      left: 20,
                      bottom: 5,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis dataKey="name" stroke="#64748b" />
                    <YAxis stroke="#64748b" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: '#fff', 
                        border: '1px solid #e2e8f0',
                        borderRadius: '8px',
                        boxShadow: '0 4px 6px rgba(0,0,0,0.1)'
                      }}
                    />
                    <Bar dataKey="value" fill="url(#colorBlue)" radius={[8, 8, 0, 0]} />
                    <defs>
                      <linearGradient id="colorBlue" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="#06b6d4" stopOpacity={0.8}/>
                      </linearGradient>
                    </defs>
                  </BarChart>
                </ResponsiveContainer>
              </div>

              {/* Gráfico Circular - Proporción de Niveles */}
              <div className="bg-gradient-to-br from-purple-50 to-pink-50 p-6 rounded-xl">
                <h4 className="text-slate-800 mb-4 flex items-center gap-2">
                  <Users className="w-5 h-5 text-purple-600" />
                  Proporción de Usuarios
                </h4>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={distribucionData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {distribucionData.map((entry, index) => (
                        <Cell 
                          key={`cell-${index}`} 
                          fill={entry.color} 
                        />
                      ))}
                    </Pie>
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: '#fff', 
                        border: '1px solid #e2e8f0',
                        borderRadius: '8px',
                        boxShadow: '0 4px 6px rgba(0,0,0,0.1)'
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>

              {/* Gráfico de Líneas - Crecimiento Mensual */}
              <div className="bg-gradient-to-br from-green-50 to-emerald-50 p-6 rounded-xl">
                <h4 className="text-slate-800 mb-4 flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-green-600" />
                  Crecimiento Mensual
                </h4>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart
                    data={crecimientoData}
                    margin={{
                      top: 20,
                      right: 30,
                      left: 20,
                      bottom: 5,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis dataKey="name" stroke="#64748b" />
                    <YAxis stroke="#64748b" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: '#fff', 
                        border: '1px solid #e2e8f0',
                        borderRadius: '8px',
                        boxShadow: '0 4px 6px rgba(0,0,0,0.1)'
                      }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="value" 
                      stroke="#10b981" 
                      strokeWidth={3}
                      activeDot={{ r: 8 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>

              {/* Resumen Estadístico */}
              <div className="bg-gradient-to-br from-orange-50 to-amber-50 p-6 rounded-xl">
                <h4 className="text-slate-800 mb-6 flex items-center gap-2">
                  <Network className="w-5 h-5 text-orange-600" />
                  Resumen Estadístico
                </h4>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-white rounded-lg shadow-sm">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-lg bg-blue-100 flex items-center justify-center">
                        <Users className="w-6 h-6 text-blue-600" />
                      </div>
                      <div>
                        <p className="text-sm text-slate-600">Total Usuarios</p>
                        <p className="text-2xl text-slate-800">{networkStats.totalRed}</p>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-white rounded-lg shadow-sm">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-lg bg-purple-100 flex items-center justify-center">
                        <Network className="w-6 h-6 text-purple-600" />
                      </div>
                      <div>
                        <p className="text-sm text-slate-600">Usuarios Nivel 1</p>
                        <p className="text-2xl text-slate-800">{networkStats.nivel1}</p>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-white rounded-lg shadow-sm">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-lg bg-pink-100 flex items-center justify-center">
                        <Network className="w-6 h-6 text-pink-600" />
                      </div>
                      <div>
                        <p className="text-sm text-slate-600">Usuarios Nivel 2</p>
                        <p className="text-2xl text-slate-800">{networkStats.nivel2}</p>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-white rounded-lg shadow-sm">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-lg bg-green-100 flex items-center justify-center">
                        <TrendingUp className="w-6 h-6 text-green-600" />
                      </div>
                      <div>
                        <p className="text-sm text-slate-600">Promedio Referidos</p>
                        <p className="text-2xl text-slate-800">
                          {networkStats.promedioReferidos} referidos
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Card>
        </>
      )}
    </div>
  );
}