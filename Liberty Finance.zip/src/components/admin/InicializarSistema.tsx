import { useState } from 'react';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { toast } from 'sonner@2.0.3';
import { CheckCircle2, XCircle, Loader2, Package, Trophy, UserCog, Database } from 'lucide-react';
import { projectId, publicAnonKey } from '../../utils/supabase/info';

interface InicializarSistemaProps {
  onComplete?: () => void;
}

export function InicializarSistema({ onComplete }: InicializarSistemaProps) {
  const [loading, setLoading] = useState(false);
  const [resultado, setResultado] = useState<any>(null);

  const inicializarSistema = async () => {
    setLoading(true);
    setResultado(null);

    try {
      console.log('🚀 Iniciando inicialización del sistema...');
      
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-9f68532a/init/complete`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`
          }
        }
      );

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Error al inicializar: ${errorText}`);
      }

      const data = await response.json();
      console.log('✅ Inicialización completada:', data);
      
      setResultado(data.resultado);

      if (data.success) {
        toast.success('Sistema inicializado correctamente', {
          description: `${data.resultado.productos} productos, ${data.resultado.rangos} rangos cargados`
        });
        
        if (onComplete) {
          onComplete();
        }
      } else {
        toast.error('Error en la inicialización', {
          description: data.error || 'Error desconocido'
        });
      }

    } catch (error) {
      console.error('❌ Error al inicializar sistema:', error);
      toast.error('Error al inicializar sistema', {
        description: error instanceof Error ? error.message : 'Error desconocido'
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="p-8 bg-gradient-to-r from-blue-500 to-purple-600 text-white border-0">
        <div className="flex items-start gap-4">
          <div className="w-16 h-16 rounded-xl bg-white/20 flex items-center justify-center flex-shrink-0">
            <Database className="w-8 h-8 text-white" />
          </div>
          <div className="flex-1">
            <h2 className="text-2xl mb-2">Inicializar Sistema</h2>
            <p className="text-white/90 mb-4">
              Carga todos los datos por defecto en tu nueva base de datos Supabase
            </p>
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 space-y-2 text-sm">
              <p className="flex items-center gap-2">
                <Package className="w-4 h-4" />
                8 Packs de inversión ($50 - $10,000)
              </p>
              <p className="flex items-center gap-2">
                <Trophy className="w-4 h-4" />
                8 Rangos (Silver - Crown Black)
              </p>
              <p className="flex items-center gap-2">
                <UserCog className="w-4 h-4" />
                Usuario administrador (admin@libertyfinance.com)
              </p>
            </div>
          </div>
        </div>
      </Card>

      {/* Botón de inicialización */}
      {!resultado && (
        <Card className="p-6">
          <h3 className="text-lg mb-4 text-slate-800">¿Listo para inicializar?</h3>
          <p className="text-slate-600 mb-6">
            Este proceso cargará todos los datos necesarios para que Liberty Finance funcione correctamente.
            Solo necesitas hacer esto UNA VEZ después de crear tu nueva base de datos.
          </p>
          
          <div className="bg-yellow-50 border-2 border-yellow-200 rounded-xl p-4 mb-6">
            <p className="text-sm text-yellow-800">
              <strong>⚠️ Importante:</strong> Asegúrate de haber actualizado las credenciales de Supabase en
              <code className="bg-yellow-100 px-2 py-1 rounded mx-1">/utils/supabase/info.tsx</code>
              antes de continuar.
            </p>
          </div>

          <Button
            onClick={inicializarSistema}
            disabled={loading}
            className="w-full h-14 text-lg"
          >
            {loading ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                Inicializando Sistema...
              </>
            ) : (
              <>
                <Database className="w-5 h-5 mr-2" />
                Inicializar Sistema Completo
              </>
            )}
          </Button>
        </Card>
      )}

      {/* Resultado */}
      {resultado && (
        <Card className="p-6">
          <h3 className="text-lg mb-4 text-slate-800 flex items-center gap-2">
            <CheckCircle2 className="w-6 h-6 text-green-600" />
            Inicialización Completada
          </h3>

          <div className="space-y-4">
            {/* Productos */}
            <div className="flex items-center justify-between p-4 bg-green-50 rounded-xl border-2 border-green-200">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-green-500 flex items-center justify-center">
                  <Package className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="text-sm text-slate-600">Productos</p>
                  <p className="text-lg text-slate-800">
                    {resultado.productos} packs cargados
                  </p>
                </div>
              </div>
              <CheckCircle2 className="w-6 h-6 text-green-600" />
            </div>

            {/* Rangos */}
            <div className="flex items-center justify-between p-4 bg-green-50 rounded-xl border-2 border-green-200">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-green-500 flex items-center justify-center">
                  <Trophy className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="text-sm text-slate-600">Rangos</p>
                  <p className="text-lg text-slate-800">
                    {resultado.rangos} rangos cargados
                  </p>
                </div>
              </div>
              <CheckCircle2 className="w-6 h-6 text-green-600" />
            </div>

            {/* Admin */}
            <div className="flex items-center justify-between p-4 bg-green-50 rounded-xl border-2 border-green-200">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-green-500 flex items-center justify-center">
                  <UserCog className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="text-sm text-slate-600">Usuario Admin</p>
                  <p className="text-lg text-slate-800">
                    {resultado.admin ? 'Configurado' : 'Error'}
                  </p>
                </div>
              </div>
              {resultado.admin ? (
                <CheckCircle2 className="w-6 h-6 text-green-600" />
              ) : (
                <XCircle className="w-6 h-6 text-red-600" />
              )}
            </div>

            {/* Errores */}
            {resultado.errores && resultado.errores.length > 0 && (
              <div className="p-4 bg-red-50 rounded-xl border-2 border-red-200">
                <p className="text-sm text-red-800 mb-2">
                  <strong>⚠️ Errores encontrados:</strong>
                </p>
                <ul className="text-sm text-red-700 space-y-1">
                  {resultado.errores.map((error: any, index: number) => (
                    <li key={index}>
                      • {error.paso}: {error.error}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Credenciales de Admin */}
            <div className="p-6 bg-blue-50 rounded-xl border-2 border-blue-200">
              <p className="text-sm text-blue-800 mb-3">
                <strong>🔐 Credenciales de Administrador:</strong>
              </p>
              <div className="space-y-2 text-sm">
                <div className="flex items-center justify-between bg-white rounded-lg p-3">
                  <span className="text-slate-600">Email:</span>
                  <code className="bg-blue-100 px-3 py-1 rounded text-blue-900">
                    admin@libertyfinance.com
                  </code>
                </div>
                <div className="flex items-center justify-between bg-white rounded-lg p-3">
                  <span className="text-slate-600">Contraseña:</span>
                  <code className="bg-blue-100 px-3 py-1 rounded text-blue-900">
                    admin123
                  </code>
                </div>
              </div>
              <p className="text-xs text-blue-700 mt-3">
                💡 Recuerda cambiar la contraseña después del primer login
              </p>
            </div>

            {/* Próximos pasos */}
            <div className="p-6 bg-gradient-to-r from-green-50 to-blue-50 rounded-xl border-2 border-green-200">
              <p className="text-sm text-slate-800 mb-3">
                <strong>✅ ¡Todo listo! Próximos pasos:</strong>
              </p>
              <ol className="text-sm text-slate-700 space-y-2 list-decimal list-inside">
                <li>Inicia sesión con las credenciales de admin</li>
                <li>Configura tu wallet principal en Configuración</li>
                <li>Revisa que los productos estén visibles</li>
                <li>Revisa que los rangos estén visibles</li>
                <li>Registra un usuario de prueba</li>
                <li>Realiza un depósito de prueba</li>
                <li>¡Empieza a usar Liberty Finance! 🚀</li>
              </ol>
            </div>

            {/* Botón para reiniciar */}
            <Button
              onClick={() => setResultado(null)}
              variant="outline"
              className="w-full"
            >
              Volver
            </Button>
          </div>
        </Card>
      )}
    </div>
  );
}