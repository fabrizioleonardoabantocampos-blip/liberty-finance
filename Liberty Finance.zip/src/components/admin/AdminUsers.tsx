import { Search, MoreVertical, CheckCircle, XCircle, Edit, Trash2, X, UserPlus, Eye, Users, DollarSign, Package, TrendingUp, RefreshCw } from 'lucide-react';
import { useState, useEffect } from 'react';
import { usersAPI, packsAPI, comisionesAPI, depositosAPI, cobrosAPI, callServer, fetchAPI } from '../../utils/api';
import { toast } from 'sonner@2.0.3';
import { useCustomDialog } from '../CustomDialog';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { ejecutarConReintentos, obtenerMensajeError } from '../../utils/wasm-fix';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '../ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from '../ui/dropdown-menu';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '../ui/alert-dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';

interface User {
  id: string;
  id_unico: string;
  nombre: string;
  apellido: string;
  email: string;
  telefono: string;
  wallet: string;
  password?: string; // Agregar campo password
  fechaRegistro: string;
  activo: boolean;
}

interface UserWithStats extends User {
  referidosCount: number;
  totalInversion: number;
  totalComisiones: number;
}

interface AdminUsersProps {
  preloadedData?: any;
  onDataUpdate?: () => void;
}

export function AdminUsers({ preloadedData, onDataUpdate }: AdminUsersProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [users, setUsers] = useState<UserWithStats[]>([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isHistorialOpen, setIsHistorialOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isResetConfirmOpen, setIsResetConfirmOpen] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [selectedUser, setSelectedUser] = useState<UserWithStats | null>(null);
  const [userHistorial, setUserHistorial] = useState<any>(null);
  const [isDiagnosticoOpen, setIsDiagnosticoOpen] = useState(false);
  const [diagnosticoData, setDiagnosticoData] = useState<any>(null);
  const [loadingDiagnostico, setLoadingDiagnostico] = useState(false);
  const [isPacksModalOpen, setIsPacksModalOpen] = useState(false);
  const [packsDuplicados, setPacksDuplicados] = useState<any>(null);
  const [loadingPacks, setLoadingPacks] = useState(false);
  const [formData, setFormData] = useState({
    nombre: '',
    apellido: '',
    email: '',
    telefono: '',
    wallet: '',
    password: '',
  });
  
  const { dialogState, closeDialog, showDialog, DialogComponent } = useCustomDialog();

  useEffect(() => {
    // Si hay datos pre-cargados, usarlos inmediatamente
    if (preloadedData?.users) {
      console.log('✅ [AdminUsers] Usando datos pre-cargados:', preloadedData.users.length);
      setUsers(preloadedData.users);
      setLoading(false);
      return;
    }

    // Fallback: cargar datos si no están pre-cargados
    console.log('⚠️ [AdminUsers] No hay datos pre-cargados, cargando...');
    loadUsers();
  }, [preloadedData]);

  const loadUsers = async () => {
    try {
      setLoading(true);
      
      // Usar el endpoint optimizado
      const usuariosCompletos = await callServer('/admin/users-complete', 'GET');
      
      console.log('🔍 DEBUG - Usuarios recibidos del servidor:', usuariosCompletos.length);
      console.log('🔍 DEBUG - Primeros 3 usuarios:', usuariosCompletos.slice(0, 3));
      
      // Buscar específicamente a Juan Solano por ID único
      const juanSolano = usuariosCompletos.find((u: any) => 
        u.id_unico === 'LF1766035063633662' ||
        u.email?.toLowerCase().includes('juansolano') || 
        u.nombre?.toLowerCase().includes('juan')
      );
      console.log('🔍 DEBUG - Juan Solano (LF1766035063633662) encontrado?', juanSolano);
      
      // Ver cuántos usuarios tienen datos completos vs vacíos
      const usuariosCompletos2 = usuariosCompletos.filter((u: any) => u.nombre !== 'Sin nombre');
      const usuariosVacios = usuariosCompletos.filter((u: any) => u.nombre === 'Sin nombre');
      console.log(`📊 Usuarios con datos: ${usuariosCompletos2.length} | Sin datos: ${usuariosVacios.length}`);
      
      // Mapear al formato esperado
      const usuariosConEstadisticas = usuariosCompletos.map((u: any) => ({
        id: u.id,
        id_unico: u.id_unico,
        nombre: u.nombre,
        apellido: u.apellido,
        email: u.email,
        telefono: u.telefono,
        wallet: u.wallet,
        password: u.password, // Incluir contraseña
        fechaRegistro: u.fechaRegistro,
        activo: u.activo,
        referidosCount: u.referidos,
        totalInversion: u.inversion,
        totalComisiones: u.comisiones
      }));
      
      setUsers(usuariosConEstadisticas);
      setLoading(false);
    } catch (error) {
      console.error('Error al cargar usuarios:', error);
      toast.error('Error al cargar usuarios');
      setLoading(false);
    }
  };

  const loadUserHistorial = async (user: UserWithStats) => {
    try {
      setSelectedUser(user);
      
      const [allUsers, packs, comisiones, depositos, cobros] = await Promise.all([
        usersAPI.getAll(),
        packsAPI.getByUserId(user.id).catch(() => []),
        comisionesAPI.getByUserId(user.id).catch(() => []),
        depositosAPI.getByUserId(user.id).catch(() => []),
        cobrosAPI.getByUserId(user.id).catch(() => []),
      ]);

      const referidosDirectos = allUsers.filter((u: User) => u.referidoPor === user.id);
      
      // Obtener referidor si existe
      let referidor = null;
      if (user.referidoPor) {
        referidor = allUsers.find((u: User) => u.id === user.referidoPor);
      }

      setUserHistorial({
        referidosDirectos,
        referidor,
        packs,
        comisiones,
        depositos,
        cobros,
        totalInversion: packs.reduce((sum: number, p: any) => sum + p.monto, 0),
        totalComisiones: comisiones.reduce((sum: number, c: any) => sum + c.monto, 0),
      });
      
      setIsHistorialOpen(true);
    } catch (error) {
      console.error('Error al cargar historial:', error);
      toast.error('Error al cargar historial del usuario');
    }
  };

  const handleDiagnosticoInversion = async (user: UserWithStats) => {
    setLoadingDiagnostico(true);
    setSelectedUser(user);
    setIsDiagnosticoOpen(true);
    
    try {
      console.log('🔍 Solicitando diagnóstico de inversión para:', user.id);
      
      const response = await callServer(`/diagnostico-inversion/${user.id}`, 'GET');
      
      console.log('📊 Diagnóstico recibido:', response);
      
      setDiagnosticoData(response);
      toast.success('✅ Diagnóstico completado');
      
    } catch (error: any) {
      console.error('❌ Error al diagnosticar inversión:', error);
      toast.error(`Error: ${error.message || 'No se pudo obtener el diagnóstico'}`);
      setDiagnosticoData(null);
    } finally {
      setLoadingDiagnostico(false);
    }
  };

  const handleDiagnosticoPacks = async (user: UserWithStats) => {
    setLoadingDiagnostico(true);
    setSelectedUser(user);
    setIsDiagnosticoOpen(true);
    
    try {
      console.log('🔬 Solicitando diagnóstico de packs para:', user.id);
      
      const response = await callServer(`/admin/diagnostico-packs/${user.id}`, 'GET');
      
      console.log('📦 Diagnóstico de packs recibido:', response);
      setDiagnosticoData(response);
      toast.success('✅ Diagnóstico de packs completado');
      
    } catch (error: any) {
      console.error('❌ Error al diagnosticar packs:', error);
      toast.error(`Error: ${error.message || 'No se pudo obtener el diagnóstico de packs'}`);
      setDiagnosticoData(null);
    } finally {
      setLoadingDiagnostico(false);
    }
  };

  const handleCorregirDistribucion = async (user: UserWithStats) => {
    console.log('🎯 handleCorregirDistribucion LLAMADA para:', user.nombre, user.apellido, user.id);
    if (!confirm(`⚠️ ¿Confirmas que quieres CORREGIR la distribución de comisiones de ${user.nombre} ${user.apellido}?\n\nEsto redistribuirá TODAS las comisiones (incluidas las "huérfanas") a los packs correctos y actualizará el estado de cada pack.`)) {
      return;
    }

    setLoadingDiagnostico(true);
    
    try {
      console.log('🔧 Solicitando corrección de distribución para:', user.id);
      
      const response = await callServer(`/admin/corregir-distribucion-comisiones/${user.id}`, 'POST');
      
      console.log('✅ Corrección completada:', response);
      toast.success(`✅ Distribución corregida: ${response.correccion?.comisionesActualizadas || 0} comisiones actualizadas`);
      
      // Refrescar el diagnóstico
      await handleDiagnosticoPacks(user);
      
    } catch (error: any) {
      console.error('❌ Error al corregir distribución:', error);
      toast.error(`Error: ${error.message || 'No se pudo corregir la distribución'}`);
    } finally {
      setLoadingDiagnostico(false);
    }
  };

  const handleOpenDialog = (user?: User) => {
    if (user) {
      setEditingUser(user);
      setFormData({
        nombre: user.nombre,
        apellido: user.apellido,
        email: user.email,
        telefono: user.telefono,
        wallet: user.wallet,
        password: '',
      });
    } else {
      setEditingUser(null);
      setFormData({
        nombre: '',
        apellido: '',
        email: '',
        telefono: '',
        wallet: '',
        password: '',
      });
    }
    setIsDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setEditingUser(null);
    setFormData({
      nombre: '',
      apellido: '',
      email: '',
      telefono: '',
      wallet: '',
      password: '',
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      if (editingUser) {
        // Actualizar usuario existente
        const updates: any = {
          nombre: formData.nombre,
          apellido: formData.apellido,
          telefono: formData.telefono,
          wallet: formData.wallet,
        };
        
        // Solo actualizar password si se proporcionó uno nuevo
        if (formData.password) {
          updates.password = formData.password;
        }
        
        await usersAPI.update(editingUser.id, updates);
        toast.success('Usuario actualizado correctamente');
      } else {
        // Crear nuevo usuario
        if (!formData.password) {
          toast.error('La contraseña es requerida para nuevos usuarios');
          return;
        }
        
        // Para crear un nuevo usuario, usamos el endpoint de registro
        const response = await fetch(`https://${(await import('../../utils/supabase/info')).projectId}.supabase.co/functions/v1/make-server-9f68532a/auth/register`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${(await import('../../utils/supabase/info')).publicAnonKey}`,
          },
          body: JSON.stringify({
            nombre: formData.nombre,
            apellido: formData.apellido,
            email: formData.email,
            telefono: formData.telefono,
            wallet: formData.wallet,
            password: formData.password,
          }),
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw new Error(data.error || 'Error al crear usuario');
        }
        
        toast.success('Usuario creado correctamente');
      }
      
      handleCloseDialog();
      loadUsers();
    } catch (error: any) {
      console.error('Error al guardar usuario:', error);
      toast.error(error.message || 'Error al guardar usuario');
    }
  };

  const handleToggleActive = async (user: User) => {
    try {
      await usersAPI.update(user.id, { activo: !user.activo });
      toast.success(`Usuario ${!user.activo ? 'activado' : 'desactivado'} correctamente`);
      loadUsers();
    } catch (error) {
      console.error('Error al cambiar estado:', error);
      toast.error('Error al cambiar estado del usuario');
    }
  };

  const handleDeleteUser = async () => {
    if (!selectedUser) return;
    
    try {
      // Desactivar el usuario permanentemente
      await usersAPI.update(selectedUser.id, { activo: false });
      
      console.log(`✅ Usuario ${selectedUser.email} desactivado`);
      toast.success('Usuario eliminado correctamente. No podrá iniciar sesión.');
      
      setIsDeleteDialogOpen(false);
      setSelectedUser(null);
      
      // Recargar la lista de usuarios
      await loadUsers();
    } catch (error) {
      console.error('Error al eliminar usuario:', error);
      toast.error('Error al eliminar usuario');
    }
  };

  const handleSyncUsers = async () => {
    setIsSyncing(true);
    try {
      console.log('🔄 Iniciando sincronización de usuarios...');
      
      const response = await callServer('/admin/sincronizar-usuarios-auth', 'POST');
      
      console.log('✅ Resultado de sincronización:', response);
      
      if (response.sincronizados > 0) {
        toast.success(`✅ ${response.sincronizados} usuario(s) sincronizado(s) correctamente`);
        await loadUsers();
      } else {
        toast.success('✅ Todos los usuarios ya están sincronizados');
      }
      
    } catch (error) {
      console.error('Error al sincronizar usuarios:', error);
      toast.error('Error al sincronizar usuarios');
    } finally {
      setIsSyncing(false);
    }
  };

  const handleDebug48h = async () => {
    try {
      const response = await callServer('/debug/usuarios-48h', 'GET');
      console.log('🐛 DEBUG: Usuarios últimas 48h:', response);
      
      // Mostrar modal con los resultados
      const usuariosHTML = response.usuarios.map((u: any, idx: number) => `
        ${idx + 1}. ${u.nombre} ${u.apellido}
           Email: ${u.email}
           ID: ${u.id_unico}
           Hace ${u.horasDesdeRegistro}h
           Activo: ${u.activo ? 'Sí' : 'No'}
      `).join('\n\n');
      
      showDialog({
        title: `📋 Usuarios Últimas 48h (${response.totalUltimas48h})`,
        description: `Total en KV: ${response.totalUsuariosKV}\n\n${usuariosHTML || 'No hay usuarios en las últimas 48 horas'}`,
        confirmText: 'Cerrar',
        onConfirm: closeDialog
      });
      
      toast.success(`Encontrados ${response.totalUltimas48h} usuarios. Ver consola para detalles completos.`);
    } catch (error) {
      console.error('Error en debug 48h:', error);
      toast.error('Error al obtener datos de debug');
    }
  };

  const handleCountRaw = async () => {
    try {
      const response = await callServer('/debug/count-raw', 'GET');
      console.log('🐛 DEBUG: Conteo RAW de base de datos:', response);
      
      showDialog({
        title: '📊 Conteo Directo en Base de Datos',
        description: `Total registros: ${response.totalRegistros}\nUsuarios (user:UUID): ${response.usuarios}\nMapeo emails: ${response.mapeoEmails}\nMapeo IDs únicos: ${response.mapeoIdsUnicos}\n\n⚠️ Si usuarios ≠ emails o ≠ IDs únicos, hay un problema de sincronización.`,
        confirmText: 'Cerrar',
        onConfirm: closeDialog
      });
      
      toast.success(`${response.usuarios} usuarios en BD. Ver consola para detalles.`);
    } catch (error) {
      console.error('Error en count-raw:', error);
      toast.error('Error al obtener conteo');
    }
  };

  const handleFindUser = async () => {
    const idUnico = prompt('Ingresa el ID único del usuario a buscar (ej: LF1764085135266676):');
    if (!idUnico) return;
    
    try {
      const response = await callServer(`/debug/find-user/${idUnico}`, 'GET');
      console.log('🔍 RESULTADO DE BÚSQUEDA:', response);
      
      let mensaje = `ID Único: ${response.idUnicoBuscado}\nTotal encontrados: ${response.totalEncontrados}\n\n`;
      
      if (response.registros && response.registros.length > 0) {
        mensaje += '📋 REGISTROS EN BASE DE DATOS:\n';
        response.registros.forEach((reg: any, idx: number) => {
          mensaje += `\n${idx + 1}. Tipo: ${reg.tipoRegistro}\n`;
          mensaje += `   Key: ${reg.key}\n`;
          mensaje += `   Tiene nombre: ${reg.tieneNombre ? 'Sí' : 'No'}\n`;
          mensaje += `   Tiene email: ${reg.tieneEmail ? 'Sí' : 'No'}\n`;
        });
      } else {
        mensaje += '❌ NO SE ENCONTRÓ NINGÚN REGISTRO\n';
      }
      
      if (response.usuarioRecuperadoPorFuncion) {
        mensaje += `\n✅ Usuario recuperado por función:\n`;
        mensaje += `   Nombre: ${response.usuarioRecuperadoPorFuncion.nombre}\n`;
        mensaje += `   Email: ${response.usuarioRecuperadoPorFuncion.email}\n`;
      } else {
        mensaje += `\n❌ getUserByIdUnico() NO pudo recuperar el usuario`;
      }
      
      showDialog({
        title: '🔍 Búsqueda de Usuario',
        description: mensaje,
        confirmText: 'Cerrar',
        onConfirm: closeDialog
      });
      
    } catch (error) {
      console.error('Error buscando usuario:', error);
      toast.error('Error al buscar usuario');
    }
  };

  const handleDiagnosticarUsuarios = async () => {
    setLoadingDiagnostico(true);
    try {
      const response = await callServer('/debug/usuarios-especificos', 'GET');
      console.log('🔍 DIAGNÓSTICO DE USUARIOS:', response);
      
      let mensaje = `🔍 DIAGNÓSTICO DE USUARIOS ESPECÍFICOS\n\n`;
      mensaje += `Total en getAllUsers(): ${response.usuarios[0]?.totalUsuariosEnGetAllUsers || 'N/A'}\n\n`;
      
      response.usuarios.forEach((u: any, idx: number) => {
        mensaje += `${idx + 1}. ${u.idUnico}\n`;
        mensaje += `   Usuario ID: ${u.userId || 'N/A'}\n`;
        mensaje += `   Encontrado: ${u.encontrado ? 'SÍ' : 'NO'}\n`;
        if (u.encontrado) {
          mensaje += `   Nombre: ${u.nombreValor || 'N/A'}\n`;
          mensaje += `   Email: ${u.emailValor || 'N/A'}\n`;
          mensaje += `   Tiene nombre: ${u.tieneNombre ? 'SÍ' : 'NO'}\n`;
          mensaje += `   Tiene email: ${u.tieneEmail ? 'SÍ' : 'NO'}\n`;
          mensaje += `   Has colon (:): ${u.hasColon ? 'SÍ ❌' : 'NO ✅'}\n`;
          mensaje += `   Is valid UUID: ${u.isValidUUID ? 'SÍ ✅' : 'NO ❌'}\n`;
          mensaje += `   ✅ Pasaría filtro: ${u.pasariaFiltro ? 'SÍ' : 'NO'}\n`;
          mensaje += `   🎯 APARECE EN getAllUsers(): ${u.apareceEnGetAllUsers ? '✅ SÍ' : '❌ NO'}\n`;
        } else {
          mensaje += `   ❌ Error: ${u.error}\n`;
        }
        mensaje += `\n`;
      });
      
      mensaje += `\n💡 Ver consola para objeto completo`;
      
      setDiagnosticoData(mensaje);
      setIsDiagnosticoOpen(true);
      
    } catch (error) {
      console.error('Error en diagnstico:', error);
      toast.error('Error al diagnosticar usuarios');
    } finally {
      setLoadingDiagnostico(false);
    }
  };

  const handleDetectarPacksDuplicados = async () => {
    setLoadingPacks(true);
    try {
      console.log('🔍 Detectando usuarios con packs duplicados...');
      
      const response = await callServer('/admin/detectar-packs-duplicados', 'GET');
      console.log('📊 DETECCIÓN DE PACKS DUPLICADOS:', response);
      
      setPacksDuplicados(response);
      setIsPacksModalOpen(true);
      
      if (response.total > 0) {
        toast.success(`⚠️ Encontrados ${response.total} usuarios con packs duplicados`);
      } else {
        toast.success('✅ No se encontraron packs duplicados');
      }
      
    } catch (error) {
      console.error('Error en detección de packs duplicados:', error);
      toast.error('Error al detectar packs duplicados');
    } finally {
      setLoadingPacks(false);
    }
  };

  const handleDebugPacksIsrael = async () => {
    try {
      console.log('🔍 Solicitando debug de packs de Israel...');
      const response = await callServer('/debug/packs-israel', 'GET');
      console.log('📦 Debug de packs recibido:', response);
      
      let mensaje = `🔍 DEBUG: PACKS DE ISRAEL SANDOVAL\n\n`;
      mensaje += `📊 Total packs en sistema: ${response.totalPacksSistema}\n`;
      mensaje += `📦 Packs de Israel: ${response.packsIsrael}\n\n`;
      
      if (response.packs && response.packs.length > 0) {
        response.packs.forEach((pack: any, idx: number) => {
          mensaje += `${idx + 1}. ${pack.nombre} (ID: ${pack.id.substring(0, 8)}...)\n`;
          mensaje += `   Monto: $${pack.monto}\n`;
          mensaje += `   Rendimiento: $${pack.rendimientoAcumulado || 0}\n`;
          mensaje += `   Límite 200%: $${pack.limite200 || (pack.monto * 2)}\n`;
          mensaje += `   Porcentaje: ${pack.porcentaje || 0}%\n`;
          mensaje += `   Activo (bool): ${pack.activo}\n`;
          mensaje += `   Status (string): ${pack.status || 'sin campo'}\n`;
          mensaje += `   Fecha Compra: ${new Date(pack.fechaCompra).toLocaleDateString()}\n`;
          if (pack.fechaDesactivacion) {
            mensaje += `   Fecha Desactivación: ${new Date(pack.fechaDesactivacion).toLocaleDateString()}\n`;
            mensaje += `   Motivo: ${pack.motivoDesactivacion}\n`;
          }
          mensaje += `\n`;
        });
      } else {
        mensaje += 'No se encontraron packs para Israel.\n';
      }
      
      alert(mensaje);
      toast.success('✅ Debug de packs completado');
      
    } catch (error: any) {
      console.error('❌ Error al obtener debug de packs:', error);
      toast.error(`Error: ${error.message || 'No se pudo obtener el debug'}`);
    }
  };

  const handleDebugComisionesIsrael = async () => {
    try {
      console.log('🔍 Solicitando debug de comisiones de Israel...');
      const response = await callServer('/debug/comisiones-israel', 'GET');
      console.log('📊 Debug de comisiones recibido:', response);
      
      let mensaje = `🔍 DEBUG: COMISIONES DE ISRAEL SANDOVAL\n\n`;
      mensaje += `Total comisiones: ${response.totalComisiones}\n`;
      mensaje += `Monto total: $${response.montoTotal}\n`;
      mensaje += `Packs con comisiones: ${response.comisionesPorPack}\n`;
      mensaje += `Comisiones sin pack: ${response.comisionesSinPack}\n\n`;
      
      if (response.analisis && response.analisis.length > 0) {
        mensaje += `ANÁLISIS POR PACK:\n\n`;
        response.analisis.forEach((item: any, idx: number) => {
          mensaje += `${idx + 1}. Pack ID: ${item.packId.substring(0, 8)}...\n`;
          mensaje += `   Comisiones: ${item.totalComisiones}\n`;
          mensaje += `   Monto: $${item.montoTotal}\n`;
          mensaje += `   Pack existe: ${item.packExiste ? 'SÍ' : 'NO (HUÉRFANAS)'}\n`;
          if (item.packInfo) {
            mensaje += `   Info: ${item.packInfo.nombre} - $${item.packInfo.monto}\n`;
            mensaje += `   Activo: ${item.packInfo.activo} - Status: ${item.packInfo.status || 'N/A'}\n`;
          }
          mensaje += `\n`;
        });
      } else {
        mensaje += 'No se encontraron comisiones.\n';
      }
      
      alert(mensaje);
      toast.success('✅ Debug de comisiones completado');
      
    } catch (error: any) {
      console.error('❌ Error al obtener debug de comisiones:', error);
      toast.error(`Error: ${error.message || 'No se pudo obtener el debug'}`);
    }
  };

  const handleDebugComisionesDetalladoIsrael = async () => {
    try {
      console.log('🔬 Obteniendo diagnóstico detallado de comisiones...');
      const response = await callServer('/debug/comisiones-detallado-israel', 'GET');
      console.log('🔬 Diagnóstico detallado:', response);
      
      let mensaje = `🔬 DIAGNÓSTICO DETALLADO DE COMISIONES\\n\\n`;
      mensaje += `RESUMEN:\\n`;
      mensaje += `📊 Total comisiones: ${response.resumen.totalComisiones}\\n`;
      mensaje += `💵 Monto total: $${response.resumen.montoTotal}\\n`;
      mensaje += `📦 Total packs: ${response.resumen.totalPacks}\\n\\n`;
      
      mensaje += `DISTRIBUCIÓN:\\n`;
      mensaje += `✅ Con pack válido: ${response.resumen.comisionesConPackValido}\\n`;
      mensaje += `❌ Sin pack: ${response.resumen.comisionesSinPack}\\n`;
      mensaje += `⚠️ Pack inexistente: ${response.resumen.comisionesPackInexistente}\\n`;
      mensaje += `🚨 Duplicadas: ${response.resumen.comisionesDuplicadas}\\n\\n`;
      
      if (response.packs && response.packs.length > 0) {
        mensaje += `PACKS ACTUALES:\\n\\n`;
        response.packs.forEach((pack: any, idx: number) => {
          mensaje += `${idx + 1}. ${pack.nombre}\\n`;
          mensaje += `   ID: ${pack.packId}\\n`;
          mensaje += `   Original: $${pack.montoOriginal}\\n`;
          mensaje += `   Rendimiento DB: $${pack.rendimientoAcumulado}\\n`;
          mensaje += `   Comisiones asignadas: ${pack.cantidadComisiones}\\n`;
          mensaje += `   Monto en comisiones: $${pack.montoTotalComisiones}\\n`;
          mensaje += `   Estado: ${pack.activo ? 'ACTIVO' : 'INACTIVO'}\\n\\n`;
        });
      }
      
      if (response.resumen.comisionesDuplicadas > 0) {
        mensaje += `⚠️ PROBLEMA: ${response.resumen.comisionesDuplicadas} comisiones duplicadas!\\n`;
        mensaje += `Las mismas comisiones están asignadas a múltiples packs.\\n\\n`;
      }
      
      if (response.resumen.comisionesSinPack > 0) {
        mensaje += `⚠️ PROBLEMA: ${response.resumen.comisionesSinPack} comisiones sin pack!\\n\\n`;
      }
      
      if (response.resumen.comisionesPackInexistente > 0) {
        mensaje += `⚠️ PROBLEMA: ${response.resumen.comisionesPackInexistente} comisiones con pack inexistente!\\n\\n`;
      }
      
      alert(mensaje);
    } catch (error: any) {
      console.error('❌ Error al obtener diagnóstico detallado:', error);
      toast.error(`Error: ${error.message || 'No se pudo obtener el diagnóstico'}`);
    }
  };

  const handleDebugHistorialIsrael = async () => {
    try {
      console.log('🔍 Solicitando historial completo de packs de Israel...');
      const response = await callServer('/debug/historial-packs-israel', 'GET');
      console.log('📜 Historial de packs recibido:', response);
      
      let mensaje = `🔍 DEBUG: HISTORIAL COMPLETO DE ISRAEL\n\n`;
      mensaje += `Total comisiones: ${response.totalComisiones}\n`;
      mensaje += `Packs en historial: ${response.packsEnHistorial}\n`;
      mensaje += `Comisiones sin pack: ${response.comisionesSinPack}\n\n`;
      
      if (response.historial && response.historial.length > 0) {
        mensaje += `HISTORIAL DE PACKS:\n\n`;
        response.historial.forEach((item: any, idx: number) => {
          mensaje += `${idx + 1}. Pack ID: ${item.packId.substring(0, 8)}...\n`;
          mensaje += `   Existe: ${item.existe ? 'SÍ' : 'NO (ELIMINADO)'}\n`;
          if (item.packInfo) {
            mensaje += `   ${item.packInfo.nombre} - $${item.packInfo.monto}\n`;
            mensaje += `   Activo: ${item.packInfo.activo} - Status: ${item.packInfo.status || 'N/A'}\n`;
            if (item.packInfo.fechaDesactivacion) {
              mensaje += `   Desactivado: ${new Date(item.packInfo.fechaDesactivacion).toLocaleDateString()}\n`;
              mensaje += `   Motivo: ${item.packInfo.motivoDesactivacion}\n`;
            }
          }
          mensaje += `   Comisiones: ${item.totalComisiones}\n`;
          mensaje += `   Rendimiento: $${item.rendimientoAcumulado} (${item.porcentajeRendimiento}%)\n`;
          mensaje += `   Límite 200%: $${item.limite200}\n`;
          mensaje += `   Debería estar: ${item.deberiaEstarActivo ? 'ACTIVO' : 'INACTIVO'}\n`;
          mensaje += `\n`;
        });
      } else {
        mensaje += 'No se encontró historial de packs.\n';
      }
      
      alert(mensaje);
      toast.success('✅ Historial completo obtenido');
      
    } catch (error: any) {
      console.error('❌ Error al obtener historial:', error);
      toast.error(`Error: ${error.message || 'No se pudo obtener el historial'}`);
    }
  };

  const handleRepararIsrael = async () => {
    const confirmacion = confirm(
      '🔧 REPARACIÓN DE CUENTA DE ISRAEL\n\n' +
      'Esta acción va a:\n' +
      '1. Crear 3 nuevos packs ($50, $100, $200)\n' +
      '2. Redistribuir las 79 comisiones ($825.25)\n' +
      '3. Calcular automáticamente cuál pack llegó al 200%\n' +
      '4. Eliminar el pack corrupto\n\n' +
      '⏱️ Tiempo estimado: 1-2 minutos\n\n' +
      '¿Continuar?'
    );
    
    if (!confirmacion) return;
    
    try {
      console.log('🔧 Iniciando reparación de cuenta de Israel...');
      toast.info('🔧 Iniciando reparación... Esto puede tardar 1-2 minutos. Se reintentará automáticamente si hay errores de WebAssembly.', { duration: 5000 });
      
      // ⚡ NUEVA SOLUCIÓN: Usar sistema de reintentos automáticos para errores de WebAssembly
      const response = await ejecutarConReintentos(
        () => fetchAPI('/admin/reparar-cuenta-israel', { method: 'POST' }, 150000),
        { maxIntentos: 3, delayBase: 2000, limpiarCacheEnReintento: true }
      );
      
      console.log('✅ Reparación completada:', response);
      
      // Verificar si hay error
      if (!response.success) {
        throw new Error(response.error || 'Error desconocido');
      }
      
      let mensaje = `✅ REPARACIÓN EXITOSA\n\n`;
      mensaje += `⏱️ Duración: ${response.duration || 'N/A'}s\n`;
      mensaje += `⏰ Completado: ${new Date(response.timestamp).toLocaleString()}\n`;
      mensaje += `Comisiones reasignadas: ${response.comisionesReasignadas}\n`;
      mensaje += `Total: $${response.totalMonto}\n\n`;
      mensaje += `PACKS CREADOS:\n\n`;
      
      if (response.packsDetalle && Array.isArray(response.packsDetalle)) {
        response.packsDetalle.forEach((pack: any, idx: number) => {
          mensaje += `${idx + 1}. ${pack.nombre}\n`;
          mensaje += `   Monto original: $${pack.monto}\n`;
          mensaje += `   Rendimiento: $${pack.rendimientoAcumulado} (${pack.porcentaje}%)\n`;
          mensaje += `   Estado: ${pack.activo ? 'ACTIVO' : 'INACTIVO (llegó al 200%)'}\n`;
          mensaje += `   Comisiones: ${pack.comisiones}\n\n`;
        });
      }
      
      alert(mensaje);
      toast.success('✅ Cuenta de Israel reparada exitosamente');
      
      // Recargar usuarios
      await loadUsers();
      
    } catch (error: any) {
      console.error('❌ Error al reparar cuenta después de reintentos:', error);
      
      // Usar utilidad para obtener mensaje de error amigable
      const errorMsg = obtenerMensajeError(error);
      
      toast.error(`Error: ${errorMsg}`, { duration: 10000 });
    }
  };

  const handleVerPacksActualesIsrael = async () => {
    try {
      console.log('✅ Obteniendo packs actuales de Israel...');
      const response = await callServer('/debug/packs-israel', 'GET');
      console.log('📦 Packs actuales recibidos:', response);
      
      let mensaje = `✅ PACKS ACTUALES DE ISRAEL\n\n`;
      mensaje += `📊 Total packs en sistema: ${response.totalPacksSistema || 0}\n`;
      mensaje += `📦 Packs de Israel: ${response.packs?.length || 0}\n\n`;
      
      if (response.packs && response.packs.length > 0) {
        response.packs.forEach((pack: any, idx: number) => {
          mensaje += `${idx + 1}. ${pack.nombre || 'Sin nombre'}\n`;
          mensaje += `   ID: ${pack.id?.substring(0, 8)}...\n`;
          mensaje += `   Monto: $${pack.monto || 0}\n`;
          mensaje += `   Rendimiento: $${pack.rendimientoAcumulado || 0}\n`;
          mensaje += `   Límite 200%: $${pack.limite200 || (pack.monto * 2)}\n`;
          mensaje += `   Porcentaje: ${pack.porcentaje || 0}%\n`;
          mensaje += `   Estado: ${pack.activo ? '✅ ACTIVO' : '❌ INACTIVO'}\n`;
          mensaje += `   Status: ${pack.status || 'sin status'}\n`;
          mensaje += `   Fecha compra: ${pack.fechaCompra ? new Date(pack.fechaCompra).toLocaleDateString() : 'N/A'}\n\n`;
        });
      } else {
        mensaje += '⚠️ No se encontraron packs.\n';
      }
      
      alert(mensaje);
      toast.success('✅ Packs actuales obtenidos');
      
    } catch (error: any) {
      console.error('❌ Error al obtener packs actuales:', error);
      toast.error(`Error: ${error.message || 'No se pudo obtener los packs'}`);
    }
  };

  const handleDesactivarPack = async (packId: string, nombreUsuario: string, nombrePack: string) => {
    console.log('🎯 handleDesactivarPack LLAMADA con:', { packId, nombreUsuario, nombrePack });
    const confirmacion = confirm(
      `¿Estás seguro de desactivar el pack "${nombrePack}" del usuario ${nombreUsuario}?\n\nEsta acción NO se puede deshacer.`
    );
    
    if (!confirmacion) return;
    
    try {
      console.log(`🔒 Desactivando pack ${packId}...`);
      
      const response = await callServer(`/admin/desactivar-pack/${packId}`, 'POST');
      console.log('✅ Pack desactivado:', response);
      
      toast.success(`✅ Pack "${nombrePack}" desactivado correctamente`);
      
      // Si estamos en el modal de diagnóstico, recargar el diagnóstico
      if (selectedUser && isDiagnosticoOpen) {
        console.log('🔄 Recargando diagnóstico del usuario...');
        await handleDiagnosticoPacks(selectedUser);
      }
      
      // Recargar la detección de packs duplicados si está abierta
      if (isPacksModalOpen) {
        await handleDetectarPacksDuplicados();
      }
      
      // Recargar usuarios
      await loadUsers();
      
    } catch (error: any) {
      console.error('Error al desactivar pack:', error);
      toast.error(`Error: ${error.message || 'No se pudo desactivar el pack'}`);
    }
  };

  const filteredUsers = users.filter(user => 
    // REMOVIDO: Filtro de nombre && email - ahora mostramos TODOS
    (
      (user.nombre || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (user.apellido || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (user.id_unico || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (user.email || '').toLowerCase().includes(searchTerm.toLowerCase())
    )
  );

  const activeUsers = users.filter(u => u.activo).length;
  const inactiveUsers = users.filter(u => !u.activo).length;
  
  // Calcular nuevos usuarios del último mes
  const oneMonthAgo = new Date();
  oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1);
  const newUsers = users.filter(u => new Date(u.fechaRegistro) >= oneMonthAgo).length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl text-slate-800 mb-2">Gestión de Usuarios</h1>
          <p className="text-slate-600">Administra todos los usuarios del sistema</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Button 
            onClick={() => setIsResetConfirmOpen(true)}
            variant="outline"
            className="border-red-300 text-red-600 hover:bg-red-50"
          >
            <Trash2 className="w-4 h-4 mr-2" />
            Limpiar Todo
          </Button>
          <Button 
            onClick={handleDetectarPacksDuplicados}
            variant="outline"
            className="border-orange-300 text-orange-600 hover:bg-orange-50"
            disabled={loadingPacks}
          >
            <Package className="w-4 h-4 mr-2" />
            {loadingPacks ? 'Detectando...' : 'Detectar Packs Duplicados'}
          </Button>
          <Button 
            onClick={handleDebugPacksIsrael}
            variant="outline"
            className="border-purple-300 text-purple-600 hover:bg-purple-50"
          >
            🔬 Debug Packs Israel
          </Button>
          <Button 
            onClick={handleDebugComisionesIsrael}
            variant="outline"
            className="border-pink-300 text-pink-600 hover:bg-pink-50"
          >
            💰 Debug Comisiones Israel
          </Button>
          <Button 
            onClick={handleDebugComisionesDetalladoIsrael}
            variant="outline"
            className="border-rose-300 text-rose-600 hover:bg-rose-50"
          >
            🔬 Diagnóstico Detallado
          </Button>
          <Button 
            onClick={handleDebugHistorialIsrael}
            variant="outline"
            className="border-cyan-300 text-cyan-600 hover:bg-cyan-50"
          >
            📜 Historial Israel
          </Button>
          <Button 
            onClick={handleVerPacksActualesIsrael}
            variant="outline"
            className="border-emerald-300 text-emerald-600 hover:bg-emerald-50"
          >
            ✅ Packs Actuales
          </Button>
          <Button 
            onClick={handleRepararIsrael}
            className="bg-gradient-to-r from-green-600 to-emerald-500 hover:from-green-700 hover:to-emerald-600"
            title="Ejecuta reparación completa. Tiempo estimado: 1-2 minutos"
          >
            🔧 Reparar Israel (⏱️ 1-2min)
          </Button>
          <Button 
            onClick={() => handleOpenDialog()}
            className="bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600"
          >
            <UserPlus className="w-4 h-4 mr-2" />
            Nuevo Usuario
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="p-4 bg-white border-0 shadow-lg">
          <p className="text-slate-600 text-sm mb-1">Total Usuarios</p>
          <p className="text-2xl text-slate-800">{users.length}</p>
        </Card>
        <Card className="p-4 bg-white border-0 shadow-lg">
          <p className="text-slate-600 text-sm mb-1">Activos</p>
          <p className="text-2xl text-green-600">{activeUsers}</p>
        </Card>
        <Card className="p-4 bg-white border-0 shadow-lg">
          <p className="text-slate-600 text-sm mb-1">Inactivos</p>
          <p className="text-2xl text-red-600">{inactiveUsers}</p>
        </Card>
        <Card className="p-4 bg-white border-0 shadow-lg">
          <p className="text-slate-600 text-sm mb-1">Nuevos (mes)</p>
          <p className="text-2xl text-blue-600">{newUsers}</p>
        </Card>
      </div>

      {/* Search */}
      <Card className="p-6 bg-white border-0 shadow-lg">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <Input
            type="text"
            placeholder="Buscar por nombre, ID o email..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-12 h-12 rounded-xl border-slate-200"
          />
        </div>
      </Card>

      {/* Users Table */}
      <Card className="p-6 bg-white border-0 shadow-lg">
        {loading ? (
          <div className="text-center py-12">
            <p className="text-slate-600">Cargando usuarios...</p>
          </div>
        ) : filteredUsers.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-slate-600">No se encontraron usuarios</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-200">
                  <th className="text-left py-3 px-4 text-slate-600 text-sm">Usuario</th>
                  <th className="text-left py-3 px-4 text-slate-600 text-sm">Email</th>
                  <th className="text-left py-3 px-4 text-slate-600 text-sm">Contraseña</th>
                  <th className="text-left py-3 px-4 text-slate-600 text-sm">Teléfono</th>
                  <th className="text-left py-3 px-4 text-slate-600 text-sm">Referidos</th>
                  <th className="text-left py-3 px-4 text-slate-600 text-sm">Inversión</th>
                  <th className="text-left py-3 px-4 text-slate-600 text-sm">Comisiones</th>
                  <th className="text-left py-3 px-4 text-slate-600 text-sm">Estado</th>
                  <th className="text-left py-3 px-4 text-slate-600 text-sm">Acciones</th>
                </tr>
              </thead>
              <tbody>
                {filteredUsers.map((user, index) => (
                  <tr key={`${user.id}-${user.id_unico}-${index}`} className="border-b border-slate-100 hover:bg-slate-50 transition-colors">
                    <td className="py-4 px-4">
                      <div>
                        <p className="text-slate-800">{user.nombre} {user.apellido}</p>
                        <p className="text-sm text-slate-500">{user.id_unico}</p>
                      </div>
                    </td>
                    <td className="py-4 px-4 text-slate-600">{user.email}</td>
                    <td className="py-4 px-4">
                      <code className="text-xs bg-slate-100 px-2 py-1 rounded text-slate-800">
                        {user.password || 'N/A'}
                      </code>
                    </td>
                    <td className="py-4 px-4 text-slate-600">{user.telefono}</td>
                    <td className="py-4 px-4">
                      <span className="inline-flex items-center gap-1 text-blue-600">
                        <Users className="w-4 h-4" />
                        {user.referidosCount || 0}
                      </span>
                    </td>
                    <td className="py-4 px-4 text-slate-800">
                      ${(user.totalInversion || 0).toFixed(2)}
                    </td>
                    <td className="py-4 px-4 text-green-600">
                      ${(user.totalComisiones || 0).toFixed(2)}
                    </td>
                    <td className="py-4 px-4">
                      {user.activo ? (
                        <span className="flex items-center gap-1 text-green-600">
                          <CheckCircle className="w-4 h-4" />
                          <span className="text-sm">Activo</span>
                        </span>
                      ) : (
                        <span className="flex items-center gap-1 text-red-600">
                          <XCircle className="w-4 h-4" />
                          <span className="text-sm">Inactivo</span>
                        </span>
                      )}
                    </td>
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-2">
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="text-green-600 hover:bg-green-50"
                          onClick={() => {
                            console.log('Ver historial:', user.id);
                            loadUserHistorial(user);
                          }}
                          title="Ver historial completo"
                        >
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="text-purple-600 hover:bg-purple-50"
                          onClick={() => {
                            console.log('Diagnosticar inversión:', user.id);
                            handleDiagnosticoInversion(user);
                          }}
                          title="🔍 Diagnosticar Inversión"
                        >
                          <DollarSign className="w-4 h-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="text-indigo-600 hover:bg-indigo-50"
                          onClick={() => {
                            console.log('Diagnosticar packs:', user.id);
                            handleDiagnosticoPacks(user);
                          }}
                          title="📦 Diagnosticar Packs y Rendimientos"
                        >
                          <Package className="w-4 h-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="text-orange-600 hover:bg-orange-50"
                          onClick={() => {
                            console.log('Corregir distribución:', user.id);
                            handleCorregirDistribucion(user);
                          }}
                          title="🔧 Corregir Distribución de Comisiones"
                        >
                          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                          </svg>
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="text-blue-600 hover:bg-blue-50"
                          onClick={() => handleOpenDialog(user)}
                          title="Editar usuario"
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className={user.activo ? 'text-orange-600 hover:bg-orange-50' : 'text-green-600 hover:bg-green-50'}
                          onClick={() => {
                            console.log('Toggle activo:', user.id);
                            handleToggleActive(user);
                          }}
                          title={user.activo ? 'Desactivar usuario' : 'Activar usuario'}
                        >
                          {user.activo ? <XCircle className="w-4 h-4" /> : <CheckCircle className="w-4 h-4" />}
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="text-red-600 hover:bg-red-50"
                          onClick={() => {
                            console.log('Eliminar:', user.id);
                            setSelectedUser(user);
                            setIsDeleteDialogOpen(true);
                          }}
                          title="Eliminar usuario"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {/* Dialog para Crear/Editar Usuario */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>
              {editingUser ? 'Editar Usuario' : 'Nuevo Usuario'}
            </DialogTitle>
            <DialogDescription>
              {editingUser 
                ? 'Modifica los datos del usuario. Los campos vacíos no se actualizarán.'
                : 'Completa todos los campos para crear un nuevo usuario.'}
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={handleSubmit}>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="nombre">Nombre</Label>
                  <Input
                    id="nombre"
                    value={formData.nombre}
                    onChange={(e) => setFormData({ ...formData, nombre: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="apellido">Apellido</Label>
                  <Input
                    id="apellido"
                    value={formData.apellido}
                    onChange={(e) => setFormData({ ...formData, apellido: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  required
                  disabled={!!editingUser}
                />
                {editingUser && (
                  <p className="text-xs text-slate-500">El email no se puede modificar</p>
                )}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="telefono">Teléfono</Label>
                  <Input
                    id="telefono"
                    value={formData.telefono}
                    onChange={(e) => setFormData({ ...formData, telefono: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="wallet">Wallet USDT TRC20</Label>
                  <Input
                    id="wallet"
                    value={formData.wallet}
                    onChange={(e) => setFormData({ ...formData, wallet: e.target.value })}
                    required
                    placeholder="TXXXXXXXXXxxxxxxxxxxxxxx"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">
                  Contraseña {editingUser && '(dejar vacío para no cambiar)'}
                </Label>
                <Input
                  id="password"
                  type="password"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  required={!editingUser}
                  placeholder={editingUser ? 'Dejar vacío para mantener la actual' : 'Mínimo 8 caracteres'}
                  minLength={editingUser ? undefined : 8}
                />
              </div>
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={handleCloseDialog}>
                Cancelar
              </Button>
              <Button type="submit" className="bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600">
                {editingUser ? 'Guardar Cambios' : 'Crear Usuario'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Dialog de Historial del Usuario */}
      <Dialog open={isHistorialOpen} onOpenChange={setIsHistorialOpen}>
        <DialogContent className="sm:max-w-[900px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              Historial de {selectedUser?.nombre} {selectedUser?.apellido}
            </DialogTitle>
            <DialogDescription>
              ID: {selectedUser?.id_unico} | Email: {selectedUser?.email}
            </DialogDescription>
          </DialogHeader>

          {userHistorial && (
            <Tabs defaultValue="resumen" className="w-full">
              <TabsList className="grid w-full grid-cols-5">
                <TabsTrigger value="resumen">Resumen</TabsTrigger>
                <TabsTrigger value="referidos">Referidos</TabsTrigger>
                <TabsTrigger value="packs">Packs</TabsTrigger>
                <TabsTrigger value="comisiones">Comisiones</TabsTrigger>
                <TabsTrigger value="transacciones">Transacciones</TabsTrigger>
              </TabsList>

              <TabsContent value="resumen" className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <Card className="p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <Users className="w-5 h-5 text-blue-600" />
                      <p className="text-sm text-slate-600">Referidos Directos</p>
                    </div>
                    <p className="text-2xl text-slate-800">{userHistorial.referidosDirectos.length}</p>
                  </Card>
                  <Card className="p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <DollarSign className="w-5 h-5 text-green-600" />
                      <p className="text-sm text-slate-600">Total Inversión</p>
                    </div>
                    <p className="text-2xl text-slate-800">${userHistorial.totalInversion.toFixed(2)}</p>
                  </Card>
                  <Card className="p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <TrendingUp className="w-5 h-5 text-emerald-600" />
                      <p className="text-sm text-slate-600">Total Comisiones</p>
                    </div>
                    <p className="text-2xl text-slate-800">${userHistorial.totalComisiones.toFixed(2)}</p>
                  </Card>
                  <Card className="p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <Package className="w-5 h-5 text-purple-600" />
                      <p className="text-sm text-slate-600">Packs Activos</p>
                    </div>
                    <p className="text-2xl text-slate-800">{userHistorial.packs.filter((p: any) => p.activo).length}</p>
                  </Card>
                </div>

                {userHistorial.referidor && (
                  <Card className="p-4">
                    <p className="text-sm text-slate-600 mb-2">Referido por:</p>
                    <p className="text-slate-800">
                      {userHistorial.referidor.nombre} {userHistorial.referidor.apellido} ({userHistorial.referidor.id_unico})
                    </p>
                  </Card>
                )}
              </TabsContent>

              <TabsContent value="referidos" className="space-y-4">
                {userHistorial.referidosDirectos.length === 0 ? (
                  <p className="text-center text-slate-600 py-8">No tiene referidos directos</p>
                ) : (
                  <div className="space-y-2">
                    {userHistorial.referidosDirectos.map((ref: User) => (
                      <Card key={ref.id} className="p-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-slate-800">{ref.nombre} {ref.apellido}</p>
                            <p className="text-sm text-slate-500">{ref.id_unico} | {ref.email}</p>
                          </div>
                          <div className="text-right">
                            <p className="text-sm text-slate-600">
                              {new Date(ref.fechaRegistro).toLocaleDateString()}
                            </p>
                            <span className={`text-sm ${ref.activo ? 'text-green-600' : 'text-red-600'}`}>
                              {ref.activo ? 'Activo' : 'Inactivo'}
                            </span>
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>

              <TabsContent value="packs" className="space-y-4">
                {userHistorial.packs.length === 0 ? (
                  <p className="text-center text-slate-600 py-8">No tiene packs registrados</p>
                ) : (
                  <div className="space-y-2">
                    {userHistorial.packs.map((pack: any) => (
                      <Card key={pack.id} className="p-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-slate-800">{pack.nombre}</p>
                            <p className="text-sm text-slate-500">
                              Rendimiento: {pack.rendimientoDiario}% diario
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="text-lg text-slate-800">${pack.monto}</p>
                            <p className="text-sm text-slate-600">
                              {new Date(pack.fechaCompra).toLocaleDateString()}
                            </p>
                            <span className={`text-sm ${pack.activo ? 'text-green-600' : 'text-red-600'}`}>
                              {pack.activo ? 'Activo' : 'Inactivo'}
                            </span>
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>

              <TabsContent value="comisiones" className="space-y-4">
                {userHistorial.comisiones.length === 0 ? (
                  <p className="text-center text-slate-600 py-8">No tiene comisiones registradas</p>
                ) : (
                  <div className="space-y-2">
                    {userHistorial.comisiones.map((comision: any) => (
                      <Card key={comision.id} className="p-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-slate-800">{comision.descripcion}</p>
                            <p className="text-sm text-slate-500">
                              Tipo: {comision.tipo} {comision.nivel && `| Nivel: ${comision.nivel}`}
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="text-lg text-green-600">${comision.monto.toFixed(2)}</p>
                            <p className="text-sm text-slate-600">
                              {new Date(comision.fecha).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>

              <TabsContent value="transacciones" className="space-y-4">
                <div className="space-y-4">
                  <div>
                    <h3 className="text-sm text-slate-600 mb-2">Depósitos ({userHistorial.depositos.length})</h3>
                    {userHistorial.depositos.length === 0 ? (
                      <p className="text-center text-slate-500 py-4 text-sm">No hay depósitos</p>
                    ) : (
                      <div className="space-y-2">
                        {userHistorial.depositos.map((dep: any) => (
                          <Card key={dep.id} className="p-3">
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="text-sm text-slate-800">{dep.packNombre}</p>
                                <p className="text-xs text-slate-500">{new Date(dep.fecha).toLocaleDateString()}</p>
                              </div>
                              <div className="text-right">
                                <p className="text-sm text-slate-800">${dep.monto}</p>
                                <span className={`text-xs ${
                                  dep.estado === 'verificado' ? 'text-green-600' :
                                  dep.estado === 'rechazado' ? 'text-red-600' :
                                  'text-yellow-600'
                                }`}>
                                  {dep.estado}
                                </span>
                              </div>
                            </div>
                          </Card>
                        ))}
                      </div>
                    )}
                  </div>

                  <div>
                    <h3 className="text-sm text-slate-600 mb-2">Retiros ({userHistorial.cobros.length})</h3>
                    {userHistorial.cobros.length === 0 ? (
                      <p className="text-center text-slate-500 py-4 text-sm">No hay retiros</p>
                    ) : (
                      <div className="space-y-2">
                        {userHistorial.cobros.map((cobro: any) => (
                          <Card key={cobro.id} className="p-3">
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="text-sm text-slate-800">Retiro</p>
                                <p className="text-xs text-slate-500">{new Date(cobro.fecha).toLocaleDateString()}</p>
                              </div>
                              <div className="text-right">
                                <p className="text-sm text-slate-800">${cobro.monto}</p>
                                <span className={`text-xs ${
                                  cobro.estado === 'completado' ? 'text-green-600' :
                                  cobro.estado === 'aprobado' ? 'text-blue-600' :
                                  cobro.estado === 'rechazado' ? 'text-red-600' :
                                  'text-yellow-600'
                                }`}>
                                  {cobro.estado}
                                </span>
                              </div>
                            </div>
                          </Card>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          )}

          <DialogFooter>
            <Button onClick={() => setIsHistorialOpen(false)}>Cerrar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* AlertDialog para Confirmar Eliminación */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Estás seguro?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta acción desactivará permanentemente al usuario {selectedUser?.nombre} {selectedUser?.apellido}.
              No se podrán revertir los cambios.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setSelectedUser(null)}>Cancelar</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDeleteUser}
              className="bg-red-600 hover:bg-red-700"
            >
              Eliminar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* AlertDialog para Confirmar Reset */}
      <AlertDialog open={isResetConfirmOpen} onOpenChange={setIsResetConfirmOpen}>
        <AlertDialogContent className="sm:max-w-[500px] bg-white rounded-3xl border-0 shadow-2xl">
          <AlertDialogHeader className="space-y-6 pt-6">
            {/* Icono de advertencia */}
            <div className="mx-auto w-20 h-20 rounded-full bg-red-50 flex items-center justify-center">
              <Trash2 className="w-10 h-10 text-red-500" />
            </div>
            
            <AlertDialogTitle className="text-center text-2xl text-slate-800">
              ⚠️ ¿Estás completamente seguro?
            </AlertDialogTitle>
            
            <AlertDialogDescription className="text-center space-y-4 px-4" asChild>
              <div className="text-sm text-slate-600">
                <p>
                  Esta acción eliminará <span className="text-red-600 font-semibold">permanentemente</span> todos los datos de prueba:
                </p>
                
                <div className="bg-red-50 rounded-xl p-4 space-y-2 text-left">
                  <div className="flex items-center gap-2 text-sm text-slate-700">
                    <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                    <span>Todos los usuarios de prueba</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-slate-700">
                    <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                    <span>Todos los depósitos y retiros</span>
                  </div>
                </div>
                
                <div className="bg-green-50 rounded-xl p-4 text-left">
                  <div className="flex items-center gap-2 text-sm text-green-700">
                    <CheckCircle className="w-4 h-4" />
                    <span className="font-medium">Las cuentas de Admin y Desarrollador se mantendrán intactas</span>
                  </div>
                </div>
                
                <p className="text-sm text-red-600 font-medium">
                  ⚠️ Esta acción NO se puede deshacer
                </p>
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          
          <AlertDialogFooter className="flex gap-3 px-6 pb-6">
            <AlertDialogCancel 
              onClick={() => setIsResetConfirmOpen(false)}
              className="flex-1 h-12 rounded-xl border-slate-300 hover:bg-slate-100 text-slate-700"
            >
              Cancelar
            </AlertDialogCancel>
            <AlertDialogAction 
              onClick={async () => {
                try {
                  console.log('🔄 Iniciando limpieza de datos...');
                  
                  const data = await callServer('/dev/reset', 'POST');
                  
                  console.log('✅ Respuesta recibida:', data);
                  
                  toast.success(`✅ Proceso iniciado: Se eliminarán ${data.deleted.users} usuarios. Espera unos segundos...`);
                  setIsResetConfirmOpen(false);
                  
                  // Esperar 3 segundos y recargar
                  setTimeout(async () => {
                    await loadUsers();
                    toast.success('✅ Lista actualizada');
                  }, 3000);
                } catch (error: any) {
                  console.error('❌ Error completo:', error);
                  console.error('❌ Error message:', error.message);
                  
                  toast.error(`Error: ${error.message || 'No se pudo conectar con el servidor'}`);
                }
              }}
              className="flex-1 h-12 rounded-xl bg-gradient-to-r from-red-600 to-red-500 hover:from-red-700 hover:to-red-600 text-white shadow-lg"
            >
              Sí, eliminar todo
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Dialog para Diagnóstico de Usuarios */}
      <Dialog open={isDiagnosticoOpen} onOpenChange={setIsDiagnosticoOpen}>
        <DialogContent className="sm:max-w-[900px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              Diagnóstico de Usuarios
            </DialogTitle>
            <DialogDescription>
              Resultados del diagnóstico de usuarios específicos
            </DialogDescription>
          </DialogHeader>

          {loadingDiagnostico ? (
            <div className="text-center py-12">
              <p className="text-slate-600">Cargando diagnóstico...</p>
            </div>
          ) : diagnosticoData ? (
            <div className="space-y-4">
              {diagnosticoData.usuario && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <h3 className="font-semibold text-blue-900 mb-2">👤 Usuario</h3>
                  <p className="text-blue-800 text-sm">
                    {diagnosticoData.usuario.nombre} {diagnosticoData.usuario.apellido} ({diagnosticoData.usuario.id_unico})
                  </p>
                  <p className="text-blue-600 text-xs">{diagnosticoData.usuario.email}</p>
                </div>
              )}
              
              {diagnosticoData.resumen && (
                <div className="bg-slate-50 border border-slate-200 rounded-lg p-4">
                  <h3 className="font-semibold text-slate-900 mb-3">📊 Resumen Global</h3>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div>
                      <span className="text-slate-600">Total Packs:</span>
                      <span className="ml-2 font-semibold">{diagnosticoData.resumen.totalPacks}</span>
                    </div>
                    <div>
                      <span className="text-slate-600">Inversión Total:</span>
                      <span className="ml-2 font-semibold text-green-600">${diagnosticoData.resumen.inversionTotal}</span>
                    </div>
                    <div>
                      <span className="text-slate-600">Total Ganado:</span>
                      <span className="ml-2 font-semibold text-blue-600">${diagnosticoData.resumen.totalGanado}</span>
                    </div>
                    <div>
                      <span className="text-slate-600">Límite Total (200%):</span>
                      <span className="ml-2 font-semibold">${diagnosticoData.resumen.totalLimite}</span>
                    </div>
                    <div>
                      <span className="text-slate-600">Progreso Global:</span>
                      <span className="ml-2 font-semibold text-purple-600">{diagnosticoData.resumen.progresoGlobal}</span>
                    </div>
                    <div>
                      <span className="text-slate-600">Excedente:</span>
                      <span className="ml-2 font-semibold text-orange-600">${diagnosticoData.resumen.excedente}</span>
                    </div>
                  </div>
                </div>
              )}

              {diagnosticoData.diagnostico && (
                <div className={`border rounded-lg p-4 ${
                  diagnosticoData.diagnostico.problema === '✅ Todo parece correcto' 
                    ? 'bg-green-50 border-green-200' 
                    : 'bg-orange-50 border-orange-200'
                }`}>
                  <h3 className={`font-semibold mb-2 ${
                    diagnosticoData.diagnostico.problema === '✅ Todo parece correcto' 
                      ? 'text-green-900' 
                      : 'text-orange-900'
                  }`}>
                    🔬 Diagnóstico
                  </h3>
                  <p className={`text-sm mb-2 ${
                    diagnosticoData.diagnostico.problema === '✅ Todo parece correcto' 
                      ? 'text-green-800' 
                      : 'text-orange-800'
                  }`}>
                    {diagnosticoData.diagnostico.problema}
                  </p>
                  <div className="text-xs space-y-1">
                    <p className="text-slate-600">
                      Packs Completados: <span className="font-semibold">{diagnosticoData.diagnostico.packsCompletados}</span>
                    </p>
                    <p className="text-slate-600">
                      Packs Activos: <span className="font-semibold">{diagnosticoData.diagnostico.packsActivos}</span>
                    </p>
                  </div>
                </div>
              )}

              {diagnosticoData.packs && diagnosticoData.packs.length > 0 && (
                <div className="space-y-2">
                  <h3 className="font-semibold text-slate-900">📦 Detalles por Pack</h3>
                  {diagnosticoData.packs.map((pack: any, index: number) => (
                    <div 
                      key={pack.id} 
                      className={`border rounded-lg p-3 ${
                        pack.completado && pack.activo 
                          ? 'bg-red-50 border-red-300' 
                          : pack.activo 
                            ? 'bg-green-50 border-green-300' 
                            : 'bg-slate-50 border-slate-200'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div>
                          <h4 className="font-semibold text-sm">
                            {pack.nombre} - ${pack.monto}
                          </h4>
                          <p className="text-xs text-slate-600">
                            {new Date(pack.fechaCompra).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className={`text-xs px-2 py-1 rounded-full ${
                            pack.activo 
                              ? 'bg-green-600 text-white' 
                              : 'bg-slate-300 text-slate-700'
                          }`}>
                            {pack.activo ? '✓ Activo' : 'Inactivo'}
                          </span>
                          {pack.activo && (
                            <Button
                              size="sm"
                              variant="outline"
                              className="h-6 px-2 text-xs border-red-300 text-red-600 hover:bg-red-50 hover:text-red-700"
                              onClick={() => {
                                console.log('🔒 CLICK EN DESACTIVAR PACK:', pack.id, pack.nombre);
                                console.log('selectedUser:', selectedUser);
                                if (selectedUser) {
                                  console.log('✅ selectedUser existe, llamando handleDesactivarPack...');
                                  handleDesactivarPack(
                                    pack.id,
                                    `${diagnosticoData?.usuario?.nombre || ''} ${diagnosticoData?.usuario?.apellido || ''}`,
                                    pack.nombre
                                  );
                                } else {
                                  console.error('❌ selectedUser es null/undefined');
                                }
                              }}
                            >
                              🔒 Desactivar
                            </Button>
                          )}
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        <div>
                          <span className="text-slate-600">Rendimiento:</span>
                          <span className="ml-1 font-semibold">${pack.rendimientoTotal}</span>
                        </div>
                        <div>
                          <span className="text-slate-600">Límite (200%):</span>
                          <span className="ml-1 font-semibold">${pack.limite200}</span>
                        </div>
                        <div>
                          <span className="text-slate-600">Progreso:</span>
                          <span className="ml-1 font-semibold text-purple-600">{pack.progreso}</span>
                        </div>
                        <div>
                          <span className="text-slate-600">Falta:</span>
                          <span className="ml-1 font-semibold text-orange-600">${pack.falta}</span>
                        </div>
                      </div>
                      {pack.completado && pack.activo && (
                        <div className="mt-2 text-xs text-red-600 font-semibold">
                          ⚠️ Este pack está activo pero ya completó el 200%
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
              
              {diagnosticoData.correccion && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <h3 className="font-semibold text-green-900 mb-2">✅ Corrección Aplicada</h3>
                  <div className="text-sm space-y-1 text-green-800">
                    <p>Comisiones actualizadas: <span className="font-semibold">{diagnosticoData.correccion.comisionesActualizadas}</span></p>
                    <p>Packs completados: <span className="font-semibold">{diagnosticoData.correccion.packsActualizados}</span></p>
                  </div>
                </div>
              )}
              
              <details className="text-xs">
                <summary className="cursor-pointer text-slate-500 hover:text-slate-700">Ver JSON completo</summary>
                <pre className="text-xs text-slate-600 whitespace-pre-wrap bg-slate-50 p-4 rounded mt-2 max-h-64 overflow-y-auto border border-slate-200">
                  {typeof diagnosticoData === 'string' ? diagnosticoData : JSON.stringify(diagnosticoData, null, 2)}
                </pre>
              </details>
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-slate-600">No hay datos de diagnóstico disponibles</p>
            </div>
          )}

          <DialogFooter className="gap-2">
            {diagnosticoData && diagnosticoData.diagnostico && diagnosticoData.diagnostico.problema && diagnosticoData.diagnostico.problema !== '✅ Todo parece correcto' && selectedUser && (
              <Button 
                onClick={() => {
                  console.log('🔧 CLICK EN CORREGIR DISTRIBUCIÓN');
                  console.log('selectedUser:', selectedUser);
                  console.log('loadingDiagnostico:', loadingDiagnostico);
                  handleCorregirDistribucion(selectedUser);
                }}
                disabled={loadingDiagnostico}
                className="bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-700 hover:to-orange-600 text-white"
              >
                🔧 Corregir Distribución
              </Button>
            )}
            <Button onClick={() => setIsDiagnosticoOpen(false)}>Cerrar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog para Packs Duplicados */}
      <Dialog open={isPacksModalOpen} onOpenChange={setIsPacksModalOpen}>
        <DialogContent className="sm:max-w-[1000px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Package className="w-6 h-6 text-orange-600" />
              Detección de Packs Duplicados
            </DialogTitle>
            <DialogDescription>
              {packsDuplicados && packsDuplicados.total > 0 
                ? `Se encontraron ${packsDuplicados.total} usuario(s) con packs duplicados. Los usuarios solo deben tener 1 pack activo.`
                : 'Verificando usuarios con múltiples packs activos...'}
            </DialogDescription>
          </DialogHeader>

          {loadingPacks ? (
            <div className="text-center py-12">
              <div className="animate-pulse space-y-4">
                <Package className="w-12 h-12 text-orange-400 mx-auto" />
                <p className="text-slate-600">Analizando usuarios...</p>
              </div>
            </div>
          ) : packsDuplicados && packsDuplicados.total > 0 ? (
            <div className="space-y-6">
              {/* Resumen */}
              <Card className="p-4 bg-gradient-to-r from-orange-50 to-amber-50 border-orange-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-slate-600">Total usuarios afectados</p>
                    <p className="text-3xl text-orange-600">{packsDuplicados.total}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-slate-600">Total usuarios</p>
                    <p className="text-2xl text-slate-800">{packsDuplicados.resumen?.totalUsuarios || 0}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-slate-600">% Afectado</p>
                    <p className="text-2xl text-red-600">{packsDuplicados.resumen?.porcentajeAfectado || 0}%</p>
                  </div>
                </div>
              </Card>

              {/* Lista de usuarios con packs duplicados */}
              <div className="space-y-6">
                {packsDuplicados.usuarios?.map((userData: any, idx: number) => (
                  <Card key={userData.usuario.id} className="p-6 border-2 border-orange-200">
                    {/* Header del usuario */}
                    <div className="flex items-start justify-between mb-4 pb-4 border-b border-slate-200">
                      <div>
                        <h3 className="text-lg text-slate-800">
                          {userData.usuario.nombre} {userData.usuario.apellido}
                        </h3>
                        <p className="text-sm text-slate-500">{userData.usuario.id_unico}</p>
                        <p className="text-sm text-slate-500">{userData.usuario.email}</p>
                      </div>
                      <div className="text-right">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="text-sm text-slate-600">Packs activos:</span>
                          <span className="px-3 py-1 bg-red-100 text-red-700 rounded-full text-sm">
                            {userData.packsActivos}
                          </span>
                        </div>
                        <p className="text-sm text-slate-600">
                          Inversión total: <span className="text-orange-600">${userData.inversionTotal}</span>
                        </p>
                        <p className="text-sm text-slate-600">
                          Inversión correcta: <span className="text-green-600">${userData.inversionCorrecta}</span>
                        </p>
                        <p className="text-sm text-red-600">
                          Exceso: ${userData.exceso}
                        </p>
                      </div>
                    </div>

                    {/* Lista de packs */}
                    <div className="space-y-3">
                      {userData.packs?.map((pack: any, packIdx: number) => (
                        <div 
                          key={pack.id} 
                          className={`p-4 rounded-lg border-2 ${
                            pack.deberiaMantenerse 
                              ? 'bg-green-50 border-green-300' 
                              : 'bg-red-50 border-red-300'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-3 mb-2">
                                {pack.deberiaMantenerse ? (
                                  <CheckCircle className="w-5 h-5 text-green-600" />
                                ) : (
                                  <XCircle className="w-5 h-5 text-red-600" />
                                )}
                                <div>
                                  <p className="text-slate-800">
                                    {pack.nombre} - ${pack.monto}
                                  </p>
                                  <p className="text-sm text-slate-500">
                                    Fecha: {new Date(pack.fechaCompra).toLocaleDateString('es-ES', {
                                      year: 'numeric',
                                      month: 'long',
                                      day: 'numeric',
                                      hour: '2-digit',
                                      minute: '2-digit'
                                    })}
                                  </p>
                                  <p className="text-xs text-slate-400 mt-1">
                                    ID: {pack.id}
                                  </p>
                                </div>
                              </div>
                              
                              {pack.deberiaMantenerse ? (
                                <div className="flex items-center gap-2 mt-2">
                                  <span className="px-3 py-1 bg-green-200 text-green-800 rounded-full text-xs">
                                    ✅ Pack más antiguo - MANTENER
                                  </span>
                                </div>
                              ) : (
                                <div className="flex items-center gap-2 mt-2">
                                  <span className="px-3 py-1 bg-red-200 text-red-800 rounded-full text-xs">
                                    ❌ Pack duplicado - DEBE ELIMINARSE
                                  </span>
                                </div>
                              )}
                            </div>

                            <div className="ml-4">
                              {pack.deberiaMantenerse ? (
                                <Button
                                  variant="outline"
                                  size="sm"
                                  disabled
                                  className="border-green-300 text-green-600 cursor-not-allowed"
                                >
                                  <CheckCircle className="w-4 h-4 mr-2" />
                                  Mantener
                                </Button>
                              ) : (
                                <Button
                                  variant="destructive"
                                  size="sm"
                                  onClick={() => handleDesactivarPack(
                                    pack.id, 
                                    `${userData.usuario.nombre} ${userData.usuario.apellido}`,
                                    pack.nombre
                                  )}
                                  className="bg-red-600 hover:bg-red-700"
                                >
                                  <Trash2 className="w-4 h-4 mr-2" />
                                  Eliminar
                                </Button>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          ) : packsDuplicados && packsDuplicados.total === 0 ? (
            <div className="text-center py-12">
              <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
              <p className="text-slate-800 text-lg mb-2">¡Todo está en orden!</p>
              <p className="text-slate-600">No se encontraron usuarios con packs duplicados</p>
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-slate-600">No hay datos disponibles</p>
            </div>
          )}

          <DialogFooter>
            <Button 
              onClick={() => setIsPacksModalOpen(false)}
              variant="outline"
            >
              Cerrar
            </Button>
            {packsDuplicados && packsDuplicados.total > 0 && (
              <Button 
                onClick={handleDetectarPacksDuplicados}
                className="bg-orange-600 hover:bg-orange-700"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Actualizar
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Custom Dialog Component */}
      <DialogComponent />
    </div>
  );
}