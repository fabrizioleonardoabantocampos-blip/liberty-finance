import { useState, useEffect } from 'react';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Trophy, Plus, Edit2, Trash2, Save, X, Upload } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { rangosAPI } from '../../utils/api';
import { ImageWithFallback } from '../figma/ImageWithFallback';

interface Rango {
  id: string;
  nombre: string;
  directos: number;
  volumen: number;
  premio: string;
  color: string;
  gradient: string;
  icon: string;
  imagen: string;
}

export function GestionarRangos() {
  const [rangos, setRangos] = useState<Rango[]>([]);
  const [loading, setLoading] = useState(false);
  const [editando, setEditando] = useState<string | null>(null);
  const [creando, setCreando] = useState(false);
  const [formData, setFormData] = useState({
    nombre: '',
    directos: 0,
    volumen: 0,
    premio: '',
    color: 'slate',
    gradient: 'from-slate-400 to-slate-600',
    icon: '🥈',
    imagen: ''
  });
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [uploadingImage, setUploadingImage] = useState(false);

  useEffect(() => {
    cargarRangos();
  }, []);

  const cargarRangos = async () => {
    setLoading(true);
    try {
      let data = await rangosAPI.getAll();
      
      // Si no hay rangos, inicializar los rangos por defecto
      if (data.length === 0) {
        console.log('⚙️  No hay rangos, inicializando rangos por defecto...');
        data = await rangosAPI.init();
        toast.success('Rangos inicializados correctamente');
      }
      
      setRangos(data);
    } catch (error) {
      console.error('Error al cargar rangos:', error);
      toast.error('Error al cargar los rangos');
    } finally {
      setLoading(false);
    }
  };

  const handleCrear = () => {
    setCreando(true);
    setFormData({
      nombre: '',
      directos: 0,
      volumen: 0,
      premio: '',
      color: 'slate',
      gradient: 'from-slate-400 to-slate-600',
      icon: '🥈',
      imagen: ''
    });
  };

  const handleEditar = (rango: Rango) => {
    setEditando(rango.id);
    setFormData(rango);
  };

  const handleCancelar = () => {
    setEditando(null);
    setCreando(false);
    setFormData({
      nombre: '',
      directos: 0,
      volumen: 0,
      premio: '',
      color: 'slate',
      gradient: 'from-slate-400 to-slate-600',
      icon: '🥈',
      imagen: ''
    });
  };

  const handleGuardar = async () => {
    try {
      if (!formData.nombre || !formData.directos || !formData.volumen || !formData.premio) {
        toast.error('Por favor completa todos los campos obligatorios');
        return;
      }

      if (creando) {
        await rangosAPI.create(formData as Omit<Rango, 'id'>);
        toast.success('Rango creado exitosamente');
      } else if (editando) {
        await rangosAPI.update(editando, formData);
        toast.success('Rango actualizado exitosamente');
      }

      await cargarRangos();
      handleCancelar();
    } catch (error) {
      console.error('Error al guardar rango:', error);
      toast.error('Error al guardar el rango');
    }
  };

  const handleEliminar = async (id: string) => {
    if (!confirm('¿Estás seguro de eliminar este rango?')) return;

    try {
      await rangosAPI.delete(id);
      toast.success('Rango eliminado exitosamente');
      await cargarRangos();
    } catch (error) {
      console.error('Error al eliminar rango:', error);
      toast.error('Error al eliminar el rango');
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validar tipo de archivo
    if (!file.type.startsWith('image/')) {
      toast.error('Por favor selecciona un archivo de imagen válido');
      return;
    }

    // Validar tamaño (máximo 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast.error('La imagen no debe superar los 5MB');
      return;
    }

    setUploadingImage(true);
    try {
      // Convertir a base64
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        setFormData({ ...formData, imagen: base64String });
        toast.success('Imagen cargada exitosamente');
        setUploadingImage(false);
      };
      reader.onerror = () => {
        toast.error('Error al leer la imagen');
        setUploadingImage(false);
      };
      reader.readAsDataURL(file);
    } catch (error) {
      console.error('Error al subir imagen:', error);
      toast.error('Error al subir la imagen');
      setUploadingImage(false);
    }
  };

  const handleIconUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validar tipo de archivo
    if (!file.type.startsWith('image/')) {
      toast.error('Por favor selecciona un archivo de imagen válido');
      return;
    }

    // Validar tamaño (máximo 2MB para iconos)
    if (file.size > 2 * 1024 * 1024) {
      toast.error('El icono no debe superar los 2MB');
      return;
    }

    try {
      // Convertir a base64
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        setFormData({ ...formData, icon: base64String });
        toast.success('Icono cargado exitosamente');
      };
      reader.onerror = () => {
        toast.error('Error al leer el icono');
      };
      reader.readAsDataURL(file);
    } catch (error) {
      console.error('Error al subir icono:', error);
      toast.error('Error al subir el icono');
    }
  };

  const colores = [
    { nombre: 'Plata', color: 'slate', gradient: 'from-slate-400 to-slate-600' },
    { nombre: 'Oro', color: 'yellow', gradient: 'from-yellow-400 to-yellow-600' },
    { nombre: 'Naranja', color: 'orange', gradient: 'from-orange-400 to-orange-600' },
    { nombre: 'Rojo', color: 'red', gradient: 'from-red-500 to-red-700' },
    { nombre: 'Cian', color: 'cyan', gradient: 'from-cyan-400 to-cyan-600' },
    { nombre: 'Azul', color: 'blue', gradient: 'from-blue-500 to-blue-700' },
    { nombre: 'Gris', color: 'gray', gradient: 'from-gray-700 to-gray-900' },
    { nombre: 'Púrpura', color: 'purple', gradient: 'from-purple-700 to-purple-900' },
  ];

  const iconos = ['🥈', '🥇', '🏅', '🎖️', '💎', '👑', '⭐', '🔥'];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-600 to-purple-700 flex items-center justify-center shadow-lg">
            <Trophy className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-3xl text-slate-800">Gestionar Rangos</h1>
            <p className="text-slate-600">Configura los rangos y categorías del sistema</p>
          </div>
        </div>
        
        {!creando && !editando && (
          <Button onClick={handleCrear} className="gap-2">
            <Plus className="w-4 h-4" />
            Nuevo Rango
          </Button>
        )}
      </div>

      {/* Formulario de Creación/Edición */}
      {(creando || editando) && (
        <Card className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl text-slate-800">
              {creando ? 'Crear Nuevo Rango' : 'Editar Rango'}
            </h3>
            <div className="flex gap-2">
              <Button onClick={handleGuardar} className="gap-2">
                <Save className="w-4 h-4" />
                Guardar
              </Button>
              <Button onClick={handleCancelar} variant="outline" className="gap-2">
                <X className="w-4 h-4" />
                Cancelar
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Columna Izquierda */}
            <div className="space-y-4">
              <div>
                <Label>Nombre del Rango *</Label>
                <Input
                  value={formData.nombre}
                  onChange={(e) => setFormData({ ...formData, nombre: e.target.value })}
                  placeholder="Ej: Gold, Platinum, Diamond"
                />
              </div>

              <div>
                <Label>Referidos Directos Requeridos *</Label>
                <Input
                  type="number"
                  value={formData.directos}
                  onChange={(e) => setFormData({ ...formData, directos: parseInt(e.target.value) || 0 })}
                  placeholder="Ej: 5"
                />
              </div>

              <div>
                <Label>Volumen de Red Requerido (USDT) *</Label>
                <Input
                  type="number"
                  value={formData.volumen}
                  onChange={(e) => setFormData({ ...formData, volumen: parseInt(e.target.value) || 0 })}
                  placeholder="Ej: 10000"
                />
              </div>

              <div>
                <Label>Premio *</Label>
                <Input
                  value={formData.premio}
                  onChange={(e) => setFormData({ ...formData, premio: e.target.value })}
                  placeholder="Ej: Viaje a Dubai, Bono $500"
                />
              </div>
            </div>

            {/* Columna Derecha */}
            <div className="space-y-4">
              <div>
                <Label>Color del Rango</Label>
                <div className="space-y-3 mt-2">
                  {/* Colores predeterminados */}
                  <div>
                    <p className="text-xs text-slate-600 mb-2">Colores predeterminados:</p>
                    <div className="grid grid-cols-4 gap-2">
                      {colores.map((color) => (
                        <button
                          key={color.color}
                          type="button"
                          onClick={() => setFormData({ ...formData, color: color.color, gradient: color.gradient })}
                          className={`p-3 rounded-lg bg-gradient-to-br ${color.gradient} text-white text-xs transition-all ${
                            formData.color === color.color ? 'ring-2 ring-slate-800 scale-105' : 'opacity-70 hover:opacity-100'
                          }`}
                          title={color.nombre}
                        >
                          {color.nombre}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Color personalizado con paleta completa */}
                  <div className="pt-2 border-t border-slate-200">
                    <p className="text-xs text-slate-600 mb-2">O elige un color personalizado:</p>
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <input
                          type="color"
                          value={formData.color.startsWith('#') ? formData.color : '#6b7280'}
                          onChange={(e) => {
                            const hexColor = e.target.value;
                            setFormData({ 
                              ...formData, 
                              color: hexColor, 
                              gradient: `from-[${hexColor}] to-[${hexColor}CC]` 
                            });
                          }}
                          className="w-20 h-12 rounded-lg cursor-pointer border-2 border-slate-300 hover:border-slate-400 transition-colors"
                          title="Selecciona un color personalizado"
                        />
                      </div>
                      <div className="flex-1">
                        <Input
                          type="text"
                          value={formData.color}
                          onChange={(e) => {
                            const value = e.target.value;
                            setFormData({ 
                              ...formData, 
                              color: value,
                              gradient: value.startsWith('#') 
                                ? `from-[${value}] to-[${value}CC]` 
                                : formData.gradient
                            });
                          }}
                          placeholder="#6b7280 o nombre del color"
                          className="h-12"
                        />
                      </div>
                    </div>
                    <p className="text-xs text-slate-500 mt-1">
                      Haz clic en el cuadro de color para abrir la paleta completa
                    </p>
                    {/* Vista previa del color seleccionado */}
                    {formData.color && (
                      <div className="mt-2 p-3 rounded-lg bg-slate-50 border border-slate-200">
                        <p className="text-xs text-slate-600 mb-2">Vista previa del color:</p>
                        <div 
                          className={`h-8 rounded-lg ${
                            formData.color.startsWith('#') || formData.color.startsWith('rgb')
                              ? ''
                              : `bg-gradient-to-br ${formData.gradient}`
                          }`}
                          style={
                            formData.color.startsWith('#') || formData.color.startsWith('rgb')
                              ? { background: `linear-gradient(to bottom right, ${formData.color}, ${formData.color}CC)` }
                              : undefined
                          }
                        />
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div>
                <Label>Icono</Label>
                <div className="space-y-3 mt-2">
                  {/* Emojis predefinidos */}
                  <div>
                    <p className="text-xs text-slate-600 mb-2">Selecciona un emoji:</p>
                    <div className="grid grid-cols-4 gap-2">
                      {iconos.map((icono) => (
                        <button
                          key={icono}
                          type="button"
                          onClick={() => setFormData({ ...formData, icon: icono })}
                          className={`p-3 rounded-lg border-2 text-2xl transition-all ${
                            formData.icon === icono
                              ? 'border-blue-600 bg-blue-50 scale-110'
                              : 'border-slate-200 hover:border-slate-300'
                          }`}
                        >
                          {icono}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Subir icono personalizado */}
                  <div className="pt-2 border-t border-slate-200">
                    <p className="text-xs text-slate-600 mb-2">O sube tu propio icono:</p>
                    <label htmlFor="icon-upload" className="relative cursor-pointer inline-flex items-center gap-2 px-4 py-2 border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors">
                      <Upload className="w-4 h-4 text-slate-600" />
                      <span className="text-sm text-slate-700">
                        Subir Icono Personalizado
                      </span>
                      <input
                        id="icon-upload"
                        type="file"
                        accept="image/*"
                        onChange={handleIconUpload}
                        className="sr-only"
                      />
                    </label>
                    <p className="text-xs text-slate-500 mt-1">
                      Máximo 2MB - PNG transparente recomendado (256x256px)
                    </p>
                  </div>

                  {/* Vista previa del icono si es una imagen */}
                  {formData.icon && formData.icon.startsWith('data:image') && (
                    <div className="pt-2">
                      <p className="text-xs text-slate-600 mb-2">Vista previa del icono:</p>
                      <div className="inline-flex items-center gap-3 p-3 bg-slate-50 rounded-lg border border-slate-200">
                        <ImageWithFallback
                          src={formData.icon}
                          alt="Icon Preview"
                          className="w-12 h-12 object-contain"
                        />
                        <button
                          type="button"
                          onClick={() => setFormData({ ...formData, icon: '🥈' })}
                          className="text-xs text-red-600 hover:text-red-700 underline"
                        >
                          Eliminar
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <div>
                <Label>URL de Imagen de Fondo</Label>
                <Input
                  value={formData.imagen}
                  onChange={(e) => setFormData({ ...formData, imagen: e.target.value })}
                  placeholder="https://..."
                />
                <p className="text-xs text-slate-500 mt-1">
                  Recomendado: Imagen de Unsplash o similar (1920x1080)
                </p>
              </div>

              {/* Cargar Imagen como Archivo */}
              <div>
                <Label>O cargar imagen desde tu computadora</Label>
                <div className="mt-2">
                  <label htmlFor="file-upload" className={`relative cursor-pointer inline-flex items-center gap-2 px-4 py-2 border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors ${uploadingImage ? 'opacity-50 pointer-events-none' : ''}`}>
                    <Upload className="w-4 h-4 text-slate-600" />
                    <span className="text-sm text-slate-700">
                      {uploadingImage ? 'Subiendo...' : 'Seleccionar imagen'}
                    </span>
                    <input
                      id="file-upload"
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      disabled={uploadingImage}
                      className="sr-only"
                    />
                  </label>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  Máximo 5MB - JPG, PNG, WEBP
                </p>
              </div>

              {/* Vista Previa */}
              {formData.imagen && (
                <div>
                  <Label>Vista Previa</Label>
                  <div className="mt-2 relative overflow-hidden rounded-lg h-32">
                    <ImageWithFallback
                      src={formData.imagen}
                      alt="Preview"
                      className="w-full h-full object-cover"
                    />
                    {/* Overlay con gradiente - usar inline styles para colores personalizados */}
                    <div 
                      className={`absolute inset-0 opacity-40 ${
                        formData.color.startsWith('#') || formData.color.startsWith('rgb')
                          ? ''
                          : `bg-gradient-to-br ${formData.gradient}`
                      }`}
                      style={
                        formData.color.startsWith('#') || formData.color.startsWith('rgb')
                          ? { background: `linear-gradient(to bottom right, ${formData.color}, ${formData.color}CC)` }
                          : undefined
                      }
                    ></div>
                    <div className="absolute inset-0 flex items-center justify-center">
                      {formData.icon.startsWith('data:image') ? (
                        <div className="w-16 h-16 rounded-xl bg-white/30 backdrop-blur-sm flex items-center justify-center border-2 border-white/50">
                          <ImageWithFallback
                            src={formData.icon}
                            alt="Icon Preview"
                            className="w-12 h-12 object-contain"
                          />
                        </div>
                      ) : (
                        <span className="text-4xl">{formData.icon}</span>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </Card>
      )}

      {/* Lista de Rangos */}
      {!creando && !editando && (
        <div className="space-y-4">
          {loading ? (
            <Card className="p-8 text-center">
              <p className="text-slate-600">Cargando rangos...</p>
            </Card>
          ) : rangos.length === 0 ? (
            <Card className="p-8 text-center">
              <Trophy className="w-16 h-16 text-slate-300 mx-auto mb-4" />
              <p className="text-slate-600 mb-4">No hay rangos configurados</p>
              <Button onClick={handleCrear} className="gap-2">
                <Plus className="w-4 h-4" />
                Crear Primer Rango
              </Button>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {rangos.map((rango) => (
                <Card key={rango.id} className="relative overflow-hidden">
                  {/* Imagen de Fondo */}
                  <div className="absolute inset-0 z-0">
                    <ImageWithFallback
                      src={rango.imagen}
                      alt={rango.nombre}
                      className="w-full h-full object-cover"
                    />
                    {/* Overlay con gradiente - usar inline styles para colores personalizados */}
                    <div 
                      className={`absolute inset-0 opacity-50 ${
                        rango.color.startsWith('#') || rango.color.startsWith('rgb')
                          ? ''
                          : `bg-gradient-to-br ${rango.gradient}`
                      }`}
                      style={
                        rango.color.startsWith('#') || rango.color.startsWith('rgb')
                          ? { background: `linear-gradient(to bottom right, ${rango.color}, ${rango.color}CC)` }
                          : undefined
                      }
                    ></div>
                  </div>

                  {/* Contenido */}
                  <div className="relative z-10 p-5">
                    <div className="flex items-start justify-between mb-4">
                      <div className="w-12 h-12 rounded-xl bg-white/30 backdrop-blur-sm flex items-center justify-center text-2xl border-2 border-white/50">
                        {rango.icon.startsWith('data:image') ? (
                          <ImageWithFallback
                            src={rango.icon}
                            alt={`${rango.nombre} icon`}
                            className="w-10 h-10 object-contain"
                          />
                        ) : (
                          <span className="text-2xl">{rango.icon}</span>
                        )}
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleEditar(rango)}
                          className="w-8 h-8 rounded-lg bg-white/90 backdrop-blur-sm flex items-center justify-center hover:bg-white transition-colors"
                        >
                          <Edit2 className="w-4 h-4 text-blue-600" />
                        </button>
                        <button
                          onClick={() => handleEliminar(rango.id)}
                          className="w-8 h-8 rounded-lg bg-white/90 backdrop-blur-sm flex items-center justify-center hover:bg-white transition-colors"
                        >
                          <Trash2 className="w-4 h-4 text-red-600" />
                        </button>
                      </div>
                    </div>

                    <h3 className="text-white text-xl drop-shadow-lg mb-3">{rango.nombre}</h3>

                    <div className="space-y-2 mb-3">
                      <div className="flex items-center gap-2 text-sm text-white drop-shadow">
                        👥 {rango.directos} Referidos Directos
                      </div>
                      <div className="flex items-center gap-2 text-sm text-white drop-shadow">
                        💰 ${rango.volumen.toLocaleString()} Volumen
                      </div>
                    </div>

                    <div className="p-3 rounded-lg bg-white/90 backdrop-blur-sm border border-white/50">
                      <p className="text-xs text-slate-600 mb-1">Premio</p>
                      <p className="text-sm text-slate-800">🎁 {rango.premio}</p>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}