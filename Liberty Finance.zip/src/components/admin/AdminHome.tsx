import { Card } from '../ui/card';
import { Users, DollarSign, TrendingUp, Activity, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { useState, useEffect } from 'react';
import { toast } from 'sonner@2.0.3';
import { callServer } from '../../utils/api';

interface AdminHomeProps {
  preloadedData?: any;
  onDataUpdate?: () => void;
}

export function AdminHome({ preloadedData }: AdminHomeProps) {
  const [loading, setLoading] = useState(false);
  const [stats, setStats] = useState({
    totalUsers: 0,
    activeUsers: 0,
    inactiveUsers: 0,
    totalInvested: 0,
    pendingWithdrawals: 0,
    totalWithdrawn: 0,
    totalComisiones: 0,
    depositosPendientes: 0
  });
  const [recentUsers, setRecentUsers] = useState<any[]>([]);
  const [rendimientoActivo, setRendimientoActivo] = useState(true);
  const [procesando, setProcesando] = useState(false);

  useEffect(() => {
    // Si hay datos pre-cargados, usarlos inmediatamente
    if (preloadedData?.dashboardStats) {
      console.log('✅ [AdminHome] Usando datos pre-cargados');
      const data = preloadedData.dashboardStats;
      setStats({
        totalUsers: data.totalUsers,
        activeUsers: data.activeUsers,
        inactiveUsers: data.inactiveUsers,
        totalInvested: data.totalInvested,
        pendingWithdrawals: data.pendingWithdrawals,
        totalWithdrawn: data.totalWithdrawn,
        totalComisiones: data.totalComisiones,
        depositosPendientes: data.depositosPendientes
      });
      setRecentUsers(data.recentUsers || []);
      return;
    }

    // Fallback: cargar datos si no están pre-cargados
    console.log('⚠️ [AdminHome] No hay datos pre-cargados, cargando...');
    loadDashboardData(false);
  }, [preloadedData]);

  const loadDashboardData = async (showLoading = true) => {
    try {
      if (showLoading) {
        setLoading(true);
      }
      
      // Usar el endpoint optimizado que devuelve todo en una sola llamada
      const stats = await callServer('/admin/dashboard-stats', 'GET');
      
      setStats({
        totalUsers: stats.totalUsers,
        activeUsers: stats.activeUsers,
        inactiveUsers: stats.inactiveUsers,
        totalInvested: stats.totalInvested,
        pendingWithdrawals: stats.pendingWithdrawals,
        totalWithdrawn: stats.totalWithdrawn,
        totalComisiones: stats.totalComisiones,
        depositosPendientes: stats.depositosPendientes
      });
      
      setRecentUsers(stats.recentUsers);
      
      // Guardar en caché
      sessionStorage.setItem('adminDashboardCache', JSON.stringify({
        stats: {
          totalUsers: stats.totalUsers,
          activeUsers: stats.activeUsers,
          inactiveUsers: stats.inactiveUsers,
          totalInvested: stats.totalInvested,
          pendingWithdrawals: stats.pendingWithdrawals,
          totalWithdrawn: stats.totalWithdrawn,
          totalComisiones: stats.totalComisiones,
          depositosPendientes: stats.depositosPendientes
        },
        recentUsers: stats.recentUsers
      }));
      sessionStorage.setItem('adminDashboardCacheTime', Date.now().toString());
      
      setLoading(false);
    } catch (error) {
      console.error('Error al cargar datos del dashboard:', error);
      toast.error('Error al cargar datos del dashboard');
      setLoading(false);
    }
  };

  const toggleRendimiento = () => {
    const nuevoEstado = !rendimientoActivo;
    setRendimientoActivo(nuevoEstado);
    
    if (nuevoEstado) {
      toast.success('✅ Rendimiento diario ACTIVADO - Los usuarios recibirán su 1%');
    } else {
      toast.error('⛔ Rendimiento diario DESACTIVADO - Los usuarios NO recibirán su 1% hoy');
    }
  };

  const procesarRendimiento = async () => {
    try {
      setProcesando(true);
      
      const response = await callServer('/admin/procesar-rendimientos', 'POST');
      
      if (response.error) {
        // Verificar si es el error de "ya procesado hoy"
        if (response.error.includes('ya fueron procesados hoy')) {
          toast.error('⚠️ Ya se procesaron los rendimientos hoy. Solo se puede procesar una vez por día.');
        } else {
          toast.error(response.error);
        }
        return;
      }
      
      toast.success(`💰 Rendimiento procesado: ${response.procesados} usuarios recibieron su ${response.porcentaje}%`);
      
      // Recargar datos del dashboard
      loadDashboardData();
    } catch (error: any) {
      console.error('Error al procesar rendimientos:', error);
      
      // Verificar si es el error de "ya procesado hoy"
      if (error.message && error.message.includes('ya fueron procesados hoy')) {
        toast.error('⚠️ Ya se procesaron los rendimientos hoy. Solo se puede procesar una vez por día.');
      } else {
        toast.error(error.message || 'Error al procesar rendimientos');
      }
    } finally {
      setProcesando(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl text-slate-800 mb-2">Panel de Control</h1>
        <p className="text-slate-600">Vista general del sistema Liberty Finance</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Total Users */}
        <Card className="p-6 bg-gradient-to-br from-blue-600 to-blue-700 border-0 shadow-xl text-white">
          <div className="flex items-start justify-between mb-4">
            <div className="w-12 h-12 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
              <Users className="w-6 h-6" />
            </div>
            <div className="flex items-center gap-1 text-xs bg-white/20 px-2 py-1 rounded-lg backdrop-blur-sm">
              <ArrowUpRight className="w-3 h-3" />
              <span>12%</span>
            </div>
          </div>
          <p className="text-white/80 text-sm mb-1">Usuarios Totales</p>
          <p className="text-3xl">{stats.totalUsers.toLocaleString()}</p>
        </Card>

        {/* Active Users */}
        <Card className="p-6 bg-gradient-to-br from-slate-700 to-slate-800 border-0 shadow-xl text-white">
          <div className="flex items-start justify-between mb-4">
            <div className="w-12 h-12 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
              <Activity className="w-6 h-6" />
            </div>
            <div className="flex items-center gap-1 text-xs bg-white/20 px-2 py-1 rounded-lg backdrop-blur-sm">
              <ArrowUpRight className="w-3 h-3" />
              <span>8%</span>
            </div>
          </div>
          <p className="text-white/80 text-sm mb-1">Usuarios Activos</p>
          <p className="text-3xl">{stats.activeUsers.toLocaleString()}</p>
        </Card>

        {/* Total Invested */}
        <Card className="p-6 bg-gradient-to-br from-slate-900 to-blue-900 border-0 shadow-xl text-white">
          <div className="flex items-start justify-between mb-4">
            <div className="w-12 h-12 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
              <TrendingUp className="w-6 h-6" />
            </div>
            <div className="flex items-center gap-1 text-xs bg-white/20 px-2 py-1 rounded-lg backdrop-blur-sm">
              <ArrowUpRight className="w-3 h-3" />
              <span>15%</span>
            </div>
          </div>
          <p className="text-white/80 text-sm mb-1">Capital Invertido</p>
          <p className="text-3xl">${stats.totalInvested.toLocaleString()}</p>
        </Card>

        {/* Pending Withdrawals */}
        <Card className="p-6 bg-gradient-to-br from-blue-800 to-blue-900 border-0 shadow-xl text-white">
          <div className="flex items-start justify-between mb-4">
            <div className="w-12 h-12 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
              <DollarSign className="w-6 h-6" />
            </div>
            <div className="flex items-center gap-1 text-xs bg-white/20 px-2 py-1 rounded-lg backdrop-blur-sm">
              <ArrowDownRight className="w-3 h-3" />
              <span>5%</span>
            </div>
          </div>
          <p className="text-white/80 text-sm mb-1">Retiros Pendientes</p>
          <p className="text-3xl">{stats.pendingWithdrawals}</p>
        </Card>
      </div>

      {/* Control Panel Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        {/* Rendimiento Diario */}
        <Card className="p-6 bg-white border-slate-200 shadow-lg">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-xl bg-blue-100 flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <h3 className="text-slate-800">Rendimiento Diario</h3>
              <p className="text-xs text-slate-600">Estado del procesamiento</p>
            </div>
          </div>
          <button
            onClick={procesarRendimiento}
            disabled={procesando}
            className={`w-full py-3 rounded-xl text-white bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600 transition-all ${
              procesando ? 'opacity-50 cursor-not-allowed' : ''
            }`}
          >
            {procesando ? 'Procesando...' : '💰 Procesar Rendimientos'}
          </button>
          <p className="text-xs text-slate-500 mt-3 text-center">
            Solo una vez por día
          </p>
        </Card>

        {/* Estado del Sistema */}
        <Card className="p-6 bg-white border-slate-200 shadow-lg">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-xl bg-slate-100 flex items-center justify-center">
              <Activity className="w-6 h-6 text-slate-600" />
            </div>
            <div>
              <h3 className="text-slate-800">Estado del Sistema</h3>
              <p className="text-xs text-slate-600">Todo operativo</p>
            </div>
          </div>
          <div className="flex items-center justify-center h-12">
            <span className="text-green-600 text-sm">✅ Sistema funcionando correctamente</span>
          </div>
        </Card>
      </div>

      {/* Revenue Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="p-6 bg-white border-slate-200 shadow-lg">
          <h3 className="text-slate-800 mb-4">Estadísticas Financieras</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-gradient-to-r from-blue-50 to-blue-100 rounded-xl border border-blue-200">
              <div>
                <p className="text-slate-600 text-sm mb-1">Total Comisiones Pagadas</p>
                <p className="text-2xl text-blue-700">${stats.totalComisiones.toLocaleString()}</p>
              </div>
              <div className="w-12 h-12 rounded-xl bg-blue-600 flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
            </div>
            <div className="flex items-center justify-between p-4 bg-gradient-to-r from-slate-50 to-slate-100 rounded-xl border border-slate-200">
              <div>
                <p className="text-slate-600 text-sm mb-1">Total Retirado</p>
                <p className="text-2xl text-slate-800">${stats.totalWithdrawn.toLocaleString()}</p>
              </div>
              <div className="w-12 h-12 rounded-xl bg-slate-700 flex items-center justify-center">
                <DollarSign className="w-6 h-6 text-white" />
              </div>
            </div>
          </div>
        </Card>

        <Card className="p-6 bg-white border-slate-200 shadow-lg">
          <h3 className="text-slate-800 mb-4">Transacciones Pendientes</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-gradient-to-r from-orange-50 to-orange-100 rounded-xl border border-orange-200">
              <div>
                <p className="text-slate-600 text-sm mb-1">Depósitos Pendientes</p>
                <p className="text-2xl text-orange-700">{stats.depositosPendientes}</p>
              </div>
              <div className="text-right">
                <p className="text-sm text-slate-600">Por verificar</p>
              </div>
            </div>
            <div className="flex items-center justify-between p-4 bg-gradient-to-r from-blue-50 to-blue-100 rounded-xl border border-blue-200">
              <div>
                <p className="text-slate-600 text-sm mb-1">Retiros Pendientes</p>
                <p className="text-2xl text-blue-700">{stats.pendingWithdrawals}</p>
              </div>
              <div className="text-right">
                <p className="text-sm text-slate-600">Por aprobar</p>
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Recent Users Table */}
      <Card className="p-6 bg-white border-slate-200 shadow-lg">
        <h3 className="text-slate-800 mb-4">Registros Recientes</h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-200">
                <th className="text-left py-3 px-4 text-slate-600 text-sm">ID Usuario</th>
                <th className="text-left py-3 px-4 text-slate-600 text-sm">Nombre</th>
                <th className="text-left py-3 px-4 text-slate-600 text-sm">Pack</th>
                <th className="text-left py-3 px-4 text-slate-600 text-sm">Inversión</th>
                <th className="text-left py-3 px-4 text-slate-600 text-sm">Fecha</th>
                <th className="text-left py-3 px-4 text-slate-600 text-sm">Estado</th>
              </tr>
            </thead>
            <tbody>
              {recentUsers.map((user, index) => (
                <tr key={index} className="border-b border-slate-100 hover:bg-slate-50 transition-colors">
                  <td className="py-3 px-4 text-slate-800">{user.id}</td>
                  <td className="py-3 px-4 text-slate-800">{user.name}</td>
                  <td className="py-3 px-4">
                    <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-lg text-sm border border-blue-200">
                      {user.pack}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-slate-800">${user.amount}</td>
                  <td className="py-3 px-4 text-slate-600">{user.date}</td>
                  <td className="py-3 px-4">
                    <span className={`px-3 py-1 rounded-lg text-sm ${
                      user.status === 'active' 
                        ? 'bg-blue-100 text-blue-700 border border-blue-200'
                        : 'bg-slate-100 text-slate-700 border border-slate-200'
                    }`}>
                      {user.status === 'active' ? 'Activo' : 'Pendiente'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}