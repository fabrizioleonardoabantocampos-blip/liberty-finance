import { Mail, Smartphone, Monitor } from 'lucide-react';
import { useState } from 'react';
import { Button } from '../ui/button';
import { Card } from '../ui/card';

export function VistaPreviewEmail() {
  const [device, setDevice] = useState<'desktop' | 'mobile'>('desktop');
  const codigoEjemplo = '123456';
  const nombreEjemplo = 'Juan Pérez';

  return (
    <div className="space-y-4">
      {/* Device Selector */}
      <div className="flex items-center justify-between">
        <h3 className="text-lg text-white">Vista Previa del Email</h3>
        <div className="flex gap-2">
          <Button
            variant={device === 'desktop' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setDevice('desktop')}
            className={device === 'desktop' ? 'bg-purple-600' : ''}
          >
            <Monitor className="w-4 h-4 mr-2" />
            Desktop
          </Button>
          <Button
            variant={device === 'mobile' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setDevice('mobile')}
            className={device === 'mobile' ? 'bg-purple-600' : ''}
          >
            <Smartphone className="w-4 h-4 mr-2" />
            Móvil
          </Button>
        </div>
      </div>

      {/* Email Preview */}
      <Card className="bg-gray-800/50 border-gray-700 p-6 overflow-hidden">
        <div 
          className={`mx-auto transition-all duration-300 ${
            device === 'mobile' ? 'max-w-[375px]' : 'max-w-[600px]'
          }`}
          style={{
            transform: device === 'mobile' ? 'scale(0.8)' : 'scale(1)',
            transformOrigin: 'top center'
          }}
        >
          {/* Email Container */}
          <div className="bg-white rounded-3xl shadow-2xl overflow-hidden">
            {/* Header con gradiente */}
            <div 
              className="px-10 py-12 text-center"
              style={{
                background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'
              }}
            >
              <div className="w-20 h-20 mx-auto mb-5 bg-white rounded-2xl flex items-center justify-center">
                <span className="text-4xl">🔐</span>
              </div>
              <h1 className="text-3xl font-bold text-white mb-2">
                Recupera tu Contraseña
              </h1>
              <p className="text-blue-100">Liberty Finance</p>
            </div>

            {/* Body */}
            <div className="p-10">
              <p className="text-gray-800 mb-4">
                Hola <strong>{nombreEjemplo}</strong>,
              </p>
              
              <p className="text-gray-700 mb-8 leading-relaxed">
                Recibimos una solicitud para restablecer la contraseña de tu cuenta en{' '}
                <strong>Liberty Finance</strong>. Usa el siguiente código para continuar con el proceso:
              </p>

              {/* Código destacado */}
              <div 
                className="rounded-2xl p-8 text-center mb-8"
                style={{
                  background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'
                }}
              >
                <p className="text-white text-sm font-semibold uppercase tracking-widest mb-4">
                  Tu Código de Verificación
                </p>
                <div 
                  className="text-6xl font-black text-white tracking-[0.3em] font-mono"
                  style={{ letterSpacing: '0.3em' }}
                >
                  {codigoEjemplo}
                </div>
              </div>

              {/* Alerta de tiempo */}
              <div className="bg-yellow-50 border-l-4 border-yellow-400 rounded-lg p-5 mb-6">
                <p className="text-yellow-900 text-sm">
                  <strong>⏰ Importante:</strong> Este código expirará en{' '}
                  <strong>15 minutos</strong> por tu seguridad.
                </p>
              </div>

              <p className="text-gray-600 text-sm leading-relaxed">
                Si no solicitaste este cambio, puedes ignorar este correo. Tu contraseña permanecerá sin cambios.
              </p>
            </div>

            {/* Footer */}
            <div className="bg-gray-50 px-10 py-8 border-t border-gray-200 text-center">
              <p className="text-gray-600 text-sm mb-4">
                Este es un mensaje automático, por favor no respondas a este correo.
              </p>
              <p className="text-gray-400 text-xs">
                © {new Date().getFullYear()} Liberty Finance. Todos los derechos reservados.
              </p>
            </div>
          </div>
        </div>

        {/* Info adicional */}
        <div className="mt-6 text-center">
          <p className="text-gray-400 text-sm">
            📧 Esta es una vista previa del email que recibirán los usuarios
          </p>
        </div>
      </Card>

      {/* Características del email */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-gray-800/50 border-gray-700 p-4">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center flex-shrink-0">
              <Mail className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <p className="text-white text-sm font-semibold mb-1">Responsive</p>
              <p className="text-gray-400 text-xs">
                Se adapta a móviles y desktop automáticamente
              </p>
            </div>
          </div>
        </Card>

        <Card className="bg-gray-800/50 border-gray-700 p-4">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center flex-shrink-0">
              <span className="text-purple-400">🎨</span>
            </div>
            <div>
              <p className="text-white text-sm font-semibold mb-1">Diseño Moderno</p>
              <p className="text-gray-400 text-xs">
                Colores corporativos y gradientes profesionales
              </p>
            </div>
          </div>
        </Card>

        <Card className="bg-gray-800/50 border-gray-700 p-4">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-lg bg-green-500/20 flex items-center justify-center flex-shrink-0">
              <span className="text-green-400">⚡</span>
            </div>
            <div>
              <p className="text-white text-sm font-semibold mb-1">Rápido</p>
              <p className="text-gray-400 text-xs">
                Entrega instantánea con Resend
              </p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
