import { useState } from 'react';
import { Send, CheckCircle, XCircle, Loader2 } from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { toast } from 'sonner@2.0.3';
import { projectId, publicAnonKey } from '../../utils/supabase/info';

export function TestEmailQuick() {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [resultado, setResultado] = useState<{
    success: boolean;
    message: string;
    emailId?: string;
  } | null>(null);

  const handleTest = async () => {
    if (!email || !email.includes('@')) {
      toast.error('Ingresa un email válido');
      return;
    }

    setLoading(true);
    setResultado(null);

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-9f68532a/auth/test-email`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`
          },
          body: JSON.stringify({ email })
        }
      );

      const data = await response.json();

      setResultado({
        success: data.success,
        message: data.message || data.error || 'Sin mensaje',
        emailId: data.emailId
      });

      if (data.success) {
        toast.success(`✅ Email enviado a ${email}`);
      } else {
        toast.error(`❌ ${data.error || 'Error al enviar'}`);
      }
    } catch (error) {
      console.error('Error:', error);
      setResultado({
        success: false,
        message: 'Error de conexión'
      });
      toast.error('Error de conexión');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">
        🧪 Test Rápido de Email
      </h3>
      
      <div className="space-y-4">
        <div>
          <Input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="tu@email.com"
            className="w-full"
          />
        </div>

        <Button
          onClick={handleTest}
          disabled={loading}
          className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
        >
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Enviando...
            </>
          ) : (
            <>
              <Send className="w-4 h-4 mr-2" />
              Enviar Email de Prueba
            </>
          )}
        </Button>

        {resultado && (
          <div className={`rounded-lg border p-4 ${
            resultado.success 
              ? 'bg-green-50 border-green-200' 
              : 'bg-red-50 border-red-200'
          }`}>
            <div className="flex items-start gap-3">
              {resultado.success ? (
                <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
              ) : (
                <XCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              )}
              <div className="flex-1">
                <p className={`font-medium ${
                  resultado.success ? 'text-green-900' : 'text-red-900'
                }`}>
                  {resultado.success ? 'Email Enviado' : 'Error'}
                </p>
                <p className={`text-sm mt-1 ${
                  resultado.success ? 'text-green-700' : 'text-red-700'
                }`}>
                  {resultado.message}
                </p>
                {resultado.emailId && (
                  <p className="text-xs text-green-600 mt-2 font-mono">
                    ID: {resultado.emailId}
                  </p>
                )}
              </div>
            </div>
          </div>
        )}

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-sm">
          <p className="text-blue-900">
            <strong>✅ API Key configurada:</strong> re_4ht...Ckc
          </p>
          <p className="text-blue-700 mt-2">
            Si el email llega → ✅ Todo configurado correctamente<br />
            Si falla → Verificar consola del servidor
          </p>
        </div>
      </div>
    </div>
  );
}