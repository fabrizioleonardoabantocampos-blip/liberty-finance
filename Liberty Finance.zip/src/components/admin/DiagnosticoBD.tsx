import { useState } from 'react';
import { Database, Search, AlertCircle, CheckCircle, Loader2, FileText } from 'lucide-react';

interface DiagnosticoBDProps {
  onNavigate: (page: string) => void;
}

export function DiagnosticoBD({ onNavigate }: DiagnosticoBDProps) {
  const [loading, setLoading] = useState(false);
  const [resultado, setResultado] = useState<any>(null);
  const [error, setError] = useState<string>('');

  const ejecutarDiagnostico = async () => {
    setLoading(true);
    setError('');
    setResultado(null);

    try {
      const { projectId, publicAnonKey } = await import('../../utils/supabase/info');
      
      // ⚡ Timeout controller para manejar timeouts largos
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 180000); // 3 minutos de timeout
      
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-9f68532a/admin/diagnostico-bd`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`
          },
          signal: controller.signal
        }
      );
      
      clearTimeout(timeoutId);

      if (!response.ok) {
        throw new Error('Error al ejecutar diagnóstico');
      }

      const data = await response.json();
      setResultado(data);
      
      console.log('📊 Resultado del diagnóstico:', data);
    } catch (err: any) {
      console.error('Error:', err);
      if (err.name === 'AbortError') {
        setError('El diagnóstico tardó demasiado tiempo. Intenta de nuevo.');
      } else {
        setError(err.message || 'Error desconocido');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={() => onNavigate('admin')}
            className="text-slate-600 hover:text-slate-900 mb-4 flex items-center gap-2"
          >
            ← Volver al Panel
          </button>
          <h1 className="text-slate-900 flex items-center gap-3">
            <Database className="w-8 h-8 text-blue-600" />
            Diagnóstico de Base de Datos
          </h1>
          <p className="text-slate-600 mt-2">
            Analiza la estructura de datos y detecta si hay información que requiere migración
          </p>
        </div>

        {/* Acción Principal */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-8 mb-6">
          <div className="text-center">
            <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <Search className="w-10 h-10 text-white" />
            </div>
            <h2 className="text-slate-900 mb-3">Ejecutar Diagnóstico Completo</h2>
            <p className="text-slate-600 mb-6 max-w-2xl mx-auto">
              Este proceso analizará toda la base de datos para verificar la estructura de datos,
              detectar datos antiguos en formato monolítico y determinar si se requiere migración.
            </p>
            <button
              onClick={ejecutarDiagnostico}
              disabled={loading}
              className="px-8 py-3 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-xl hover:from-blue-700 hover:to-blue-800 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 mx-auto"
            >
              {loading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Analizando...
                </>
              ) : (
                <>
                  <Search className="w-5 h-5" />
                  Ejecutar Diagnóstico
                </>
              )}
            </button>
          </div>
        </div>

        {/* Error */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-xl p-4 mb-6">
            <div className="flex items-center gap-3">
              <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0" />
              <div>
                <p className="text-red-900">Error al ejecutar diagnóstico</p>
                <p className="text-red-700 text-sm mt-1">{error}</p>
              </div>
            </div>
          </div>
        )}

        {/* Resultados */}
        {resultado && (
          <div className="space-y-6">
            {/* Estado General */}
            <div className={`${
              resultado.requiereMigracion 
                ? 'bg-yellow-50 border-yellow-200' 
                : 'bg-green-50 border-green-200'
            } border rounded-xl p-6`}>
              <div className="flex items-start gap-4">
                {resultado.requiereMigracion ? (
                  <AlertCircle className="w-6 h-6 text-yellow-600 flex-shrink-0 mt-1" />
                ) : (
                  <CheckCircle className="w-6 h-6 text-green-600 flex-shrink-0 mt-1" />
                )}
                <div className="flex-1">
                  <h3 className={`${
                    resultado.requiereMigracion ? 'text-yellow-900' : 'text-green-900'
                  } mb-2`}>
                    {resultado.requiereMigracion 
                      ? '⚠️ Se encontraron datos que requieren migración' 
                      : '✅ Estructura de datos correcta'}
                  </h3>
                  <p className={`${
                    resultado.requiereMigracion ? 'text-yellow-700' : 'text-green-700'
                  } text-sm mb-2`}>
                    {resultado.requiereMigracion
                      ? 'Se detectaron datos en formato antiguo que deben migrarse a la estructura actual.'
                      : 'Todos los datos están correctamente organizados en la estructura optimizada.'}
                  </p>
                  {resultado.categoriasConProblemas && resultado.categoriasConProblemas.length > 0 && (
                    <div className="mt-2 pt-2 border-t border-yellow-300">
                      <p className="text-yellow-800 text-xs mb-1">Categorías afectadas:</p>
                      <div className="flex flex-wrap gap-2">
                        {resultado.categoriasConProblemas.map((cat: string) => (
                          <span key={cat} className="px-2 py-1 bg-yellow-200 text-yellow-900 rounded text-xs">
                            {cat}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Análisis de Estructura */}
            {resultado.analisis && (
              <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                <h3 className="text-slate-900 mb-4 flex items-center gap-2">
                  <FileText className="w-5 h-5 text-blue-600" />
                  Análisis de Estructura
                </h3>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  <div className="bg-slate-50 rounded-lg p-4">
                    <p className="text-slate-600 text-sm mb-1">Total de Keys</p>
                    <p className="text-slate-900">{resultado.analisis.totalKeys}</p>
                  </div>
                  <div className="bg-slate-50 rounded-lg p-4">
                    <p className="text-slate-600 text-sm mb-1">Categorías</p>
                    <p className="text-slate-900">{Object.keys(resultado.analisis.categorias).length}</p>
                  </div>
                  <div className="bg-slate-50 rounded-lg p-4">
                    <p className="text-slate-600 text-sm mb-1">Keys Sospechosas</p>
                    <p className={`${
                      resultado.analisis.keysSospechosas.length > 0 
                        ? 'text-yellow-600' 
                        : 'text-green-600'
                    }`}>
                      {resultado.analisis.keysSospechosas.length}
                    </p>
                  </div>
                </div>

                {/* Categorías */}
                <div className="mb-4">
                  <h4 className="text-slate-700 mb-3">Categorías Encontradas:</h4>
                  <div className="space-y-2 max-h-96 overflow-y-auto">
                    {Object.entries(resultado.analisis.categorias)
                      .sort((a: any, b: any) => b[1] - a[1])
                      .map(([prefijo, cantidad]: [string, any]) => (
                        <div key={prefijo} className="flex items-center justify-between bg-slate-50 rounded-lg p-3">
                          <div className="flex-1">
                            <span className="text-slate-900 font-mono">{prefijo}</span>
                            {resultado.analisis.ejemplos[prefijo] && (
                              <div className="mt-2 space-y-1">
                                {resultado.analisis.ejemplos[prefijo].map((ejemplo: string, idx: number) => (
                                  <p key={idx} className="text-slate-500 text-xs font-mono pl-4">
                                    └─ {ejemplo}
                                  </p>
                                ))}
                              </div>
                            )}
                          </div>
                          <span className="text-slate-600 ml-4">{cantidad} registros</span>
                        </div>
                      ))}
                  </div>
                </div>

                {/* Keys Sospechosas */}
                {resultado.analisis.keysSospechosas.length > 0 && (
                  <div className="mt-4 p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                    <h4 className="text-yellow-900 mb-2 flex items-center gap-2">
                      <AlertCircle className="w-4 h-4" />
                      Keys Sospechosas (sin estructura estándar):
                    </h4>
                    <div className="space-y-1 max-h-48 overflow-y-auto">
                      {resultado.analisis.keysSospechosas.map((key: string, idx: number) => (
                        <p key={idx} className="text-yellow-700 text-sm font-mono">
                          ⚠️ {key}
                        </p>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Datos Antiguos */}
            {resultado.datosAntiguos && Object.keys(resultado.datosAntiguos).length > 0 && (
              <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                <h3 className="text-slate-900 mb-4 flex items-center gap-2">
                  <AlertCircle className="w-5 h-5 text-yellow-600" />
                  Datos Antiguos Encontrados
                </h3>
                <div className="space-y-3">
                  {Object.entries(resultado.datosAntiguos).map(([key, value]: [string, any]) => (
                    <div key={key} className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                      <p className="text-yellow-900 mb-2">
                        📦 Key: <span className="font-mono">{key}</span>
                      </p>
                      <p className="text-yellow-700 text-sm">
                        Tipo: {typeof value}
                      </p>
                      {typeof value === 'object' && (
                        <p className="text-yellow-700 text-sm">
                          Propiedades: {Object.keys(value).length}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Análisis de Registros */}
            {resultado.analisisRegistros && Object.keys(resultado.analisisRegistros).length > 0 && (
              <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                <h3 className="text-slate-900 mb-4 flex items-center gap-2">
                  <FileText className="w-5 h-5 text-blue-600" />
                  Análisis de Estructura de Registros
                </h3>
                <p className="text-slate-600 text-sm mb-6">
                  Este análisis compara la estructura de cada categoría para detectar si usan formato monolítico (todo en una key) o individual (propiedades separadas).
                </p>
                
                <div className="space-y-4">
                  {Object.entries(resultado.analisisRegistros).map(([categoria, datos]: [string, any]) => (
                    <div key={categoria} className={`border rounded-lg p-4 ${
                      datos.requiereMigracion 
                        ? 'bg-red-50 border-red-200' 
                        : 'bg-green-50 border-green-200'
                    }`}>
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h4 className={`flex items-center gap-2 ${
                            datos.requiereMigracion ? 'text-red-900' : 'text-green-900'
                          }`}>
                            {datos.requiereMigracion ? '🔴' : '🟢'} {categoria}
                            {datos.requiereMigracion && (
                              <span className="text-xs px-2 py-0.5 bg-red-200 text-red-800 rounded">
                                REQUIERE MIGRACIÓN
                              </span>
                            )}
                          </h4>
                          <p className={`text-sm mt-1 ${
                            datos.requiereMigracion ? 'text-red-700' : 'text-green-700'
                          }`}>
                            {datos.totalRegistros} registros totales • {datos.muestrasAnalizadas} analizados
                          </p>
                        </div>
                        <div className={`text-2xl ${
                          datos.requiereMigracion ? 'text-red-600' : 'text-green-600'
                        }`}>
                          {datos.porcentajeMonolitico}%
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-3 gap-2 mb-3">
                        <div className="bg-white bg-opacity-50 rounded p-2">
                          <p className="text-xs text-slate-600">Monolítica</p>
                          <p className={datos.estructuraMonolitica > 0 ? 'text-red-700' : 'text-slate-900'}>
                            {datos.estructuraMonolitica}
                          </p>
                        </div>
                        <div className="bg-white bg-opacity-50 rounded p-2">
                          <p className="text-xs text-slate-600">Individual</p>
                          <p className={datos.estructuraIndividual > 0 ? 'text-green-700' : 'text-slate-900'}>
                            {datos.estructuraIndividual}
                          </p>
                        </div>
                        <div className="bg-white bg-opacity-50 rounded p-2">
                          <p className="text-xs text-slate-600">Híbrida</p>
                          <p className="text-slate-900">{datos.estructuraHibrida}</p>
                        </div>
                      </div>
                      
                      {/* Ejemplos de estructura monolítica */}
                      {datos.ejemplosMonolitica && datos.ejemplosMonolitica.length > 0 && (
                        <div className="mt-3 pt-3 border-t border-red-300">
                          <p className="text-xs text-red-800 mb-2">📋 Ejemplos de estructura monolítica:</p>
                          {datos.ejemplosMonolitica.map((ejemplo: any, idx: number) => (
                            <div key={idx} className="bg-white bg-opacity-70 rounded p-2 mb-2 text-xs">
                              <p className="font-mono text-red-900 mb-1">{ejemplo.key}</p>
                              <p className="text-red-700">
                                • {ejemplo.propiedades} propiedades
                                {ejemplo.tieneArrays && ' • Contiene arrays'}
                                {ejemplo.tieneObjetosComplejos && ' • Objetos complejos'}
                              </p>
                              <p className="text-red-600 font-mono text-xs mt-1">
                                {ejemplo.ejemploPropiedades.join(', ')}...
                              </p>
                            </div>
                          ))}
                        </div>
                      )}
                      
                      {/* Ejemplos de estructura individual */}
                      {datos.ejemplosIndividual && datos.ejemplosIndividual.length > 0 && (
                        <div className="mt-3 pt-3 border-t border-green-300">
                          <p className="text-xs text-green-800 mb-2">✅ Ejemplos de estructura individual:</p>
                          {datos.ejemplosIndividual.map((ejemplo: any, idx: number) => (
                            <div key={idx} className="bg-white bg-opacity-70 rounded p-2 mb-2 text-xs">
                              <p className="font-mono text-green-900 mb-1">{ejemplo.key}</p>
                              <p className="text-green-700">
                                • {ejemplo.propiedades} propiedades
                              </p>
                              <p className="text-green-600 font-mono text-xs mt-1">
                                {ejemplo.ejemploPropiedades.join(', ')}
                              </p>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Información Adicional */}
        <div className="mt-8 bg-blue-50 border border-blue-200 rounded-xl p-6">
          <h3 className="text-blue-900 mb-3">ℹ️ Información</h3>
          <ul className="space-y-2 text-blue-700 text-sm">
            <li>• Este diagnóstico analiza la estructura actual de la base de datos</li>
            <li>• Detecta datos en formato antiguo que requieren migración</li>
            <li>• La estructura óptima usa keys individuales para cada registro</li>
            <li>• Los resultados se muestran en la consola del servidor para análisis detallado</li>
          </ul>
        </div>
      </div>
    </div>
  );
}