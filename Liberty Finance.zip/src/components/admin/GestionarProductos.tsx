import { useState, useEffect } from 'react';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Package, Plus, Edit, Trash2, Save, X, Upload, Loader2 } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { productosAPI } from '../../utils/api';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '../ui/dialog';

interface Producto {
  id: string;
  nombre: string;
  descripcion: string;
  precio: number;
  imagen: string;
  stock: number;
}

export function GestionarProductos() {
  const [productos, setProductos] = useState<Producto[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Producto | null>(null);
  const [saving, setSaving] = useState(false);
  
  const [formData, setFormData] = useState({
    nombre: '',
    descripcion: '',
    precio: 0,
    imagen: '',
    stock: 0
  });

  useEffect(() => {
    cargarProductos();
  }, []);

  const cargarProductos = async () => {
    try {
      const data = await productosAPI.getAll();
      setProductos(data);
    } catch (error) {
      console.error('Error al cargar productos:', error);
      toast.error('Error al cargar productos');
    } finally {
      setLoading(false);
    }
  };

  const handleOpenDialog = (producto?: Producto) => {
    if (producto) {
      setEditingProduct(producto);
      setFormData({
        nombre: producto.nombre,
        descripcion: producto.descripcion,
        precio: producto.precio,
        imagen: producto.imagen,
        stock: producto.stock
      });
    } else {
      setEditingProduct(null);
      setFormData({
        nombre: '',
        descripcion: '',
        precio: 0,
        imagen: '',
        stock: 0
      });
    }
    setDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setDialogOpen(false);
    setEditingProduct(null);
    setFormData({
      nombre: '',
      descripcion: '',
      precio: 0,
      imagen: '',
      stock: 0
    });
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        toast.error('Por favor selecciona una imagen válida');
        return;
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        setFormData({ ...formData, imagen: base64String });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleGuardar = async () => {
    if (!formData.nombre.trim()) {
      toast.error('El nombre del producto es requerido');
      return;
    }

    if (formData.precio <= 0) {
      toast.error('El precio debe ser mayor a 0');
      return;
    }

    setSaving(true);
    try {
      if (editingProduct) {
        // Actualizar producto existente
        await productosAPI.update(editingProduct.id, formData);
        toast.success('Producto actualizado exitosamente');
      } else {
        // Crear nuevo producto
        await productosAPI.create(formData);
        toast.success('Producto creado exitosamente');
      }
      
      await cargarProductos();
      handleCloseDialog();
    } catch (error: any) {
      console.error('Error al guardar producto:', error);
      toast.error(error.message || 'Error al guardar producto');
    } finally {
      setSaving(false);
    }
  };

  const handleEliminar = async (id: string) => {
    if (!confirm('¿Estás seguro de eliminar este producto?')) {
      return;
    }

    try {
      await productosAPI.delete(id);
      toast.success('Producto eliminado exitosamente');
      await cargarProductos();
    } catch (error: any) {
      console.error('Error al eliminar producto:', error);
      toast.error(error.message || 'Error al eliminar producto');
    }
  };

  if (loading) {
    return (
      <Card className="p-6">
        <div className="flex items-center justify-center py-8">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-purple-100 flex items-center justify-center">
            <Package className="w-6 h-6 text-purple-600" />
          </div>
          <div>
            <h2 className="text-2xl text-slate-800">Gestionar Productos</h2>
            <p className="text-slate-600 text-sm">Administra el catálogo de productos</p>
          </div>
        </div>
        <Button
          onClick={() => handleOpenDialog()}
          className="bg-purple-600 hover:bg-purple-700"
        >
          <Plus className="w-4 h-4 mr-2" />
          Nuevo Producto
        </Button>
      </div>

      {/* Lista de Productos */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {productos.length === 0 ? (
          <Card className="col-span-full p-12 text-center">
            <Package className="w-16 h-16 text-slate-300 mx-auto mb-4" />
            <p className="text-slate-600 mb-4">No hay productos registrados</p>
            <Button
              onClick={() => handleOpenDialog()}
              variant="outline"
            >
              Crear Primer Producto
            </Button>
          </Card>
        ) : (
          productos.map((producto) => (
            <Card key={producto.id} className="overflow-hidden">
              {/* Imagen del Producto */}
              <div className="relative h-48 bg-slate-100">
                {producto.imagen ? (
                  <ImageWithFallback
                    src={producto.imagen}
                    alt={producto.nombre}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <Package className="w-16 h-16 text-slate-300" />
                  </div>
                )}
              </div>

              {/* Información */}
              <div className="p-4 space-y-3">
                <div>
                  <h3 className="text-lg text-slate-800 mb-1">{producto.nombre}</h3>
                  <p className="text-sm text-slate-600 line-clamp-2">
                    {producto.descripcion}
                  </p>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-2xl text-purple-600">${producto.precio}</p>
                    <p className="text-xs text-slate-500">Stock: {producto.stock}</p>
                  </div>
                </div>

                {/* Botones */}
                <div className="flex gap-2 pt-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1"
                    onClick={() => handleOpenDialog(producto)}
                  >
                    <Edit className="w-4 h-4 mr-1" />
                    Editar
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    onClick={() => handleEliminar(producto.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </Card>
          ))
        )}
      </div>

      {/* Dialog de Crear/Editar */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingProduct ? 'Editar Producto' : 'Nuevo Producto'}
            </DialogTitle>
            <DialogDescription>
              {editingProduct 
                ? 'Modifica la información del producto'
                : 'Completa los datos del nuevo producto'
              }
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 mt-4">
            {/* Nombre */}
            <div className="space-y-2">
              <Label htmlFor="nombre">Nombre del Producto *</Label>
              <Input
                id="nombre"
                value={formData.nombre}
                onChange={(e) => setFormData({ ...formData, nombre: e.target.value })}
                placeholder="Ej: iPhone 15 Pro Max"
              />
            </div>

            {/* Descripción */}
            <div className="space-y-2">
              <Label htmlFor="descripcion">Descripción</Label>
              <Textarea
                id="descripcion"
                value={formData.descripcion}
                onChange={(e) => setFormData({ ...formData, descripcion: e.target.value })}
                placeholder="Describe el producto..."
                rows={3}
              />
            </div>

            {/* Precio y Stock */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="precio">Precio (USDT) *</Label>
                <Input
                  id="precio"
                  type="number"
                  value={formData.precio}
                  onChange={(e) => setFormData({ ...formData, precio: Number(e.target.value) })}
                  placeholder="0.00"
                  min="0"
                  step="0.01"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="stock">Stock Disponible *</Label>
                <Input
                  id="stock"
                  type="number"
                  value={formData.stock}
                  onChange={(e) => setFormData({ ...formData, stock: Number(e.target.value) })}
                  placeholder="0"
                  min="0"
                />
              </div>
            </div>

            {/* Imagen */}
            <div className="space-y-3">
              <Label>Imagen del Producto</Label>
              <div className="flex items-start gap-3">
                <div>
                  <Input
                    id="imagen"
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                  <Button
                    variant="outline"
                    onClick={() => document.getElementById('imagen')?.click()}
                    type="button"
                  >
                    <Upload className="mr-2 h-4 w-4" />
                    {formData.imagen ? 'Cambiar Imagen' : 'Subir Imagen'}
                  </Button>
                </div>

                {formData.imagen && (
                  <div className="flex items-start gap-2">
                    <div className="border-2 border-gray-200 rounded-lg p-2 bg-white">
                      <ImageWithFallback
                        src={formData.imagen}
                        alt="Preview"
                        className="w-24 h-24 object-cover rounded"
                      />
                    </div>
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => setFormData({ ...formData, imagen: '' })}
                      type="button"
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                )}
              </div>
            </div>

            {/* Botones */}
            <div className="flex gap-3 pt-4">
              <Button
                variant="outline"
                onClick={handleCloseDialog}
                className="flex-1"
                disabled={saving}
              >
                Cancelar
              </Button>
              <Button
                onClick={handleGuardar}
                className="flex-1 bg-purple-600 hover:bg-purple-700"
                disabled={saving}
              >
                {saving ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Guardando...
                  </>
                ) : (
                  <>
                    <Save className="mr-2 h-4 w-4" />
                    {editingProduct ? 'Guardar Cambios' : 'Crear Producto'}
                  </>
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
