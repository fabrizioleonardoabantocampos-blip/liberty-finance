import { useState, useEffect } from 'react';
import { Mail, Send, CheckCircle, AlertCircle, Key, ExternalLink, Copy, Check } from 'lucide-react';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { toast } from 'sonner@2.0.3';
import { VistaPreviewEmail } from './VistaPreviewEmail';
import { projectId, publicAnonKey } from '../../utils/supabase/info';
import { TestEmailQuick } from './TestEmailQuick';

export function ConfiguracionEmail() {
  const [apiKeyStatus, setApiKeyStatus] = useState<'configurada' | 'no-configurada' | 'verificando'>('verificando');
  const [testEmail, setTestEmail] = useState('');
  const [sendingTest, setSendingTest] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    // Verificar si la API key está configurada
    const checkApiKey = async () => {
      try {
        const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f68532a/auth/check-resend-config`, {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`
          }
        });
        const data = await response.json();
        
        if (data.configured) {
          setApiKeyStatus('configurada');
        } else {
          setApiKeyStatus('no-configurada');
        }
      } catch (error) {
        console.error('Error verificando API key:', error);
        setApiKeyStatus('no-configurada');
      }
    };
    
    checkApiKey();
  }, []);

  const handleCopyInstructions = () => {
    const instructions = `
Pasos para configurar Resend:

1. Ve a https://resend.com y crea una cuenta
2. Verifica tu email
3. En el dashboard, ve a "API Keys"
4. Crea una nueva API Key
5. Copia la key (empieza con "re_")
6. Agrega la key en las variables de entorno como RESEND_API_KEY
7. Opcional: Configura un dominio verificado para mejor deliverability
    `;
    
    navigator.clipboard.writeText(instructions);
    setCopied(true);
    toast.success('Instrucciones copiadas al portapapeles');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSendTestEmail = async () => {
    if (!testEmail || !testEmail.includes('@')) {
      toast.error('Por favor ingresa un email válido');
      return;
    }

    setSendingTest(true);
    
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f68532a/auth/test-email`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify({ email: testEmail })
      });

      const data = await response.json();

      if (data.success) {
        toast.success(`✅ Email enviado a ${testEmail}! Revisa tu bandeja de entrada.`);
        setTestEmail('');
        setApiKeyStatus('configurada');
      } else {
        if (data.configured === false) {
          toast.error('⚠️ API Key no configurada. Agrega tu RESEND_API_KEY.');
        } else {
          toast.error(`❌ Error: ${data.error || 'No se pudo enviar el email'}`);
        }
      }
    } catch (error) {
      console.error('Error al enviar email de prueba:', error);
      toast.error('Error de conexión al intentar enviar el email');
    } finally {
      setSendingTest(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl text-white flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/20 flex items-center justify-center">
              <Mail className="w-6 h-6 text-blue-400" />
            </div>
            Configuración de Email
          </h2>
          <p className="text-gray-400 mt-2">
            Configura el servicio de envío de correos para recuperación de contraseñas
          </p>
        </div>
      </div>

      {/* Status Card */}
      <Card className="bg-gray-800/50 border-gray-700 p-6">
        <div className="flex items-start gap-4">
          {apiKeyStatus === 'configurada' ? (
            <div className="w-12 h-12 rounded-full bg-green-500/20 flex items-center justify-center flex-shrink-0">
              <CheckCircle className="w-6 h-6 text-green-400" />
            </div>
          ) : (
            <div className="w-12 h-12 rounded-full bg-orange-500/20 flex items-center justify-center flex-shrink-0">
              <AlertCircle className="w-6 h-6 text-orange-400" />
            </div>
          )}
          
          <div className="flex-1">
            <h3 className="text-lg text-white mb-1">
              {apiKeyStatus === 'configurada' ? 'API Key Configurada' : 'API Key No Configurada'}
            </h3>
            <p className="text-sm text-gray-400 mb-3">
              {apiKeyStatus === 'configurada' 
                ? 'El sistema puede enviar correos electrónicos automáticamente.'
                : 'Configura una API key de Resend para habilitar el envío de emails.'}
            </p>
            
            {apiKeyStatus === 'no-configurada' && (
              <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4 mt-3">
                <p className="text-blue-300 text-sm mb-2">
                  💡 <strong>Modo actual:</strong> Los códigos se muestran en la consola del servidor.
                </p>
                <p className="text-blue-300 text-sm">
                  Configura Resend para enviar emails reales a los usuarios.
                </p>
              </div>
            )}
          </div>
        </div>
      </Card>

      {/* Test Rápido de Email */}
      <TestEmailQuick />

      {/* Info adicional */}
      <Card className="bg-gradient-to-r from-blue-500/10 to-purple-500/10 border-blue-500/20 p-6">
        <div className="flex items-start gap-4">
          <div className="w-10 h-10 rounded-full bg-blue-500/20 flex items-center justify-center flex-shrink-0">
            <Mail className="w-5 h-5 text-blue-400" />
          </div>
          <div className="flex-1">
            <h4 className="text-white mb-2">¿Cómo funciona la recuperación de contraseña?</h4>
            <ul className="space-y-2 text-sm text-gray-300">
              <li>• Usuario ingresa su correo en la página de recuperación</li>
              <li>• Sistema genera un código de 6 dígitos válido por 15 minutos</li>
              <li>• Email enviado automáticamente con diseño profesional</li>
              <li>• Usuario verifica el código e ingresa nueva contraseña</li>
              <li>• Puede iniciar sesión inmediatamente con la nueva contraseña</li>
            </ul>
          </div>
        </div>
      </Card>

      {/* Documentación completa */}
      <div className="text-center">
        <p className="text-gray-400 text-sm">
          📚 Para más detalles, revisa el archivo{' '}
          <code className="bg-gray-800 px-2 py-1 rounded text-blue-400">
            CONFIGURACION_EMAIL_RECUPERACION.md
          </code>
        </p>
      </div>

      {/* Vista previa del email */}
      <VistaPreviewEmail />
    </div>
  );
}