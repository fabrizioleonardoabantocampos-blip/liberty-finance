import { useState, useEffect } from 'react';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Check, X, Loader2, ExternalLink } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { depositosAPI, usersAPI } from '../../utils/api';
import { projectId, publicAnonKey } from '../../utils/supabase/info';

interface Deposito {
  id: string;
  userId: string;
  packNombre: string;
  monto: number;
  walletDestino: string;
  comprobante?: string;
  estado: 'pendiente' | 'verificado' | 'rechazado';
  fecha: string;
  fechaProcesado?: string;
  procesadoPor?: string;
  metodoPago?: 'manual' | 'nowpayments';
  paymentId?: string;
  txHash?: string;
}

interface User {
  id: string;
  nombre: string;
  apellido: string;
  email: string;
  id_unico: string;
}

interface AdminDepositosProps {
  preloadedData?: any;
  onDataUpdate?: () => void;
}

export function AdminDepositos({ preloadedData, onDataUpdate }: AdminDepositosProps) {
  const [depositos, setDepositos] = useState<Deposito[]>([]);
  const [users, setUsers] = useState<Record<string, User>>({});
  const [loading, setLoading] = useState(true);
  const [procesando, setProcesando] = useState<string | null>(null);

  useEffect(() => {
    // Si hay datos pre-cargados, usarlos inmediatamente
    if (preloadedData?.depositos && preloadedData?.users) {
      console.log('✅ [AdminDepositos] Usando datos pre-cargados');
      console.log('📦 Depósitos pre-cargados:', preloadedData.depositos.length);
      console.log('👥 Usuarios pre-cargados:', preloadedData.users.length);
      
      setDepositos(preloadedData.depositos);
      
      // Convertir array de usuarios a objeto indexado por ID
      const usersMap: Record<string, User> = {};
      if (Array.isArray(preloadedData.users)) {
        preloadedData.users.forEach((user: User) => {
          if (user && user.id) {
            usersMap[user.id] = user;
          }
        });
      }
      setUsers(usersMap);
      setLoading(false);
      return;
    }

    // Fallback: cargar datos si no están pre-cargados
    console.log('⚠️ [AdminDepositos] No hay datos pre-cargados, cargando...');
    cargarDatos();
  }, [preloadedData]);

  const cargarDatos = async () => {
    setLoading(true);
    try {
      // 🔍 DIAGNÓSTICO: Llamar a la ruta de debug
      try {
        const debugResponse = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-9f68532a/users/debug/filtered`,
          {
            headers: {
              'Authorization': `Bearer ${publicAnonKey}`,
            },
          }
        );
        const debugData = await debugResponse.json();
        console.log('🔍 DIAGNÓSTICO - Usuarios filtrados:');
        console.log(`  Total items: ${debugData.total}`);
        console.log(`  Usuarios válidos: ${debugData.valid}`);
        console.log(`  Items filtrados: ${debugData.filtered}`);
        console.log('  Items filtrados detalle:', debugData.filteredItems);
      } catch (debugError) {
        console.log('⚠️ Error en diagnóstico (no crítico):', debugError);
      }
      
      // Cargar depósitos
      const depositosData = await depositosAPI.getAll();
      console.log('📦 Depósitos cargados:', depositosData.length);
      console.log('📦 Primeros 3 depósitos:', depositosData.slice(0, 3));
      setDepositos(depositosData);

      // Cargar usuarios
      const usersData = await usersAPI.getAll();
      console.log('👥 Usuarios cargados:', usersData.length);
      console.log('👥 Primeros 3 usuarios:', usersData.slice(0, 3));
      
      // Verificar que usersData es un array
      if (!Array.isArray(usersData)) {
        console.error('❌ ERROR: usersData NO es un array:', typeof usersData, usersData);
        toast.error('Error: La respuesta de usuarios no es válida');
        return;
      }
      
      const usersMap: Record<string, User> = {};
      usersData.forEach((user: User) => {
        if (user && user.id) {
          usersMap[user.id] = user;
        } else {
          console.warn('  ⚠️ Usuario inválido (sin ID):', user);
        }
      });
      
      setUsers(usersMap);
      
      console.log('📊 Map de usuarios creado con', Object.keys(usersMap).length, 'entradas');
      
      // Verificar qué depósitos NO tienen usuario
      console.log('🔍 Verificando depósitos sin usuario:');
      const depositosSinUsuario = depositosData.filter((dep: any) => !usersMap[dep.userId]);
      console.log(`  - Total depósitos sin usuario: ${depositosSinUsuario.length}`);
      
      if (depositosSinUsuario.length > 0) {
        console.log('  - UserIds faltantes:');
        const missingUserIds = [...new Set(depositosSinUsuario.map((d: any) => d.userId))];
        missingUserIds.forEach((id: string) => {
          console.log(`    • ${id}`);
        });
        
        // Intentar cargar esos usuarios específicamente
        console.log('🔄 Intentando cargar usuarios faltantes individualmente...');
        for (const userId of missingUserIds) {
          try {
            const userData = await usersAPI.getById(userId);
            console.log(`  ✓ Usuario ${userId} encontrado:`, userData.nombre, userData.apellido);
            usersMap[userId] = userData;
          } catch (error) {
            console.log(`  ❌ Usuario ${userId} no encontrado:`, error);
          }
        }
        
        // Actualizar el estado con los usuarios adicionales
        setUsers({...usersMap});
        console.log('📊 Map actualizado con', Object.keys(usersMap).length, 'entradas');
      }
      
    } catch (error) {
      console.error('❌ Error al cargar datos:', error);
      toast.error('Error al cargar los depósitos');
    } finally {
      setLoading(false);
    }
  };

  const handleAprobar = async (depositoId: string) => {
    setProcesando(depositoId);
    try {
      await depositosAPI.update(depositoId, { estado: 'verificado' });

      toast.success('Depósito aprobado y pack activado');
      await cargarDatos();
      if (onDataUpdate) onDataUpdate();
    } catch (error) {
      console.error('Error al aprobar depósito:', error);
      toast.error('Error al aprobar el depósito');
    } finally {
      setProcesando(null);
    }
  };

  const handleRechazar = async (depositoId: string) => {
    setProcesando(depositoId);
    try {
      await depositosAPI.update(depositoId, { estado: 'rechazado' });

      toast.success('Depósito rechazado');
      await cargarDatos();
      if (onDataUpdate) onDataUpdate();
    } catch (error) {
      console.error('Error al rechazar depósito:', error);
      toast.error('Error al rechazar el depósito');
    } finally {
      setProcesando(null);
    }
  };

  const getEstadoBadge = (estado: string) => {
    switch (estado) {
      case 'pendiente':
        return <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">Pendiente</Badge>;
      case 'verificado':
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Verificado</Badge>;
      case 'rechazado':
        return <Badge className="bg-red-100 text-red-800 hover:bg-red-100">Rechazado</Badge>;
      default:
        return <Badge>{estado}</Badge>;
    }
  };

  const getMetodoPagoBadge = (metodo?: string) => {
    if (!metodo) return null;
    
    switch (metodo) {
      case 'manual':
        return <Badge variant="outline" className="text-xs">Manual</Badge>;
      case 'nowpayments':
        return <Badge variant="outline" className="bg-blue-50 text-blue-700 text-xs">NOWPayments</Badge>;
      default:
        return <Badge variant="outline" className="text-xs">{metodo}</Badge>;
    }
  };

  const depositosPendientes = depositos.filter(d => d.estado === 'pendiente');
  const depositosVerificados = depositos.filter(d => d.estado === 'verificado');
  const depositosRechazados = depositos.filter(d => d.estado === 'rechazado');

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl text-slate-800">Gestión de Depósitos</h2>
          <p className="text-slate-600">Aprueba o rechaza los depósitos de usuarios</p>
        </div>
        <Button onClick={cargarDatos} variant="outline">
          Actualizar
        </Button>
      </div>

      {/* Estadísticas */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="p-4 md:p-6 bg-yellow-50 border-yellow-200">
          <p className="text-sm text-yellow-800 mb-1 font-medium">Pendientes</p>
          <p className="text-2xl md:text-3xl text-yellow-900 font-bold">{depositosPendientes.length}</p>
        </Card>
        <Card className="p-4 md:p-6 bg-green-50 border-green-200">
          <p className="text-sm text-green-800 mb-1 font-medium">Verificados</p>
          <p className="text-2xl md:text-3xl text-green-900 font-bold">{depositosVerificados.length}</p>
        </Card>
        <Card className="p-4 md:p-6 bg-red-50 border-red-200">
          <p className="text-sm text-red-800 mb-1 font-medium">Rechazados</p>
          <p className="text-2xl md:text-3xl text-red-900 font-bold">{depositosRechazados.length}</p>
        </Card>
      </div>

      {/* Tabla de depósitos pendientes */}
      {depositosPendientes.length > 0 && (
        <Card className="p-6">
          <h3 className="text-lg text-slate-800 mb-4">⏳ Depósitos Pendientes de Aprobación</h3>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-200">
                  <th className="text-left py-3 px-4 text-slate-600 text-sm">Fecha</th>
                  <th className="text-left py-3 px-4 text-slate-600 text-sm">Usuario</th>
                  <th className="text-left py-3 px-4 text-slate-600 text-sm">Pack</th>
                  <th className="text-left py-3 px-4 text-slate-600 text-sm">Monto</th>
                  <th className="text-left py-3 px-4 text-slate-600 text-sm">Comprobante/Hash</th>
                  <th className="text-left py-3 px-4 text-slate-600 text-sm">Método</th>
                  <th className="text-left py-3 px-4 text-slate-600 text-sm">Wallet</th>
                  <th className="text-right py-3 px-4 text-slate-600 text-sm">Acciones</th>
                </tr>
              </thead>
              <tbody>
                {depositosPendientes.map((deposito) => {
                  const user = users[deposito.userId];
                  return (
                    <tr key={deposito.id} className="border-b border-slate-100 hover:bg-slate-50">
                      <td className="py-3 px-4 text-slate-600 text-sm">
                        {new Date(deposito.fecha).toLocaleDateString('es-ES')}
                      </td>
                      <td className="py-3 px-4">
                        <div>
                          <p className="text-slate-800 text-sm">
                            {user ? `${user.nombre} ${user.apellido}` : 'Usuario desconocido'}
                          </p>
                          <p className="text-slate-500 text-xs">{user?.id_unico}</p>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-slate-800">{deposito.packNombre}</td>
                      <td className="py-3 px-4 text-slate-800">
                        ${deposito.monto?.toFixed(2) || '0.00'}
                      </td>
                      <td className="py-3 px-4">
                         <div className="space-y-1">
                           {deposito.txHash && (
                             <div className="text-xs font-mono bg-slate-100 p-1 rounded text-slate-600 truncate max-w-[120px]" title={deposito.txHash}>
                               {deposito.txHash.substring(0, 6)}...{deposito.txHash.substring(deposito.txHash.length - 4)}
                             </div>
                           )}
                           {deposito.comprobante && typeof deposito.comprobante === 'string' && deposito.comprobante.startsWith('http') && (
                             <a 
                               href={deposito.comprobante} 
                               target="_blank" 
                               rel="noopener noreferrer"
                               className="text-xs text-blue-600 hover:underline flex items-center gap-1"
                             >
                               <ExternalLink className="w-3 h-3" />
                               Ver Imagen
                             </a>
                           )}
                           {!deposito.txHash && !deposito.comprobante && (
                             <span className="text-xs text-slate-400">-</span>
                           )}
                         </div>
                      </td>
                      <td className="py-3 px-4">
                        {getMetodoPagoBadge(deposito.metodoPago)}
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <span className="text-slate-600 text-xs font-mono truncate max-w-[120px]" title={deposito.walletDestino}>
                            {deposito.walletDestino}
                          </span>
                          {deposito.paymentId && (
                            <Button
                              size="sm"
                              variant="ghost"
                              className="h-6 w-6 p-0"
                              onClick={() => window.open(`https://nowpayments.io/payment/?iid=${deposito.paymentId}`, '_blank')}
                            >
                              <ExternalLink className="h-3 w-3" />
                            </Button>
                          )}
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex items-center justify-end gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleAprobar(deposito.id)}
                            disabled={procesando === deposito.id}
                            className="bg-green-50 hover:bg-green-100 text-green-700 border-green-200"
                          >
                            {procesando === deposito.id ? (
                              <Loader2 className="h-4 w-4 animate-spin" />
                            ) : (
                              <>
                                <Check className="h-4 w-4 mr-1" />
                                Aprobar
                              </>
                            )}
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleRechazar(deposito.id)}
                            disabled={procesando === deposito.id}
                            className="bg-red-50 hover:bg-red-100 text-red-700 border-red-200"
                          >
                            <X className="h-4 w-4 mr-1" />
                            Rechazar
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {/* Tabla de todos los depósitos */}
      <Card className="p-6">
        <h3 className="text-lg text-slate-800 mb-4">📋 Todos los Depósitos</h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-200">
                <th className="text-left py-3 px-4 text-slate-600 text-sm">Fecha</th>
                <th className="text-left py-3 px-4 text-slate-600 text-sm">Usuario</th>
                <th className="text-left py-3 px-4 text-slate-600 text-sm">Pack</th>
                <th className="text-left py-3 px-4 text-slate-600 text-sm">Monto</th>
                <th className="text-left py-3 px-4 text-slate-600 text-sm">Comprobante/Hash</th>
                <th className="text-left py-3 px-4 text-slate-600 text-sm">Método</th>
                <th className="text-left py-3 px-4 text-slate-600 text-sm">Estado</th>
              </tr>
            </thead>
            <tbody>
              {depositos
                .sort((a, b) => new Date(b.fecha).getTime() - new Date(a.fecha).getTime())
                .map((deposito) => {
                  const user = users[deposito.userId];
                  
                  // DEBUG: Log en el renderizado
                  if (!user) {
                    console.log(`❌ RENDER: No se encontró usuario para depósito ${deposito.id}, userId="${deposito.userId}"`);
                    console.log(`   Usuarios disponibles:`, Object.keys(users).length);
                    console.log(`   ¿El userId existe en users?:`, deposito.userId in users);
                  }
                  
                  return (
                    <tr key={deposito.id} className="border-b border-slate-100 hover:bg-slate-50">
                      <td className="py-3 px-4 text-slate-600 text-sm">
                        {new Date(deposito.fecha).toLocaleDateString('es-ES', {
                          year: 'numeric',
                          month: 'short',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </td>
                      <td className="py-3 px-4">
                        <div>
                          <p className="text-slate-800 text-sm">
                            {user ? `${user.nombre} ${user.apellido}` : 'Usuario desconocido'}
                          </p>
                          <p className="text-slate-500 text-xs">{user?.id_unico}</p>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-slate-800">{deposito.packNombre}</td>
                      <td className="py-3 px-4 text-slate-800">
                        ${deposito.monto?.toFixed(2) || '0.00'}
                      </td>
                      <td className="py-3 px-4">
                         <div className="space-y-1">
                           {deposito.txHash && (
                             <div className="text-xs font-mono bg-slate-100 p-1 rounded text-slate-600 truncate max-w-[120px]" title={deposito.txHash}>
                               {deposito.txHash.substring(0, 6)}...{deposito.txHash.substring(deposito.txHash.length - 4)}
                             </div>
                           )}
                           {deposito.comprobante && typeof deposito.comprobante === 'string' && deposito.comprobante.startsWith('http') && (
                             <a 
                               href={deposito.comprobante} 
                               target="_blank" 
                               rel="noopener noreferrer"
                               className="text-xs text-blue-600 hover:underline flex items-center gap-1"
                             >
                               <ExternalLink className="w-3 h-3" />
                               Ver Imagen
                             </a>
                           )}
                           {!deposito.txHash && !deposito.comprobante && (
                             <span className="text-xs text-slate-400">-</span>
                           )}
                         </div>
                      </td>
                      <td className="py-3 px-4">
                        {getMetodoPagoBadge(deposito.metodoPago)}
                      </td>
                      <td className="py-3 px-4">
                        {getEstadoBadge(deposito.estado)}
                      </td>
                    </tr>
                  );
                })}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Info Card */}
      <Card className="p-4 bg-blue-50 border-blue-200">
        <div className="flex items-start gap-3">
          <div className="text-blue-600 text-2xl">ℹ️</div>
          <div className="flex-1">
            <p className="text-sm text-blue-800 mb-2">
              <strong>Importante:</strong> Al aprobar un depósito se realizarán las siguientes acciones automáticamente:
            </p>
            <ul className="text-sm text-blue-700 space-y-1 list-disc list-inside">
              <li>Se activará el pack correspondiente para el usuario</li>
              <li>Se distribuirán las comisiones de red a 10 niveles (8%, 6%, 4%, 2%, 1%, 1%, 1%, 1%, 0.5%, 0.5%)</li>
              <li>Se otorgará el bono de patrocinio del 10% al referidor directo</li>
              <li>El usuario podrá ver su pack activo y empezar a generar rendimientos</li>
              <li>El usuario aparecerá en la matriz multinivel</li>
            </ul>
          </div>
        </div>
      </Card>
    </div>
  );
}