import { useState, useEffect } from 'react';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Label } from '../ui/label';
import { Input } from '../ui/input';
import { Percent, Mail, Database, Network, Loader2, AlertTriangle, DollarSign, Clock, Settings, Trash2, Users, Award } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { callServer } from '../../utils/api';
import { ConfiguracionEmail } from './ConfiguracionEmail';

export function AdminSettings() {
  const [settings, setSettings] = useState({
    rendimientoPorcentaje: 15,
    redPorcentaje: 10,
    comisionRetiroRendimiento: 10,
    comisionRetiroRed: 6,
    tiempoRetiro: 48
  });
  const [isResetting, setIsResetting] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isRecalculatingMatrix, setIsRecalculatingMatrix] = useState(false);
  const [isDiagnosticando, setIsDiagnosticando] = useState(false);
  const [diagnosticoMatriz, setDiagnosticoMatriz] = useState<any>(null);
  const [isDiagnosticandoDuplicados, setIsDiagnosticandoDuplicados] = useState(false);
  const [duplicados, setDuplicados] = useState<any>(null);
  const [isFusionando, setIsFusionando] = useState<string | null>(null);
  const [diagnosticoUsuarioId, setDiagnosticoUsuarioId] = useState('');
  const [isDiagnosticandoUsuario, setIsDiagnosticandoUsuario] = useState(false);
  const [diagnosticoUsuario, setDiagnosticoUsuario] = useState<any>(null);
  const [isRecalculatingMatrizUsuario, setIsRecalculatingMatrizUsuario] = useState(false);
  const [isRecalculatingRangos, setIsRecalculatingRangos] = useState(false);
  const [isRecalculatingJorge, setIsRecalculatingJorge] = useState(false);
  const [isDiagnosticandoSilver, setIsDiagnosticandoSilver] = useState(false);
  const [diagnosticoSilver, setDiagnosticoSilver] = useState<any>(null);
  const [recalcularRangoEmail, setRecalcularRangoEmail] = useState('');
  const [isRecalculatingRangoEmail, setIsRecalculatingRangoEmail] = useState(false);

  const handleVerDiagnostico = async () => {
    setIsDiagnosticando(true);
    try {
      const response = await callServer('/debug/matriz-status', 'GET');
      setDiagnosticoMatriz(response);
      
      if (response.sinMatrizPadre > 0) {
        toast.warning(`⚠️ Hay ${response.sinMatrizPadre} packs sin posición de matriz`);
      } else {
        toast.success('✅ Todos los packs tienen posición asignada');
      }
    } catch (error) {
      console.error('Error al obtener diagnóstico:', error);
      toast.error('Error al obtener diagnóstico de matriz');
    } finally {
      setIsDiagnosticando(false);
    }
  };

  const handleRecalcularMatriz = async () => {
    if (!confirm('🔄 ¿Deseas recalcular las posiciones de matriz para todos los usuarios?\n\nEsto asignará posiciones en la matriz a todos los packs que aún no las tengan.\n\nEsta operación puede tardar algunos segundos.')) {
      return;
    }

    setIsRecalculatingMatrix(true);
    try {
      const response = await callServer('/admin/recalcular-matriz', 'POST');
      
      if (response && response.success) {
        toast.success(`✅ Matriz recalculada: ${response.packsActualizados} packs actualizados`);
      } else {
        toast.error('Error al recalcular la matriz');
      }
    } catch (error) {
      console.error('Error al recalcular matriz:', error);
      toast.error('Error al recalcular la matriz');
    } finally {
      setIsRecalculatingMatrix(false);
    }
  };

  const loadSettings = async () => {
    setIsLoading(true);
    try {
      const config = await callServer('/admin/configuracion', 'GET');
      if (config) {
        setSettings({
          rendimientoPorcentaje: config.porcentajeRendimiento || 1,
          redPorcentaje: config.comisionReferidoDirecto ? (config.comisionReferidoDirecto * 100) : 10,
          comisionRetiroRendimiento: config.comisionRetiroRendimiento || 10,
          comisionRetiroRed: config.comisionRetiroRed || 6,
          tiempoRetiro: config.tiempoRetiro || 48
        });
      }
    } catch (error) {
      console.error('Error loading settings:', error);
      toast.error('Error al cargar la configuración');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      // Mapear settings a formato backend
      const configToSave = {
        porcentajeRendimiento: settings.rendimientoPorcentaje,
        comisionReferidoDirecto: settings.redPorcentaje / 100,
        comisionRetiroRendimiento: settings.comisionRetiroRendimiento,
        comisionRetiroRed: settings.comisionRetiroRed,
        tiempoRetiro: settings.tiempoRetiro
      };

      const response = await callServer('/admin/configuracion', 'PUT', configToSave);
      
      if (response && !response.error) {
        toast.success('Configuración guardada exitosamente');
      } else {
        toast.error('Error al guardar la configuración');
      }
    } catch (error) {
      console.error('Error saving settings:', error);
      toast.error('Error al guardar la configuración');
    } finally {
      setIsSaving(false);
    }
  };

  const handleResetDatabase = async () => {
    if (!confirm('⚠️ ¿Estás seguro de que deseas resetear TODOS los datos? Esta acción NO se puede deshacer.\n\nSe eliminarán:\n- Todos los usuarios (excepto admin)\n- Todos los packs\n- Todos los depósitos\n- Todos los cobros\n- Todas las comisiones')) {
      return;
    }

    setIsResetting(true);
    try {
      const response = await callServer('/dev/reset', 'POST');
      
      if (response.success) {
        toast.success('✅ Base de datos reseteada exitosamente. Se ha creado el usuario admin por defecto.');
        setTimeout(() => {
          window.location.reload();
        }, 2000);
      } else {
        toast.error('Error al resetear la base de datos');
      }
    } catch (error) {
      console.error('Error al resetear base de datos:', error);
      toast.error('Error al resetear la base de datos');
    } finally {
      setIsResetting(false);
    }
  };

  const handleVerDuplicados = async () => {
    setIsDiagnosticandoDuplicados(true);
    try {
      const response = await callServer('/debug/usuarios-duplicados', 'GET');
      setDuplicados(response);
      
      if (response.totalDuplicados > 0) {
        toast.warning(`⚠️ Encontrados ${response.totalDuplicados} emails con duplicados`);
      } else {
        toast.success('✅ No se encontraron usuarios duplicados');
      }
    } catch (error) {
      console.error('Error al buscar duplicados:', error);
      toast.error('Error al buscar duplicados');
    } finally {
      setIsDiagnosticandoDuplicados(false);
    }
  };

  const handleFusionarDuplicado = async (email: string) => {
    if (!confirm(`🔄 ¿Fusionar usuarios duplicados con email ${email}?\n\n✅ Se mantendrá el usuario más antiguo\n🗑️ Se eliminarán los duplicados\n📦 Se transferirán todos los packs\n👥 Se transferirán todos los referidos`)) {
      return;
    }
    
    setIsFusionando(email);
    try {
      const response = await callServer('/admin/fusionar-duplicado', 'POST', { email });
      
      if (response && response.success) {
        toast.success(`✅ ${response.usuariosEliminados} duplicados eliminados, ${response.packsTransferidos} packs transferidos`);
        // Refrescar la lista de duplicados
        handleVerDuplicados();
      } else {
        const errorMsg = response?.details || response?.error || 'Error desconocido';
        console.error('Error en fusión:', errorMsg);
        toast.error(`Error al fusionar duplicados: ${errorMsg}`);
      }
    } catch (error: any) {
      console.error('Error al fusionar:', error);
      const errorMsg = error?.message || String(error);
      toast.error(`Error al fusionar duplicados: ${errorMsg}`);
    } finally {
      setIsFusionando(null);
    }
  };

  const handleDiagnosticarUsuario = async () => {
    if (!diagnosticoUsuarioId) {
      toast.error('Por favor, ingresa el ID del usuario');
      return;
    }

    setIsDiagnosticandoUsuario(true);
    try {
      const response = await callServer('/debug/diagnostico-usuario', 'POST', { id: diagnosticoUsuarioId });
      setDiagnosticoUsuario(response);
      
      if (response.problema.referidosSinMatriz > 0) {
        toast.warning(`⚠️ Encontrados ${response.problema.referidosSinMatriz} referidos sin posición de matriz`);
      } else {
        toast.success('✅ Todos los referidos tienen posición asignada');
      }
    } catch (error) {
      console.error('Error al diagnosticar usuario:', error);
      toast.error('Error al diagnosticar usuario');
    } finally {
      setIsDiagnosticandoUsuario(false);
    }
  };

  const handleDiagnosticarSilver = async () => {
    setIsDiagnosticandoSilver(true);
    toast.loading('🔍 Diagnosticando rango Silver...', { id: 'silver' });
    
    try {
      const response = await callServer('/admin/diagnosticar-silver', 'GET');
      setDiagnosticoSilver(response);
      
      toast.dismiss('silver');
      
      if (response.estado === 'corregido') {
        toast.success(`✅ Rango Silver corregido!\nAntes: ${response.antes.directos} directos, $${response.antes.volumen/1000}K\nAhora: ${response.despues.directos} directos, $${response.despues.volumen/1000}K`, {
          duration: 7000
        });
      } else {
        toast.success(`✅ Rango Silver está correcto: ${response.configuracion.directos} directos, $${response.configuracion.volumen/1000}K volumen`);
      }
    } catch (error: any) {
      console.error('Error al diagnosticar Silver:', error);
      toast.dismiss('silver');
      toast.error(`❌ Error: ${error.message || 'Error desconocido'}`);
    } finally {
      setIsDiagnosticandoSilver(false);
    }
  };

  const handleRecalcularJorge = async () => {
    setIsRecalculatingJorge(true);
    toast.loading('🔄 Recalculando rango de Jorge...', { id: 'jorge' });
    
    try {
      // ID de Jorge Sandoval
      const jorgeIdUnico = 'LF1764093102964454';
      
      // Primero obtener todos los usuarios para encontrar el UUID de Jorge
      const usuarios = await callServer('/users', 'GET');
      const jorge = usuarios.find((u: any) => u.id_unico === jorgeIdUnico);
      
      if (!jorge) {
        toast.dismiss('jorge');
        toast.error('❌ No se encontró a Jorge en el sistema');
        return;
      }
      
      // Recalcular su rango
      const response = await callServer(`/users/${jorge.id}/recalcular-rango`, 'POST');
      
      toast.dismiss('jorge');
      
      if (response.success) {
        toast.success(`✅ Rango de Jorge actualizado a: ${response.rango}`, {
          duration: 5000
        });
      } else {
        toast.error('❌ Error al recalcular rango de Jorge');
      }
    } catch (error: any) {
      console.error('Error al recalcular rango de Jorge:', error);
      toast.dismiss('jorge');
      toast.error(`❌ Error: ${error.message || 'Error desconocido'}`);
    } finally {
      setIsRecalculatingJorge(false);
    }
  };

  const handleRecalcularTodosRangos = async () => {
    if (!confirm('🔄 ¿Deseas recalcular los rangos de TODOS los usuarios?\n\nEsto actualizará el rango de cada usuario según su volumen y referidos actuales.\n\nEsta operación puede tardar hasta 2-3 minutos. Por favor, no cierres esta ventana.')) {
      return;
    }

    setIsRecalculatingRangos(true);
    
    // Mostrar mensaje de progreso
    toast.loading('⏳ Recalculando rangos... Por favor espera (puede tardar hasta 3 min)', {
      id: 'recalcular-rangos',
      duration: 180000 // 3 minutos
    });
    
    try {
      // Aumentar timeout para esta operación específica
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 180000); // 3 minutos
      
      const response = await fetch(
        `https://${(await import('../../utils/supabase/info')).projectId}.supabase.co/functions/v1/make-server-9f68532a/admin/recalcular-todos-rangos`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${(await import('../../utils/supabase/info')).publicAnonKey}`,
          },
          signal: controller.signal,
        }
      );
      
      clearTimeout(timeoutId);
      
      if (!response.ok) {
        throw new Error(`Error ${response.status}: ${response.statusText}`);
      }
      
      const data = await response.json();
      
      toast.dismiss('recalcular-rangos');
      
      if (data.success) {
        const mensaje = data.usuariosProcesados 
          ? `✅ ${data.totalCambios} rangos actualizados (${data.usuariosProcesados} procesados de ${data.totalUsuarios} usuarios)`
          : `✅ ${data.totalCambios} rangos actualizados de ${data.totalUsuarios} usuarios`;
        
        toast.success(mensaje, {
          duration: 5000
        });
        
        // Mostrar algunos cambios si los hay
        if (data.resultados && data.resultados.length > 0) {
          console.log('📊 Cambios de rangos:', data.resultados);
        }
      } else {
        toast.error('Error al recalcular rangos');
      }
    } catch (error: any) {
      console.error('Error al recalcular rangos:', error);
      toast.dismiss('recalcular-rangos');
      
      if (error.name === 'AbortError') {
        toast.error('⏱️ La operación tardó demasiado. Por favor, intenta de nuevo más tarde.', {
          duration: 7000
        });
      } else {
        toast.error(`❌ Error: ${error.message || 'Error al recalcular rangos'}`, {
          duration: 5000
        });
      }
    } finally {
      setIsRecalculatingRangos(false);
    }
  };

  const handleRecalcularMatrizUsuario = async () => {
    if (!diagnosticoUsuarioId) {
      toast.error('Por favor, ingresa primero el ID del usuario');
      return;
    }

    const usuario = diagnosticoUsuario?.usuario;
    if (!usuario) {
      toast.error('Primero diagnostica el usuario antes de recalcular');
      return;
    }

    if (!confirm(`🔧 ¿Recalcular la matriz SOLO para los referidos directos de ${usuario.nombre}?\\n\\n✅ Solo afectará a los ${diagnosticoUsuario.referidosDirectos.total} referidos directos\\n✅ NO afectará al resto de la matriz\\n✅ Se ordenarán por fecha de registro`)) {
      return;
    }

    setIsRecalculatingMatrizUsuario(true);
    try {
      const response = await callServer('/admin/recalcular-matriz-usuario', 'POST', { userId: diagnosticoUsuarioId });
      
      if (response && response.success) {
        toast.success(`✅ ${response.referidosRecalculados} referidos recalculados, ${response.packsActualizados} packs actualizados`);
        // Refrescar el diagnóstico
        handleDiagnosticarUsuario();
      } else {
        toast.error('Error al recalcular matriz del usuario');
      }
    } catch (error) {
      console.error('Error al recalcular matriz del usuario:', error);
      toast.error('Error al recalcular matriz del usuario');
    } finally {
      setIsRecalculatingMatrizUsuario(false);
    }
  };

  const handleRecalcularRangoEmail = async () => {
    if (!recalcularRangoEmail) {
      toast.error('Por favor, ingresa el email del usuario');
      return;
    }

    setIsRecalculatingRangoEmail(true);
    toast.loading('🔄 Recalculando rango...', { id: 'recalcular-rango' });
    
    try {
      const response = await callServer('/admin/recalcular-rango-usuario', 'POST', { email: recalcularRangoEmail });
      
      toast.dismiss('recalcular-rango');
      
      if (response && response.success) {
        const usuario = response.usuario;
        if (usuario.cambio) {
          toast.success(`✅ Rango actualizado: "${usuario.rangoAnterior}" → "${usuario.rangoNuevo}"`, {
            duration: 5000
          });
        } else {
          toast.info(`ℹ️ Rango sin cambios: "${usuario.rangoNuevo}"`, {
            duration: 3000
          });
        }
      } else {
        toast.error('❌ Error al recalcular rango del usuario');
      }
    } catch (error: any) {
      console.error('Error al recalcular rango del usuario:', error);
      toast.dismiss('recalcular-rango');
      toast.error(`❌ Error: ${error.message || 'Error al recalcular rango del usuario'}`, {
        duration: 5000
      });
    } finally {
      setIsRecalculatingRangoEmail(false);
    }
  };

  useEffect(() => {
    loadSettings();
  }, []);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl text-slate-800 mb-2">Configuración del Sistema</h1>
        <p className="text-slate-600">Ajusta los parámetros globales de Liberty Finance</p>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="general">
        <TabsList className="grid grid-cols-2">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="email">Email</TabsTrigger>
        </TabsList>

        {/* General Settings */}
        <TabsContent value="general">
          {/* Percentages */}
          <Card className="p-6 bg-white border-0 shadow-lg">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-xl bg-blue-100 flex items-center justify-center">
                <Percent className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <h3 className="text-slate-800">Porcentajes de Ganancias</h3>
                <p className="text-sm text-slate-600">Configura los porcentajes de rendimiento</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label>Rendimiento Diario (%)</Label>
                <Input
                  type="number"
                  value={settings.rendimientoPorcentaje}
                  onChange={(e) => setSettings({ ...settings, rendimientoPorcentaje: Number(e.target.value) })}
                  className="h-12 rounded-xl"
                />
                <p className="text-xs text-slate-500">Porcentaje diario sobre la inversión</p>
              </div>

              <div className="space-y-2">
                <Label>Comisión de Red (%)</Label>
                <Input
                  type="number"
                  value={settings.redPorcentaje}
                  onChange={(e) => setSettings({ ...settings, redPorcentaje: Number(e.target.value) })}
                  className="h-12 rounded-xl"
                />
                <p className="text-xs text-slate-500">Porcentaje de comisión por referidos</p>
              </div>
            </div>
          </Card>

          {/* Withdrawal Fees */}
          <Card className="p-6 bg-white border-0 shadow-lg">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-xl bg-green-100 flex items-center justify-center">
                <DollarSign className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <h3 className="text-slate-800">Comisiones de Retiro</h3>
                <p className="text-sm text-slate-600">Configura las comisiones por retiro</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label>Comisión Retiro Rendimiento (%)</Label>
                <Input
                  type="number"
                  value={settings.comisionRetiroRendimiento}
                  onChange={(e) => setSettings({ ...settings, comisionRetiroRendimiento: Number(e.target.value) })}
                  className="h-12 rounded-xl"
                />
                <p className="text-xs text-slate-500">Comisión sobre retiros de rendimiento diario</p>
              </div>

              <div className="space-y-2">
                <Label>Comisión Retiro Red (%)</Label>
                <Input
                  type="number"
                  value={settings.comisionRetiroRed}
                  onChange={(e) => setSettings({ ...settings, comisionRetiroRed: Number(e.target.value) })}
                  className="h-12 rounded-xl"
                />
                <p className="text-xs text-slate-500">Comisión sobre retiros de comisiones de red</p>
              </div>
            </div>
          </Card>

          {/* Processing Time */}
          <Card className="p-6 bg-white border-0 shadow-lg">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-xl bg-purple-100 flex items-center justify-center">
                <Clock className="w-6 h-6 text-purple-600" />
              </div>
              <div>
                <h3 className="text-slate-800">Tiempo de Procesamiento</h3>
                <p className="text-sm text-slate-600">Configura los tiempos del sistema</p>
              </div>
            </div>

            <div className="space-y-2 max-w-md">
              <Label>Tiempo de Procesamiento de Retiros (horas)</Label>
              <Input
                type="number"
                value={settings.tiempoRetiro}
                onChange={(e) => setSettings({ ...settings, tiempoRetiro: Number(e.target.value) })}
                className="h-12 rounded-xl"
              />
              <p className="text-xs text-slate-500">Tiempo estimado para procesar retiros</p>
            </div>
          </Card>

          {/* Packs Configuration */}
          <Card className="p-6 bg-white border-0 shadow-lg">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-xl bg-amber-100 flex items-center justify-center">
                <Settings className="w-6 h-6 text-amber-600" />
              </div>
              <div>
                <h3 className="text-slate-800">Configuración de Packs</h3>
                <p className="text-sm text-slate-600">Administra los planes de inversión</p>
              </div>
            </div>

            <div className="space-y-4">
              {[
                { name: 'Starter', amount: 100, color: 'blue' },
                { name: 'Basic', amount: 250, color: 'green' },
                { name: 'Premium', amount: 500, color: 'purple' },
              ].map((pack, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-slate-50 rounded-xl">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-xl bg-${pack.color}-100 flex items-center justify-center`}>
                      <span className={`text-${pack.color}-600`}>{index + 1}</span>
                    </div>
                    <div>
                      <p className="text-slate-800">{pack.name}</p>
                      <p className="text-sm text-slate-500">${pack.amount} USDT</p>
                    </div>
                  </div>
                  <Button variant="outline" size="sm">
                    Editar
                  </Button>
                </div>
              ))}
            </div>
          </Card>

          {/* Matrix Recalculation Tool */}
          <Card className="p-6 bg-blue-50 border-2 border-blue-200 shadow-lg">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-xl bg-blue-100 flex items-center justify-center">
                <Network className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <h3 className="text-blue-800">Herramienta de Matriz</h3>
                <p className="text-sm text-blue-600">Recalcular posiciones de spillover</p>
              </div>
            </div>

            <div className="p-4 bg-white rounded-lg border-2 border-blue-200 mb-4">
              <h4 className="text-slate-800 mb-2">Recalcular Posiciones de Matriz</h4>
              <p className="text-sm text-slate-600 mb-3">
                Esta herramienta asignará automáticamente posiciones en la matriz (spillover) a todos los packs que aún no las tengan. Útil para:
              </p>
              <ul className="text-sm text-slate-600 space-y-1 mb-4 list-disc list-inside">
                <li>Corregir packs antiguos sin posición de matriz</li>
                <li>Asegurar que todos los referidos aparezcan en el árbol visual</li>
                <li>Sincronizar la estructura de spillover</li>
              </ul>
              <div className="p-3 bg-blue-50 rounded-lg border border-blue-200 mb-4">
                <p className="text-xs text-blue-800">
                  ℹ️ <strong>Nota:</strong> Esta operación NO modifica la red de referidos ni las comisiones. Solo asigna posiciones visuales en la matriz 3x3 de 10 niveles.
                </p>
              </div>
              
              {/* Diagnóstico de Matriz */}
              {diagnosticoMatriz && (
                <div className={`p-3 rounded-lg border mb-3 ${
                  diagnosticoMatriz.sinMatrizPadre > 0 
                    ? 'bg-amber-50 border-amber-200' 
                    : 'bg-green-50 border-green-200'
                }`}>
                  <p className={`text-sm ${
                    diagnosticoMatriz.sinMatrizPadre > 0 
                      ? 'text-amber-800' 
                      : 'text-green-800'
                  }`}>
                    {diagnosticoMatriz.sinMatrizPadre > 0 ? (
                      <>⚠️ <strong>{diagnosticoMatriz.sinMatrizPadre} packs</strong> sin posición de matriz</>
                    ) : (
                      <>✅ Todos los packs tienen posición asignada</>
                    )}
                  </p>
                  <p className="text-xs text-slate-600 mt-1">
                    Total: {diagnosticoMatriz.totalPacks} packs | Con matriz: {diagnosticoMatriz.conMatrizPadre}
                  </p>
                </div>
              )}

              {/* Botón Diagnosticar */}
              <Button
                onClick={handleVerDiagnostico}
                variant="outline"
                className="w-full border-amber-300 text-amber-700 hover:bg-amber-100 hover:border-amber-400 h-12 mb-3"
                disabled={isDiagnosticando}
              >
                {isDiagnosticando ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Diagnosticando...
                  </>
                ) : (
                  <>
                    <AlertTriangle className="w-4 h-4 mr-2" />
                    1. Ver Diagnóstico
                  </>
                )}
              </Button>

              {/* Botón Recalcular */}
              <Button
                onClick={handleRecalcularMatriz}
                variant="outline"
                className="w-full border-blue-300 text-blue-700 hover:bg-blue-100 hover:border-blue-400 h-12"
                disabled={isRecalculatingMatrix}
              >
                {isRecalculatingMatrix ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Recalculando matriz...
                  </>
                ) : (
                  <>
                    <Network className="w-4 h-4 mr-2" />
                    2. Recalcular Matriz de Spillover
                  </>
                )}
              </Button>
            </div>
          </Card>

          {/* Recalcular Rangos Tool */}
          <Card className="p-6 bg-purple-50 border-2 border-purple-200 shadow-lg">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-xl bg-purple-100 flex items-center justify-center">
                <Award className="w-6 h-6 text-purple-600" />
              </div>
              <div>
                <h3 className="text-purple-800">Sistema de Rangos</h3>
                <p className="text-sm text-purple-600">Actualiza los rangos de todos los usuarios</p>
              </div>
            </div>

            <div className="space-y-3">
              <div className="bg-purple-100 border border-purple-300 rounded-lg p-4">
                <p className="text-sm text-purple-800">
                  <strong>¿Cuándo usar esto?</strong>
                </p>
                <ul className="text-xs text-purple-700 mt-2 space-y-1 list-disc list-inside">
                  <li>Después de cambiar requisitos de rangos</li>
                  <li>Si los rangos no se actualizan automáticamente</li>
                  <li>Para corregir inconsistencias en rangos</li>
                </ul>
                <p className="text-xs text-purple-600 mt-3 italic">
                  ⚡ Solo procesa usuarios que ya tienen un rango asignado (más rápido)
                </p>
              </div>

              {/* Botón de diagnóstico de rango Silver */}
              <Button
                onClick={handleDiagnosticarSilver}
                variant="outline"
                className="w-full border-blue-300 text-blue-700 hover:bg-blue-100 hover:border-blue-400 h-10"
                disabled={isDiagnosticandoSilver}
              >
                {isDiagnosticandoSilver ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Diagnosticando...
                  </>
                ) : (
                  <>
                    🔍 Diagnosticar y Corregir Silver
                  </>
                )}
              </Button>

              {/* Resultado del diagnóstico */}
              {diagnosticoSilver && (
                <div className={`p-3 rounded-lg text-sm ${
                  diagnosticoSilver.estado === 'corregido' 
                    ? 'bg-orange-50 border border-orange-200' 
                    : 'bg-green-50 border border-green-200'
                }`}>
                  {diagnosticoSilver.estado === 'corregido' ? (
                    <>
                      <p className="font-semibold text-orange-700">🔧 Rango Corregido:</p>
                      <p className="text-orange-600 mt-1">
                        Antes: {diagnosticoSilver.antes.directos} directos, ${diagnosticoSilver.antes.volumen/1000}K volumen
                      </p>
                      <p className="text-green-700 font-semibold">
                        Ahora: {diagnosticoSilver.despues.directos} directos, ${diagnosticoSilver.despues.volumen/1000}K volumen
                      </p>
                    </>
                  ) : (
                    <p className="text-green-700">
                      ✅ Rango Silver está correcto: {diagnosticoSilver.configuracion.directos} directos, ${diagnosticoSilver.configuracion.volumen/1000}K volumen
                    </p>
                  )}
                </div>
              )}

              {/* Botón rápido para Jorge (DEBUG) */}
              <Button
                onClick={handleRecalcularJorge}
                variant="outline"
                className="w-full border-orange-300 text-orange-700 hover:bg-orange-100 hover:border-orange-400 h-10"
                disabled={isRecalculatingJorge}
              >
                {isRecalculatingJorge ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Recalculando...
                  </>
                ) : (
                  <>
                    ⚡ Recalcular Solo Jorge (Rápido)
                  </>
                )}
              </Button>

              <Button
                onClick={handleRecalcularTodosRangos}
                variant="outline"
                className="w-full border-purple-300 text-purple-700 hover:bg-purple-100 hover:border-purple-400 h-12"
                disabled={isRecalculatingRangos}
              >
                {isRecalculatingRangos ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Recalculando rangos...
                  </>
                ) : (
                  <>
                    <Award className="w-4 h-4 mr-2" />
                    Recalcular Todos los Rangos
                  </>
                )}
              </Button>

              {/* Recalcular Rango por Email */}
              <div className="mt-4">
                <Label>Recalcular Rango por Email</Label>
                <div className="flex gap-2">
                  <Input
                    type="email"
                    placeholder="Ej: usuario@example.com"
                    value={recalcularRangoEmail}
                    onChange={(e) => setRecalcularRangoEmail(e.target.value)}
                    className="h-12 rounded-xl"
                  />
                  <Button
                    onClick={handleRecalcularRangoEmail}
                    variant="outline"
                    className="border-purple-300 text-purple-700 hover:bg-purple-100 whitespace-nowrap h-12"
                    disabled={isRecalculatingRangoEmail || !recalcularRangoEmail}
                  >
                    {isRecalculatingRangoEmail ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Recalculando...
                      </>
                    ) : (
                      'Recalcular Rango'
                    )}
                  </Button>
                </div>
              </div>
            </div>
          </Card>

          {/* Duplicate Users Tool */}
          <Card className="p-6 bg-amber-50 border-2 border-amber-200 shadow-lg">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-xl bg-amber-100 flex items-center justify-center">
                <Users className="w-6 h-6 text-amber-600" />
              </div>
              <div>
                <h3 className="text-amber-800">Usuarios Duplicados</h3>
                <p className="text-sm text-amber-600">Detectar y fusionar cuentas duplicadas</p>
              </div>
            </div>

            <div className="p-4 bg-white rounded-lg border-2 border-amber-200 mb-4">
              <h4 className="text-slate-800 mb-2">Detectar y Fusionar Duplicados</h4>
              <p className="text-sm text-slate-600 mb-3">
                Esta herramienta busca usuarios con el mismo email y permite fusionarlos en un solo usuario. Útil para:
              </p>
              <ul className="text-sm text-slate-600 space-y-1 mb-4 list-disc list-inside">
                <li>Corregir registros duplicados por error de migración</li>
                <li>Consolidar packs y referidos de un mismo usuario</li>
                <li>Limpiar la base de datos de duplicados</li>
              </ul>
              <div className="p-3 bg-amber-50 rounded-lg border border-amber-200 mb-4">
                <p className="text-xs text-amber-800">
                  ⚠️ <strong>Nota:</strong> Se mantendrá el usuario más antiguo y se transferirán todos los packs y referidos. Los duplicados se eliminarán.
                </p>
              </div>
              
              {/* Resultados de Duplicados */}
              {duplicados && duplicados.totalDuplicados > 0 && (
                <div className="space-y-3 mb-4 max-h-96 overflow-y-auto">
                  {duplicados.duplicados.map((dup: any, index: number) => (
                    <div key={index} className="p-3 bg-red-50 border border-red-200 rounded-lg">
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex-1">
                          <p className="text-red-900">
                            📧 <strong>{dup.email}</strong>
                          </p>
                          <p className="text-xs text-red-700 mt-1">
                            {dup.cantidad} registros duplicados
                          </p>
                        </div>
                        <Button
                          onClick={() => handleFusionarDuplicado(dup.email)}
                          size="sm"
                          variant="outline"
                          className="border-red-300 text-red-700 hover:bg-red-100"
                          disabled={isFusionando === dup.email}
                        >
                          {isFusionando === dup.email ? (
                            <>
                              <Loader2 className="w-3 h-3 mr-1 animate-spin" />
                              Fusionando...
                            </>
                          ) : (
                            'Fusionar'
                          )}
                        </Button>
                      </div>
                      <div className="space-y-1 mt-2">
                        {dup.usuarios.map((usuario: any, uIdx: number) => (
                          <div key={uIdx} className="text-xs text-slate-600 bg-white p-2 rounded border border-slate-200">
                            <div className="flex items-center justify-between">
                              <span>
                                <strong>{usuario.id_unico}</strong> - {usuario.nombre}
                              </span>
                              <span className="text-xs">
                                {usuario.packs} packs | {usuario.referidos} referidos
                              </span>
                            </div>
                            {usuario.detallesPacks && usuario.detallesPacks.length > 0 && (
                              <div className="mt-1 text-xs text-slate-500">
                                Packs: {usuario.detallesPacks.map((p: any) => `${p.nombre} ($${p.monto})`).join(', ')}
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {duplicados && duplicados.totalDuplicados === 0 && (
                <div className="p-3 rounded-lg border mb-3 bg-green-50 border-green-200">
                  <p className="text-sm text-green-800">
                    ✅ No se encontraron usuarios duplicados
                  </p>
                </div>
              )}

              {/* Botón Buscar Duplicados */}
              <Button
                onClick={handleVerDuplicados}
                variant="outline"
                className="w-full border-amber-300 text-amber-700 hover:bg-amber-100 hover:border-amber-400 h-12"
                disabled={isDiagnosticandoDuplicados}
              >
                {isDiagnosticandoDuplicados ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Buscando duplicados...
                  </>
                ) : (
                  <>
                    <Users className="w-4 h-4 mr-2" />
                    Buscar Usuarios Duplicados
                  </>
                )}
              </Button>
            </div>
          </Card>

          {/* Diagnostic Tool for Specific User */}
          <Card className="p-6 bg-purple-50 border-2 border-purple-200 shadow-lg">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-xl bg-purple-100 flex items-center justify-center">
                <Network className="w-6 h-6 text-purple-600" />
              </div>
              <div>
                <h3 className="text-purple-800">Diagnóstico de Referidos</h3>
                <p className="text-sm text-purple-600">Ver referidos y su posición en matriz</p>
              </div>
            </div>

            <div className="p-4 bg-white rounded-lg border-2 border-purple-200 mb-4">
              <h4 className="text-slate-800 mb-2">Diagnosticar Usuario Específico</h4>
              <p className="text-sm text-slate-600 mb-3">
                Ingresa el ID del usuario para ver sus referidos directos y verificar si aparecen en su matriz:
              </p>
              
              <div className="flex gap-2 mb-4">
                <Input
                  type="text"
                  placeholder="Ej: LF1764093102964454"
                  value={diagnosticoUsuarioId}
                  onChange={(e) => setDiagnosticoUsuarioId(e.target.value)}
                  className="h-12 rounded-xl"
                />
                <Button
                  onClick={handleDiagnosticarUsuario}
                  variant="outline"
                  className="border-purple-300 text-purple-700 hover:bg-purple-100 whitespace-nowrap h-12"
                  disabled={isDiagnosticandoUsuario || !diagnosticoUsuarioId}
                >
                  {isDiagnosticandoUsuario ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Buscando...
                    </>
                  ) : (
                    'Diagnosticar'
                  )}
                </Button>
              </div>

              {/* Resultados del Diagnóstico */}
              {diagnosticoUsuario && (
                <div className="space-y-3 mt-4">
                  {/* Info del Usuario */}
                  <div className="p-3 bg-purple-50 rounded-lg border border-purple-200">
                    <p className="text-sm text-purple-900 mb-1">
                      <strong>Usuario:</strong> {diagnosticoUsuario.usuario.nombre} ({diagnosticoUsuario.usuario.id_unico})
                    </p>
                    <p className="text-xs text-purple-700">
                      Estado: {diagnosticoUsuario.usuario.activo ? '✅ Activo' : '⛔ Inactivo'}
                    </p>
                  </div>

                  {/* Referidos Directos */}
                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                    <p className="text-sm text-slate-900 mb-2">
                      <strong>Referidos Directos:</strong> {diagnosticoUsuario.referidosDirectos.total}
                    </p>
                    {diagnosticoUsuario.referidosDirectos.lista.length > 0 ? (
                      <div className="space-y-2 max-h-60 overflow-y-auto">
                        {diagnosticoUsuario.referidosDirectos.lista.map((ref: any, idx: number) => (
                          <div 
                            key={idx} 
                            className={`p-2 rounded border text-xs ${
                              ref.tieneMatrizAsignada 
                                ? 'bg-green-50 border-green-200' 
                                : 'bg-red-50 border-red-300'
                            }`}
                          >
                            <div className="flex items-center justify-between mb-1">
                              <span className="font-semibold">
                                {ref.nombre} ({ref.id_unico})
                              </span>
                              <span className={`text-xs px-2 py-0.5 rounded ${
                                ref.tieneMatrizAsignada 
                                  ? 'bg-green-200 text-green-800' 
                                  : 'bg-red-200 text-red-800'
                              }`}>
                                {ref.tieneMatrizAsignada ? '✅ En matriz' : '❌ Sin matriz'}
                              </span>
                            </div>
                            <div className="text-xs text-slate-600">
                              Packs: {ref.packs} | Registrado: {new Date(ref.fechaRegistro).toLocaleDateString()}
                            </div>
                            {ref.packsSinMatriz > 0 && (
                              <div className="text-xs text-red-700 mt-1">
                                ⚠️ {ref.packsSinMatriz} packs sin posición de matriz
                              </div>
                            )}
                            {/* Mostrar detalles de cada pack */}
                            {ref.detallesPacks && ref.detallesPacks.length > 0 && (
                              <div className="mt-2 space-y-1 pl-2 border-l-2 border-slate-300">
                                {ref.detallesPacks.map((pack: any, pIdx: number) => (
                                  <div key={pIdx} className="text-xs bg-white p-1.5 rounded">
                                    <div className="font-semibold">{pack.nombre} (${pack.monto})</div>
                                    <div className="text-slate-600">
                                      Padre: {pack.matrizPadreIdUnico} | Nivel: {pack.matrizNivel} | Pos: {pack.matrizPosicion}
                                    </div>
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-xs text-slate-500">No tiene referidos directos</p>
                    )}
                  </div>

                  {/* Matriz Todos los Niveles */}
                  {diagnosticoUsuario.matrizTodosNiveles && (
                    <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                      <p className="text-sm text-blue-900 mb-2">
                        <strong>Matriz Completa:</strong> {diagnosticoUsuario.matrizTodosNiveles.total} posiciones
                      </p>
                      {diagnosticoUsuario.matrizTodosNiveles.total > 0 && (
                        <div className="space-y-2 max-h-60 overflow-y-auto">
                          {Object.keys(diagnosticoUsuario.matrizTodosNiveles.porNivel).map((nivel: string) => (
                            <div key={nivel} className="bg-white p-2 rounded border border-blue-200">
                              <p className="text-xs font-semibold text-blue-800 mb-1">Nivel {nivel}:</p>
                              <div className="space-y-1">
                                {diagnosticoUsuario.matrizTodosNiveles.porNivel[nivel].map((m: any, idx: number) => (
                                  <div key={idx} className="text-xs text-slate-700 pl-2">
                                    • {m.usuario} - {m.pack} (Pos: {m.posicion})
                                  </div>
                                ))}
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                      {diagnosticoUsuario.matrizTodosNiveles.total === 0 && (
                        <p className="text-xs text-slate-500">No tiene nadie en su matriz (spillover vacío)</p>
                      )}
                    </div>
                  )}

                  {/* Problema Detectado */}
                  {diagnosticoUsuario.problema.tieneProblemas && (
                    <div className="p-3 bg-red-50 rounded-lg border-2 border-red-300">
                      <p className="text-sm text-red-800">
                        <strong>⚠️ Problema Detectado:</strong>
                      </p>
                      <p className="text-xs text-red-700 mt-1">
                        {diagnosticoUsuario.problema.descripcion}
                      </p>
                      <p className="text-xs text-red-600 mt-2 mb-3">
                        💡 <strong>Solución:</strong> Usa el botón de abajo para recalcular SOLO este usuario (no afectará al resto de la matriz).
                      </p>
                      <Button
                        onClick={handleRecalcularMatrizUsuario}
                        variant="outline"
                        className="w-full border-purple-300 text-purple-700 hover:bg-purple-100 h-10"
                        disabled={isRecalculatingMatrizUsuario}
                      >
                        {isRecalculatingMatrizUsuario ? (
                          <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            Recalculando...
                          </>
                        ) : (
                          <>
                            <Network className="w-4 h-4 mr-2" />
                            🔧 Recalcular Solo Este Usuario (Seguro)
                          </>
                        )}
                      </Button>
                    </div>
                  )}
                </div>
              )}
            </div>
          </Card>

          {/* Danger Zone - Reset Database */}
          <Card className="p-6 bg-red-50 border-2 border-red-200 shadow-lg">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-xl bg-red-100 flex items-center justify-center">
                <Database className="w-6 h-6 text-red-600" />
              </div>
              <div>
                <h3 className="text-red-800">Zona Peligrosa</h3>
                <p className="text-sm text-red-600">Esta acción es irreversible</p>
              </div>
            </div>

            <div className="p-4 bg-white rounded-lg border-2 border-red-200 mb-4">
              <h4 className="text-slate-800 mb-2">Resetear Base de Datos</h4>
              <p className="text-sm text-slate-600 mb-3">
                Esta acción eliminará TODOS los datos del sistema excepto el usuario administrador:
              </p>
              <ul className="text-sm text-slate-600 space-y-1 mb-4 list-disc list-inside">
                <li>Todos los usuarios registrados</li>
                <li>Todos los packs de inversión</li>
                <li>Todos los depósitos</li>
                <li>Todos los retiros</li>
                <li>Todas las comisiones</li>
              </ul>
              <Button
                onClick={handleResetDatabase}
                variant="outline"
                className="w-full border-red-300 text-red-700 hover:bg-red-100 hover:border-red-400 h-12"
                disabled={isResetting}
              >
                {isResetting ? (
                  <>
                    <Trash2 className="w-4 h-4 mr-2 animate-pulse" />
                    Reseteando...
                  </>
                ) : (
                  <>
                    <Trash2 className="w-4 h-4 mr-2" />
                    Resetear Base de Datos
                  </>
                )}
              </Button>
            </div>
          </Card>

          {/* Save Button */}
          <div className="flex justify-end">
            <Button
              onClick={handleSave}
              disabled={isSaving}
              className="bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600 px-8 h-12"
            >
              {isSaving ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Guardando...
                </>
              ) : (
                'Guardar Configuración'
              )}
            </Button>
          </div>
        </TabsContent>

        {/* Email Settings */}
        <TabsContent value="email">
          <ConfiguracionEmail />
        </TabsContent>
      </Tabs>
    </div>
  );
}