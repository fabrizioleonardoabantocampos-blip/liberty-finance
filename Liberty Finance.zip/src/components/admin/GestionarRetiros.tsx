import { useState, useEffect } from 'react';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Check, X, Loader2, Clock, CheckCircle, XCircle, DollarSign, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';
import { cobrosAPI, usersAPI } from '../../utils/api';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '../ui/dialog';

interface Cobro {
  id: string;
  userId: string;
  monto: number;
  wallet: string;
  estado: 'pendiente' | 'aprobado' | 'rechazado' | 'completado';
  fecha: string;
  fechaProcesado?: string;
  txHash?: string;
  imagen?: string;
}

interface Usuario {
  id: string;
  nombre: string;
  apellido: string;
  email: string;
  wallet: string;
}

export function GestionarRetiros() {
  const [cobros, setCobros] = useState<Cobro[]>([]);
  const [usuarios, setUsuarios] = useState<Record<string, Usuario>>({});
  const [loading, setLoading] = useState(true);
  const [processingId, setProcessingId] = useState<string | null>(null);
  const [filtro, setFiltro] = useState<'todos' | 'pendiente' | 'aprobado' | 'completado' | 'rechazado'>('pendiente');
  const [dialogAprobar, setDialogAprobar] = useState<Cobro | null>(null);
  const [txHash, setTxHash] = useState('');
  const [imagenUrl, setImagenUrl] = useState('');
  const [isRefreshing, setIsRefreshing] = useState(false);

  const cargarCobros = async () => {
    try {
      const data = await cobrosAPI.getAll();
      setCobros(data);

      // Cargar información de usuarios
      const userIds = [...new Set(data.map((c: Cobro) => c.userId))];
      const usersData: Record<string, Usuario> = {};
      
      for (const userId of userIds) {
        try {
          const user = await usersAPI.getById(userId);
          usersData[userId] = user;
        } catch (error) {
          console.error(`Error al cargar usuario ${userId}:`, error);
        }
      }
      
      setUsuarios(usersData);
    } catch (error) {
      console.error('Error al cargar retiros:', error);
      toast.error('Error al cargar retiros');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    cargarCobros();
    
    // Auto-refresh cada 10 segundos
    const interval = setInterval(() => {
      cargarCobros();
    }, 10000);
    
    return () => clearInterval(interval);
  }, []);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await cargarCobros();
    toast.success('Datos actualizados');
    setIsRefreshing(false);
  };

  const handleAbrirDialogoAprobar = (cobro: Cobro) => {
    setDialogAprobar(cobro);
    setTxHash('');
    setImagenUrl('');
  };

  const handleAprobar = async () => {
    if (!dialogAprobar) return;

    setProcessingId(dialogAprobar.id);
    try {
      await cobrosAPI.update(dialogAprobar.id, {
        estado: 'completado',
        txHash: txHash || undefined,
        imagen: imagenUrl || undefined
      });

      toast.success('¡Retiro aprobado y procesado!');
      setDialogAprobar(null);
      setTxHash('');
      setImagenUrl('');
      await cargarCobros();
    } catch (error: any) {
      console.error('Error al aprobar retiro:', error);
      toast.error(error.message || 'Error al aprobar retiro');
    } finally {
      setProcessingId(null);
    }
  };

  const handleRechazar = async (cobroId: string) => {
    setProcessingId(cobroId);
    try {
      await cobrosAPI.update(cobroId, {
        estado: 'rechazado'
      });

      toast.success('Retiro rechazado');
      await cargarCobros();
    } catch (error: any) {
      console.error('Error al rechazar retiro:', error);
      toast.error(error.message || 'Error al rechazar retiro');
    } finally {
      setProcessingId(null);
    }
  };

  const cobrosFiltrados = cobros.filter(c => 
    filtro === 'todos' ? true : c.estado === filtro
  );

  const pendientesCount = cobros.filter(c => c.estado === 'pendiente').length;

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl">Gestión de Retiros</h2>
          <p className="text-gray-600">
            Aprueba y procesa las solicitudes de retiro
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            size="sm"
            onClick={handleRefresh}
            disabled={isRefreshing}
            className="gap-2"
          >
            <RefreshCw className={`h-4 w-4 ${isRefreshing ? 'animate-spin' : ''}`} />
            {isRefreshing ? 'Actualizando...' : 'Actualizar'}
          </Button>
          {pendientesCount > 0 && (
            <Badge variant="destructive" className="text-lg px-4 py-2">
              {pendientesCount} Pendientes
            </Badge>
          )}
        </div>
      </div>

      {/* Filtros */}
      <div className="flex gap-2 flex-wrap">
        <Button
          variant={filtro === 'pendiente' ? 'default' : 'outline'}
          onClick={() => setFiltro('pendiente')}
          className="gap-2"
        >
          <Clock className="h-4 w-4" />
          Pendientes ({cobros.filter(c => c.estado === 'pendiente').length})
        </Button>
        <Button
          variant={filtro === 'completado' ? 'default' : 'outline'}
          onClick={() => setFiltro('completado')}
          className="gap-2"
        >
          <CheckCircle className="h-4 w-4" />
          Completados ({cobros.filter(c => c.estado === 'completado').length})
        </Button>
        <Button
          variant={filtro === 'rechazado' ? 'default' : 'outline'}
          onClick={() => setFiltro('rechazado')}
          className="gap-2"
        >
          <XCircle className="h-4 w-4" />
          Rechazados ({cobros.filter(c => c.estado === 'rechazado').length})
        </Button>
        <Button
          variant={filtro === 'todos' ? 'default' : 'outline'}
          onClick={() => setFiltro('todos')}
        >
          Todos ({cobros.length})
        </Button>
      </div>

      {/* Lista de retiros */}
      <div className="space-y-4">
        {cobrosFiltrados.length === 0 ? (
          <Card className="p-8 text-center">
            <p className="text-gray-500">No hay retiros {filtro !== 'todos' && filtro}s</p>
          </Card>
        ) : (
          cobrosFiltrados.map((cobro) => {
            const usuario = usuarios[cobro.userId];
            
            return (
              <Card key={cobro.id} className="p-6">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 space-y-3">
                    {/* Encabezado */}
                    <div className="flex items-center gap-3">
                      <Badge
                        variant={
                          cobro.estado === 'pendiente' ? 'default' :
                          cobro.estado === 'completado' ? 'default' :
                          'destructive'
                        }
                        className={
                          cobro.estado === 'pendiente' ? 'bg-yellow-500' :
                          cobro.estado === 'completado' ? 'bg-green-500' :
                          'bg-red-500'
                        }
                      >
                        {cobro.estado === 'pendiente' && '⏱️ PENDIENTE'}
                        {cobro.estado === 'completado' && '✅ COMPLETADO'}
                        {cobro.estado === 'rechazado' && '❌ RECHAZADO'}
                      </Badge>
                      <span className="text-sm text-gray-500">
                        Solicitado: {new Date(cobro.fecha).toLocaleString('es-PE')}
                      </span>
                    </div>

                    {/* Información del usuario */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-gray-500">Usuario</p>
                        <p className="text-lg">
                          {usuario ? `${usuario.nombre} ${usuario.apellido}` : 'Cargando...'}
                        </p>
                        <p className="text-sm text-gray-600">{usuario?.email}</p>
                      </div>

                      <div>
                        <p className="text-sm text-gray-500">Monto a Retirar</p>
                        <p className="text-3xl text-[#0EA5E9]">
                          ${cobro.monto.toLocaleString()} USDT
                        </p>
                      </div>
                    </div>

                    {/* Wallet del usuario */}
                    <div>
                      <p className="text-sm text-gray-500">Wallet de Destino (TRC20)</p>
                      <p className="text-sm font-mono bg-gray-50 p-3 rounded border">
                        {cobro.wallet}
                      </p>
                    </div>

                    {/* Hash de transacción (si existe) */}
                    {cobro.txHash && (
                      <div>
                        <p className="text-sm text-gray-500">Hash de Transacción</p>
                        <p className="text-sm font-mono bg-gray-50 p-2 rounded border">
                          {cobro.txHash}
                        </p>
                      </div>
                    )}

                    {/* Imagen Comprobante (si existe) */}
                    {cobro.imagen && (
                      <div>
                        <p className="text-sm text-gray-500 mb-1">Comprobante de Pago</p>
                        <div className="relative w-full max-w-[200px] h-32 bg-gray-100 rounded-lg overflow-hidden border">
                          <img 
                            src={cobro.imagen} 
                            alt="Comprobante" 
                            className="w-full h-full object-cover cursor-pointer hover:scale-105 transition-transform"
                            onClick={() => window.open(cobro.imagen, '_blank')}
                          />
                        </div>
                      </div>
                    )}

                    {/* Fecha de procesado */}
                    {cobro.fechaProcesado && (
                      <p className="text-sm text-gray-500">
                        Procesado el {new Date(cobro.fechaProcesado).toLocaleString('es-PE')}
                      </p>
                    )}
                  </div>

                  {/* Acciones */}
                  {cobro.estado === 'pendiente' && (
                    <div className="flex flex-col gap-2">
                      <Button
                        onClick={() => handleAbrirDialogoAprobar(cobro)}
                        disabled={processingId !== null}
                        className="bg-green-600 hover:bg-green-700"
                      >
                        <Check className="h-4 w-4 mr-2" />
                        Aprobar
                      </Button>
                      <Button
                        variant="destructive"
                        onClick={() => handleRechazar(cobro.id)}
                        disabled={processingId !== null}
                      >
                        <X className="h-4 w-4 mr-2" />
                        Rechazar
                      </Button>
                    </div>
                  )}
                </div>
              </Card>
            );
          })
        )}
      </div>

      {/* Dialog para aprobar con hash */}
      <Dialog open={!!dialogAprobar} onOpenChange={() => setDialogAprobar(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Aprobar Retiro</DialogTitle>
            <DialogDescription>
              Confirma que has enviado los fondos al usuario
            </DialogDescription>
          </DialogHeader>

          {dialogAprobar && (
            <div className="space-y-4">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm text-blue-900">
                  <strong>Usuario:</strong> {usuarios[dialogAprobar.userId]?.nombre} {usuarios[dialogAprobar.userId]?.apellido}
                </p>
                <p className="text-sm text-blue-900">
                  <strong>Monto:</strong> ${dialogAprobar.monto.toLocaleString()} USDT
                </p>
                <p className="text-sm text-blue-900 font-mono mt-2">
                  <strong>Wallet:</strong> {dialogAprobar.wallet}
                </p>
              </div>

              <div>
                <Label>Hash de Transacción (Opcional)</Label>
                <Input
                  value={txHash}
                  onChange={(e) => setTxHash(e.target.value)}
                  placeholder="0x..."
                  className="font-mono"
                />
                <p className="text-sm text-gray-500 mt-1">
                  Ingresa el hash de la transacción de la blockchain
                </p>
              </div>

              <div>
                <Label>URL Comprobante (Imagen)</Label>
                <Input
                  value={imagenUrl}
                  onChange={(e) => setImagenUrl(e.target.value)}
                  placeholder="https://..."
                  className="font-mono"
                />
                <p className="text-sm text-gray-500 mt-1">
                  Pega aquí la URL de la imagen del comprobante (opcional)
                </p>
              </div>

              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={() => setDialogAprobar(null)}
                  className="flex-1"
                  disabled={processingId !== null}
                >
                  Cancelar
                </Button>
                <Button
                  onClick={handleAprobar}
                  className="flex-1 bg-green-600 hover:bg-green-700"
                  disabled={processingId !== null}
                >
                  {processingId ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Procesando...
                    </>
                  ) : (
                    <>
                      <Check className="mr-2 h-4 w-4" />
                      Confirmar Pago
                    </>
                  )}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}