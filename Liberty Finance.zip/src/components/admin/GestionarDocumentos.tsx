import { useState, useEffect } from 'react';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Label } from '../ui/label';
import { Upload, FileText, Check, ExternalLink, Loader2 } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { documentosAPI } from '../../utils/api';

interface DocumentosLegales {
  terminos: string;
  privacidad: string;
  aviso: string;
}

export function GestionarDocumentos() {
  const [documentos, setDocumentos] = useState<DocumentosLegales>({
    terminos: '',
    privacidad: '',
    aviso: ''
  });
  const [uploading, setUploading] = useState<{
    terminos: boolean;
    privacidad: boolean;
    aviso: boolean;
  }>({
    terminos: false,
    privacidad: false,
    aviso: false
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    cargarDocumentos();
  }, []);

  const cargarDocumentos = async () => {
    setLoading(true);
    try {
      const docs = await documentosAPI.getLegales();
      setDocumentos(docs);
    } catch (error) {
      console.error('Error al cargar documentos:', error);
      toast.error('Error al cargar los documentos');
    } finally {
      setLoading(false);
    }
  };

  const handleUpload = async (file: File, tipo: 'terminos' | 'privacidad' | 'aviso') => {
    // Validar tipo de archivo
    if (!file.type.includes('pdf')) {
      toast.error('Por favor selecciona un archivo PDF válido');
      return;
    }

    // Validar tamaño (máximo 10MB)
    if (file.size > 10 * 1024 * 1024) {
      toast.error('El PDF no debe superar los 10MB');
      return;
    }

    setUploading({ ...uploading, [tipo]: true });
    
    try {
      const response = await documentosAPI.uploadPDF(file, tipo);
      
      // Actualizar el estado local
      setDocumentos({ ...documentos, [tipo]: response.url });
      
      toast.success(`PDF de ${getNombreTipo(tipo)} subido exitosamente`);
    } catch (error) {
      console.error('Error al subir PDF:', error);
      toast.error('Error al subir el PDF');
    } finally {
      setUploading({ ...uploading, [tipo]: false });
    }
  };

  const getNombreTipo = (tipo: 'terminos' | 'privacidad' | 'aviso') => {
    switch (tipo) {
      case 'terminos':
        return 'Términos y Condiciones';
      case 'privacidad':
        return 'Política de Privacidad';
      case 'aviso':
        return 'Aviso Legal';
      default:
        return tipo;
    }
  };

  const renderDocumentoCard = (
    tipo: 'terminos' | 'privacidad' | 'aviso',
    titulo: string,
    descripcion: string
  ) => {
    const tieneDocumento = documentos[tipo] && documentos[tipo].length > 0;
    const isUploading = uploading[tipo];

    return (
      <Card className="p-6">
        <div className="flex items-start gap-4">
          <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
            tieneDocumento ? 'bg-green-100' : 'bg-slate-100'
          }`}>
            {tieneDocumento ? (
              <Check className="w-6 h-6 text-green-600" />
            ) : (
              <FileText className="w-6 h-6 text-slate-600" />
            )}
          </div>
          
          <div className="flex-1">
            <h3 className="text-lg text-slate-800 mb-1">{titulo}</h3>
            <p className="text-sm text-slate-600 mb-4">{descripcion}</p>
            
            {tieneDocumento && (
              <div className="mb-4 p-3 bg-green-50 border border-green-200 rounded-lg">
                <p className="text-sm text-green-800 mb-2">
                  ✓ Documento cargado exitosamente
                </p>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => window.open(documentos[tipo], '_blank')}
                  className="text-xs"
                >
                  <ExternalLink className="w-3 h-3 mr-2" />
                  Ver PDF
                </Button>
              </div>
            )}
            
            <div>
              <Label htmlFor={`upload-${tipo}`} className="cursor-pointer">
                <div className={`inline-flex items-center gap-2 px-4 py-2 border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors ${
                  isUploading ? 'opacity-50 pointer-events-none' : ''
                }`}>
                  {isUploading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin text-slate-600" />
                      <span className="text-sm text-slate-700">Subiendo...</span>
                    </>
                  ) : (
                    <>
                      <Upload className="w-4 h-4 text-slate-600" />
                      <span className="text-sm text-slate-700">
                        {tieneDocumento ? 'Reemplazar PDF' : 'Subir PDF'}
                      </span>
                    </>
                  )}
                </div>
              </Label>
              <input
                id={`upload-${tipo}`}
                type="file"
                accept="application/pdf"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) {
                    handleUpload(file, tipo);
                  }
                  // Reset input para permitir subir el mismo archivo de nuevo
                  e.target.value = '';
                }}
                disabled={isUploading}
                className="sr-only"
              />
              <p className="text-xs text-slate-500 mt-2">
                Máximo 10MB - Solo archivos PDF
              </p>
            </div>
          </div>
        </div>
      </Card>
    );
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl text-slate-800 mb-2">Documentos Legales</h2>
        <p className="text-slate-600">
          Gestiona los documentos legales que se mostrarán en el footer del sitio web
        </p>
      </div>

      {/* Info Banner */}
      <Card className="p-4 bg-blue-50 border-blue-200">
        <div className="flex items-start gap-3">
          <FileText className="w-5 h-5 text-blue-600 mt-0.5" />
          <div>
            <p className="text-sm text-blue-800">
              <strong>Importante:</strong> Los PDFs que subas aquí se podrán descargar o abrir en una nueva pestaña desde los enlaces del footer.
            </p>
            <p className="text-xs text-blue-700 mt-2">
              Los archivos se almacenan de forma segura en Supabase Storage y son públicamente accesibles.
            </p>
          </div>
        </div>
      </Card>

      {/* Documentos */}
      <div className="grid grid-cols-1 gap-6">
        {renderDocumentoCard(
          'terminos',
          'Términos y Condiciones',
          'Documento que establece las reglas y condiciones de uso de la plataforma'
        )}
        
        {renderDocumentoCard(
          'privacidad',
          'Política de Privacidad',
          'Documento que explica cómo se recopilan, usan y protegen los datos personales'
        )}
        
        {renderDocumentoCard(
          'aviso',
          'Aviso Legal',
          'Información legal sobre la empresa, derechos de autor y responsabilidades'
        )}
      </div>

      {/* Instrucciones */}
      <Card className="p-6 bg-slate-50">
        <h3 className="text-slate-800 mb-3">📋 Instrucciones de Uso</h3>
        <ul className="space-y-2 text-sm text-slate-700">
          <li className="flex items-start gap-2">
            <span className="text-blue-600 shrink-0">1.</span>
            <span>Prepara tus documentos legales en formato PDF (máximo 10MB cada uno)</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-blue-600 shrink-0">2.</span>
            <span>Haz clic en "Subir PDF" o "Reemplazar PDF" según corresponda</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-blue-600 shrink-0">3.</span>
            <span>Selecciona el archivo PDF desde tu computadora</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-blue-600 shrink-0">4.</span>
            <span>El PDF se subirá automáticamente y estará disponible en el footer del sitio</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-blue-600 shrink-0">5.</span>
            <span>Los usuarios podrán descargar o ver estos documentos al hacer clic en los enlaces del footer</span>
          </li>
        </ul>
      </Card>
    </div>
  );
}
