import { Home, Users, Network, DollarSign, Settings, Shield, Menu, X, ChevronLeft, ChevronRight, Package, Wrench, Trophy, FileText, LogOut, Upload, Bug, Database, FileSearch, UserSearch } from 'lucide-react';
import { useState } from 'react';
import { useLogo } from '../../hooks/useLogo';

interface AdminSidebarProps {
  activeSection: string;
  setActiveSection: (section: string) => void;
  onLogout?: () => void;
  collapsed?: boolean;
  setCollapsed?: (collapsed: boolean) => void;
}

export function AdminSidebar({ activeSection, setActiveSection, onLogout, collapsed: externalCollapsed, setCollapsed: externalSetCollapsed }: AdminSidebarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [internalCollapsed, setInternalCollapsed] = useState(false);
  const { logoUrl } = useLogo();
  
  // Usar collapsed externo si está disponible, sino usar interno
  const collapsed = externalCollapsed !== undefined ? externalCollapsed : internalCollapsed;
  const setCollapsed = externalSetCollapsed || setInternalCollapsed;

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Home },
    { id: 'users', label: 'Usuarios', icon: Users },
    { id: 'network', label: 'Red Global', icon: Network },
    { id: 'depositos', label: 'Depósitos', icon: Upload },
    { id: 'withdrawals', label: 'Retiros', icon: DollarSign },
    { id: 'productos', label: 'Productos', icon: Package },
    { id: 'rangos', label: 'Rangos', icon: Trophy },
    { id: 'documentos', label: 'Documentos', icon: FileText },
    { id: 'configuracion', label: 'Configuración', icon: Wrench },
    { id: 'settings', label: 'Avanzado', icon: Settings },
    { id: 'database', label: '🗄️ Base de Datos', icon: Database },
    { id: 'diagnostico-estructura', label: '🔍 Estructura BD', icon: FileSearch },
    { id: 'diagnostico-usuario', label: '🔍 Diagnóstico Usuario', icon: UserSearch },
    { id: 'usuarios-duplicados', label: '🛡️ Duplicados', icon: Users },
    { id: 'debug-servidor', label: '🔧 Debug Servidor', icon: Bug }
  ];

  return (
    <>
      {/* Mobile menu button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="md:hidden fixed top-4 left-4 z-50 p-3 rounded-xl bg-blue-600 text-white shadow-lg"
      >
        {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
      </button>

      {/* Desktop Sidebar */}
      <aside
        className={`hidden md:block fixed top-0 left-0 h-full bg-gradient-to-b from-slate-900 to-blue-950 shadow-2xl transition-all duration-300 z-40 ${
          collapsed ? 'w-20' : 'w-72'
        }`}
      >
        {/* Toggle button for desktop */}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="absolute -right-3 top-8 w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-lg hover:bg-blue-700 transition-colors z-50"
        >
          {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
        </button>

        <div className="h-full flex flex-col">
          {/* Logo */}
          <div className={`transition-all duration-300 ${collapsed ? 'p-4' : 'p-6'}`}>
            {collapsed ? (
              <div className="flex justify-center p-4 border-b border-blue-800/30">
                <div className="w-10 h-10 rounded-lg bg-blue-600 flex items-center justify-center">
                  <Shield className="w-6 h-6 text-white" />
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-3 p-4 border-b border-blue-800/30">
                <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <img 
                    src={logoUrl} 
                    alt="Liberty Finance" 
                    className="h-8 w-auto"
                  />
                </div>
                <div>
                  <h1 className="text-xl text-white">Liberty Finance</h1>
                  <p className="text-blue-300 text-xs">Panel de Administración</p>
                </div>
              </div>
            )}
          </div>

          {/* Stats Card */}
          <div className={`p-6 border-b border-white/10 transition-all duration-300 ${collapsed ? 'px-3' : ''}`}>
            {collapsed ? (
              <div className="flex justify-center">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-r from-blue-600/20 to-blue-700/20 backdrop-blur-sm border border-blue-500/30 flex items-center justify-center">
                  <Shield className="w-5 h-5 text-blue-300" />
                </div>
              </div>
            ) : (
              <div className="bg-gradient-to-r from-blue-600/20 to-blue-700/20 backdrop-blur-sm rounded-xl p-4 border border-blue-500/30">
                <div className="flex items-center gap-2 mb-2">
                  <Shield className="w-4 h-4 text-blue-300" />
                  <span className="text-blue-200 text-sm">Administrador</span>
                </div>
                <p className="text-white text-lg">Sistema Activo</p>
                <p className="text-blue-300 text-xs mt-1">Todos los servicios operando</p>
              </div>
            )}
          </div>

          {/* Menu */}
          <nav className="flex-1 p-6 space-y-2 overflow-y-auto">
            {menuItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveSection(item.id)}
                  className={`w-full flex items-center ${collapsed ? 'justify-center' : 'gap-3'} px-4 py-3 rounded-xl transition-all ${
                    activeSection === item.id
                      ? 'bg-blue-600 text-white shadow-lg'
                      : 'text-blue-200 hover:bg-white/10 hover:text-white'
                  }`}
                  title={collapsed ? item.label : ''}
                >
                  <Icon className="w-5 h-5" />
                  {!collapsed && <span>{item.label}</span>}
                </button>
              );
            })}
          </nav>

          {/* Logout */}
          {onLogout && (
            <div className={`p-6 border-t border-white/10 ${collapsed ? 'px-2' : ''}`}>
              <button
                onClick={onLogout}
                className={`w-full flex items-center ${collapsed ? 'justify-center px-2' : 'gap-3'} px-4 py-3 rounded-xl text-blue-200 hover:bg-white/10 hover:text-white transition-all`}
                title={collapsed ? 'Cerrar Sesión' : ''}
              >
                <LogOut className="w-5 h-5" />
                {!collapsed && <span>Cerrar Sesión</span>}
              </button>
            </div>
          )}
        </div>
      </aside>

      {/* Mobile Sidebar */}
      <aside
        className={`md:hidden fixed top-0 left-0 h-full w-72 bg-gradient-to-b from-slate-900 to-blue-950 shadow-2xl transform transition-transform duration-300 z-40 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="p-6 border-b border-white/10">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-600 to-blue-700 flex items-center justify-center shadow-lg">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl text-white">Liberty Finance</h1>
                <p className="text-blue-300 text-xs">Panel de Administración</p>
              </div>
            </div>
          </div>

          {/* Stats Card */}
          <div className="p-6 border-b border-white/10">
            <div className="bg-gradient-to-r from-blue-600/20 to-blue-700/20 backdrop-blur-sm rounded-xl p-4 border border-blue-500/30">
              <div className="flex items-center gap-2 mb-2">
                <Shield className="w-4 h-4 text-blue-300" />
                <span className="text-blue-200 text-sm">Administrador</span>
              </div>
              <p className="text-white text-lg">Sistema Activo</p>
              <p className="text-blue-300 text-xs mt-1">Todos los servicios operando</p>
            </div>
          </div>

          {/* Menu */}
          <nav className="flex-1 p-6 space-y-2 overflow-y-auto">
            {menuItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveSection(item.id);
                    setIsOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                    activeSection === item.id
                      ? 'bg-blue-600 text-white shadow-lg'
                      : 'text-blue-200 hover:bg-white/10 hover:text-white'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Logout */}
          {onLogout && (
            <div className="p-6 border-t border-white/10">
              <button
                onClick={onLogout}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-blue-200 hover:bg-white/10 hover:text-white transition-all"
              >
                <LogOut className="w-5 h-5" />
                <span>Cerrar Sesión</span>
              </button>
            </div>
          )}
        </div>
      </aside>

      {/* Overlay for mobile */}
      {isOpen && (
        <div
          className="md:hidden fixed inset-0 bg-black/50 z-30"
          onClick={() => setIsOpen(false)}
        />
      )}
    </>
  );
}