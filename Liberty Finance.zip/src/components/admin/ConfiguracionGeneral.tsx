import { useState, useEffect } from 'react';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Wallet, Save, Loader2, Upload, X, Percent, Clock, TrendingUp, Image as ImageIcon, Trash2, Unlock, RefreshCw, Search, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { configuracionAPI, adminAPI } from '../../utils/api';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { Switch } from '../ui/switch';

export function ConfiguracionGeneral() {
  const [walletPrincipal, setWalletPrincipal] = useState('');
  const [qrCodeUrl, setQrCodeUrl] = useState('');
  const [qrPreview, setQrPreview] = useState('');
  const [logoUrl, setLogoUrl] = useState('');
  const [logoPreview, setLogoPreview] = useState('');
  const [rendimientoActivo, setRendimientoActivo] = useState(true);
  const [porcentajeRendimiento, setPorcentajeRendimiento] = useState(1);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [procesandoRendimientos, setProcesandoRendimientos] = useState(false);
  const [diagnosticandoRendimientos, setDiagnosticandoRendimientos] = useState(false);
  const [eliminandoDuplicados, setEliminandoDuplicados] = useState(false);
  const [limpiandoLocks, setLimpiandoLocks] = useState(false);
  const [sincronizandoIndices, setSincronizandoIndices] = useState(false);
  const [yaProcesadoHoy, setYaProcesadoHoy] = useState(false);
  const [ultimoProcesamiento, setUltimoProcesamiento] = useState<string | null>(null);
  const [duplicadosData, setDuplicadosData] = useState<any>(null);

  useEffect(() => {
    cargarConfiguracion();
  }, []);

  const cargarConfiguracion = async () => {
    try {
      const config = await configuracionAPI.get();
      setWalletPrincipal(config.walletPrincipal || '');
      setQrCodeUrl(config.qrCodeUrl || '');
      setQrPreview(config.qrCodeUrl || '');
      setLogoUrl(config.logoUrl || '');
      setLogoPreview(config.logoUrl || '');
      setRendimientoActivo(config.rendimientoActivo ?? true);
      setPorcentajeRendimiento(config.porcentajeRendimiento || 1);
      setYaProcesadoHoy(config.yaProcesadoHoy ?? false);
      setUltimoProcesamiento(config.ultimoProcesamientoRendimiento || null);
    } catch (error) {
      console.error('Error al cargar configuración:', error);
      toast.error('Error al cargar configuración');
    } finally {
      setLoading(false);
    }
  };

  const handleQrUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        toast.error('Por favor selecciona una imagen válida');
        return;
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        setQrPreview(base64String);
        setQrCodeUrl(base64String);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemoveQr = () => {
    setQrPreview('');
    setQrCodeUrl('');
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        toast.error('Por favor selecciona una imagen válida');
        return;
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        setLogoPreview(base64String);
        setLogoUrl(base64String);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemoveLogo = () => {
    setLogoPreview('');
    setLogoUrl('');
  };

  const handleToggleRendimiento = async (nuevoEstado: boolean) => {
    setRendimientoActivo(nuevoEstado);
    
    if (nuevoEstado) {
      toast.success('✅ Rendimiento diario ACTIVADO - Los usuarios recibirán su porcentaje');
    } else {
      toast.error('⛔ Rendimiento diario DESACTIVADO - Los usuarios NO recibirán su porcentaje hoy');
    }
  };

  const handleProcesarRendimientos = async () => {
    if (!rendimientoActivo) {
      toast.error('El rendimiento está desactivado. Actívalo primero.');
      return;
    }

    // Validar porcentaje antes de procesar
    if (porcentajeRendimiento <= 0 || porcentajeRendimiento > 100) {
      toast.error('El porcentaje debe estar entre 0.1 y 100');
      return;
    }

    setProcesandoRendimientos(true);
    try {
      // PASO CRÍTICO: Guardar la configuración actual antes de procesar
      // Esto asegura que el backend use el porcentaje que el usuario ve en pantalla (ej: 0.5%)
      // en lugar del valor antiguo almacenado en la base de datos.
      await configuracionAPI.update({
        walletPrincipal: walletPrincipal.trim(),
        qrCodeUrl: qrCodeUrl,
        logoUrl: logoUrl,
        rendimientoActivo,
        porcentajeRendimiento
      });

      // Una vez guardado el nuevo porcentaje, llamamos al procesador
      const result = await adminAPI.procesarRendimientos();
      
      toast.success(`✅ Rendimientos procesados! ${result.procesados} usuarios recibieron su ${porcentajeRendimiento}%`);
      
      // Recargar configuración para actualizar estado
      await cargarConfiguracion();
    } catch (error: any) {
      console.error('Error al procesar rendimientos:', error);
      
      // Verificar si es el error de "ya procesado hoy"
      if (error.message && error.message.includes('ya fueron procesados hoy')) {
        toast.error('⚠️ Ya se procesaron los rendimientos hoy. Solo se puede procesar una vez por día.');
      } else {
        toast.error(error.message || 'Error al procesar rendimientos');
      }
    } finally {
      setProcesandoRendimientos(false);
    }
  };

  const handleDiagnosticarRendimientos = async () => {
    setDiagnosticandoRendimientos(true);
    try {
      const diagnostico = await adminAPI.diagnosticarRendimientos();
      
      console.log('🔍 DIAGNÓSTICO DE RENDIMIENTOS:', diagnostico);
      
      if (!diagnostico.success) {
        toast.error('Error al realizar el diagnóstico');
        return;
      }
      
      const { resumen, duplicados, historialPorFecha, doblePago, recomendaciones } = diagnostico;
      
      // Mostrar resumen
      console.log('📊 RESUMEN:', resumen);
      console.log('📅 HISTORIAL POR FECHA:', historialPorFecha);
      
      if (duplicados && duplicados.cantidad > 0) {
        toast.error(
          `🚨 DUPLICADOS DETECTADOS:\n\n` +
          `❌ ${duplicados.cantidad} usuarios con rendimientos duplicados\n\n` +
          `Ver consola para detalles completos`,
          { duration: 8000 }
        );
        console.table(duplicados.detalle);
        
        // Mapear los datos correctamente para la tabla
        const duplicadosMapeados = duplicados.detalle.map((dup: any) => ({
          nombre_completo: dup.usuario ? `${dup.usuario.nombre} ${dup.usuario.apellido}`.trim() : 'Sin nombre',
          email: dup.usuario?.email || 'Sin email',
          id_unico: dup.usuario?.id_unico || 'N/A',
          fecha_comision: dup.fecha,
          cantidad_rendimientos: dup.cantidadDuplicados,
          total_duplicado: dup.totalMonto
        }));
        
        setDuplicadosData(duplicadosMapeados);
      } else if (doblePago && doblePago.cantidad > 0) {
        toast.error(
          `🚨 DOBLE PAGO DETECTADO:\n\n` +
          `❌ ${doblePago.cantidad} usuarios recibieron pago duplicado\n` +
          `(Tabla rendimientos + Comisiones)\n\n` +
          `Ver consola para detalles`,
          { duration: 8000 }
        );
        console.table(doblePago.detalle);
      } else {
        toast.success(
          `✅ DIAGNÓSTICO COMPLETADO (60 días)\\n\\n` +
          `📊 Total comisiones rendimiento: ${resumen.totalComisionesRendimiento}\\n` +
          `✅ No se detectaron duplicados\\n` +
          `📅 Último procesamiento: ${resumen.ultimoProcesamiento}\\n\\n` +
          `Ver consola para historial completo`,
          { duration: 6000 }
        );
        // Limpiar duplicados si no hay ninguno
        setDuplicadosData(null);
      }
      
      // Mostrar recomendaciones
      if (recomendaciones && recomendaciones.length > 0) {
        console.log('💡 RECOMENDACIONES:');
        recomendaciones.forEach((rec: string) => console.log(`  ${rec}`));
      }
      
      // Mostrar historial de fechas con posibles duplicados
      if (historialPorFecha && historialPorFecha.fechasConDuplicados > 0) {
        console.log(`⚠️ Fechas con posibles duplicados: ${historialPorFecha.fechasConDuplicados}`);
        console.table(historialPorFecha.fechas.filter((f: any) => f.posibleDuplicado));
      }
      
    } catch (error: any) {
      console.error('❌ Error al diagnosticar rendimientos:', error);
      toast.error(error.message || 'Error al realizar el diagnóstico');
    } finally {
      setDiagnosticandoRendimientos(false);
    }
  };

  const handleGuardar = async () => {
    if (!walletPrincipal.trim()) {
      toast.error('La wallet no puede estar vacía');
      return;
    }

    if (porcentajeRendimiento <= 0 || porcentajeRendimiento > 100) {
      toast.error('El porcentaje debe estar entre 0.1 y 100');
      return;
    }

    setSaving(true);
    try {
      await configuracionAPI.update({
        walletPrincipal: walletPrincipal.trim(),
        qrCodeUrl: qrCodeUrl,
        logoUrl: logoUrl,
        rendimientoActivo,
        porcentajeRendimiento
      });

      toast.success('¡Configuración guardada exitosamente!');
    } catch (error: any) {
      console.error('Error al guardar configuración:', error);
      toast.error(error.message || 'Error al guardar configuración');
    } finally {
      setSaving(false);
    }
  };

  const handleEliminarDuplicados = async () => {
    setEliminandoDuplicados(true);
    try {
      const result = await adminAPI.eliminarDuplicados();
      
      console.log('📊 Resultado limpieza duplicados:', result);
      
      if (result.duplicadosEliminados === 0) {
        toast.info(`✅ No se detectaron rendimientos duplicados en los últimos 60 días`);
      } else {
        toast.success(
          `✅ Limpieza completada (últimos 60 días):\n` +
          `• ${result.duplicadosEliminados} rendimientos duplicados eliminados\n` +
          `• ${result.usuariosAfectados} usuarios afectados\n` +
          `• Total rendimientos procesados: ${result.totalRendimientos}`,
          { duration: 6000 }
        );
        
        // Mostrar ejemplos en consola si hay detalles
        if (result.detalle && result.detalle.length > 0) {
          console.log('📋 Ejemplos de duplicados eliminados:', result.detalle);
        }
        
        // Limpiar el estado de duplicados después de eliminar
        setDuplicadosData(null);
        
        // Volver a diagnosticar para verificar que se limpiaron correctamente
        setTimeout(() => {
          handleDiagnosticarRendimientos();
        }, 1000);
      }
    } catch (error: any) {
      console.error('Error al eliminar duplicados:', error);
      toast.error(error.message || 'Error al eliminar duplicados');
    } finally {
      setEliminandoDuplicados(false);
    }
  };

  const handleLimpiarLocks = async () => {
    setLimpiandoLocks(true);
    try {
      const result = await adminAPI.limpiarLocks();
      
      console.log('🧹 Resultado limpieza locks:', result);
      
      if (result.locksEliminados === 0) {
        toast.info(`✅ No hay locks para limpiar`);
      } else {
        toast.success(
          `✅ Locks limpiados exitosamente:\n` +
          `• ${result.locksEliminados} locks eliminados\n` +
          `• ${result.locksDeHoy} locks de hoy removidos\n` +
          `• Ahora puedes procesar rendimientos nuevamente`,
          { duration: 5000 }
        );
      }
    } catch (error: any) {
      console.error('Error al limpiar locks:', error);
      toast.error(error.message || 'Error al limpiar locks');
    } finally {
      setLimpiandoLocks(false);
    }
  };

  const handleSincronizarIndices = async () => {
    setSincronizandoIndices(true);
    try {
      const result = await adminAPI.sincronizarIndices();
      
      console.log('🔄 Resultado sincronización de índices:', result);
      
      if (result.success) {
        toast.success(
          `✅ Sincronización completada:\\n` +
          `• Total usuarios: ${result.stats.totalUsers}\\n` +
          `• Índices creados: ${result.stats.indexesCreated}\\n` +
          `• Índices ya existentes: ${result.stats.indexesAlreadyExist}`,
          { duration: 6000 }
        );
      } else {
        toast.error(result.message || 'Error al sincronizar índices');
      }
    } catch (error: any) {
      console.error('Error al sincronizar índices:', error);
      toast.error(error.message || 'Error al sincronizar índices');
    } finally {
      setSincronizandoIndices(false);
    }
  };

  if (loading) {
    return (
      <Card className="p-6">
        <div className="flex items-center justify-center py-8">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl text-slate-800 mb-2">Configuración General</h2>
        <p className="text-slate-600">Administra la configuración principal del sistema</p>
      </div>

      {/* Control de Rendimiento Diario */}
      <Card className="p-6 bg-gradient-to-br from-blue-600 to-blue-700 border-0 shadow-xl text-white">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
            <Percent className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="text-xl text-white">Control de Rendimiento Diario</h3>
            <p className="text-white/80 text-sm">Activa o desactiva manualmente el rendimiento del día</p>
          </div>
        </div>

        <div className="space-y-4">
          {/* Porcentaje de Rendimiento */}
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
            <Label className="text-white mb-2 block">Porcentaje Diario (%)</Label>
            <Input
              type="number"
              value={porcentajeRendimiento}
              onChange={(e) => setPorcentajeRendimiento(Number(e.target.value))}
              min="0.1"
              max="100"
              step="0.1"
              className="bg-white/20 border-white/30 text-white placeholder:text-white/50"
            />
            <p className="text-white/70 text-xs mt-1">
              Porcentaje que se aplicará sobre el monto invertido de cada usuario
            </p>
          </div>

          {/* Switch de Activación */}
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-white">Estado del Rendimiento</p>
                <p className="text-white/70 text-sm">
                  {rendimientoActivo ? 'Actualmente ACTIVADO' : 'Actualmente DESACTIVADO'}
                </p>
              </div>
              <Switch
                checked={rendimientoActivo}
                onCheckedChange={handleToggleRendimiento}
                className="data-[state=checked]:bg-green-500"
              />
            </div>
            
            <div className="flex items-center gap-2 text-sm mb-4">
              <Clock className="w-4 h-4 text-white/70" />
              <p className="text-white/70 text-xs">
                {rendimientoActivo 
                  ? 'Los usuarios están recibiendo su rendimiento diario'
                  : 'El rendimiento diario está pausado temporalmente'
                }
              </p>
            </div>

            {/* Estado de Procesamiento Hoy */}
            {yaProcesadoHoy && ultimoProcesamiento && (
              <div className="bg-green-500/20 border border-green-500/30 rounded-lg p-3 mb-4">
                <div className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-green-400 animate-pulse" />
                  <p className="text-white text-sm font-medium">
                    ✅ Ya procesado hoy
                  </p>
                </div>
                <p className="text-white/70 text-xs mt-1">
                  Último procesamiento: {new Date(ultimoProcesamiento).toLocaleDateString('es-ES')}
                </p>
              </div>
            )}

            {/* Botón Procesar Ahora */}
            <Button
              onClick={handleProcesarRendimientos}
              disabled={!rendimientoActivo || procesandoRendimientos || yaProcesadoHoy}
              className="w-full bg-white/20 hover:bg-white/30 text-white border-white/30 disabled:opacity-50 disabled:cursor-not-allowed"
              variant="outline"
            >
              {procesandoRendimientos ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Procesando Rendimientos...
                </>
              ) : (
                <>
                  <TrendingUp className="mr-2 h-4 w-4" />
                  Procesar Rendimientos Ahora
                </>
              )}
            </Button>
            <p className="text-white/60 text-xs mt-2 text-center">
              {yaProcesadoHoy 
                ? '⚠️ Ya se procesó hoy - Se desbloqueará mañana a las 00:00'
                : `Distribuye el ${porcentajeRendimiento}% a todos los usuarios con packs activos`
              }
            </p>
            
            {/* Botón Diagnóstico */}
            <Button
              onClick={handleDiagnosticarRendimientos}
              disabled={diagnosticandoRendimientos}
              className="w-full bg-amber-500/20 hover:bg-amber-500/30 text-white border-amber-300/30 mt-3"
              variant="outline"
            >
              {diagnosticandoRendimientos ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Analizando...
                </>
              ) : (
                <>
                  <Search className="mr-2 h-4 w-4" />
                  Diagnosticar Rendimientos Duplicados
                </>
              )}
            </Button>
            <p className="text-white/60 text-xs mt-1 text-center">
              Detecta y muestra rendimientos duplicados por usuario y fecha
            </p>
          </div>

          {/* Info */}
          <div className="bg-white/5 backdrop-blur-sm rounded-lg p-4 border border-white/20">
            <p className="text-white/90 text-sm mb-2">ℹ️ Información Importante:</p>
            <ul className="text-white/70 text-xs space-y-1 list-disc list-inside">
              <li>El rendimiento se aplica sobre el monto total invertido de cada usuario</li>
              <li>⚠️ <strong className="text-white">SOLO se puede procesar UNA VEZ por día</strong></li>
              <li>El sistema se resetea automáticamente a medianoche (00:00)</li>
              <li>Puedes activar/desactivar el rendimiento en cualquier momento</li>
              <li>El porcentaje personalizado se aplicará al siguiente cálculo</li>
              <li>🔍 <strong className="text-white">Diagnóstico</strong>: Revisa la consola del navegador (F12) para ver detalles completos de rendimientos duplicados</li>
            </ul>
          </div>
        </div>
      </Card>

      {/* Configuración de Wallet y QR */}
      <Card className="p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="h-12 w-12 rounded-full bg-[#0EA5E9]/10 flex items-center justify-center">
            <Wallet className="h-6 w-6 text-[#0EA5E9]" />
          </div>
          <div>
            <h3 className="text-xl">Wallet de Depósitos</h3>
            <p className="text-gray-600 text-sm">
              Configura la wallet y código QR para recibir depósitos
            </p>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h4 className="text-blue-900 mb-2">📌 Información Importante</h4>
            <ul className="list-disc list-inside space-y-1 text-sm text-blue-800">
              <li>Esta wallet se mostrará a todos los usuarios al comprar packs</li>
              <li>Debe ser una wallet TRC20 (Tron) válida para USDT</li>
              <li>El código QR facilita los depósitos desde mobile</li>
              <li>Los cambios se aplican inmediatamente</li>
            </ul>
          </div>

          <div className="space-y-2">
            <Label htmlFor="wallet">Wallet Principal (TRC20 - USDT)</Label>
            <Input
              id="wallet"
              value={walletPrincipal}
              onChange={(e) => setWalletPrincipal(e.target.value)}
              placeholder="TXXXXXXXXXxxxxxxxxxxxxxx"
              className="font-mono"
            />
            <p className="text-sm text-gray-500">
              Red: TRC20 (Tron) - Solo USDT
            </p>
          </div>

          {/* Upload QR Code */}
          <div className="space-y-3">
            <Label htmlFor="qrCode">Código QR de la Wallet</Label>
            <p className="text-sm text-gray-500">
              Sube un código QR de tu wallet para que los usuarios puedan escanear y depositar fácilmente
            </p>
            
            <div className="flex items-start gap-3">
              <div>
                <Input
                  id="qrCode"
                  type="file"
                  accept="image/*"
                  onChange={handleQrUpload}
                  className="hidden"
                />
                <Button
                  variant="outline"
                  onClick={() => document.getElementById('qrCode')?.click()}
                  type="button"
                >
                  <Upload className="mr-2 h-4 w-4" />
                  {qrPreview ? 'Cambiar QR' : 'Cargar QR'}
                </Button>
              </div>

              {qrPreview && (
                <div className="flex items-start gap-2">
                  <div className="border-2 border-gray-200 rounded-lg p-2 bg-white">
                    <ImageWithFallback
                      src={qrPreview}
                      alt="QR Code Preview"
                      className="w-32 h-32 object-contain"
                    />
                  </div>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={handleRemoveQr}
                    type="button"
                    className="text-red-600 hover:text-red-700 hover:bg-red-50"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              )}
            </div>
          </div>

          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <h4 className="text-yellow-900 mb-2">⚠️ Verificación</h4>
            <p className="text-sm text-yellow-800">
              Asegúrate de que la wallet y el código QR sean correctos. Una wallet incorrecta puede resultar en pérdida de fondos.
            </p>
          </div>

          {/* Preview de la wallet */}
          {walletPrincipal && (
            <div className="border-t pt-4">
              <p className="text-sm text-gray-500 mb-2">Vista previa de lo que verán los usuarios:</p>
              <div className="bg-gray-50 p-4 rounded-lg border">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-600 mb-2">Dirección de Wallet:</p>
                    <p className="font-mono text-sm bg-white p-3 rounded border break-all">
                      {walletPrincipal}
                    </p>
                  </div>
                  {qrPreview && (
                    <div>
                      <p className="text-sm text-gray-600 mb-2">Código QR:</p>
                      <div className="bg-white p-3 rounded border inline-block">
                        <ImageWithFallback
                          src={qrPreview}
                          alt="QR Preview"
                          className="w-32 h-32 object-contain"
                        />
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </Card>

      {/* Configuración de Logo */}
      <Card className="p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="h-12 w-12 rounded-full bg-[#0EA5E9]/10 flex items-center justify-center">
            <ImageIcon className="h-6 w-6 text-[#0EA5E9]" />
          </div>
          <div>
            <h3 className="text-xl">Logo de la Empresa</h3>
            <p className="text-gray-600 text-sm">
              Configura el logo que se mostrará en la plataforma
            </p>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h4 className="text-blue-900 mb-2">📌 Información Importante</h4>
            <ul className="list-disc list-inside space-y-1 text-sm text-blue-800">
              <li>Este logo se mostrará en la página principal y en los correos electrónicos</li>
              <li>Debe ser una imagen en formato PNG o JPEG</li>
              <li>Los cambios se aplican inmediatamente</li>
            </ul>
          </div>

          {/* Upload Logo */}
          <div className="space-y-3">
            <Label htmlFor="logo">Logo de la Empresa</Label>
            <p className="text-sm text-gray-500">
              Sube un logo para que se muestre en la plataforma
            </p>
            
            <div className="flex items-start gap-3">
              <div>
                <Input
                  id="logo"
                  type="file"
                  accept="image/*"
                  onChange={handleLogoUpload}
                  className="hidden"
                />
                <Button
                  variant="outline"
                  onClick={() => document.getElementById('logo')?.click()}
                  type="button"
                >
                  <Upload className="mr-2 h-4 w-4" />
                  {logoPreview ? 'Cambiar Logo' : 'Cargar Logo'}
                </Button>
              </div>

              {logoPreview && (
                <div className="flex items-start gap-2">
                  <div className="border-2 border-gray-200 rounded-lg p-2 bg-white">
                    <ImageWithFallback
                      src={logoPreview}
                      alt="Logo Preview"
                      className="w-32 h-32 object-contain"
                    />
                  </div>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={handleRemoveLogo}
                    type="button"
                    className="text-red-600 hover:text-red-700 hover:bg-red-50"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              )}
            </div>
          </div>

          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <h4 className="text-yellow-900 mb-2">⚠️ Verificación</h4>
            <p className="text-sm text-yellow-800">
              Asegúrate de que el logo sea correcto y cumpla con las dimensiones recomendadas.
            </p>
          </div>

          {/* Preview del logo */}
          {logoPreview && (
            <div className="border-t pt-4">
              <p className="text-sm text-gray-500 mb-2">Vista previa de lo que verán los usuarios:</p>
              <div className="bg-gray-50 p-4 rounded-lg border">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-600 mb-2">Logo de la Empresa:</p>
                    <div className="bg-white p-3 rounded border inline-block">
                      <ImageWithFallback
                        src={logoPreview}
                        alt="Logo Preview"
                        className="w-32 h-32 object-contain"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </Card>

      {/* Botón Guardar */}
      <div className="flex gap-3">
        <Button
          variant="outline"
          onClick={cargarConfiguracion}
          disabled={saving}
        >
          Cancelar
        </Button>
        <Button
          onClick={handleGuardar}
          disabled={saving}
          className="bg-[#0EA5E9] hover:bg-[#0EA5E9]/90"
        >
          {saving ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Guardando...
            </>
          ) : (
            <>
              <Save className="mr-2 h-4 w-4" />
              Guardar Cambios
            </>
          )}
        </Button>
        <Button
          onClick={handleEliminarDuplicados}
          disabled={eliminandoDuplicados}
          className="bg-red-500 hover:bg-red-600 text-white"
          title="Elimina rendimientos duplicados de los últimos 60 días"
        >
          {eliminandoDuplicados ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Eliminando Duplicados...
            </>
          ) : (
            <>
              <Trash2 className="mr-2 h-4 w-4" />
              Eliminar Duplicados (60 días)
            </>
          )}
        </Button>
        <Button
          onClick={handleLimpiarLocks}
          disabled={limpiandoLocks}
          className="bg-orange-500 hover:bg-orange-600 text-white"
          title="Limpiar bloqueos de procesamiento (útil para reprocesar rendimientos)"
        >
          {limpiandoLocks ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Limpiando Locks...
            </>
          ) : (
            <>
              <Unlock className="mr-2 h-4 w-4" />
              Limpiar Locks
            </>
          )}
        </Button>
        <Button
          onClick={handleSincronizarIndices}
          disabled={sincronizandoIndices}
          className="bg-green-500 hover:bg-green-600 text-white"
          title="Sincronizar índices de la base de datos"
        >
          {sincronizandoIndices ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Sincronizando Índices...
            </>
          ) : (
            <>
              <RefreshCw className="mr-2 h-4 w-4" />
              Sincronizar Índices
            </>
          )}
        </Button>
      </div>

      {/* Sección de Duplicados Detectados */}
      {duplicadosData && duplicadosData.length > 0 && (
        <Card className="p-6 bg-red-50 border-red-200">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-xl bg-red-500 flex items-center justify-center">
              <AlertTriangle className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="text-xl text-red-900">🚨 Rendimientos Duplicados Detectados</h3>
              <p className="text-red-700 text-sm">
                Se encontraron {duplicadosData.length} usuarios con rendimientos duplicados
              </p>
            </div>
          </div>

          <div className="bg-white rounded-lg overflow-hidden border border-red-200">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-red-100 border-b border-red-200">
                  <tr>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-red-900">Usuario</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-red-900">Email</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-red-900">Fecha</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-red-900">Rendimientos</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-red-900">Total Duplicado</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-red-100">
                  {duplicadosData.map((dup: any, index: number) => (
                    <tr key={index} className="hover:bg-red-50">
                      <td className="px-4 py-3 text-sm text-slate-900">{dup.nombre_completo || 'Sin nombre'}</td>
                      <td className="px-4 py-3 text-sm text-slate-700">{dup.email}</td>
                      <td className="px-4 py-3 text-sm text-slate-700">
                        {new Date(dup.fecha_comision).toLocaleDateString('es-ES')}
                      </td>
                      <td className="px-4 py-3 text-sm">
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800">
                          {dup.cantidad_rendimientos} rendimientos
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm font-semibold text-red-900">
                        ${parseFloat(dup.total_duplicado).toFixed(2)} USDT
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="mt-4 bg-amber-50 border border-amber-200 rounded-lg p-4">
            <p className="text-amber-900 text-sm mb-2">💡 Recomendaciones:</p>
            <ul className="list-disc list-inside space-y-1 text-sm text-amber-800">
              <li>Revisa la consola del navegador (F12) para ver detalles completos</li>
              <li>Usa el botón "Eliminar Duplicados (60 días)" para limpiar automáticamente</li>
              <li>Verifica que no se esté ejecutando el procesamiento dos veces por día</li>
              <li>Revisa los logs del servidor para identificar la causa raíz</li>
            </ul>
          </div>
        </Card>
      )}
    </div>
  );
}