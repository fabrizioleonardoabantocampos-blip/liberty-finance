import { useState, useEffect } from 'react';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Wallet, Save, Loader2, Upload, X } from 'lucide-react';
import { toast } from 'sonner';
import { configuracionAPI } from '../../utils/api';
import { ImageWithFallback } from '../figma/ImageWithFallback';

export function ConfiguracionWallet() {
  const [walletPrincipal, setWalletPrincipal] = useState('');
  const [qrCodeUrl, setQrCodeUrl] = useState('');
  const [qrPreview, setQrPreview] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    cargarConfiguracion();
  }, []);

  const cargarConfiguracion = async () => {
    try {
      const config = await configuracionAPI.get();
      setWalletPrincipal(config.walletPrincipal);
      setQrCodeUrl(config.qrCodeUrl || '');
      setQrPreview(config.qrCodeUrl || '');
    } catch (error) {
      console.error('Error al cargar configuración:', error);
      toast.error('Error al cargar configuración');
    } finally {
      setLoading(false);
    }
  };

  const handleQrUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Validar que sea una imagen
      if (!file.type.startsWith('image/')) {
        toast.error('Por favor selecciona una imagen válida');
        return;
      }

      // Convertir a base64 para preview
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        setQrPreview(base64String);
        setQrCodeUrl(base64String);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemoveQr = () => {
    setQrPreview('');
    setQrCodeUrl('');
  };

  const handleGuardar = async () => {
    if (!walletPrincipal.trim()) {
      toast.error('La wallet no puede estar vacía');
      return;
    }

    setSaving(true);
    try {
      await configuracionAPI.update({
        walletPrincipal: walletPrincipal.trim(),
        qrCodeUrl: qrCodeUrl
      });

      toast.success('¡Configuración guardada exitosamente!');
    } catch (error: any) {
      console.error('Error al guardar configuración:', error);
      toast.error(error.message || 'Error al guardar configuración');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <Card className="p-6">
        <div className="flex items-center justify-center py-8">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </Card>
    );
  }

  return (
    <Card className="p-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="h-12 w-12 rounded-full bg-[#0EA5E9]/10 flex items-center justify-center">
          <Wallet className="h-6 w-6 text-[#0EA5E9]" />
        </div>
        <div>
          <h3 className="text-xl">Configuración de Wallet</h3>
          <p className="text-gray-600 text-sm">
            Configura la wallet principal y código QR para recibir depósitos
          </p>
        </div>
      </div>

      <div className="space-y-6">
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <h4 className="text-blue-900 mb-2">📌 Información Importante</h4>
          <ul className="list-disc list-inside space-y-1 text-sm text-blue-800">
            <li>Esta wallet se mostrará a todos los usuarios al comprar packs</li>
            <li>Debe ser una wallet TRC20 (Tron) válida para USDT</li>
            <li>El código QR facilita los depósitos desde mobile</li>
            <li>Los cambios se aplican inmediatamente</li>
          </ul>
        </div>

        <div className="space-y-2">
          <Label htmlFor="wallet">Wallet Principal (TRC20 - USDT)</Label>
          <Input
            id="wallet"
            value={walletPrincipal}
            onChange={(e) => setWalletPrincipal(e.target.value)}
            placeholder="TXXXXXXXXXxxxxxxxxxxxxxx"
            className="font-mono"
          />
          <p className="text-sm text-gray-500">
            Red: TRC20 (Tron) - Solo USDT
          </p>
        </div>

        {/* Upload QR Code */}
        <div className="space-y-3">
          <Label htmlFor="qrCode">Código QR de la Wallet</Label>
          <p className="text-sm text-gray-500">
            Sube un código QR de tu wallet para que los usuarios puedan escanear y depositar fácilmente
          </p>
          
          <div className="flex items-start gap-3">
            <div>
              <Input
                id="qrCode"
                type="file"
                accept="image/*"
                onChange={handleQrUpload}
                className="hidden"
              />
              <Button
                variant="outline"
                onClick={() => document.getElementById('qrCode')?.click()}
                type="button"
              >
                <Upload className="mr-2 h-4 w-4" />
                {qrPreview ? 'Cambiar QR' : 'Cargar QR'}
              </Button>
            </div>

            {qrPreview && (
              <div className="flex items-start gap-2">
                <div className="border-2 border-gray-200 rounded-lg p-2 bg-white">
                  <ImageWithFallback
                    src={qrPreview}
                    alt="QR Code Preview"
                    className="w-32 h-32 object-contain"
                  />
                </div>
                <Button
                  variant="outline"
                  size="icon"
                  onClick={handleRemoveQr}
                  type="button"
                  className="text-red-600 hover:text-red-700 hover:bg-red-50"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            )}
          </div>
        </div>

        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <h4 className="text-yellow-900 mb-2">⚠️ Verificación</h4>
          <p className="text-sm text-yellow-800">
            Asegúrate de que la wallet y el código QR sean correctos. Una wallet incorrecta puede resultar en pérdida de fondos.
          </p>
        </div>

        <div className="flex gap-3">
          <Button
            variant="outline"
            onClick={cargarConfiguracion}
            disabled={saving}
          >
            Cancelar
          </Button>
          <Button
            onClick={handleGuardar}
            disabled={saving}
            className="bg-[#0EA5E9] hover:bg-[#0EA5E9]/90"
          >
            {saving ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Guardando...
              </>
            ) : (
              <>
                <Save className="mr-2 h-4 w-4" />
                Guardar Cambios
              </>
            )}
          </Button>
        </div>

        {/* Preview de la wallet */}
        {walletPrincipal && (
          <div className="border-t pt-4">
            <p className="text-sm text-gray-500 mb-2">Vista previa de lo que verán los usuarios:</p>
            <div className="bg-gray-50 p-4 rounded-lg border">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-600 mb-2">Dirección de Wallet:</p>
                  <p className="font-mono text-sm bg-white p-3 rounded border break-all">
                    {walletPrincipal}
                  </p>
                </div>
                {qrPreview && (
                  <div>
                    <p className="text-sm text-gray-600 mb-2">Código QR:</p>
                    <div className="bg-white p-3 rounded border inline-block">
                      <ImageWithFallback
                        src={qrPreview}
                        alt="QR Preview"
                        className="w-32 h-32 object-contain"
                      />
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </Card>
  );
}
