import { useState } from 'react';
import { callServer } from '../../utils/api';
import { AlertCircle, CheckCircle, Database, FileText, Search } from 'lucide-react';

export function DiagnosticoEstructura() {
  const [loading, setLoading] = useState(false);
  const [resultado, setResultado] = useState<any>(null);
  const [activeTab, setActiveTab] = useState<'completo' | 'estructura' | 'antiguos'>('completo');

  const ejecutarDiagnosticoCompleto = async () => {
    setLoading(true);
    try {
      const response = await callServer('/admin/diagnostico-estructura', 'POST');
      setResultado(response);
      console.log('📊 Diagnóstico completo:', response);
    } catch (error: any) {
      console.error('Error en diagnóstico:', error);
      alert('Error al ejecutar diagnóstico: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const analizarEstructura = async () => {
    setLoading(true);
    try {
      const response = await callServer('/admin/analizar-estructura', 'GET');
      setResultado(response);
      console.log('📊 Análisis de estructura:', response);
    } catch (error: any) {
      console.error('Error en análisis:', error);
      alert('Error al analizar estructura: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const buscarDatosAntiguos = async () => {
    setLoading(true);
    try {
      const response = await callServer('/admin/buscar-datos-antiguos', 'GET');
      setResultado(response);
      console.log('🔍 Datos antiguos:', response);
    } catch (error: any) {
      console.error('Error buscando datos antiguos:', error);
      alert('Error al buscar datos antiguos: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const renderCategoriasResumen = () => {
    if (!resultado?.analisis?.categorias && !resultado?.diagnostico?.analisis?.categorias) return null;

    const categorias = resultado.analisis?.categorias || resultado.diagnostico?.analisis?.categorias;
    
    return (
      <div className="mt-6">
        <h3 className="text-lg font-semibold mb-4">📊 Resumen por Categorías</h3>
        <div className="space-y-2">
          {Object.entries(categorias)
            .sort(([, a]: any, [, b]: any) => b - a)
            .map(([categoria, cantidad]: [string, any]) => (
              <div key={categoria} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                <span className="font-medium text-gray-700">{categoria}</span>
                <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">
                  {cantidad.toLocaleString()} registros
                </span>
              </div>
            ))}
        </div>
      </div>
    );
  };

  const renderDatosAntiguos = () => {
    if (!resultado?.datosAntiguos && !resultado?.diagnostico?.datosAntiguos) return null;

    const datosAntiguos = resultado.datosAntiguos || resultado.diagnostico?.datosAntiguos;
    const hayDatos = resultado.hayDatos || Object.keys(datosAntiguos).length > 0;
    
    return (
      <div className="mt-6">
        <h3 className="text-lg font-semibold mb-4">🔍 Datos Antiguos en Formato Monolítico</h3>
        
        {hayDatos ? (
          <div className="space-y-4">
            <div className="flex items-center gap-2 p-4 bg-red-50 border border-red-200 rounded-lg">
              <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0" />
              <div>
                <p className="font-semibold text-red-800">¡Datos antiguos encontrados!</p>
                <p className="text-sm text-red-600">
                  Se encontraron {Object.keys(datosAntiguos).length} keys en formato monolítico que pueden estar causando lentitud.
                </p>
              </div>
            </div>
            
            <div className="space-y-2">
              {Object.entries(datosAntiguos).map(([key, value]: [string, any]) => {
                const propiedades = typeof value === 'object' ? Object.keys(value) : [];
                const tieneArrays = propiedades.some(p => Array.isArray(value[p]));
                const arrayLengths = propiedades
                  .filter(p => Array.isArray(value[p]))
                  .map(p => ({ key: p, length: value[p].length }));
                
                return (
                  <div key={key} className="p-4 bg-white border border-gray-200 rounded-lg">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <p className="font-mono text-sm font-semibold text-gray-800">{key}</p>
                        <p className="text-xs text-gray-500 mt-1">
                          {propiedades.length} propiedades
                        </p>
                        {tieneArrays && (
                          <div className="mt-2 space-y-1">
                            {arrayLengths.map(({ key: arrKey, length }) => (
                              <p key={arrKey} className="text-xs text-orange-600">
                                • {arrKey}: {length.toLocaleString()} items
                              </p>
                            ))}
                          </div>
                        )}
                      </div>
                      <div className="px-3 py-1 bg-orange-100 text-orange-800 rounded-full text-xs">
                        Monolítico
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ) : (
          <div className="flex items-center gap-2 p-4 bg-green-50 border border-green-200 rounded-lg">
            <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
            <p className="text-green-800">No se encontraron datos en formato monolítico</p>
          </div>
        )}
      </div>
    );
  };

  const renderAnalisisRegistros = () => {
    if (!resultado?.diagnostico?.analisisRegistros) return null;

    const analisisRegistros = resultado.diagnostico.analisisRegistros;
    
    return (
      <div className="mt-6">
        <h3 className="text-lg font-semibold mb-4">🔬 Análisis de Registros por Categoría</h3>
        <div className="space-y-4">
          {Object.entries(analisisRegistros).map(([categoria, datos]: [string, any]) => (
            <div key={categoria} className="p-4 bg-white border border-gray-200 rounded-lg">
              <div className="flex items-start justify-between mb-3">
                <h4 className="font-semibold text-gray-800">{categoria}</h4>
                {datos.requiereMigracion ? (
                  <span className="px-3 py-1 bg-red-100 text-red-800 rounded-full text-xs">
                    ⚠️ Requiere Migración
                  </span>
                ) : (
                  <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-xs">
                    ✅ Estructura OK
                  </span>
                )}
              </div>
              
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <p className="text-gray-500">Total registros</p>
                  <p className="font-semibold">{datos.totalRegistros.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-gray-500">Muestras analizadas</p>
                  <p className="font-semibold">{datos.muestrasAnalizadas}</p>
                </div>
                <div>
                  <p className="text-gray-500">Estructura monolítica</p>
                  <p className="font-semibold text-red-600">
                    {datos.estructuraMonolitica} ({datos.porcentajeMonolitico}%)
                  </p>
                </div>
                <div>
                  <p className="text-gray-500">Estructura individual</p>
                  <p className="font-semibold text-green-600">{datos.estructuraIndividual}</p>
                </div>
              </div>
              
              {datos.requiereMigracion && (
                <div className="mt-3 p-3 bg-orange-50 border border-orange-200 rounded text-sm">
                  <p className="text-orange-800">
                    Esta categoría tiene {datos.porcentajeMonolitico}% de registros en formato monolítico y requiere migración para mejorar el rendimiento.
                  </p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    );
  };

  const renderConclusion = () => {
    if (!resultado?.diagnostico?.requiereMigracion) return null;

    const requiereMigracion = resultado.diagnostico.requiereMigracion;
    const categoriasConProblemas = resultado.diagnostico.categoriasConProblemas || [];
    
    return (
      <div className="mt-6">
        <h3 className="text-lg font-semibold mb-4">🎯 Conclusión</h3>
        {requiereMigracion ? (
          <div className="space-y-4">
            <div className="flex items-center gap-2 p-4 bg-red-50 border border-red-200 rounded-lg">
              <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0" />
              <div>
                <p className="font-semibold text-red-800">Se requiere migración de datos</p>
                <p className="text-sm text-red-600 mt-1">
                  Se detectaron problemas de estructura que pueden estar causando lentitud en el sistema.
                </p>
              </div>
            </div>
            
            {categoriasConProblemas.length > 0 && (
              <div className="p-4 bg-white border border-gray-200 rounded-lg">
                <p className="font-semibold text-gray-800 mb-2">Categorías que requieren migración:</p>
                <ul className="space-y-1">
                  {categoriasConProblemas.map((cat: string) => (
                    <li key={cat} className="text-sm text-gray-600">
                      • {cat}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        ) : (
          <div className="flex items-center gap-2 p-4 bg-green-50 border border-green-200 rounded-lg">
            <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
            <div>
              <p className="font-semibold text-green-800">Estructura de datos correcta</p>
              <p className="text-sm text-green-600 mt-1">
                Todos los datos están en formato individual optimizado.
              </p>
            </div>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="p-6">
      <div className="mb-8">
        <h1 className="text-2xl font-bold mb-2">🔍 Diagnóstico de Estructura de Datos</h1>
        <p className="text-gray-600">
          Analiza la estructura de la base de datos para detectar problemas de rendimiento causados por datos en formato monolítico.
        </p>
      </div>

      {/* Botones de acción */}
      <div className="flex gap-3 mb-6">
        <button
          onClick={ejecutarDiagnosticoCompleto}
          disabled={loading}
          className="flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          <Database className="w-5 h-5" />
          {loading && activeTab === 'completo' ? 'Analizando...' : 'Diagnóstico Completo'}
        </button>

        <button
          onClick={analizarEstructura}
          disabled={loading}
          className="flex items-center gap-2 px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          <FileText className="w-5 h-5" />
          {loading && activeTab === 'estructura' ? 'Analizando...' : 'Solo Estructura'}
        </button>

        <button
          onClick={buscarDatosAntiguos}
          disabled={loading}
          className="flex items-center gap-2 px-6 py-3 bg-orange-600 text-white rounded-lg hover:bg-orange-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          <Search className="w-5 h-5" />
          {loading && activeTab === 'antiguos' ? 'Buscando...' : 'Buscar Datos Antiguos'}
        </button>
      </div>

      {/* Resultados */}
      {loading && (
        <div className="flex items-center justify-center p-12">
          <div className="text-center">
            <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-blue-600 border-t-transparent mb-4"></div>
            <p className="text-gray-600">Analizando estructura de datos...</p>
            <p className="text-sm text-gray-500 mt-2">Esto puede tomar algunos segundos</p>
          </div>
        </div>
      )}

      {!loading && resultado && (
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          {/* Información general */}
          <div className="mb-6 pb-6 border-b border-gray-200">
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle className="w-5 h-5 text-green-600" />
              <h3 className="text-lg font-semibold">Análisis Completado</h3>
            </div>
            <p className="text-sm text-gray-500">
              Ejecutado el {new Date(resultado.timestamp).toLocaleString('es-ES')}
            </p>
          </div>

          {/* Renderizar resultados según el tipo de análisis */}
          {renderCategoriasResumen()}
          {renderDatosAntiguos()}
          {renderAnalisisRegistros()}
          {renderConclusion()}
        </div>
      )}

      {!loading && !resultado && (
        <div className="bg-gray-50 rounded-lg border border-gray-200 p-12 text-center">
          <Database className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600">No se ha ejecutado ningún diagnóstico aún</p>
          <p className="text-sm text-gray-500 mt-2">
            Selecciona una opción arriba para comenzar el análisis
          </p>
        </div>
      )}
    </div>
  );
}
