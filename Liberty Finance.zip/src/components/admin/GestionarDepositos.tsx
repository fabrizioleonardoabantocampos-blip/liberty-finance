import { useState, useEffect } from 'react';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Check, X, ExternalLink, Loader2, Clock, CheckCircle, XCircle, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';
import { depositosAPI, usersAPI } from '../../utils/api';
import { useAutoRefresh } from '../../hooks/useAutoRefresh';

interface Deposito {
  id: string;
  userId: string;
  packNombre: string;
  monto: number;
  walletDestino: string;
  comprobante?: string;
  txHash?: string;
  estado: 'pendiente' | 'verificado' | 'rechazado';
  fecha: string;
  fechaProcesado?: string;
  procesadoPor?: string;
}

interface Usuario {
  id: string;
  nombre: string;
  apellido: string;
  email: string;
  wallet: string;
}

export function GestionarDepositos() {
  const [depositos, setDepositos] = useState<Deposito[]>([]);
  const [usuarios, setUsuarios] = useState<Record<string, Usuario>>({});
  const [loading, setLoading] = useState(true);
  const [processingId, setProcessingId] = useState<string | null>(null);
  const [filtro, setFiltro] = useState<'todos' | 'pendiente' | 'verificado' | 'rechazado'>('pendiente');
  const [isRefreshing, setIsRefreshing] = useState(false);

  const cargarDepositos = async () => {
    try {
      const data = await depositosAPI.getAll();
      setDepositos(data);

      // Cargar información de usuarios
      const userIds = [...new Set(data.map((d: Deposito) => d.userId))];
      const usersData: Record<string, Usuario> = {};
      
      for (const userId of userIds) {
        try {
          const user = await usersAPI.getById(userId);
          usersData[userId] = user;
        } catch (error) {
          console.error(`Error al cargar usuario ${userId}:`, error);
        }
      }
      
      setUsuarios(usersData);
    } catch (error) {
      console.error('Error al cargar depósitos:', error);
      toast.error('Error al cargar depósitos');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    cargarDepositos();
    
    // Auto-refresh cada 10 segundos
    const interval = setInterval(() => {
      cargarDepositos();
    }, 10000);
    
    return () => clearInterval(interval);
  }, []);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await cargarDepositos();
    toast.success('Datos actualizados');
    setIsRefreshing(false);
  };

  const handleAprobar = async (depositoId: string) => {
    setProcessingId(depositoId);
    try {
      await depositosAPI.update(depositoId, {
        estado: 'verificado',
        procesadoPor: 'admin' // En producción, usar ID del admin autenticado
      });

      toast.success('¡Depósito verificado! Pack activado y comisiones distribuidas.');
      await cargarDepositos(); // Refrescar inmediatamente después de aprobar
    } catch (error: any) {
      console.error('Error al verificar depósito:', error);
      toast.error(error.message || 'Error al verificar depósito');
    } finally {
      setProcessingId(null);
    }
  };

  const handleRechazar = async (depositoId: string) => {
    setProcessingId(depositoId);
    try {
      await depositosAPI.update(depositoId, {
        estado: 'rechazado',
        procesadoPor: 'admin'
      });

      toast.success('Depósito rechazado');
      await cargarDepositos(); // Refrescar inmediatamente después de rechazar
    } catch (error: any) {
      console.error('Error al rechazar depósito:', error);
      toast.error(error.message || 'Error al rechazar depósito');
    } finally {
      setProcessingId(null);
    }
  };

  const depositosFiltrados = depositos.filter(d => 
    filtro === 'todos' ? true : d.estado === filtro
  );

  const pendientesCount = depositos.filter(d => d.estado === 'pendiente').length;

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl">Gestión de Depósitos</h2>
          <p className="text-gray-600">
            Verifica y aprueba los depósitos de los usuarios
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            size="sm"
            onClick={handleRefresh}
            disabled={isRefreshing}
            className="gap-2"
          >
            <RefreshCw className={`h-4 w-4 ${isRefreshing ? 'animate-spin' : ''}`} />
            {isRefreshing ? 'Actualizando...' : 'Actualizar'}
          </Button>
          {pendientesCount > 0 && (
            <Badge variant="destructive" className="text-lg px-4 py-2">
              {pendientesCount} Pendientes
            </Badge>
          )}
        </div>
      </div>

      {/* Filtros */}
      <div className="flex gap-2">
        <Button
          variant={filtro === 'pendiente' ? 'default' : 'outline'}
          onClick={() => setFiltro('pendiente')}
          className="gap-2"
        >
          <Clock className="h-4 w-4" />
          Pendientes ({depositos.filter(d => d.estado === 'pendiente').length})
        </Button>
        <Button
          variant={filtro === 'verificado' ? 'default' : 'outline'}
          onClick={() => setFiltro('verificado')}
          className="gap-2"
        >
          <CheckCircle className="h-4 w-4" />
          Verificados ({depositos.filter(d => d.estado === 'verificado').length})
        </Button>
        <Button
          variant={filtro === 'rechazado' ? 'default' : 'outline'}
          onClick={() => setFiltro('rechazado')}
          className="gap-2"
        >
          <XCircle className="h-4 w-4" />
          Rechazados ({depositos.filter(d => d.estado === 'rechazado').length})
        </Button>
        <Button
          variant={filtro === 'todos' ? 'default' : 'outline'}
          onClick={() => setFiltro('todos')}
        >
          Todos ({depositos.length})
        </Button>
      </div>

      {/* Lista de depósitos */}
      <div className="space-y-4">
        {depositosFiltrados.length === 0 ? (
          <Card className="p-8 text-center">
            <p className="text-gray-500">No hay depósitos {filtro !== 'todos' && filtro}s</p>
          </Card>
        ) : (
          depositosFiltrados.map((deposito) => {
            const usuario = usuarios[deposito.userId];
            
            return (
              <Card key={deposito.id} className="p-6">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 space-y-3">
                    {/* Encabezado */}
                    <div className="flex items-center gap-3">
                      <Badge
                        variant={
                          deposito.estado === 'pendiente' ? 'default' :
                          deposito.estado === 'verificado' ? 'default' :
                          'destructive'
                        }
                        className={
                          deposito.estado === 'pendiente' ? 'bg-yellow-500' :
                          deposito.estado === 'verificado' ? 'bg-green-500' :
                          'bg-red-500'
                        }
                      >
                        {deposito.estado === 'pendiente' && '⏱️ PENDIENTE'}
                        {deposito.estado === 'verificado' && '✅ VERIFICADO'}
                        {deposito.estado === 'rechazado' && '❌ RECHAZADO'}
                      </Badge>
                      <span className="text-sm text-gray-500">
                        {new Date(deposito.fecha).toLocaleString('es-PE')}
                      </span>
                    </div>

                    {/* Información del usuario */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-gray-500">Usuario</p>
                        <p className="text-lg">
                          {usuario ? `${usuario.nombre} ${usuario.apellido}` : 'Cargando...'}
                        </p>
                        <p className="text-sm text-gray-600">{usuario?.email}</p>
                      </div>

                      <div>
                        <p className="text-sm text-gray-500">Pack</p>
                        <p className="text-lg">{deposito.packNombre}</p>
                        <p className="text-2xl text-[#0EA5E9]">
                          ${deposito.monto.toLocaleString()} USDT
                        </p>
                      </div>
                    </div>

                    {/* Wallet del usuario */}
                    <div>
                      <p className="text-sm text-gray-500">Wallet del Usuario</p>
                      <p className="text-sm font-mono bg-gray-50 p-2 rounded border">
                        {usuario?.wallet || 'No disponible'}
                      </p>
                    </div>

                    {/* Comprobante (Hash o Imagen) */}
                    <div>
                      <p className="text-sm text-gray-500 mb-1">Comprobante de Pago</p>
                      
                      {/* Caso 1: Es una URL de imagen */}
                      {deposito.comprobante && (deposito.comprobante.startsWith('http') || deposito.comprobante.startsWith('data:image')) && !deposito.comprobante.includes('tronscan') ? (
                        <div className="space-y-2">
                          <div className="relative w-full max-w-[200px] h-32 bg-gray-100 rounded-lg overflow-hidden border">
                            <img 
                              src={deposito.comprobante} 
                              alt="Comprobante" 
                              className="w-full h-full object-cover cursor-pointer hover:scale-105 transition-transform"
                              onClick={() => window.open(deposito.comprobante, '_blank')}
                            />
                          </div>
                          <p className="text-xs text-gray-400">Clic para ampliar imagen</p>
                        </div>
                      ) : (
                        /* Caso 2: Es un Hash o Texto */
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-mono bg-gray-50 p-2 rounded border flex-1 truncate">
                            {deposito.comprobante || deposito.txHash || 'No adjuntado'}
                          </p>
                          {(deposito.comprobante || deposito.txHash) && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                const hash = deposito.comprobante || deposito.txHash;
                                if (hash?.startsWith('http')) {
                                  window.open(hash, '_blank');
                                } else {
                                  window.open(`https://tronscan.org/#/transaction/${hash}`, '_blank');
                                }
                              }}
                            >
                              <ExternalLink className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Si tiene ambos (Hash separado) */}
                    {deposito.txHash && deposito.comprobante && deposito.comprobante !== deposito.txHash && (
                      <div className="mt-2">
                        <p className="text-sm text-gray-500">Hash de Transacción</p>
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-mono bg-gray-50 p-2 rounded border flex-1 truncate">
                            {deposito.txHash}
                          </p>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => window.open(`https://tronscan.org/#/transaction/${deposito.txHash}`, '_blank')}
                          >
                            <ExternalLink className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    )}

                    {/* Fecha de procesado */}
                    {deposito.fechaProcesado && (
                      <p className="text-sm text-gray-500">
                        Procesado el {new Date(deposito.fechaProcesado).toLocaleString('es-PE')}
                      </p>
                    )}
                  </div>

                  {/* Acciones */}
                  {deposito.estado === 'pendiente' && (
                    <div className="flex flex-col gap-2">
                      <Button
                        onClick={() => handleAprobar(deposito.id)}
                        disabled={processingId !== null}
                        className="bg-green-600 hover:bg-green-700"
                      >
                        {processingId === deposito.id ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <>
                            <Check className="h-4 w-4 mr-2" />
                            Aprobar
                          </>
                        )}
                      </Button>
                      <Button
                        variant="destructive"
                        onClick={() => handleRechazar(deposito.id)}
                        disabled={processingId !== null}
                      >
                        {processingId === deposito.id ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <>
                            <X className="h-4 w-4 mr-2" />
                            Rechazar
                          </>
                        )}
                      </Button>
                    </div>
                  )}
                </div>
              </Card>
            );
          })
        )}
      </div>
    </div>
  );
}