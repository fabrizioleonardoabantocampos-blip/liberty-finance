import { useState } from 'react';
import { Search, Activity, DollarSign, Users, TrendingUp, Package, AlertCircle, Wrench } from 'lucide-react';
import { adminAPI } from '../../utils/api';
import { projectId, publicAnonKey } from '../../utils/supabase/info';

export default function DiagnosticoUsuario() {
  const [idUnico, setIdUnico] = useState('');
  const [loading, setLoading] = useState(false);
  const [diagnostico, setDiagnostico] = useState<any>(null);
  const [error, setError] = useState('');
  const [reparando, setReparando] = useState(false);
  const [resultadoReparacion, setResultadoReparacion] = useState<any>(null);
  const [analizandoRendimientos, setAnalizandoRendimientos] = useState(false);
  const [analisisRendimientos, setAnalisisRendimientos] = useState<any>(null);
  const [reparandoRendimientos, setReparandoRendimientos] = useState(false);
  const [resultadoReparacionRendimientos, setResultadoReparacionRendimientos] = useState<any>(null);
  const [corrigiendoHistoricos, setCorrigiendoHistoricos] = useState(false);
  const [resultadoCorreccionHistorica, setResultadoCorreccionHistorica] = useState<any>(null);
  const [diagnosticoPack, setDiagnosticoPack] = useState<any>(null);
  const [activandoPack, setActivandoPack] = useState(false);
  const [resultadoActivacion, setResultadoActivacion] = useState<any>(null);

  const ejecutarDiagnostico = async () => {
    if (!idUnico.trim()) {
      setError('Por favor ingresa un ID único');
      return;
    }

    setLoading(true);
    setError('');
    setDiagnostico(null);

    try {
      console.log(`🔍 Ejecutando diagnóstico para: ${idUnico}`);
      const resultado = await adminAPI.diagnosticarUsuario(idUnico);
      
      console.log('✅ Diagnóstico completado:', resultado);
      console.log('📦 Packs activos:', resultado.packs.activos);
      console.log('👥 Referidos:', resultado.referidos.directos);
      console.log('💰 Ganancias:', resultado.ganancias);
      
      setDiagnostico(resultado);
    } catch (err: any) {
      console.error('❌ Error en diagnóstico:', err);
      setError(err.message || 'Error al ejecutar diagnóstico');
    } finally {
      setLoading(false);
    }
  };

  const repararUsuario = async () => {
    if (!idUnico.trim()) {
      setError('Por favor ingresa un ID único');
      return;
    }

    setReparando(true);
    setError('');
    setResultadoReparacion(null);

    try {
      console.log(`🔧 Reparando packs de usuario para: ${idUnico}`);
      const resultado = await adminAPI.repararPacksUsuario(idUnico);
      
      console.log('✅ Reparación completada:', resultado);
      setResultadoReparacion(resultado);
      
      // Reejecutar diagnóstico para ver los cambios
      setTimeout(() => {
        ejecutarDiagnostico();
      }, 1000);
    } catch (err: any) {
      console.error('❌ Error en reparación:', err);
      setError(err.message || 'Error al reparar packs del usuario');
    } finally {
      setReparando(false);
    }
  };

  const analizarRendimientos = async () => {
    if (!idUnico.trim()) {
      setError('Por favor ingresa un ID único');
      return;
    }

    setAnalizandoRendimientos(true);
    setError('');
    setAnalisisRendimientos(null);

    try {
      console.log(`🔍 Analizando rendimientos para: ${idUnico}`);
      const resultado = await adminAPI.analizarRendimientosUsuario(idUnico);
      
      console.log('✅ Análisis completado:', resultado);
      setAnalisisRendimientos(resultado);
    } catch (err: any) {
      console.error('❌ Error en análisis:', err);
      setError(err.message || 'Error al analizar rendimientos del usuario');
    } finally {
      setAnalizandoRendimientos(false);
    }
  };

  const repararRendimientos = async () => {
    if (!idUnico.trim()) {
      setError('Por favor ingresa un ID único');
      return;
    }

    setReparandoRendimientos(true);
    setError('');
    setResultadoReparacionRendimientos(null);

    try {
      console.log(`🔧 Reparando rendimientos de usuario para: ${idUnico}`);
      const resultado = await adminAPI.repararRendimientosHuerfanos(idUnico);
      
      console.log('✅ Reparación de rendimientos completada:', resultado);
      setResultadoReparacionRendimientos(resultado);
      
      // Reanalizar rendimientos y rediagnosticar
      setTimeout(() => {
        analizarRendimientos();
        ejecutarDiagnostico();
      }, 1000);
    } catch (err: any) {
      console.error('❌ Error en reparación de rendimientos:', err);
      setError(err.message || 'Error al reparar rendimientos del usuario');
    } finally {
      setReparandoRendimientos(false);
    }
  };

  const corregirRendimientosHistoricos = async () => {
    if (!diagnostico?.usuario?.id) {
      setError('Primero ejecuta un diagnóstico');
      return;
    }

    setCorrigiendoHistoricos(true);
    setError('');
    setResultadoCorreccionHistorica(null);

    try {
      console.log(`🔧 Corrigiendo rendimientos históricos para: ${diagnostico.usuario.id}`);
      const resultado = await adminAPI.corregirRendimientosHistoricos(diagnostico.usuario.id);
      
      console.log('✅ Corrección histórica completada:', resultado);
      setResultadoCorreccionHistorica(resultado);
      
      // Rediagnosticar
      setTimeout(() => {
        ejecutarDiagnostico();
      }, 1000);
    } catch (err: any) {
      console.error('❌ Error en corrección histórica:', err);
      setError(err.message || 'Error al corregir rendimientos históricos');
    } finally {
      setCorrigiendoHistoricos(false);
    }
  };

  const diagnosticarPack = async (packId: string) => {
    try {
      console.log(`🔍 Diagnosticando pack: ${packId}`);
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-9f68532a/admin/diagnostico-pack/${packId}`,
        {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
            'Content-Type': 'application/json'
          }
        }
      );
      
      const data = await response.json();
      console.log('🔍 DIAGNÓSTICO PACK COMPLETO:', data);
      console.log('\n📊 ANÁLISIS:');
      console.log('- activo:', data.analisis?.activo, `(${data.analisis?.activoTipo})`);
      console.log('- activo === true:', data.analisis?.activoStrictTrue);
      console.log('- depositoVerificado:', data.analisis?.depositoVerificado);
      console.log('- Pasa filtro completo:', data.analisis?.pasaFiltroCompleto);
      console.log('- Razón de rechazo:', data.analisis?.razonRechazo);
      
      alert(`✅ Diagnóstico completado\n\nPack: ${data.pack?.nombre}\nActivo: ${data.analisis?.activo}\nPasa filtro: ${data.analisis?.pasaFiltroCompleto}\nRazón: ${data.analisis?.razonRechazo}`);
      setDiagnosticoPack(data);
    } catch (err: any) {
      console.error('❌ Error diagnosticando pack:', err);
      alert('❌ Error: ' + err.message);
    }
  };

  const activarPack = async (packId: string) => {
    if (!diagnostico?.usuario?.id) {
      setError('Primero ejecuta un diagnóstico');
      return;
    }

    setActivandoPack(true);
    setError('');
    setResultadoActivacion(null);

    try {
      console.log(`🔧 Activando pack: ${packId}`);
      const resultado = await adminAPI.activarPack(diagnostico.usuario.id, packId);
      
      console.log('✅ Activación completada:', resultado);
      setResultadoActivacion(resultado);
      
      // Rediagnosticar
      setTimeout(() => {
        ejecutarDiagnostico();
      }, 1000);
    } catch (err: any) {
      console.error('❌ Error en activación:', err);
      setError(err.message || 'Error al activar pack');
    } finally {
      setActivandoPack(false);
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h2 className="text-white mb-2">🔍 Diagnóstico de Usuario</h2>
        <p className="text-gray-400 text-sm">
          Analiza en profundidad los datos de un usuario específico para detectar inconsistencias
        </p>
      </div>

      {/* Buscador */}
      <div className="bg-[#1a1f2e] rounded-xl p-6 border border-gray-700">
        <label className="block text-sm text-gray-400 mb-2">
          ID Único del Usuario
        </label>
        <div className="flex gap-3">
          <input
            type="text"
            value={idUnico}
            onChange={(e) => setIdUnico(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && ejecutarDiagnostico()}
            placeholder="Ej: LF1764086702089158"
            className="flex-1 bg-[#0f1419] text-white px-4 py-3 rounded-lg border border-gray-700 focus:border-blue-500 focus:outline-none"
          />
          <button
            onClick={ejecutarDiagnostico}
            disabled={loading}
            className="px-6 py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 text-white rounded-lg transition-colors flex items-center gap-2"
          >
            {loading ? (
              <>
                <Activity className="w-5 h-5 animate-spin" />
                Diagnosticando...
              </>
            ) : (
              <>
                <Search className="w-5 h-5" />
                Diagnosticar
              </>
            )}
          </button>
        </div>
        {error && (
          <div className="mt-3 p-3 bg-red-500/10 border border-red-500/20 rounded-lg flex items-start gap-2">
            <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
            <p className="text-red-400 text-sm">{error}</p>
          </div>
        )}
      </div>

      {/* Resultados del Diagnóstico */}
      {diagnostico && (
        <div className="space-y-4">
          {/* Header: Información del Usuario */}
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl p-6 text-white">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-xl mb-1">{diagnostico.usuario.nombre}</h3>
                <p className="text-blue-100 text-sm">{diagnostico.usuario.email}</p>
                <p className="text-blue-100 text-sm mt-1">ID: {diagnostico.usuario.id_unico}</p>
              </div>
              <div className="text-right">
                <div className="text-sm text-blue-100">Rango</div>
                <div className="text-lg">{diagnostico.usuario.rango}</div>
              </div>
            </div>
            <div className="mt-4 text-xs text-blue-100">
              ⏱️ Diagnóstico: {diagnostico.tiempoDiagnostico} | 📅 {new Date(diagnostico.timestamp).toLocaleString()}
            </div>
          </div>

          {/* Grid de Métricas Principales */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {/* Inversión Total */}
            <div className="bg-[#1a1f2e] rounded-xl p-5 border border-gray-700">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 rounded-lg bg-green-500/10 flex items-center justify-center">
                  <Package className="w-5 h-5 text-green-400" />
                </div>
                <div>
                  <div className="text-xs text-gray-400">Inversión Total</div>
                  <div className="text-2xl text-white">${diagnostico.packs.inversionTotal.toFixed(2)}</div>
                </div>
              </div>
              <div className="text-xs text-gray-400">
                {diagnostico.packs.totalActivos} pack{diagnostico.packs.totalActivos !== 1 ? 's' : ''} activo{diagnostico.packs.totalActivos !== 1 ? 's' : ''}
              </div>
            </div>

            {/* Ganancia Total */}
            <div className="bg-[#1a1f2e] rounded-xl p-5 border border-gray-700">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center">
                  <DollarSign className="w-5 h-5 text-blue-400" />
                </div>
                <div>
                  <div className="text-xs text-gray-400">Ganancia Total</div>
                  <div className="text-2xl text-white">${diagnostico.ganancias.gananciaTotal.toFixed(2)}</div>
                </div>
              </div>
              <div className="text-xs text-gray-400">
                {diagnostico.ganancias.rentabilidadPorcentaje.toFixed(2)}% rentabilidad
              </div>
            </div>

            {/* Referidos */}
            <div className="bg-[#1a1f2e] rounded-xl p-5 border border-gray-700">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 rounded-lg bg-purple-500/10 flex items-center justify-center">
                  <Users className="w-5 h-5 text-purple-400" />
                </div>
                <div>
                  <div className="text-xs text-gray-400">Referidos Directos</div>
                  <div className="text-2xl text-white">{diagnostico.referidos.totalDirectos}</div>
                </div>
              </div>
              <div className="text-xs text-gray-400">
                Red de referidos
              </div>
            </div>

            {/* Volumen del Equipo */}
            <div className="bg-[#1a1f2e] rounded-xl p-5 border border-gray-700">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 rounded-lg bg-yellow-500/10 flex items-center justify-center">
                  <TrendingUp className="w-5 h-5 text-yellow-400" />
                </div>
                <div>
                  <div className="text-xs text-gray-400">Volumen Equipo</div>
                  <div className="text-2xl text-white">${diagnostico.referidos.volumenEquipo.toFixed(2)}</div>
                </div>
              </div>
              <div className="text-xs text-gray-400">
                Volumen total generado
              </div>
            </div>
          </div>

          {/* Packs Activos */}
          <div className="bg-[#1a1f2e] rounded-xl p-6 border border-gray-700">
            <h3 className="text-white mb-4 flex items-center gap-2">
              <Package className="w-5 h-5 text-green-400" />
              Packs Activos ({diagnostico.packs.totalActivos})
            </h3>
            {diagnostico.packs.activos.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="text-left text-gray-400 text-sm border-b border-gray-700">
                      <th className="pb-3">ID</th>
                      <th className="pb-3">Tipo</th>
                      <th className="pb-3">Monto</th>
                      <th className="pb-3">Estado</th>
                      <th className="pb-3">Activación</th>
                    </tr>
                  </thead>
                  <tbody className="text-sm">
                    {diagnostico.packs.activos.map((pack: any, idx: number) => (
                      <tr key={idx} className="border-b border-gray-800">
                        <td className="py-3 text-gray-300 font-mono">{pack.id}</td>
                        <td className="py-3 text-white">{pack.tipo}</td>
                        <td className="py-3 text-green-400">${pack.monto.toFixed(2)}</td>
                        <td className="py-3">
                          <span className="px-2 py-1 bg-green-500/10 text-green-400 rounded text-xs">
                            {pack.status}
                          </span>
                        </td>
                        <td className="py-3 text-gray-400">
                          {pack.fechaActivacion ? new Date(pack.fechaActivacion).toLocaleDateString() : 'N/A'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-gray-400 text-sm">No hay packs activos</p>
            )}
          </div>

          {/* Packs Inactivos */}
          {diagnostico.packs.inactivos.length > 0 && (
            <div className="bg-[#1a1f2e] rounded-xl p-6 border border-gray-700">
              <h3 className="text-white mb-4 flex items-center gap-2">
                <Package className="w-5 h-5 text-gray-400" />
                Packs Inactivos ({diagnostico.packs.totalInactivos})
              </h3>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="text-left text-gray-400 text-sm border-b border-gray-700">
                      <th className="pb-3">ID</th>
                      <th className="pb-3">Tipo</th>
                      <th className="pb-3">Monto</th>
                      <th className="pb-3">Estado</th>
                      <th className="pb-3">Fecha Activación</th>
                    </tr>
                  </thead>
                  <tbody className="text-sm">
                    {diagnostico.packs.inactivos.map((pack: any, idx: number) => (
                      <tr key={idx} className="border-b border-gray-800">
                        <td className="py-3 text-gray-300 font-mono">{pack.id}</td>
                        <td className="py-3 text-white">{pack.tipo}</td>
                        <td className="py-3 text-gray-400">${pack.monto.toFixed(2)}</td>
                        <td className="py-3">
                          <span className="px-2 py-1 bg-gray-700 text-gray-400 rounded text-xs">
                            {pack.status}
                          </span>
                        </td>
                        <td className="py-3 text-gray-400">
                          {pack.fechaActivacion ? new Date(pack.fechaActivacion).toLocaleString() : 'N/A'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Desglose de Ganancias */}
          <div className="bg-[#1a1f2e] rounded-xl p-6 border border-gray-700">
            <h3 className="text-white mb-4 flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-blue-400" />
              Desglose de Ganancias
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="bg-[#0f1419] rounded-lg p-4">
                <div className="text-xs text-gray-400 mb-1">Rendimientos</div>
                <div className="text-xl text-white">${diagnostico.ganancias.rendimientos.total.toFixed(2)}</div>
                <div className="text-xs text-gray-400 mt-1">{diagnostico.ganancias.rendimientos.cantidad} registros</div>
              </div>
              <div className="bg-[#0f1419] rounded-lg p-4">
                <div className="text-xs text-gray-400 mb-1">Comisión Directa</div>
                <div className="text-xl text-white">${diagnostico.ganancias.comisionDirecta.total.toFixed(2)}</div>
                <div className="text-xs text-gray-400 mt-1">{diagnostico.ganancias.comisionDirecta.cantidad} registros</div>
              </div>
              <div className="bg-[#0f1419] rounded-lg p-4">
                <div className="text-xs text-gray-400 mb-1">Comisión Referido</div>
                <div className="text-xl text-white">${diagnostico.ganancias.comisionReferido.total.toFixed(2)}</div>
                <div className="text-xs text-gray-400 mt-1">{diagnostico.ganancias.comisionReferido.cantidad} registros</div>
              </div>
              <div className="bg-[#0f1419] rounded-lg p-4">
                <div className="text-xs text-gray-400 mb-1">Comisión Matriz</div>
                <div className="text-xl text-white">${diagnostico.ganancias.comisionMatriz.total.toFixed(2)}</div>
                <div className="text-xs text-gray-400 mt-1">{diagnostico.ganancias.comisionMatriz.cantidad} registros</div>
              </div>
              <div className="bg-[#0f1419] rounded-lg p-4">
                <div className="text-xs text-gray-400 mb-1">Comisión Rango</div>
                <div className="text-xl text-white">${diagnostico.ganancias.comisionRango.total.toFixed(2)}</div>
                <div className="text-xs text-gray-400 mt-1">{diagnostico.ganancias.comisionRango.cantidad} registros</div>
              </div>
              <div className="bg-[#0f1419] rounded-lg p-4 border-2 border-blue-500/20">
                <div className="text-xs text-gray-400 mb-1">Total Comisiones</div>
                <div className="text-xl text-blue-400">${diagnostico.ganancias.totalComisiones.toFixed(2)}</div>
                <div className="text-xs text-gray-400 mt-1">Todas las comisiones</div>
              </div>
            </div>
          </div>

          {/* Referidos Directos */}
          <div className="bg-[#1a1f2e] rounded-xl p-6 border border-gray-700">
            <h3 className="text-white mb-4 flex items-center gap-2">
              <Users className="w-5 h-5 text-purple-400" />
              Referidos Directos ({diagnostico.referidos.totalDirectos})
            </h3>
            {diagnostico.referidos.directos.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="text-left text-gray-400 text-sm border-b border-gray-700">
                      <th className="pb-3">ID Único</th>
                      <th className="pb-3">Nombre</th>
                      <th className="pb-3">Email</th>
                      <th className="pb-3">Packs</th>
                      <th className="pb-3">Inversión</th>
                    </tr>
                  </thead>
                  <tbody className="text-sm">
                    {diagnostico.referidos.directos.map((ref: any, idx: number) => (
                      <tr key={idx} className="border-b border-gray-800">
                        <td className="py-3 text-gray-300 font-mono">{ref.id_unico}</td>
                        <td className="py-3 text-white">{ref.nombre}</td>
                        <td className="py-3 text-gray-400">{ref.email}</td>
                        <td className="py-3 text-blue-400">{ref.packsActivos}</td>
                        <td className="py-3 text-green-400">${ref.inversionTotal.toFixed(2)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-gray-400 text-sm">No hay referidos directos</p>
            )}
          </div>

          {/* Matriz Binaria */}
          <div className="bg-[#1a1f2e] rounded-xl p-6 border border-gray-700">
            <h3 className="text-white mb-4 flex items-center gap-2">
              <Activity className="w-5 h-5 text-yellow-400" />
              Matriz Binaria
            </h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-[#0f1419] rounded-lg p-4 text-center">
                <div className="text-sm text-gray-400 mb-2">Izquierda</div>
                <div className="text-3xl text-white">{diagnostico.matrizBinaria.izquierda}</div>
                <div className="text-xs text-gray-400 mt-2">packs</div>
              </div>
              <div className="bg-[#0f1419] rounded-lg p-4 text-center">
                <div className="text-sm text-gray-400 mb-2">Derecha</div>
                <div className="text-3xl text-white">{diagnostico.matrizBinaria.derecha}</div>
                <div className="text-xs text-gray-400 mt-2">packs</div>
              </div>
            </div>
            {diagnostico.matrizBinaria.balanceado && (
              <div className="mt-4 p-3 bg-green-500/10 border border-green-500/20 rounded-lg text-center">
                <p className="text-green-400 text-sm">✅ Matriz balanceada</p>
              </div>
            )}
          </div>

          {/* Botón de Reparación */}
          <div className="bg-[#1a1f2e] rounded-xl p-6 border border-gray-700">
            <h3 className="text-white mb-4 flex items-center gap-2">
              <Wrench className="w-5 h-5 text-orange-400" />
              Reparación de Packs Dañados
            </h3>
            <p className="text-gray-400 text-sm mb-4">
              Esta herramienta corrige automáticamente el estado de los packs según su depósito verificado y rendimiento acumulado. Solo estarán activos los packs con depósito aprobado que no hayan llegado al 200%.
            </p>
            <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-3 mb-4">
              <p className="text-yellow-400 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4" />
                IMPORTANTE: Presiona el botón para ejecutar la corrección. El diagnóstico de arriba muestra el estado ANTES de reparar.
              </p>
            </div>
            <button
              onClick={repararUsuario}
              disabled={reparando}
              className="px-6 py-3 bg-orange-600 hover:bg-orange-700 disabled:bg-gray-600 text-white rounded-lg transition-colors flex items-center gap-2"
            >
              {reparando ? (
                <>
                  <Activity className="w-5 h-5 animate-spin" />
                  Reparando packs...
                </>
              ) : (
                <>
                  <Wrench className="w-5 h-5" />
                  🔧 Reparar Packs de Este Usuario
                </>
              )}
            </button>
            
            {resultadoReparacion && (
              <div className="mt-4 space-y-3">
                <div className="p-4 bg-green-500/10 border border-green-500/20 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <AlertCircle className="w-5 h-5 text-green-400" />
                    <p className="text-green-400">✅ Reparación completada exitosamente</p>
                  </div>
                  <div className="text-sm text-gray-300 space-y-1 ml-7">
                    <p>📦 Packs revisados: <span className="text-white">{resultadoReparacion.packsRevisados}</span></p>
                    <p>✅ Packs actualizados: <span className="text-green-400">{resultadoReparacion.packsActualizados}</span></p>
                    <p>💰 Depósitos verificados: <span className="text-blue-400">{resultadoReparacion.depositosVerificados}</span></p>
                    {resultadoReparacion.depositosRechazados > 0 && (
                      <p>❌ Depósitos rechazados: <span className="text-red-400">{resultadoReparacion.depositosRechazados}</span></p>
                    )}
                  </div>
                </div>
                
                {resultadoReparacion.reparaciones && resultadoReparacion.reparaciones.length > 0 && (
                  <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
                    <p className="text-blue-400 mb-2">📋 Detalles de reparaciones:</p>
                    <div className="space-y-2">
                      {resultadoReparacion.reparaciones.map((rep: any, idx: number) => (
                        <div key={idx} className="text-sm text-gray-300 bg-[#0f1419] p-3 rounded">
                          <div className="flex items-center justify-between mb-1">
                            <p>Pack <span className="font-mono text-white">{rep.packId}</span> (${rep.monto})</p>
                            <span className={`px-2 py-0.5 rounded text-xs ${
                              rep.statusNuevo === 'activo' ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'
                            }`}>
                              {rep.statusAnterior} → {rep.statusNuevo}
                            </span>
                          </div>
                          <ul className="ml-4 mt-1 text-xs text-gray-400 space-y-0.5">
                            <li className={rep.statusNuevo === 'activo' ? 'text-green-400' : 'text-yellow-400'}>
                              • {rep.razon}
                            </li>
                            {rep.rendimientoTotal !== undefined && (
                              <li>• Rendimiento acumulado: ${rep.rendimientoTotal.toFixed(2)}</li>
                            )}
                            {rep.depositoEncontrado !== undefined && (
                              <li>• Depósito verificado: {rep.depositoEncontrado ? '✓ Sí' : '✗ No'}</li>
                            )}
                            {rep.actualizaciones.fechaActivacion && <li>• Fecha: {new Date(rep.actualizaciones.fechaActivacion).toLocaleString()}</li>}
                          </ul>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
                <p className="text-xs text-gray-400 italic">
                  💡 El diagnóstico se actualizará automáticamente en 1 segundo...
                </p>
              </div>
            )}
          </div>

          {/* Análisis Detallado de Rendimientos */}
          <div className="bg-[#1a1f2e] rounded-xl p-6 border border-gray-700">
            <h3 className="text-white mb-4 flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-blue-400" />
              Análisis Detallado de Rendimientos (DEBUG)
            </h3>
            <p className="text-gray-400 text-sm mb-4">
              Esta herramienta muestra qué rendimientos están asociados a qué packs, y detecta rendimientos huérfanos (asociados a packs que ya no existen).
            </p>
            <button
              onClick={analizarRendimientos}
              disabled={analizandoRendimientos}
              className="px-6 py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 text-white rounded-lg transition-colors flex items-center gap-2"
            >
              {analizandoRendimientos ? (
                <>
                  <Activity className="w-5 h-5 animate-spin" />
                  Analizando...
                </>
              ) : (
                <>
                  <AlertCircle className="w-5 h-5" />
                  🔬 Analizar Rendimientos Detalladamente
                </>
              )}
            </button>
            
            {analisisRendimientos && (
              <div className="mt-4 space-y-4">
                {/* Resumen */}
                <div className="p-4 bg-purple-500/10 border border-purple-500/20 rounded-lg">
                  <p className="text-purple-400 mb-2">📊 Resumen General:</p>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-sm text-gray-300">
                    <div>
                      <p className="text-gray-400 text-xs">Packs Actuales</p>
                      <p className="text-white text-lg">{analisisRendimientos.resumen.packsActuales}</p>
                    </div>
                    <div>
                      <p className="text-gray-400 text-xs">Total Rendimientos</p>
                      <p className="text-white text-lg">{analisisRendimientos.resumen.totalRendimientos}</p>
                    </div>
                    <div>
                      <p className="text-gray-400 text-xs">Monto Total</p>
                      <p className="text-green-400 text-lg">${analisisRendimientos.resumen.montoTotalRendimientos.toFixed(2)}</p>
                    </div>
                    <div>
                      <p className="text-gray-400 text-xs">Rendimientos Asociados</p>
                      <p className="text-blue-400 text-lg">{analisisRendimientos.resumen.rendimientosAsociados}</p>
                    </div>
                    <div>
                      <p className="text-gray-400 text-xs">Sin Pack ID</p>
                      <p className="text-yellow-400 text-lg">{analisisRendimientos.resumen.rendimientosSinPack}</p>
                    </div>
                    <div>
                      <p className="text-gray-400 text-xs">Huérfanos</p>
                      <p className="text-red-400 text-lg">{analisisRendimientos.resumen.rendimientosHuerfanos}</p>
                    </div>
                  </div>
                </div>

                {/* Packs Actuales */}
                <div className="p-4 bg-green-500/10 border border-green-500/20 rounded-lg">
                  <p className="text-green-400 mb-3">📦 Packs Actuales y Sus Rendimientos:</p>
                  <div className="space-y-3">
                    {analisisRendimientos.packsActuales.map((pack: any, idx: number) => (
                      <div key={idx} className="bg-[#0f1419] p-3 rounded">
                        <div className="flex items-center justify-between mb-2">
                          <div>
                            <p className="text-white font-mono text-sm">{pack.packId} - ${pack.monto}</p>
                            <p className="text-gray-400 text-xs">{pack.tipo} ({pack.status})</p>
                          </div>
                          <div className="text-right">
                            <p className="text-green-400">${pack.rendimientos.total.toFixed(2)}</p>
                            <p className="text-gray-400 text-xs">{pack.rendimientos.cantidad} rendimientos</p>
                          </div>
                        </div>
                        {pack.rendimientos.detalle.length > 0 && (
                          <div className="mt-2 pl-4 border-l-2 border-gray-700">
                            <p className="text-gray-400 text-xs mb-1">Últimos rendimientos:</p>
                            {pack.rendimientos.detalle.slice(0, 3).map((rend: any, ridx: number) => (
                              <p key={ridx} className="text-gray-400 text-xs">
                                • {new Date(rend.fecha).toLocaleDateString()} - ${rend.monto.toFixed(2)} - {rend.descripcion}
                              </p>
                            ))}
                            {pack.rendimientos.detalle.length > 3 && (
                              <p className="text-gray-500 text-xs mt-1">... y {pack.rendimientos.detalle.length - 3} más</p>
                            )}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Rendimientos Huérfanos */}
                {analisisRendimientos.rendimientosHuerfanos.length > 0 && (
                  <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-lg">
                    <p className="text-red-400 mb-3">⚠️ Rendimientos Huérfanos (Pack ID ya no existe):</p>
                    <div className="space-y-3">
                      {analisisRendimientos.rendimientosHuerfanos.map((huerfano: any, idx: number) => (
                        <div key={idx} className="bg-[#0f1419] p-3 rounded">
                          <div className="flex items-center justify-between mb-2">
                            <div>
                              <p className="text-red-400 font-mono text-sm">Pack ID Antiguo: {huerfano.packIdAntiguo}</p>
                              <p className="text-gray-400 text-xs font-mono">{huerfano.packIdCompletoAntiguo}</p>
                            </div>
                            <div className="text-right">
                              <p className="text-red-400">${huerfano.total.toFixed(2)}</p>
                              <p className="text-gray-400 text-xs">{huerfano.cantidad} rendimientos</p>
                            </div>
                          </div>
                          <div className="mt-2 pl-4 border-l-2 border-red-700/30">
                            <p className="text-gray-400 text-xs mb-1">Rendimientos perdidos:</p>
                            {huerfano.rendimientos.slice(0, 5).map((rend: any, ridx: number) => (
                              <p key={ridx} className="text-gray-400 text-xs">
                                • {new Date(rend.fecha).toLocaleDateString()} - ${rend.monto.toFixed(2)} - {rend.descripcion}
                              </p>
                            ))}
                            {huerfano.rendimientos.length > 5 && (
                              <p className="text-gray-500 text-xs mt-1">... y {huerfano.rendimientos.length - 5} más</p>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Rendimientos Sin Pack ID */}
                {analisisRendimientos.rendimientosSinPackId.length > 0 && (
                  <div className="p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
                    <p className="text-yellow-400 mb-3">⚠️ Rendimientos Sin Pack ID:</p>
                    <div className="space-y-1">
                      {analisisRendimientos.rendimientosSinPackId.slice(0, 10).map((rend: any, idx: number) => (
                        <p key={idx} className="text-gray-400 text-xs">
                          • {new Date(rend.fecha).toLocaleDateString()} - ${rend.monto.toFixed(2)} - {rend.descripcion}
                        </p>
                      ))}
                      {analisisRendimientos.rendimientosSinPackId.length > 10 && (
                        <p className="text-gray-500 text-xs mt-1">... y {analisisRendimientos.rendimientosSinPackId.length - 10} más</p>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Botón de Reparación de Rendimientos */}
          <div className="bg-[#1a1f2e] rounded-xl p-6 border border-gray-700">
            <h3 className="text-white mb-4 flex items-center gap-2">
              <Wrench className="w-5 h-5 text-orange-400" />
              Reparación de Rendimientos Huérfanos
            </h3>
            <p className="text-gray-400 text-sm mb-4">
              Esta herramienta asocia automáticamente los rendimientos sin pack ID a sus packs correspondientes basándose en el monto y las fechas.
            </p>
            <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-3 mb-4">
              <p className="text-yellow-400 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4" />
                IMPORTANTE: Esta reparación es segura y no elimina datos. Solo asocia rendimientos a sus packs correctos.
              </p>
            </div>
            <button
              onClick={repararRendimientos}
              disabled={reparandoRendimientos}
              className="px-6 py-3 bg-orange-600 hover:bg-orange-700 disabled:bg-gray-600 text-white rounded-lg transition-colors flex items-center gap-2"
            >
              {reparandoRendimientos ? (
                <>
                  <Activity className="w-5 h-5 animate-spin" />
                  Reparando rendimientos...
                </>
              ) : (
                <>
                  <Wrench className="w-5 h-5" />
                  🔧 Reparar Rendimientos Huérfanos
                </>
              )}
            </button>
            
            {resultadoReparacionRendimientos && (
              <div className="mt-4 space-y-3">
                <div className="p-4 bg-green-500/10 border border-green-500/20 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <AlertCircle className="w-5 h-5 text-green-400" />
                    <p className="text-green-400">✅ Reparación completada exitosamente</p>
                  </div>
                  <div className="text-sm text-gray-300 space-y-1 ml-7">
                    <p>📊 Rendimientos sin pack ID: <span className="text-white">{resultadoReparacionRendimientos.rendimientosTotalesSinPack}</span></p>
                    <p>✅ Rendimientos reparados: <span className="text-green-400">{resultadoReparacionRendimientos.rendimientosReparados}</span></p>
                  </div>
                </div>
                
                {resultadoReparacionRendimientos.detalles && resultadoReparacionRendimientos.detalles.length > 0 && (
                  <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
                    <p className="text-blue-400 mb-2">📋 Detalles de reparaciones ({resultadoReparacionRendimientos.detalles.length}):</p>
                    <div className="space-y-2">
                      {resultadoReparacionRendimientos.detalles.map((rep: any, idx: number) => (
                        <div key={idx} className="text-sm text-gray-300 bg-[#0f1419] p-3 rounded">
                          <div className="flex items-center justify-between mb-1">
                            <p>Rendimiento <span className="font-mono text-white">{rep.rendimientoId}</span> (${rep.monto})</p>
                            <span className="px-2 py-0.5 rounded text-xs bg-green-500/20 text-green-400">
                              Asociado
                            </span>
                          </div>
                          <ul className="ml-4 mt-1 text-xs text-gray-400 space-y-0.5">
                            <li className="text-green-400">
                              • Pack {rep.packIdAsignado} (${rep.packMonto})
                            </li>
                            <li>• Fecha: {new Date(rep.fecha).toLocaleString()}</li>
                            <li>• {rep.descripcion}</li>
                          </ul>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
                <p className="text-xs text-gray-400 italic">
                  💡 El diagnóstico se actualizará automáticamente en 1 segundo...
                </p>
              </div>
            )}
          </div>

          {/* 🆕 CORRECCIÓN DE RENDIMIENTOS HISTÓRICOS */}
          <div className="bg-[#1a1f2e] rounded-xl p-6 border border-amber-700">
            <h3 className="text-white mb-4 flex items-center gap-2">
              <Package className="w-5 h-5 text-amber-400" />
              🔧 Corrección de Rendimientos Históricos
            </h3>
            <p className="text-gray-400 text-sm mb-4">
              Esta herramienta analiza packs <span className="text-amber-400 font-semibold">ACTIVOS</span> que NO alcanzaron el 200% de rendimiento y agrega automáticamente las comisiones faltantes para completarlos.
            </p>
            <div className="bg-amber-500/10 border border-amber-500/20 rounded-lg p-3 mb-4">
              <p className="text-amber-400 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4" />
                IMPORTANTE: Solo se corrigen packs <strong>ACTIVOS</strong> con más de $50 faltantes. Packs inactivos o reinvertidos NO se corrigen.
              </p>
            </div>
            <button
              onClick={corregirRendimientosHistoricos}
              disabled={corrigiendoHistoricos || !diagnostico}
              className="px-6 py-3 bg-amber-600 hover:bg-amber-700 disabled:bg-gray-600 text-white rounded-lg transition-colors flex items-center gap-2"
            >
              {corrigiendoHistoricos ? (
                <>
                  <Activity className="w-5 h-5 animate-spin" />
                  Corrigiendo rendimientos históricos...
                </>
              ) : (
                <>
                  <Package className="w-5 h-5" />
                  💰 Corregir Rendimientos Históricos (200%)
                </>
              )}
            </button>
            
            {/* 🔍 BOTÓN DE DIAGNÓSTICO DE PACK (DEBUG) */}
            <button
              onClick={() => diagnosticarPack('99754efa')}
              className="mt-3 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors text-sm flex items-center gap-2"
            >
              <AlertCircle className="w-4 h-4" />
              🔍 Diagnosticar Pack 99754efa (DEBUG)
            </button>
            
            {/* 🔓 BOTÓN PARA ACTIVAR PACK 100 */}
            <button
              onClick={() => activarPack('eb60d9d4')}
              disabled={activandoPack || !diagnostico}
              className="mt-3 px-4 py-2 bg-green-600 hover:bg-green-700 disabled:bg-gray-600 text-white rounded-lg transition-colors text-sm flex items-center gap-2"
            >
              {activandoPack ? (
                <>
                  <Activity className="w-4 h-4 animate-spin" />
                  Activando...
                </>
              ) : (
                <>
                  <Package className="w-4 h-4" />
                  🔓 Activar Pack 100 (eb60d9d4)
                </>
              )}
            </button>
            
            {/* 📊 RESULTADO DE LA ACTIVACIÓN */}
            {resultadoActivacion && (
              <div className="mt-4 p-4 bg-green-500/10 border border-green-500/20 rounded-lg">
                <p className="text-green-400 mb-3">✅ {resultadoActivacion.mensaje}</p>
                <div className="bg-[#0f1419] p-3 rounded text-sm space-y-2">
                  <p className="text-gray-300">📦 <span className="text-white">{resultadoActivacion.packActualizado?.nombre}</span> (${resultadoActivacion.packActualizado?.monto})</p>
                  <div className="grid grid-cols-2 gap-3 mt-2">
                    <div>
                      <p className="text-gray-400 text-xs">Estado Anterior:</p>
                      <p className="text-red-400">{resultadoActivacion.packAnterior?.status}</p>
                    </div>
                    <div>
                      <p className="text-gray-400 text-xs">Estado Nuevo:</p>
                      <p className="text-green-400">{resultadoActivacion.packActualizado?.status}</p>
                    </div>
                  </div>
                  <p className="text-gray-400 text-xs mt-2">💡 Ahora puedes ejecutar "Corregir Rendimientos Históricos" para agregar el 200%</p>
                </div>
              </div>
            )}
            
            {/* 📊 RESULTADO DEL DIAGNÓSTICO DE PACK */}
            {diagnosticoPack && (
              <div className="mt-4 p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
                <p className="text-blue-400 mb-3">📦 Diagnóstico del Pack {diagnosticoPack.pack?.nombre}</p>
                
                <div className="bg-[#0f1419] p-4 rounded-lg space-y-3">
                  {/* Información básica */}
                  <div>
                    <p className="text-gray-400 text-xs mb-2">📋 Información Básica:</p>
                    <div className="ml-4 space-y-1 text-sm">
                      <p className="text-gray-300">• ID: <span className="text-white font-mono">{diagnosticoPack.pack?.id}</span></p>
                      <p className="text-gray-300">• Nombre: <span className="text-white">{diagnosticoPack.pack?.nombre}</span></p>
                      <p className="text-gray-300">• Monto: <span className="text-green-400">${diagnosticoPack.pack?.monto}</span></p>
                      <p className="text-gray-300">• Fecha Compra: <span className="text-white">{diagnosticoPack.pack?.fechaCompra}</span></p>
                    </div>
                  </div>
                  
                  {/* Análisis de filtros */}
                  <div>
                    <p className="text-gray-400 text-xs mb-2">🔍 Análisis de Filtros:</p>
                    <div className="ml-4 space-y-1 text-sm">
                      <p className="text-gray-300">
                        • activo: <span className={diagnosticoPack.analisis?.activo === true ? "text-green-400" : "text-red-400"}>{String(diagnosticoPack.analisis?.activo)}</span> 
                        <span className="text-gray-500 ml-2">({diagnosticoPack.analisis?.activoTipo})</span>
                      </p>
                      <p className="text-gray-300">
                        • activo === true: <span className={diagnosticoPack.analisis?.activoStrictTrue ? "text-green-400" : "text-red-400"}>{String(diagnosticoPack.analisis?.activoStrictTrue)}</span>
                      </p>
                      <p className="text-gray-300">
                        • depositoVerificado: <span className="text-white">{String(diagnosticoPack.analisis?.depositoVerificado)}</span>
                        <span className="text-gray-500 ml-2">({diagnosticoPack.analisis?.depositoVerificadoTipo})</span>
                      </p>
                      <p className="text-gray-300">
                        • Pasa filtro activo: <span className={diagnosticoPack.analisis?.pasaFiltroActivo ? "text-green-400" : "text-red-400"}>{String(diagnosticoPack.analisis?.pasaFiltroActivo)}</span>
                      </p>
                      <p className="text-gray-300">
                        • Pasa filtro depósito: <span className={diagnosticoPack.analisis?.pasaFiltroDeposito ? "text-green-400" : "text-red-400"}>{String(diagnosticoPack.analisis?.pasaFiltroDeposito)}</span>
                      </p>
                      <p className="text-gray-300">
                        • Pasa filtro COMPLETO: <span className={diagnosticoPack.analisis?.pasaFiltroCompleto ? "text-green-400 font-bold" : "text-red-400 font-bold"}>{String(diagnosticoPack.analisis?.pasaFiltroCompleto)}</span>
                      </p>
                    </div>
                  </div>
                  
                  {/* Razón */}
                  <div className={`p-3 rounded ${diagnosticoPack.analisis?.pasaFiltroCompleto ? 'bg-green-500/10 border border-green-500/20' : 'bg-red-500/10 border border-red-500/20'}`}>
                    <p className={diagnosticoPack.analisis?.pasaFiltroCompleto ? 'text-green-400' : 'text-red-400'}>
                      {diagnosticoPack.analisis?.pasaFiltroCompleto ? '✅' : '❌'} {diagnosticoPack.analisis?.razonRechazo}
                    </p>
                  </div>
                  
                  {/* JSON Completo */}
                  <details className="mt-4">
                    <summary className="text-gray-400 text-xs cursor-pointer hover:text-gray-300">📄 Ver JSON completo</summary>
                    <pre className="mt-2 p-3 bg-black/30 rounded text-xs text-gray-300 overflow-auto max-h-96">
                      {JSON.stringify(diagnosticoPack, null, 2)}
                    </pre>
                  </details>
                </div>
              </div>
            )}
            
            {resultadoCorreccionHistorica && (
              <div className="mt-4 space-y-3">
                {resultadoCorreccionHistorica.success ? (
                  <>
                    <div className="p-4 bg-green-500/10 border border-green-500/20 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <AlertCircle className="w-5 h-5 text-green-400" />
                        <p className="text-green-400">✅ {resultadoCorreccionHistorica.mensaje}</p>
                      </div>
                      <div className="text-sm text-gray-300 space-y-1 ml-7">
                        <p>💰 Total ANTES: <span className="text-white">${resultadoCorreccionHistorica.totalComisionesAntes.toFixed(2)}</span></p>
                        <p>✅ Total DESPUÉS: <span className="text-green-400">${resultadoCorreccionHistorica.totalComisionesDespues.toFixed(2)}</span></p>
                        <p className="text-amber-400">
                          📈 Diferencia: +${(resultadoCorreccionHistorica.totalComisionesDespues - resultadoCorreccionHistorica.totalComisionesAntes).toFixed(2)}
                        </p>
                      </div>
                    </div>
                    
                    {resultadoCorreccionHistorica.correccionesRealizadas && resultadoCorreccionHistorica.correccionesRealizadas.length > 0 && (
                      <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
                        <p className="text-blue-400 mb-2">📋 Correcciones realizadas ({resultadoCorreccionHistorica.correccionesRealizadas.length}):</p>
                        <div className="space-y-2">
                          {resultadoCorreccionHistorica.correccionesRealizadas.map((corr: any, idx: number) => (
                            <div key={idx} className="text-sm text-gray-300 bg-[#0f1419] p-3 rounded">
                              <p className="text-white mb-1">📦 {corr.pack} (${corr.monto})</p>
                              <ul className="ml-4 text-xs text-gray-400 space-y-0.5">
                                <li>• Rendimiento anterior: <span className="text-red-400">${corr.rendimientoAnterior.toFixed(2)}</span></li>
                                <li>• Rendimiento agregado: <span className="text-green-400">+${corr.rendimientoAgregado.toFixed(2)}</span></li>
                                <li>• Nuevo total: <span className="text-blue-400">${corr.nuevoTotal.toFixed(2)}</span> (200% ✅)</li>
                              </ul>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </>
                ) : (
                  <div className="p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
                    <p className="text-yellow-400">ℹ️ {resultadoCorreccionHistorica.mensaje || 'No se encontraron correcciones necesarias'}</p>
                  </div>
                )}
                
                <p className="text-xs text-gray-400 italic">
                  💡 El diagnóstico se actualizará automáticamente en 1 segundo...
                </p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}