import { useState } from 'react';
import { projectId, publicAnonKey } from '../../utils/supabase/info';

export function DiagnosticoServidorDebug() {
  const [resultado, setResultado] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [diagnosticoReferidos, setDiagnosticoReferidos] = useState<any>(null);
  const [loadingReferidos, setLoadingReferidos] = useState(false);
  const [migracionResult, setMigracionResult] = useState<any>(null);
  const [loadingMigracion, setLoadingMigracion] = useState(false);
  const [diagnosticoCompleto, setDiagnosticoCompleto] = useState<any>(null);
  const [loadingCompleto, setLoadingCompleto] = useState(false);

  const [todosUsuarios, setTodosUsuarios] = useState<any>(null);
  const [loadingTodosUsuarios, setLoadingTodosUsuarios] = useState(false);

  const [diagnosticoIsrael, setDiagnosticoIsrael] = useState<any>(null);
  const [loadingIsrael, setLoadingIsrael] = useState(false);

  const [diagnosticoIsraelJorge, setDiagnosticoIsraelJorge] = useState<any>(null);
  const [loadingIsraelJorge, setLoadingIsraelJorge] = useState(false);

  const [diagnosticoPacksJorge, setDiagnosticoPacksJorge] = useState<any>(null);
  const [loadingPacksJorge, setLoadingPacksJorge] = useState(false);

  const [diagnosticoDashboardIsrael, setDiagnosticoDashboardIsrael] = useState<any>(null);
  const [loadingDashboardIsrael, setLoadingDashboardIsrael] = useState(false);

  const verificarServidor = async () => {
    setLoading(true);
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-9f68532a/health`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`
          }
        }
      );
      
      const data = await response.json();
      setResultado(data);
      console.log('🔍 DIAGNÓSTICO COMPLETO:', data);
    } catch (error) {
      setResultado({ error: String(error) });
      console.error('❌ Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const diagnosticarReferidos = async () => {
    setLoadingReferidos(true);
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-9f68532a/version?diagnostico=referidos`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`
          }
        }
      );
      
      const data = await response.json();
      setDiagnosticoReferidos(data);
      console.log('🚨 DIAGNÓSTICO REFERIDOS:', data);
    } catch (error) {
      setDiagnosticoReferidos({ error: String(error) });
      console.error('❌ Error en diagnóstico de referidos:', error);
    } finally {
      setLoadingReferidos(false);
    }
  };

  const ejecutarMigracion = async () => {
    if (!confirm('⚠️ Esta operación actualizará TODOS los usuarios que no tienen el campo referidoPor. ¿Continuar?')) {
      return;
    }
    
    setLoadingMigracion(true);
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-9f68532a/migrar-referidos`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
            'Content-Type': 'application/json'
          }
        }
      );
      
      const data = await response.json();
      setMigracionResult(data);
      console.log('✅ MIGRACIÓN COMPLETADA:', data);
      
      // Refrescar diagnóstico después de la migración
      setTimeout(() => {
        diagnosticarReferidos();
      }, 1000);
    } catch (error) {
      setMigracionResult({ error: String(error) });
      console.error('❌ Error en migración:', error);
    } finally {
      setLoadingMigracion(false);
    }
  };

  const diagnosticarCompleto = async () => {
    setLoadingCompleto(true);
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-9f68532a/diagnostico-completo`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`
          }
        }
      );
      
      const data = await response.json();
      setDiagnosticoCompleto(data);
      console.log('📊 DIAGNÓSTICO COMPLETO KV_STORE:', data);
    } catch (error) {
      setDiagnosticoCompleto({ error: String(error) });
      console.error('❌ Error en diagnóstico completo:', error);
    } finally {
      setLoadingCompleto(false);
    }
  };

  const obtenerTodosUsuarios = async () => {
    setLoadingTodosUsuarios(true);
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-9f68532a/cargar-todos-usuarios`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`
          }
        }
      );
      
      const data = await response.json();
      setTodosUsuarios(data);
      console.log('👥 TODOS LOS USUARIOS:', data);
    } catch (error) {
      setTodosUsuarios({ error: String(error) });
      console.error('❌ Error al obtener todos los usuarios:', error);
    } finally {
      setLoadingTodosUsuarios(false);
    }
  };

  const diagnosticarIsrael = async () => {
    setLoadingIsrael(true);
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-9f68532a/diagnostico-israel`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`
          }
        }
      );
      
      const data = await response.json();
      setDiagnosticoIsrael(data);
      console.log('🚨 DIAGNÓSTICO ISRAEL:', data);
    } catch (error) {
      setDiagnosticoIsrael({ error: String(error) });
      console.error('❌ Error en diagnóstico de Israel:', error);
    } finally {
      setLoadingIsrael(false);
    }
  };

  const diagnosticarIsraelJorge = async () => {
    setLoadingIsraelJorge(true);
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-9f68532a/diagnostico-israel-jorge`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`
          }
        }
      );
      
      const data = await response.json();
      setDiagnosticoIsraelJorge(data);
      console.log('🚨 DIAGNÓSTICO ISRAEL-JORGE:', data);
    } catch (error) {
      setDiagnosticoIsraelJorge({ error: String(error) });
      console.error('❌ Error en diagnóstico de Israel-Jorge:', error);
    } finally {
      setLoadingIsraelJorge(false);
    }
  };

  const diagnosticarPacksJorge = async () => {
    setLoadingPacksJorge(true);
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-9f68532a/diagnostico-packs-jorge`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`
          }
        }
      );
      
      const data = await response.json();
      setDiagnosticoPacksJorge(data);
      console.log('🚨 DIAGNÓSTICO PACKS JORGE:', data);
    } catch (error) {
      setDiagnosticoPacksJorge({ error: String(error) });
      console.error('❌ Error en diagnóstico de packs de Jorge:', error);
    } finally {
      setLoadingPacksJorge(false);
    }
  };

  const diagnosticarDashboardIsrael = async () => {
    setLoadingDashboardIsrael(true);
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-9f68532a/diagnostico-dashboard-israel`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`
          }
        }
      );
      
      const data = await response.json();
      setDiagnosticoDashboardIsrael(data);
      console.log('🎯 DIAGNÓSTICO DASHBOARD ISRAEL:', data);
    } catch (error) {
      setDiagnosticoDashboardIsrael({ error: String(error) });
      console.error('❌ Error en diagnóstico de dashboard de Israel:', error);
    } finally {
      setLoadingDashboardIsrael(false);
    }
  };

  return (
    <div className="p-8 bg-white rounded-lg shadow-lg max-w-4xl mx-auto my-8">
      <h2 className="mb-6">🔧 Diagnóstico del Servidor</h2>
      
      <div className="flex gap-4 mb-6">
        <button
          onClick={verificarServidor}
          disabled={loading}
          className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
        >
          {loading ? 'Verificando...' : '🚀 Verificar Servidor'}
        </button>

        <button
          onClick={diagnosticarReferidos}
          disabled={loadingReferidos}
          className="px-6 py-3 bg-orange-600 text-white rounded-lg hover:bg-orange-700 disabled:opacity-50"
        >
          {loadingReferidos ? 'Analizando...' : '🔍 Diagnosticar Campo "referidoPor"'}
        </button>

        <button
          onClick={ejecutarMigracion}
          disabled={loadingMigracion}
          className="px-6 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:opacity-50"
        >
          {loadingMigracion ? 'Migrando...' : '🔄 Ejecutar Migración'}
        </button>

        <button
          onClick={diagnosticarCompleto}
          disabled={loadingCompleto}
          className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50"
        >
          {loadingCompleto ? 'Diagnósticando...' : '🔍 Diagnosticar Completo'}
        </button>

        <button
          onClick={obtenerTodosUsuarios}
          disabled={loadingTodosUsuarios}
          className="px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50"
        >
          {loadingTodosUsuarios ? 'Cargando...' : '👥 Obtener Todos los Usuarios'}
        </button>

        <button
          onClick={diagnosticarIsrael}
          disabled={loadingIsrael}
          className="px-6 py-3 bg-pink-600 text-white rounded-lg hover:bg-pink-700 disabled:opacity-50"
        >
          {loadingIsrael ? 'Analizando...' : '🔍 Diagnosticar Israel'}
        </button>

        <button
          onClick={diagnosticarIsraelJorge}
          disabled={loadingIsraelJorge}
          className="px-6 py-3 bg-pink-600 text-white rounded-lg hover:bg-pink-700 disabled:opacity-50"
        >
          {loadingIsraelJorge ? 'Analizando...' : '🔍 Diagnosticar Israel-Jorge'}
        </button>

        <button
          onClick={diagnosticarPacksJorge}
          disabled={loadingPacksJorge}
          className="px-6 py-3 bg-pink-600 text-white rounded-lg hover:bg-pink-700 disabled:opacity-50"
        >
          {loadingPacksJorge ? 'Analizando...' : '🔍 Diagnosticar Packs de Jorge'}
        </button>

        <button
          onClick={diagnosticarDashboardIsrael}
          disabled={loadingDashboardIsrael}
          className="px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:opacity-50"
        >
          {loadingDashboardIsrael ? 'Analizando...' : '🎯 Simular Dashboard de Israel'}
        </button>
      </div>

      {resultado && (
        <div className="mt-6 p-6 bg-gray-50 rounded-lg">
          <h3 className="mb-4">Resultados:</h3>
          
          <div className="space-y-3">
            <div className="p-4 bg-white rounded border">
              <p className="text-sm text-gray-600">Estado:</p>
              <p className="text-lg">{resultado.status}</p>
            </div>
            
            <div className="p-4 bg-white rounded border">
              <p className="text-sm text-gray-600">Total Usuarios:</p>
              <p className="text-2xl">{resultado.totalUsuarios || 'N/A'}</p>
            </div>
            
            <div className="p-4 bg-white rounded border">
              <p className="text-sm text-gray-600">Límite Activo:</p>
              <p className="text-lg">{resultado.limiteActivo || 'N/A'}</p>
            </div>
            
            <div className="p-4 bg-white rounded border">
              <p className="text-sm text-gray-600">Pedri Vilchez:</p>
              <p className="text-lg">{resultado.pedriVilchez || 'N/A'}</p>
            </div>

            {resultado.pedriDatos && (
              <div className="p-4 bg-green-50 rounded border border-green-200">
                <p className="text-sm text-gray-600 mb-2">�� Datos de Pedri:</p>
                <pre className="text-xs overflow-auto">
                  {JSON.stringify(resultado.pedriDatos, null, 2)}
                </pre>
              </div>
            )}

            <details className="mt-4">
              <summary className="cursor-pointer text-sm text-gray-600 hover:text-gray-900">
                Ver JSON completo
              </summary>
              <pre className="mt-2 p-4 bg-gray-900 text-green-400 rounded text-xs overflow-auto max-h-96">
                {JSON.stringify(resultado, null, 2)}
              </pre>
            </details>
          </div>
        </div>
      )}

      {diagnosticoReferidos && (
        <div className="mt-6 p-6 bg-orange-50 rounded-lg border-2 border-orange-200">
          <h3 className="mb-4 text-orange-900">🚨 Diagnóstico de Referidos</h3>
          
          <div className="space-y-3">
            {diagnosticoReferidos.resumen && (
              <>
                <div className="p-4 bg-white rounded border">
                  <p className="text-sm text-gray-600">Total usuarios analizados:</p>
                  <p className="text-2xl">{diagnosticoReferidos.resumen.total}</p>
                </div>
                
                <div className="p-4 bg-white rounded border">
                  <p className="text-sm text-gray-600">Usuarios CON campo referidoPor:</p>
                  <p className="text-2xl text-green-600">{diagnosticoReferidos.resumen.conReferido}</p>
                </div>
                
                <div className="p-4 bg-white rounded border">
                  <p className="text-sm text-gray-600">Usan formato UUID (con guiones):</p>
                  <p className="text-2xl text-blue-600">{diagnosticoReferidos.resumen.esUUID}</p>
                </div>
              </>
            )}

            {diagnosticoReferidos.jorge && (
              <div className="p-4 bg-yellow-50 rounded border border-yellow-300">
                <p className="text-sm text-gray-600 mb-2">👤 Jorge (caso de prueba):</p>
                <pre className="text-xs overflow-auto">
                  {JSON.stringify(diagnosticoReferidos.jorge, null, 2)}
                </pre>
              </div>
            )}

            {diagnosticoReferidos.israel && (
              <div className="p-4 bg-blue-50 rounded border border-blue-300">
                <p className="text-sm text-gray-600 mb-2">👤 Israel (caso de prueba):</p>
                <pre className="text-xs overflow-auto">
                  {JSON.stringify(diagnosticoReferidos.israel, null, 2)}
                </pre>
              </div>
            )}

            <details className="mt-4">
              <summary className="cursor-pointer text-sm text-gray-600 hover:text-gray-900">
                Ver muestra completa (15 usuarios)
              </summary>
              <pre className="mt-2 p-4 bg-gray-900 text-green-400 rounded text-xs overflow-auto max-h-96">
                {JSON.stringify(diagnosticoReferidos, null, 2)}
              </pre>
            </details>
          </div>
        </div>
      )}

      {migracionResult && (
        <div className="mt-6 p-6 bg-green-50 rounded-lg border-2 border-green-200">
          <h3 className="mb-4 text-green-900">✅ Resultado de Migración</h3>
          
          <div className="space-y-3">
            {migracionResult.resumen && (
              <>
                <div className="grid grid-cols-3 gap-4 mb-6">
                  <div className="p-4 bg-white rounded border">
                    <p className="text-sm text-gray-600">Total usuarios actualizados:</p>
                    <p className="text-2xl text-green-600">{migracionResult.resumen.actualizados}</p>
                  </div>
                  
                  <div className="p-4 bg-white rounded border">
                    <p className="text-sm text-gray-600">Usando matrizPadre:</p>
                    <p className="text-2xl text-blue-600">{migracionResult.resumen.usandoMatrizPadre}</p>
                  </div>
                  
                  <div className="p-4 bg-white rounded border">
                    <p className="text-sm text-gray-600">Asignados a Global:</p>
                    <p className="text-2xl text-yellow-600">{migracionResult.resumen.asignadosAGlobal}</p>
                  </div>
                  
                  <div className="p-4 bg-white rounded border">
                    <p className="text-sm text-gray-600">Ya tenían referidoPor:</p>
                    <p className="text-xl text-gray-600">{migracionResult.resumen.yaTeníanReferido}</p>
                  </div>
                  
                  <div className="p-4 bg-white rounded border">
                    <p className="text-sm text-gray-600">Total usuarios:</p>
                    <p className="text-xl text-gray-600">{migracionResult.resumen.totalUsuarios}</p>
                  </div>
                  
                  {migracionResult.resumen.errores > 0 && (
                    <div className="p-4 bg-red-50 rounded border border-red-300">
                      <p className="text-sm text-gray-600">Errores:</p>
                      <p className="text-2xl text-red-600">{migracionResult.resumen.errores}</p>
                    </div>
                  )}
                </div>
                
                {migracionResult.detalles && migracionResult.detalles.length > 0 && (
                  <div className="p-4 bg-white rounded border">
                    <h4 className="mb-3">📋 Usuarios Actualizados ({migracionResult.detalles.length})</h4>
                    <div className="max-h-96 overflow-auto space-y-2">
                      {migracionResult.detalles.map((detalle: any, i: number) => (
                        <div key={i} className="p-3 bg-gray-50 rounded text-sm">
                          <p className=""><strong>{detalle.nombre}</strong> - {detalle.email}</p>
                          <p className="text-xs text-gray-600">
                            ID: {detalle.id} → Referido por: {detalle.referidoPor} ({detalle.metodo})
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </>
            )}

            <details className="mt-4">
              <summary className="cursor-pointer text-sm text-gray-600 hover:text-gray-900">
                Ver detalles de la migración
              </summary>
              <pre className="mt-2 p-4 bg-gray-900 text-green-400 rounded text-xs overflow-auto max-h-96">
                {JSON.stringify(migracionResult, null, 2)}
              </pre>
            </details>
          </div>
        </div>
      )}

      {diagnosticoCompleto && (
        <div className="mt-6 p-6 bg-purple-50 rounded-lg border-2 border-purple-200">
          <h3 className="mb-4 text-purple-900">📊 Análisis Completo del KV Store</h3>
          
          <div className="space-y-4">
            {diagnosticoCompleto.resumen && (
              <div className="grid grid-cols-3 gap-4">
                <div className="p-4 bg-white rounded border">
                  <p className="text-sm text-gray-600">Total Registros:</p>
                  <p className="text-2xl">{diagnosticoCompleto.resumen.totalRegistros}</p>
                </div>
                
                <div className="p-4 bg-green-50 rounded border border-green-300">
                  <p className="text-sm text-gray-600">👥 USUARIOS:</p>
                  <p className="text-3xl text-green-600">{diagnosticoCompleto.resumen.usuarios}</p>
                </div>
                
                <div className="p-4 bg-blue-50 rounded border border-blue-300">
                  <p className="text-sm text-gray-600">💰 Comisiones:</p>
                  <p className="text-xl text-blue-600">{diagnosticoCompleto.resumen.comisiones}</p>
                </div>
                
                <div className="p-4 bg-yellow-50 rounded border border-yellow-300">
                  <p className="text-sm text-gray-600">💳 Pagos:</p>
                  <p className="text-xl text-yellow-600">{diagnosticoCompleto.resumen.pagos}</p>
                </div>
                
                <div className="p-4 bg-purple-50 rounded border border-purple-300">
                  <p className="text-sm text-gray-600">⭐ Puntos:</p>
                  <p className="text-xl text-purple-600">{diagnosticoCompleto.resumen.puntos}</p>
                </div>
                
                <div className="p-4 bg-pink-50 rounded border border-pink-300">
                  <p className="text-sm text-gray-600">📈 Ganancias:</p>
                  <p className="text-xl text-pink-600">{diagnosticoCompleto.resumen.ganancias}</p>
                </div>
                
                <div className="p-4 bg-gray-50 rounded border border-gray-300">
                  <p className="text-sm text-gray-600">❓ Otros:</p>
                  <p className="text-xl text-gray-600">{diagnosticoCompleto.resumen.otros}</p>
                </div>
              </div>
            )}

            {diagnosticoCompleto.keysEnBD && (
              <div className="mt-6 p-4 bg-yellow-50 rounded-lg border-2 border-yellow-300">
                <h4 className="mb-3">🔑 Análisis de Keys en Base de Datos</h4>
                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3 bg-white rounded">
                    <p className="text-sm text-gray-600">Total Keys en BD:</p>
                    <p className="text-2xl">{diagnosticoCompleto.keysEnBD.totalKeys}</p>
                  </div>
                  <div className="p-3 bg-white rounded">
                    <p className="text-sm text-gray-600">Keys tipo 'user:'</p>
                    <p className="text-2xl text-green-600">{diagnosticoCompleto.keysEnBD.userKeys}</p>
                  </div>
                  <div className="p-3 bg-white rounded">
                    <p className="text-sm text-gray-600">Keys tipo 'comision:'</p>
                    <p className="text-xl text-blue-600">{diagnosticoCompleto.keysEnBD.comisionKeys}</p>
                  </div>
                  <div className="p-3 bg-white rounded">
                    <p className="text-sm text-gray-600">Keys tipo 'pago:'</p>
                    <p className="text-xl text-yellow-600">{diagnosticoCompleto.keysEnBD.pagoKeys}</p>
                  </div>
                  <div className="p-3 bg-white rounded col-span-2">
                    <p className="text-sm text-gray-600">Otras Keys:</p>
                    <p className="text-xl text-gray-600">{diagnosticoCompleto.keysEnBD.otrasKeys}</p>
                  </div>
                </div>
                
                {diagnosticoCompleto.keysEnBD.muestraUserKeys && (
                  <details className="mt-3">
                    <summary className="cursor-pointer text-sm text-gray-700 hover:text-gray-900">
                      Ver muestra de user keys (10 primeros)
                    </summary>
                    <pre className="mt-2 p-3 bg-gray-900 text-green-400 rounded text-xs overflow-auto">
                      {JSON.stringify(diagnosticoCompleto.keysEnBD.muestraUserKeys, null, 2)}
                    </pre>
                  </details>
                )}
                
                {diagnosticoCompleto.keysEnBD.muestraOtrasKeys && diagnosticoCompleto.keysEnBD.muestraOtrasKeys.length > 0 && (
                  <details className="mt-3">
                    <summary className="cursor-pointer text-sm text-gray-700 hover:text-gray-900">
                      Ver muestra de OTRAS keys (10 primeros)
                    </summary>
                    <pre className="mt-2 p-3 bg-gray-900 text-yellow-400 rounded text-xs overflow-auto">
                      {JSON.stringify(diagnosticoCompleto.keysEnBD.muestraOtrasKeys, null, 2)}
                    </pre>
                  </details>
                )}
              </div>
            )}

            {diagnosticoCompleto.alerta && (
              <div className="mt-4 p-4 bg-red-100 rounded-lg border-2 border-red-400">
                <p className="text-red-800">{diagnosticoCompleto.alerta}</p>
              </div>
            )}

            {diagnosticoCompleto.muestras && (
              <div className="mt-4 space-y-3">
                {diagnosticoCompleto.muestras.usuario && (
                  <details>
                    <summary className="cursor-pointer text-sm text-gray-700 hover:text-gray-900">
                      Ver ejemplo de USUARIO
                    </summary>
                    <pre className="mt-2 p-4 bg-gray-900 text-green-400 rounded text-xs overflow-auto">
                      {JSON.stringify(diagnosticoCompleto.muestras.usuario, null, 2)}
                    </pre>
                  </details>
                )}
                {diagnosticoCompleto.muestras.comision && (
                  <details>
                    <summary className="cursor-pointer text-sm text-gray-700 hover:text-gray-900">
                      🔍 Ver ejemplo de COMISIÓN
                    </summary>
                    <pre className="mt-2 p-4 bg-gray-900 text-blue-400 rounded text-xs overflow-auto">
                      {JSON.stringify(diagnosticoCompleto.muestras.comision, null, 2)}
                    </pre>
                  </details>
                )}
                {diagnosticoCompleto.muestras.pago && (
                  <details>
                    <summary className="cursor-pointer text-sm text-gray-700 hover:text-gray-900">
                      🔍 Ver ejemplo de PAGO
                    </summary>
                    <pre className="mt-2 p-4 bg-gray-900 text-yellow-400 rounded text-xs overflow-auto">
                      {JSON.stringify(diagnosticoCompleto.muestras.pago, null, 2)}
                    </pre>
                  </details>
                )}
              </div>
            )}

            <details className="mt-4">
              <summary className="cursor-pointer text-sm text-gray-600 hover:text-gray-900">
                Ver diagnóstico completo (JSON)
              </summary>
              <pre className="mt-2 p-4 bg-gray-900 text-green-400 rounded text-xs overflow-auto max-h-96">
                {JSON.stringify(diagnosticoCompleto, null, 2)}
              </pre>
            </details>
          </div>
        </div>
      )}

      {todosUsuarios && (
        <div className="mt-6 p-6 bg-indigo-50 rounded-lg border-2 border-indigo-200">
          <h3 className="mb-4 text-indigo-900">👥 Análisis COMPLETO de Usuarios Reales</h3>
          
          {todosUsuarios.comparacion && (
            <div className="mb-6 p-4 bg-white rounded-lg border-2 border-indigo-300">
              <h4 className="mb-3">⚖️ Comparación: Caché vs KV Store</h4>
              <div className="grid grid-cols-3 gap-4">
                <div className="p-3 bg-blue-50 rounded">
                  <p className="text-sm text-gray-600">Usuarios en Caché:</p>
                  <p className="text-2xl text-blue-600">{todosUsuarios.comparacion.usuariosEnCache}</p>
                </div>
                <div className="p-3 bg-green-50 rounded">
                  <p className="text-sm text-gray-600">Usuarios en KV Store:</p>
                  <p className="text-2xl text-green-600">{todosUsuarios.comparacion.usuariosEnKVStore}</p>
                </div>
                <div className="p-3 bg-yellow-50 rounded">
                  <p className="text-sm text-gray-600">Diferencia:</p>
                  <p className="text-2xl text-yellow-600">{todosUsuarios.comparacion.diferencia}</p>
                </div>
              </div>
              <p className="mt-3 text-center">{todosUsuarios.comparacion.mensaje}</p>
            </div>
          )}
          
          {todosUsuarios.resumen && (
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="p-4 bg-white rounded border border-indigo-300">
                <p className="text-sm text-gray-600">Total Usuarios Reales:</p>
                <p className="text-3xl text-indigo-600">{todosUsuarios.resumen.totalUsuariosReales}</p>
              </div>
              
              <div className="p-4 bg-white rounded border border-green-300">
                <p className="text-sm text-gray-600">Con referidoPor:</p>
                <p className="text-2xl text-green-600">{todosUsuarios.resumen.conReferidoPor}</p>
              </div>
              
              <div className="p-4 bg-white rounded border border-red-300">
                <p className="text-sm text-gray-600">SIN referidoPor:</p>
                <p className="text-2xl text-red-600">{todosUsuarios.resumen.sinReferidoPor}</p>
              </div>
              
              <div className="p-4 bg-white rounded border border-yellow-300">
                <p className="text-sm text-gray-600">% Sin Referido:</p>
                <p className="text-2xl text-yellow-600">{todosUsuarios.resumen.porcentajeSinReferido}</p>
              </div>
            </div>
          )}
          
          {todosUsuarios.keysAnalizadas && (
            <div className="p-4 bg-white rounded border border-indigo-200 mb-6">
              <h4 className="mb-3">🔑 Análisis de Keys</h4>
              <p className="text-sm"><strong>Total Keys Analizadas:</strong> {todosUsuarios.keysAnalizadas.totalKeys}</p>
              <p className="text-sm"><strong>Usuarios Reales (user:uuid):</strong> {todosUsuarios.keysAnalizadas.usuariosReales}</p>
              {todosUsuarios.keysAnalizadas.keysDescartadas && (
                <div className="mt-3 text-sm">
                  <p><strong>Keys Descartadas:</strong></p>
                  <ul className="ml-4 list-disc">
                    <li>Índices (user:email:, user:idUnico:): {todosUsuarios.keysAnalizadas.keysDescartadas.indices}</li>
                    <li>Comisiones anidadas: {todosUsuarios.keysAnalizadas.keysDescartadas.comisiones}</li>
                    <li>Rendimientos: {todosUsuarios.keysAnalizadas.keysDescartadas.rendimientos}</li>
                    <li>Otros: {todosUsuarios.keysAnalizadas.keysDescartadas.otros}</li>
                  </ul>
                </div>
              )}
            </div>
          )}
          
          {todosUsuarios.muestraUsuarios && todosUsuarios.muestraUsuarios.length > 0 && (
            <details className="mb-4">
              <summary className="cursor-pointer text-sm text-gray-700 hover:text-gray-900">
                Ver muestra de usuarios (5 primeros)
              </summary>
              <div className="mt-3 space-y-2">
                {todosUsuarios.muestraUsuarios.map((u: any, i: number) => (
                  <div key={i} className="p-3 bg-white rounded border text-sm">
                    <p><strong>{u.nombre}</strong> - {u.email}</p>
                    <p className="text-xs text-gray-600">ID: {u.id} | Ref: {u.referidoPor}</p>
                  </div>
                ))}
              </div>
            </details>
          )}
          
          {todosUsuarios.usuariosSinReferido && todosUsuarios.usuariosSinReferido.length > 0 && (
            <div className="p-4 bg-red-50 rounded border-2 border-red-300">
              <h4 className="mb-3 text-red-900">🚨 Usuarios SIN campo referidoPor ({todosUsuarios.usuariosSinReferido.length})</h4>
              <div className="space-y-2 max-h-64 overflow-auto">
                {todosUsuarios.usuariosSinReferido.map((u: any, i: number) => (
                  <div key={i} className="p-2 bg-white rounded text-sm">
                    <p><strong>{u.nombre}</strong></p>
                    <p className="text-xs text-gray-600">{u.email} | {u.idUnico}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          <details className="mt-4">
            <summary className="cursor-pointer text-sm text-gray-600 hover:text-gray-900">
              Ver JSON completo
            </summary>
            <pre className="mt-2 p-4 bg-gray-900 text-green-400 rounded text-xs overflow-auto max-h-96">
              {JSON.stringify(todosUsuarios, null, 2)}
            </pre>
          </details>
        </div>
      )}

      {diagnosticoIsrael && (
        <div className="mt-6 p-6 bg-pink-50 rounded-lg border-2 border-pink-200">
          <h3 className="mb-4 text-pink-900">🚨 Diagnóstico de Israel Sandoval</h3>
          
          <div className="space-y-4">
            {diagnosticoIsrael.israel && (
              <div className="p-4 bg-white rounded border border-pink-300">
                <h4 className="mb-3">👤 Datos de Israel</h4>
                <p className="text-sm"><strong>Nombre:</strong> {diagnosticoIsrael.israel.nombre}</p>
                <p className="text-sm"><strong>Email:</strong> {diagnosticoIsrael.israel.email}</p>
                <p className="text-sm"><strong>ID Único:</strong> {diagnosticoIsrael.israel.id_unico}</p>
                <p className="text-sm"><strong>ID (UUID):</strong> {diagnosticoIsrael.israel.id}</p>
                <p className="text-sm"><strong>Referido por:</strong> {diagnosticoIsrael.israel.referidoPor || 'SIN REFERIDO (root)'}</p>
              </div>
            )}
            
            {diagnosticoIsrael.referidosDirectos && (
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-white rounded border">
                  <p className="text-sm text-gray-600">Total Referidos Directos:</p>
                  <p className="text-3xl text-blue-600">{diagnosticoIsrael.referidosDirectos.total}</p>
                </div>
                
                <div className="p-4 bg-green-50 rounded border border-green-300">
                  <p className="text-sm text-gray-600">Con Pack Activo:</p>
                  <p className="text-3xl text-green-600">{diagnosticoIsrael.referidosDirectos.conPackActivo}</p>
                </div>
                
                <div className="p-4 bg-gray-50 rounded border">
                  <p className="text-sm text-gray-600">Sin Pack:</p>
                  <p className="text-xl text-gray-600">{diagnosticoIsrael.referidosDirectos.sinPack}</p>
                </div>
                
                <div className="p-4 bg-yellow-50 rounded border border-yellow-300">
                  <p className="text-sm text-gray-600">Volumen Total:</p>
                  <p className="text-2xl text-yellow-600">${diagnosticoIsrael.referidosDirectos.volumenTotal?.toLocaleString()}</p>
                </div>
              </div>
            )}
            
            {diagnosticoIsrael.listaReferidos && diagnosticoIsrael.listaReferidos.length > 0 && (
              <div className="p-4 bg-white rounded border">
                <h4 className="mb-3">📋 Lista de Referidos Directos ({diagnosticoIsrael.listaReferidos.length})</h4>
                <div className="max-h-96 overflow-auto space-y-2">
                  {diagnosticoIsrael.listaReferidos.map((ref: any, i: number) => (
                    <div key={i} className={`p-3 rounded text-sm ${ref.tienePackActivo ? 'bg-green-50 border border-green-300' : 'bg-gray-50'}`}>
                      <p className=""><strong>{ref.nombre} {ref.apellido}</strong> {ref.tienePackActivo && '✅'}</p>
                      <p className="text-xs text-gray-600">
                        {ref.email} | {ref.id_unico}
                      </p>
                      <p className="text-xs text-gray-600">
                        Pack: {ref.packActivo?.nombre || 'Sin Pack'} | Inversión: ${ref.inversionTotal?.toLocaleString()}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            {diagnosticoIsrael.mensaje && (
              <div className="p-4 bg-pink-100 rounded border border-pink-300">
                <p className="text-pink-900">{diagnosticoIsrael.mensaje}</p>
              </div>
            )}

            <details className="mt-4">
              <summary className="cursor-pointer text-sm text-gray-600 hover:text-gray-900">
                Ver JSON completo
              </summary>
              <pre className="mt-2 p-4 bg-gray-900 text-green-400 rounded text-xs overflow-auto max-h-96">
                {JSON.stringify(diagnosticoIsrael, null, 2)}
              </pre>
            </details>
          </div>
        </div>
      )}

      {diagnosticoIsraelJorge && (
        <div className="mt-6 p-6 bg-red-50 rounded-lg border-2 border-red-400">
          <h3 className="mb-4 text-red-900">🚨 DIAGNÓSTICO: Conexión Israel → Jorge</h3>
          
          <div className="space-y-4">
            {diagnosticoIsraelJorge.israel && (
              <div className="p-4 bg-white rounded border border-blue-300">
                <h4 className="mb-3 text-blue-900">👤 ISRAEL</h4>
                <p className="text-sm"><strong>Nombre:</strong> {diagnosticoIsraelJorge.israel.nombre}</p>
                <p className="text-sm"><strong>ID Único:</strong> {diagnosticoIsraelJorge.israel.id_unico}</p>
                <p className="text-sm"><strong>UUID:</strong> {diagnosticoIsraelJorge.israel.id_completo}</p>
                <p className="text-sm"><strong>Referido por:</strong> {diagnosticoIsraelJorge.israel.referidoPor || 'ROOT'}</p>
                <p className="text-sm"><strong>Tiene matriz:</strong> {diagnosticoIsraelJorge.israel.tieneMatriz ? '✅ SÍ' : '❌ NO'}</p>
              </div>
            )}
            
            <div className="grid grid-cols-2 gap-4">
              <div className={`p-4 rounded border-2 ${diagnosticoIsraelJorge.jorgeEnKVStore?.encontrado ? 'bg-green-50 border-green-400' : 'bg-red-100 border-red-400'}`}>
                <h4 className="mb-3">📦 Jorge en KV Store</h4>
                <p className="text-sm">
                  <strong>Encontrado:</strong> {diagnosticoIsraelJorge.jorgeEnKVStore?.encontrado ? '✅ SÍ' : '❌ NO'}
                </p>
                {diagnosticoIsraelJorge.jorgeEnKVStore?.datos && (
                  <div className="mt-2 text-xs">
                    <p><strong>Nombre:</strong> {diagnosticoIsraelJorge.jorgeEnKVStore.datos.nombre}</p>
                    <p><strong>ID:</strong> {diagnosticoIsraelJorge.jorgeEnKVStore.datos.id_unico}</p>
                    <p><strong>Ref:</strong> {diagnosticoIsraelJorge.jorgeEnKVStore.datos.referidoPor || 'SIN REFERIDO'}</p>
                  </div>
                )}
              </div>
              
              <div className={`p-4 rounded border-2 ${diagnosticoIsraelJorge.jorgeEnMatrizDeIsrael?.encontrado ? 'bg-green-50 border-green-400' : 'bg-gray-100 border-gray-400'}`}>
                <h4 className="mb-3">🗺️ Jorge en Matriz de Israel</h4>
                <p className="text-sm">
                  <strong>Encontrado:</strong> {diagnosticoIsraelJorge.jorgeEnMatrizDeIsrael?.encontrado ? '✅ SÍ' : '❌ NO'}
                </p>
                {diagnosticoIsraelJorge.jorgeEnMatrizDeIsrael?.datos && (
                  <div className="mt-2 text-xs">
                    <pre className="bg-white p-2 rounded overflow-auto">
                      {JSON.stringify(diagnosticoIsraelJorge.jorgeEnMatrizDeIsrael.datos, null, 2)}
                    </pre>
                  </div>
                )}
              </div>
            </div>
            
            {diagnosticoIsraelJorge.todosLosJorges && diagnosticoIsraelJorge.todosLosJorges.length > 0 && (
              <div className="p-4 bg-yellow-50 rounded border border-yellow-300">
                <h4 className="mb-3">🔍 Todos los usuarios con "Jorge" ({diagnosticoIsraelJorge.todosLosJorges.length})</h4>
                <div className="space-y-2">
                  {diagnosticoIsraelJorge.todosLosJorges.map((j: any, i: number) => (
                    <div key={i} className="p-2 bg-white rounded text-xs">
                      <p><strong>{j.nombre} {j.apellido}</strong> - {j.email}</p>
                      <p className="text-gray-600">ID: {j.id_unico} | Ref: {j.referidoPor || 'SIN REFERIDO'}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            {diagnosticoIsraelJorge.analisis && (
              <div className="grid grid-cols-3 gap-4">
                <div className="p-4 bg-blue-50 rounded border border-blue-300">
                  <p className="text-sm text-gray-600">Referidos Directos de Israel:</p>
                  <p className="text-3xl text-blue-600">{diagnosticoIsraelJorge.analisis.referidosDirectosDeIsrael}</p>
                </div>
                
                <div className="p-4 bg-green-50 rounded border border-green-300">
                  <p className="text-sm text-gray-600">Hijos de Jorge:</p>
                  <p className="text-3xl text-green-600">{diagnosticoIsraelJorge.analisis.hijosDeJorge}</p>
                </div>
                
                <div className={`p-4 rounded border-2 ${diagnosticoIsraelJorge.analisis.jorgeApuntaAIsrael ? 'bg-green-50 border-green-400' : 'bg-red-100 border-red-400'}`}>
                  <p className="text-sm text-gray-600">¿Jorge → Israel?</p>
                  <p className="text-2xl">{diagnosticoIsraelJorge.analisis.jorgeApuntaAIsrael ? '✅ SÍ' : '❌ NO'}</p>
                </div>
              </div>
            )}
            
            {diagnosticoIsraelJorge.diagnostico && (
              <div className={`p-4 rounded border-2 ${
                diagnosticoIsraelJorge.diagnostico.includes('✅') 
                  ? 'bg-green-100 border-green-400' 
                  : diagnosticoIsraelJorge.diagnostico.includes('⚠️')
                  ? 'bg-yellow-100 border-yellow-400'
                  : 'bg-red-100 border-red-400'
              }`}>
                <h4 className="mb-2">📋 Diagnóstico:</h4>
                <p className="text-sm">{diagnosticoIsraelJorge.diagnostico}</p>
              </div>
            )}
            
            {diagnosticoIsraelJorge.solucion && (
              <div className="p-4 bg-purple-100 rounded border-2 border-purple-400">
                <h4 className="mb-2 text-purple-900">💡 Solución:</h4>
                <p className="text-sm text-purple-900">{diagnosticoIsraelJorge.solucion}</p>
              </div>
            )}

            <details className="mt-4">
              <summary className="cursor-pointer text-sm text-gray-600 hover:text-gray-900">
                Ver JSON completo
              </summary>
              <pre className="mt-2 p-4 bg-gray-900 text-green-400 rounded text-xs overflow-auto max-h-96">
                {JSON.stringify(diagnosticoIsraelJorge, null, 2)}
              </pre>
            </details>
          </div>
        </div>
      )}

      {diagnosticoPacksJorge && (
        <div className="mt-6 p-6 bg-pink-50 rounded-lg border-2 border-pink-200">
          <h3 className="mb-4 text-pink-900">🚨 Diagnóstico de Packs de Jorge</h3>
          
          <div className="space-y-4">
            {diagnosticoPacksJorge.resumen && (
              <div className="grid grid-cols-3 gap-4">
                <div className="p-4 bg-white rounded border">
                  <p className="text-sm text-gray-600">Total Packs:</p>
                  <p className="text-3xl text-blue-600">{diagnosticoPacksJorge.resumen.totalPacks}</p>
                </div>
                
                <div className="p-4 bg-green-50 rounded border border-green-300">
                  <p className="text-sm text-gray-600">Packs Activos:</p>
                  <p className="text-3xl text-green-600">{diagnosticoPacksJorge.resumen.packsActivos}</p>
                </div>
                
                <div className="p-4 bg-gray-50 rounded border">
                  <p className="text-sm text-gray-600">Packs Inactivos:</p>
                  <p className="text-xl text-gray-600">{diagnosticoPacksJorge.resumen.packsInactivos}</p>
                </div>
                
                <div className="p-4 bg-yellow-50 rounded border border-yellow-300">
                  <p className="text-sm text-gray-600">Volumen Total:</p>
                  <p className="text-2xl text-yellow-600">${diagnosticoPacksJorge.resumen.volumenTotal?.toLocaleString()}</p>
                </div>
              </div>
            )}
            
            {diagnosticoPacksJorge.listaPacks && diagnosticoPacksJorge.listaPacks.length > 0 && (
              <div className="p-4 bg-white rounded border">
                <h4 className="mb-3">📋 Lista de Packs ({diagnosticoPacksJorge.listaPacks.length})</h4>
                <div className="max-h-96 overflow-auto space-y-2">
                  {diagnosticoPacksJorge.listaPacks.map((pack: any, i: number) => (
                    <div key={i} className={`p-3 rounded text-sm ${pack.activo ? 'bg-green-50 border border-green-300' : 'bg-gray-50'}`}>
                      <p className=""><strong>{pack.nombre}</strong> {pack.activo && '✅'}</p>
                      <p className="text-xs text-gray-600">
                        ID: {pack.id} | Inversión: ${pack.inversionTotal?.toLocaleString()}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            {diagnosticoPacksJorge.mensaje && (
              <div className="p-4 bg-pink-100 rounded border border-pink-300">
                <p className="text-pink-900">{diagnosticoPacksJorge.mensaje}</p>
              </div>
            )}

            <details className="mt-4">
              <summary className="cursor-pointer text-sm text-gray-600 hover:text-gray-900">
                Ver JSON completo
              </summary>
              <pre className="mt-2 p-4 bg-gray-900 text-green-400 rounded text-xs overflow-auto max-h-96">
                {JSON.stringify(diagnosticoPacksJorge, null, 2)}
              </pre>
            </details>
          </div>
        </div>
      )}

      {diagnosticoDashboardIsrael && (
        <div className="mt-6 p-6 bg-indigo-50 rounded-lg border-2 border-indigo-200">
          <h3 className="mb-4 text-indigo-900">🎯 Simulación: Dashboard de Israel</h3>
          
          <div className="space-y-4">
            {diagnosticoDashboardIsrael.resumenCache && (
              <div className="p-4 bg-white rounded border border-indigo-300">
                <h4 className="mb-3">📊 Estado del Caché</h4>
                <div className="grid grid-cols-3 gap-3">
                  <div className="p-3 bg-blue-50 rounded">
                    <p className="text-sm text-gray-600">Usuarios en Caché:</p>
                    <p className="text-2xl text-blue-600">{diagnosticoDashboardIsrael.resumenCache.totalUsuariosEnCache}</p>
                  </div>
                  <div className="p-3 bg-green-50 rounded">
                    <p className="text-sm text-gray-600">Packs en Caché:</p>
                    <p className="text-2xl text-green-600">{diagnosticoDashboardIsrael.resumenCache.totalPacksEnCache}</p>
                  </div>
                  <div className="p-3 bg-yellow-50 rounded">
                    <p className="text-sm text-gray-600">Antigüedad del Caché:</p>
                    <p className="text-xl text-yellow-600">{diagnosticoDashboardIsrael.resumenCache.cacheAgeHumano}</p>
                  </div>
                </div>
              </div>
            )}
            
            <div className="grid grid-cols-2 gap-4">
              {diagnosticoDashboardIsrael.israel && (
                <div className="p-4 bg-white rounded border border-blue-300">
                  <h4 className="mb-3 text-blue-900">👤 Israel en Caché</h4>
                  <p className="text-sm"><strong>Nombre:</strong> {diagnosticoDashboardIsrael.israel.nombre}</p>
                  <p className="text-sm"><strong>ID:</strong> {diagnosticoDashboardIsrael.israel.id_unico}</p>
                  <p className="text-sm"><strong>Referido por:</strong> {diagnosticoDashboardIsrael.israel.referidoPor || 'ROOT'}</p>
                </div>
              )}
              
              {diagnosticoDashboardIsrael.jorge && (
                <div className={`p-4 rounded border-2 ${diagnosticoDashboardIsrael.jorge.encontrado !== false ? 'bg-green-50 border-green-400' : 'bg-red-100 border-red-400'}`}>
                  <h4 className="mb-3">👤 Jorge en Caché</h4>
                  {diagnosticoDashboardIsrael.jorge.encontrado !== false ? (
                    <>
                      <p className="text-sm"><strong>Nombre:</strong> {diagnosticoDashboardIsrael.jorge.nombre}</p>
                      <p className="text-sm"><strong>ID:</strong> {diagnosticoDashboardIsrael.jorge.id_unico}</p>
                      <p className="text-sm"><strong>Referido por:</strong> {diagnosticoDashboardIsrael.jorge.referidoPor}</p>
                      <p className="text-sm mt-2">
                        <strong>En referidos directos:</strong> {diagnosticoDashboardIsrael.jorge.estaEnReferidosDirectos ? '✅ SÍ' : '❌ NO'}
                      </p>
                    </>
                  ) : (
                    <p className="text-sm text-red-700">❌ NO encontrado en caché</p>
                  )}
                </div>
              )}
            </div>
            
            {diagnosticoDashboardIsrael.referidosDirectos && (
              <div className={`p-4 rounded border-2 ${diagnosticoDashboardIsrael.referidosDirectos.total > 0 ? 'bg-green-50 border-green-400' : 'bg-red-100 border-red-400'}`}>
                <h4 className="mb-3">📊 Referidos Directos (lo que verá el dashboard)</h4>
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div className="p-3 bg-white rounded">
                    <p className="text-sm text-gray-600">Total Referidos Directos:</p>
                    <p className="text-3xl text-blue-600">{diagnosticoDashboardIsrael.referidosDirectos.total}</p>
                  </div>
                  <div className="p-3 bg-white rounded">
                    <p className="text-sm text-gray-600">Con Pack Activo:</p>
                    <p className="text-3xl text-green-600">{diagnosticoDashboardIsrael.referidosDirectos.conPack}</p>
                  </div>
                </div>
                
                {diagnosticoDashboardIsrael.referidosDirectos.lista.length > 0 && (
                  <div className="space-y-2 mt-4">
                    <h5 className="text-sm">Lista de Referidos:</h5>
                    {diagnosticoDashboardIsrael.referidosDirectos.lista.map((ref: any, i: number) => (
                      <div key={i} className={`p-2 bg-white rounded text-sm ${ref.tienePackActivo ? 'border-l-4 border-green-500' : ''}`}>
                        <p><strong>{ref.nombre} {ref.apellido}</strong> {ref.tienePackActivo && '✅'}</p>
                        <p className="text-xs text-gray-600">
                          {ref.id_unico} | Pack: {ref.pack}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
            
            {diagnosticoDashboardIsrael.diagnostico && (
              <div className={`p-4 rounded border-2 ${diagnosticoDashboardIsrael.diagnostico.includes('✅') ? 'bg-green-100 border-green-400' : 'bg-red-100 border-red-400'}`}>
                <h4 className="mb-2">📋 Diagnóstico:</h4>
                <p className="text-sm">{diagnosticoDashboardIsrael.diagnostico}</p>
              </div>
            )}
            
            {diagnosticoDashboardIsrael.solucion && (
              <div className="p-4 bg-yellow-100 rounded border-2 border-yellow-400">
                <h4 className="mb-2 text-yellow-900">💡 Solución:</h4>
                <p className="text-sm text-yellow-900">{diagnosticoDashboardIsrael.solucion}</p>
              </div>
            )}

            <details className="mt-4">
              <summary className="cursor-pointer text-sm text-gray-600 hover:text-gray-900">
                Ver JSON completo
              </summary>
              <pre className="mt-2 p-4 bg-gray-900 text-green-400 rounded text-xs overflow-auto max-h-96">
                {JSON.stringify(diagnosticoDashboardIsrael, null, 2)}
              </pre>
            </details>
          </div>
        </div>
      )}
    </div>
  );
}