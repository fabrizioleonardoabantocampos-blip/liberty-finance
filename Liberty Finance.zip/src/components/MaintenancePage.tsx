import { useEffect, useState } from 'react';
import { AlertTriangle, Clock, Wrench } from 'lucide-react';

export function MaintenancePage() {
  const [timeRemaining, setTimeRemaining] = useState('');

  useEffect(() => {
    const updateTimeRemaining = () => {
      const finMantenimiento = new Date('2025-12-21T04:30:00');
      const ahora = new Date();
      const diferencia = finMantenimiento.getTime() - ahora.getTime();

      if (diferencia > 0) {
        const horas = Math.floor(diferencia / (1000 * 60 * 60));
        const minutos = Math.floor((diferencia % (1000 * 60 * 60)) / (1000 * 60));
        const segundos = Math.floor((diferencia % (1000 * 60)) / 1000);
        
        setTimeRemaining(`${horas}h ${minutos}m ${segundos}s`);
      } else {
        // Si ya pasó la hora, recargar la página
        window.location.reload();
      }
    };

    updateTimeRemaining();
    const interval = setInterval(updateTimeRemaining, 1000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-500 via-red-500 to-orange-600 flex items-center justify-center p-4">
      <div className="max-w-2xl w-full bg-white rounded-2xl shadow-2xl p-8 md:p-12 text-center">
        {/* Logo o Icono */}
        <div className="flex justify-center mb-6">
          <div className="relative">
            <div className="absolute inset-0 bg-orange-500 blur-xl opacity-50 animate-pulse"></div>
            <div className="relative bg-gradient-to-br from-orange-500 to-red-500 p-6 rounded-full">
              <Wrench className="h-16 w-16 text-white animate-bounce" />
            </div>
          </div>
        </div>

        {/* Título */}
        <h1 className="text-4xl md:text-5xl mb-4 text-gray-800">
          🔧 Mantenimiento en Progreso
        </h1>

        {/* Mensaje Principal */}
        <div className="bg-orange-50 border-2 border-orange-200 rounded-xl p-6 mb-6">
          <div className="flex items-center justify-center gap-2 mb-3">
            <AlertTriangle className="h-6 w-6 text-orange-500" />
            <h2 className="text-xl text-orange-700">
              LIBERTY FINANCE
            </h2>
          </div>
          <p className="text-gray-700 text-lg leading-relaxed">
            Estamos realizando tareas de mantenimiento programado para mejorar tu experiencia.
          </p>
        </div>

        {/* Horario */}
        <div className="bg-gradient-to-r from-red-50 to-orange-50 rounded-xl p-6 mb-6">
          <div className="flex items-center justify-center gap-2 mb-2">
            <Clock className="h-5 w-5 text-red-500" />
            <p className="text-gray-600">Horario de Mantenimiento</p>
          </div>
          <p className="text-2xl text-gray-800 mb-2">
            00:30 - 4:30 AM
          </p>
          <p className="text-gray-600">20 de Diciembre del 2025</p>
        </div>

        {/* Contador */}
        {timeRemaining && (
          <div className="bg-gradient-to-br from-orange-100 to-red-100 rounded-xl p-6 mb-6">
            <p className="text-gray-600 mb-2">Tiempo restante estimado</p>
            <p className="text-4xl text-orange-600 font-mono">
              {timeRemaining}
            </p>
          </div>
        )}

        {/* Mensaje de Agradecimiento */}
        <div className="border-t-2 border-gray-200 pt-6">
          <p className="text-gray-600 text-lg">
            Gracias por tu paciencia. Volveremos pronto con mejoras para ti.
          </p>
          <p className="text-gray-500 mt-3">
            Esta página se actualizará automáticamente cuando finalice el mantenimiento.
          </p>
        </div>

        {/* Animación decorativa */}
        <div className="flex justify-center gap-2 mt-8">
          <div className="w-3 h-3 bg-orange-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
          <div className="w-3 h-3 bg-red-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
          <div className="w-3 h-3 bg-orange-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
        </div>
      </div>
    </div>
  );
}