import { AlertTriangle, X } from 'lucide-react';
import { useState, useEffect } from 'react';

export function MaintenanceBanner() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Fecha y hora de fin del mantenimiento: 20 de diciembre de 2025 a las 4:30 AM
    const finMantenimiento = new Date('2025-12-20T04:30:00');
    const ahora = new Date();

    // Mostrar el banner solo si aún no ha pasado la hora de fin
    if (ahora < finMantenimiento) {
      setIsVisible(true);
    } else {
      setIsVisible(false);
    }
  }, []);

  if (!isVisible) return null;

  return (
    <div className="fixed top-0 left-0 right-0 z-50 bg-gradient-to-r from-orange-500 via-red-500 to-orange-500 text-white shadow-lg">
      <div className="max-w-7xl mx-auto px-4 py-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-3 flex-1">
            <AlertTriangle className="h-6 w-6 flex-shrink-0 animate-pulse" />
            <div className="flex-1">
              <p className="text-sm sm:text-base">
                <span className="font-bold">⚠️ MANTENIMIENTO PROGRAMADO:</span>
                {' '}La plataforma de LIBERTY FINANCE se encuentra en mantenimiento de{' '}
                <span className="font-bold">00:30 hasta las 4:30 del 20 de diciembre del 2025</span>
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsVisible(false)}
            className="flex-shrink-0 p-1 rounded-md hover:bg-white/20 transition-colors"
            aria-label="Cerrar banner"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
      </div>
    </div>
  );
}