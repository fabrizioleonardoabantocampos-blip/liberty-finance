import { useState, useEffect } from 'react';
import { TrendingUp, Globe, Zap, DollarSign, Users } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { ImageWithFallback } from '../figma/ImageWithFallback';

const slides = [
  {
    title: "Libertad Financiera",
    subtitle: "Gana mientras duermes",
    description: "Con transparencia y en exchanges reconocidos.",
    image: "https://images.unsplash.com/photo-1635231152717-ec0ae1906271?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYXNzaXZlJTIwaW5jb21lJTIwaW52ZXN0bWVudHxlbnwxfHx8fDE3NjMyMzYwMzF8MA&ixlib=rb-4.1.0&q=80&w=1080",
    icon: DollarSign,
    gradient: "from-emerald-500 to-teal-600"
  },
  {
    title: "Viaja por el Mundo",
    subtitle: "Vive la vida que mereces",
    description: "Gana en USDT mientras exploras nuevos destinos.",
    image: "https://images.unsplash.com/photo-1614505241347-7f4765c1035e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjB0cmF2ZWwlMjBiZWFjaHxlbnwxfHx8fDE3NjMyMzYwMjl8MA&ixlib=rb-4.1.0&q=80&w=1080",
    icon: Globe,
    gradient: "from-blue-500 to-cyan-600"
  },
  {
    title: "Tecnología de Punta",
    subtitle: "Inversiones inteligentes",
    description: "Opera con la herramienta digital que utiliza IA.",
    image: "https://images.unsplash.com/photo-1642115958417-b67f56baf0d6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaW5hbmNpYWwlMjB0ZWNobm9sb2d5JTIwY3J5cHRvfGVufDF8fHx8MTc2MzIzNjAyOXww&ixlib=rb-4.1.0&q=80&w=1080",
    icon: Zap,
    gradient: "from-purple-500 to-pink-600"
  },
  {
    title: "Construye tu Red",
    subtitle: "Crece exponencialmente",
    description: "Sistema multinivel 3x3 con 10 niveles de comisiones.",
    image: "https://images.unsplash.com/photo-1543269664-7eef42226a21?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMHN1Y2Nlc3MlMjBsYXB0b3B8ZW58MXx8fHwxNzYzMjM2MDMwfDA&ixlib=rb-4.1.0&q=80&w=1080",
    icon: Users,
    gradient: "from-orange-500 to-red-600"
  }
];

export function LifestyleShowcase() {
  const [currentSlide, setCurrentSlide] = useState(0);

  // Auto-rotate slides
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const slide = slides[currentSlide];
  const Icon = slide.icon;

  return (
    <section className="pt-32 pb-20 bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute inset-0 bg-grid-slate-700 [mask-image:linear-gradient(0deg,transparent,rgba(255,255,255,0.6))] opacity-20" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[800px] bg-blue-600/20 rounded-full blur-3xl" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30 mb-6"
          >
            <TrendingUp className="w-4 h-4" />
            <span className="text-sm">Tu Futuro Comienza Aquí</span>
          </motion.div>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-5xl md:text-6xl text-white mb-6"
          >
            El Estilo de Vida que Mereces
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-xl text-blue-100 max-w-3xl mx-auto"
          >
            Únete a miles de personas que ya están generando ingresos pasivos con tecnología blockchain
          </motion.p>
        </div>

        {/* Interactive Carousel - Full Width */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3 }}
          className="relative max-w-5xl mx-auto"
        >
          <div className="relative rounded-3xl overflow-hidden shadow-2xl aspect-[16/9] md:aspect-[21/9]">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentSlide}
                initial={{ opacity: 0, scale: 1.1 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.7 }}
                className="absolute inset-0"
              >
                <ImageWithFallback
                  src={slide.image}
                  alt={slide.title}
                  className="w-full h-full object-cover"
                />
                
                {/* Gradient Overlay */}
                <div className={`absolute inset-0 bg-gradient-to-tr ${slide.gradient} opacity-75`} />
                
                {/* Content */}
                <div className="absolute inset-0 flex flex-col justify-end p-8 md:p-12 text-white">
                  <motion.div
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 }}
                    className="flex items-center gap-4 mb-6"
                  >
                    <div className="p-4 rounded-2xl bg-white/20 backdrop-blur-sm">
                      <Icon className="w-8 h-8" />
                    </div>
                    <div>
                      <div className="text-base md:text-lg opacity-90 mb-1">{slide.subtitle}</div>
                      <h3 className="text-4xl md:text-5xl">{slide.title}</h3>
                    </div>
                  </motion.div>
                  <motion.p
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.4 }}
                    className="text-lg md:text-xl opacity-90 max-w-2xl"
                  >
                    {slide.description}
                  </motion.p>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Slide Indicators */}
          <div className="flex justify-center gap-3 mt-8">
            {slides.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`h-2 rounded-full transition-all duration-300 ${
                  index === currentSlide
                    ? 'w-12 bg-blue-500'
                    : 'w-2 bg-slate-600 hover:bg-slate-500'
                }`}
                aria-label={`Ir a slide ${index + 1}`}
              />
            ))}
          </div>
        </motion.div>

        {/* Benefits Grid */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.4 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6 mt-16 max-w-4xl mx-auto"
        >
          {[
            { icon: "🚀", text: "Inicio desde $50", description: "Accesible para todos" },
            { icon: "🔒", text: "100% Seguro", description: "Tecnología blockchain" },
            { icon: "⚡", text: "Retiros Rápidos", description: "Procesamiento inmediato" },
            { icon: "🌍", text: "Global 24/7", description: "Opera desde cualquier lugar" }
          ].map((benefit, index) => (
            <motion.div
              key={benefit.text}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.5 + index * 0.1 }}
              whileHover={{ scale: 1.05, y: -5 }}
              className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20 hover:bg-white/15 transition-all cursor-pointer"
            >
              <div className="text-4xl mb-3">{benefit.icon}</div>
              <div className="text-white mb-1">{benefit.text}</div>
              <div className="text-sm text-blue-200">{benefit.description}</div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}