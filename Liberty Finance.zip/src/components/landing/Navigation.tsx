import { useState } from 'react';
import { Button } from '../ui/button';
import { Menu, X, LogIn } from 'lucide-react';
import logoImage from 'figma:asset/ae011bd8c8ee731107978c5fe892f24a22d34163.png';

interface NavigationProps {
  onLoginClick: () => void;
}

export function Navigation({ onLoginClick }: NavigationProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const menuItems = [
    { label: 'Inicio', href: '#inicio' },
    { label: 'Funcionamiento', href: '#funcionamiento' },
    { label: 'Productos', href: '#productos' },
    { label: 'Comisiones', href: '#comisiones' }
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-slate-950/95 backdrop-blur-lg border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <div className="flex-shrink-0 flex items-center gap-3">
            <img 
              src={logoImage} 
              alt="Liberty Finance" 
              className="h-12 w-auto"
            />
            <span className="text-white text-2xl">Liberty Finance</span>
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center gap-8">
            {menuItems.map((item) => (
              <a
                key={item.href}
                href={item.href}
                className="text-slate-300 hover:text-white transition-colors"
              >
                {item.label}
              </a>
            ))}
          </div>

          {/* Login Button - Desktop */}
          <div className="hidden md:block">
            <Button
              onClick={onLoginClick}
              className="bg-blue-600 hover:bg-blue-700 text-white rounded-xl shadow-lg"
            >
              <LogIn className="w-4 h-4 mr-2" />
              Iniciar Sesión
            </Button>
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden text-white p-2"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-slate-900 border-t border-slate-800">
          <div className="px-4 py-6 space-y-4">
            {menuItems.map((item) => (
              <a
                key={item.href}
                href={item.href}
                onClick={() => setMobileMenuOpen(false)}
                className="block text-slate-300 hover:text-white transition-colors py-2"
              >
                {item.label}
              </a>
            ))}
            <Button
              onClick={() => {
                setMobileMenuOpen(false);
                onLoginClick();
              }}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white rounded-xl shadow-lg"
            >
              <LogIn className="w-4 h-4 mr-2" />
              Iniciar Sesión
            </Button>
          </div>
        </div>
      )}
    </nav>
  );
}