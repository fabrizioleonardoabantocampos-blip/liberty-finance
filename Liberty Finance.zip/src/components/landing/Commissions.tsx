import { Card } from '../ui/card';

export function Commissions() {
  return (
    <section id="comisiones" className="py-20 bg-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl text-white mb-4">
            Sistema de Comisiones
          </h2>
          <p className="text-xl text-slate-300 max-w-3xl mx-auto">
            Genera ingresos con nuestro sistema de matriz 3x3. Cuanto más crece tu red, más ganas.
          </p>
        </div>

        {/* Bono de Patrocinio */}
        <Card className="p-8 bg-gradient-to-br from-green-600 to-emerald-600 border-0 shadow-xl text-white">
          <div className="text-center">
            <h3 className="text-3xl mb-4">🎁 Bono de Patrocinio (10%)</h3>
            <p className="text-xl text-white/90 mb-4">
              Recibe un bono del 10% cuando alguien se registra con tu código o link de referido
            </p>
            <p className="text-white/80 max-w-3xl mx-auto">
              Este bono se activa automáticamente cuando un nuevo usuario se registra utilizando tu código o enlace de referido único y realiza una inversión en cualquier paquete. El 10% de su inversión se acredita inmediatamente como bono de patrocinio.
            </p>
          </div>
        </Card>

        {/* Multinivel Info */}
        <Card className="mt-8 p-8 bg-gradient-to-br from-blue-600 to-cyan-500 border-0 shadow-xl text-white">
          <div className="text-center">
            <h3 className="text-3xl mb-4">🌐 Sistema de Matriz 3x3 (10 Niveles)</h3>
            <p className="text-xl text-white/90 mb-6">
              Gana comisiones de hasta 10 niveles de profundidad en tu red
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
                <p className="text-2xl mb-1">8%</p>
                <p className="text-sm text-white/80">Nivel 1</p>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
                <p className="text-2xl mb-1">6%</p>
                <p className="text-sm text-white/80">Nivel 2</p>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
                <p className="text-2xl mb-1">4%</p>
                <p className="text-sm text-white/80">Nivel 3</p>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
                <p className="text-2xl mb-1">2%</p>
                <p className="text-sm text-white/80">Nivel 4</p>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-md mx-auto mt-4">
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
                <p className="text-2xl mb-1">1%</p>
                <p className="text-sm text-white/80">Niveles 5-8</p>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
                <p className="text-2xl mb-1">0.5%</p>
                <p className="text-sm text-white/80">Niveles 9-10</p>
              </div>
            </div>
          </div>
        </Card>

        {/* Additional Info */}
        <Card className="mt-8 p-6 bg-white border-0 shadow-xl">
          <div className="text-center">
            <h3 className="text-2xl text-slate-900 mb-4">💡 ¿Cómo Funciona?</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-left">
              <div>
                <div className="w-12 h-12 rounded-xl bg-blue-100 flex items-center justify-center mb-3">
                  <span className="text-2xl">1️⃣</span>
                </div>
                <h4 className="text-slate-900 mb-2">Invierte en tu Pack</h4>
                <p className="text-slate-600 text-sm">
                  Elige el paquete que mejor se adapte a tus objetivos financieros
                </p>
              </div>
              <div>
                <div className="w-12 h-12 rounded-xl bg-blue-100 flex items-center justify-center mb-3">
                  <span className="text-2xl">2️⃣</span>
                </div>
                <h4 className="text-slate-900 mb-2">Comparte tu Referido</h4>
                <p className="text-slate-600 text-sm">
                  Invita a más personas a unirse usando tu código de referido único
                </p>
              </div>
              <div>
                <div className="w-12 h-12 rounded-xl bg-blue-100 flex items-center justify-center mb-3">
                  <span className="text-2xl">3️⃣</span>
                </div>
                <h4 className="text-slate-900 mb-2">Gana Comisiones</h4>
                <p className="text-slate-600 text-sm">
                  Recibe comisiones automáticas por 10 niveles de profundidad en tu red
                </p>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </section>
  );
}