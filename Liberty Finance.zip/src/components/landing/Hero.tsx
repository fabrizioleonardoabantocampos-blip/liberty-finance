import { useState, useEffect } from 'react';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Checkbox } from '../ui/checkbox';
import { ArrowRight, Check } from 'lucide-react';
import { useCustomDialog } from '../CustomDialog';
import { TerminosCondiciones } from '../TerminosCondiciones';
import { callServer } from '../../utils/api';
import { useCountdown } from '../shared/CountdownTimer';

interface HeroProps {
  onLoginClick: () => void;
}

export function Hero({ onLoginClick }: HeroProps) {
  const { showError, showSuccess, DialogComponent } = useCustomDialog();
  
  // Usar el hook compartido de cuenta regresiva para sincronizar con UserHome
  const timeLeft = useCountdown();

  const [formData, setFormData] = useState({
    nombre: '',
    apellido: '',
    pais: '',
    telefono: '',
    correo: '',
    patrocinador: '',
    usuario: '',
    password: '',
    confirmPassword: '',
    acceptTerms: false
  });

  const [showTerminos, setShowTerminos] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    
    // Auto-generar usuario cuando se ingresa teléfono
    if (field === 'telefono' && typeof value === 'string' && value.length >= 5) {
      const userId = `RMN${value.substring(0, 5)}`;
      setFormData(prev => ({ ...prev, usuario: userId }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.acceptTerms) {
      showError('Debes aceptar los términos y condiciones');
      return;
    }
    
    if (formData.password !== formData.confirmPassword) {
      showError('Las contraseñas no coinciden');
      return;
    }

    if (formData.password.length < 6) {
      showError('La contraseña debe tener al menos 6 caracteres');
      return;
    }

    setIsSubmitting(true);
    try {
      // Preparar datos para el registro en el formato esperado por el backend
      const registerData = {
        nombre: formData.nombre,
        apellido: formData.apellido,
        email: formData.correo,
        telefono: formData.telefono,
        ciudad: formData.pais, // Usamos país como ciudad
        password: formData.password,
        referralCode: formData.usuario, // Código de referido del nuevo usuario
        referidoPor: formData.patrocinador || undefined, // Código del patrocinador
        wallet: '' // Vacío por ahora
      };

      const response = await callServer('/auth/register', 'POST', registerData);
      
      if (response.success) {
        // Limpiar formulario
        setFormData({
          nombre: '',
          apellido: '',
          pais: '',
          telefono: '',
          correo: '',
          patrocinador: '',
          usuario: '',
          password: '',
          confirmPassword: '',
          acceptTerms: false
        });

        showSuccess(
          `¡Registro exitoso! 🎉\n\n` +
          `✅ Ya puedes iniciar sesión con:\n` +
          `📧 Email: ${formData.correo}\n` +
          `🔑 Contraseña: ${formData.password}\n\n` +
          `Tu código de referido: ${response.user.id_unico}\n\n` +
          `Comparte tu link:\n` +
          `https://libertyfinance.life?ref=${response.user.id_unico}`
        );

        // Esperar 3 segundos y redirigir al login
        setTimeout(() => {
          onLoginClick();
        }, 3000);
      } else {
        showError(response.error || 'Error al procesar el registro');
      }
    } catch (error: any) {
      console.error('Error en registro:', error);
      showError(error.message || 'Error al procesar el registro');
    } finally {
      setIsSubmitting(false);
    }
  };

  const features = [
    'Productos Digitales Exclusivos',
    'Comunidad Global de Emprendedores',
    'Ingresos Residuales Constantes'
  ];

  return (
    <section id="inicio" className="min-h-screen bg-gradient-to-br from-slate-950 via-blue-950 to-slate-900 relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4wMyI+PHBhdGggZD0iTTM2IDM0djItMnpNNDQgMzR2Mi0yem0wLTEwdjItMnptMCA1djItMnoiLz48L2c+PC9nPjwvc3ZnPg==')] opacity-30"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left Column - Message */}
          <div className="text-white space-y-8">
            <div>
              <h1 className="text-5xl md:text-6xl mb-6">
                Posiciónate hoy y alcanza tu
                <span className="block text-blue-500 mt-2">
                  libertad financiera
                </span>
                con Liberty Finance
              </h1>
              <p className="text-xl text-slate-300">
                Únete a nuestra comunidad global de emprendedores y construye un 
                flujo de ingresos constante y escalable. ¡El momento es ahora!
              </p>
            </div>

            <div className="space-y-4">
              {features.map((feature, index) => (
                <div key={index} className="flex items-center gap-4">
                  <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center flex-shrink-0">
                    <Check className="w-5 h-5 text-white" />
                  </div>
                  <p className="text-lg text-slate-200">{feature}</p>
                </div>
              ))}
            </div>

            <Button
              onClick={onLoginClick}
              className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-6 text-lg rounded-xl transition-all shadow-lg"
            >
              ¿Ya tienes cuenta? Inicia Sesión
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </div>

          {/* Right Column - Form */}
          <Card className="p-8 bg-white border-0 shadow-2xl">
            <h2 className="text-3xl text-slate-900 mb-2">Pre-registro Gratis</h2>
            <p className="text-slate-600 mb-6">¡Asegura tu posición ahora!</p>

            {/* Countdown */}
            <div className="mb-8">
              <p className="text-slate-700 mb-3 text-center">🚀 Lanzamiento oficial en:</p>
              <div className="grid grid-cols-4 gap-3">
                {[
                  { value: timeLeft.days, label: 'Días' },
                  { value: timeLeft.hours, label: 'Horas' },
                  { value: timeLeft.minutes, label: 'Min' },
                  { value: timeLeft.seconds, label: 'Seg' }
                ].map((item, index) => (
                  <div key={index} className="text-center p-3 bg-blue-600 rounded-xl text-white">
                    <div className="text-3xl">{item.value.toString().padStart(2, '0')}</div>
                    <div className="text-xs uppercase tracking-wider opacity-90">{item.label}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Nombre</Label>
                  <Input
                    required
                    value={formData.nombre}
                    onChange={(e) => handleInputChange('nombre', e.target.value)}
                    placeholder="Tu nombre"
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label>Apellido</Label>
                  <Input
                    required
                    value={formData.apellido}
                    onChange={(e) => handleInputChange('apellido', e.target.value)}
                    placeholder="Tu apellido"
                    className="mt-1"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>País</Label>
                  <Input
                    required
                    value={formData.pais}
                    onChange={(e) => handleInputChange('pais', e.target.value)}
                    placeholder="País"
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label>Teléfono</Label>
                  <Input
                    required
                    type="tel"
                    value={formData.telefono}
                    onChange={(e) => handleInputChange('telefono', e.target.value)}
                    placeholder="Número"
                    className="mt-1"
                  />
                </div>
              </div>

              <div>
                <Label>Correo Electrónico</Label>
                <Input
                  required
                  type="email"
                  value={formData.correo}
                  onChange={(e) => handleInputChange('correo', e.target.value)}
                  placeholder="tu@email.com"
                  className="mt-1"
                />
              </div>

              <div>
                <Label>Código de Patrocinador (Opcional)</Label>
                <Input
                  value={formData.patrocinador}
                  onChange={(e) => handleInputChange('patrocinador', e.target.value)}
                  placeholder="¿Quién te invitó?"
                  className="mt-1"
                />
              </div>

              <div>
                <Label>Usuario (Generado automáticamente)</Label>
                <Input
                  readOnly
                  value={formData.usuario}
                  placeholder="Se generará con tu teléfono"
                  className="mt-1 bg-slate-100"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Contraseña</Label>
                  <Input
                    required
                    type="password"
                    value={formData.password}
                    onChange={(e) => handleInputChange('password', e.target.value)}
                    placeholder="Mínimo 6 caracteres"
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label>Confirmar</Label>
                  <Input
                    required
                    type="password"
                    value={formData.confirmPassword}
                    onChange={(e) => handleInputChange('confirmPassword', e.target.value)}
                    placeholder="Repite contraseña"
                    className="mt-1"
                  />
                </div>
              </div>

              <div className="flex items-start gap-2">
                <Checkbox
                  checked={formData.acceptTerms}
                  onCheckedChange={(checked) => handleInputChange('acceptTerms', checked as boolean)}
                />
                <label className="text-sm text-slate-600">
                  Acepto los{' '}
                  <a 
                    href="#" 
                    onClick={(e) => {
                      e.preventDefault();
                      setShowTerminos(true);
                    }}
                    className="text-blue-600 hover:underline"
                  >
                    términos y condiciones
                  </a>
                </label>
              </div>

              <Button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white h-12 rounded-xl shadow-lg"
                disabled={isSubmitting}
              >
                {isSubmitting ? 'Procesando...' : 'Pre-registrarme Ahora'}
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </form>
          </Card>
        </div>
      </div>
      
      <DialogComponent />
      <TerminosCondiciones isOpen={showTerminos} onClose={() => setShowTerminos(false)} />
    </section>
  );
}