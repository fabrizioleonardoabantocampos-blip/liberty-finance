import { Facebook, Instagram, Youtube, Send, MessageCircle } from 'lucide-react';
import { useState, useEffect } from 'react';
import { documentosAPI } from '../../utils/api';
import { TerminosCondiciones } from '../TerminosCondiciones';

export function Footer() {
  const [documentos, setDocumentos] = useState<{
    terminos: string;
    privacidad: string;
    aviso: string;
  }>({
    terminos: '',
    privacidad: '',
    aviso: ''
  });

  const [showTerminos, setShowTerminos] = useState(false);

  useEffect(() => {
    cargarDocumentos();
  }, []);

  const cargarDocumentos = async () => {
    try {
      const docs = await documentosAPI.getLegales();
      setDocumentos(docs);
    } catch (error) {
      console.error('Error al cargar documentos legales:', error);
    }
  };

  const handleDocumentoClick = (url: string, nombre: string) => {
    if (url && url.length > 0) {
      window.open(url, '_blank');
    } else {
      console.log(`Documento "${nombre}" aún no disponible`);
    }
  };

  const socialLinks = [
    { icon: Facebook, label: 'Facebook', url: '#' },
    { icon: Send, label: 'Telegram', url: '#' },
    { icon: Youtube, label: 'YouTube', url: '#' },
    { icon: Instagram, label: 'TikTok', url: '#' },
    { icon: MessageCircle, label: 'WhatsApp', url: '#' }
  ];

  return (
    <footer className="bg-slate-950 text-white py-12 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
          {/* Logo and Description */}
          <div>
            <h3 className="text-3xl mb-4 text-white">
              Liberty Finance
            </h3>
            <p className="text-slate-400 mb-6">
              Tu camino hacia la libertad financiera comienza aquí. 
              Únete a miles de emprendedores que ya están generando ingresos diarios.
            </p>
            <div className="flex gap-4">
              {socialLinks.map((social, index) => {
                const Icon = social.icon;
                return (
                  <a
                    key={index}
                    href={social.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-10 h-10 rounded-full bg-slate-800 hover:bg-blue-600 flex items-center justify-center transition-colors"
                    aria-label={social.label}
                  >
                    <Icon className="w-5 h-5" />
                  </a>
                );
              })}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg mb-4">Enlaces Rápidos</h4>
            <ul className="space-y-3">
              <li>
                <a href="#inicio" className="text-slate-400 hover:text-white transition-colors">
                  Inicio
                </a>
              </li>
              <li>
                <a href="#funcionamiento" className="text-slate-400 hover:text-white transition-colors">
                  Cómo Funciona
                </a>
              </li>
              <li>
                <a href="#productos" className="text-slate-400 hover:text-white transition-colors">
                  Productos
                </a>
              </li>
              <li>
                <a href="#comisiones" className="text-slate-400 hover:text-white transition-colors">
                  Comisiones
                </a>
              </li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h4 className="text-lg mb-4">Legal</h4>
            <ul className="space-y-3">
              <li>
                <button
                  onClick={() => setShowTerminos(true)}
                  className="text-slate-400 hover:text-white transition-colors cursor-pointer"
                >
                  Términos y Condiciones
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleDocumentoClick(documentos.privacidad, 'Política de Privacidad')}
                  className={`text-slate-400 hover:text-white transition-colors ${
                    documentos.privacidad ? 'cursor-pointer' : 'cursor-default opacity-50'
                  }`}
                >
                  Política de Privacidad
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleDocumentoClick(documentos.aviso, 'Aviso Legal')}
                  className={`text-slate-400 hover:text-white transition-colors ${
                    documentos.aviso ? 'cursor-pointer' : 'cursor-default opacity-50'
                  }`}
                >
                  Aviso Legal
                </button>
              </li>
              <li>
                <a href="#" className="text-slate-400 hover:text-white transition-colors">
                  Contacto
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="pt-8 border-t border-slate-800 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-slate-400 text-sm">
            © 2025 Liberty Finance. Todos los derechos reservados.
          </p>
          <p className="text-slate-500 text-xs">
            Liberty Finance es una plataforma de inversión en productos digitales
          </p>
        </div>
      </div>

      <TerminosCondiciones isOpen={showTerminos} onClose={() => setShowTerminos(false)} />
    </footer>
  );
}