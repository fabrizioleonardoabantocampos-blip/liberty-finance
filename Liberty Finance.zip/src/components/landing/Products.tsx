import { Card } from '../ui/card';
import { Check, ArrowUpRight, DollarSign } from 'lucide-react';

export function Products() {
  const paquetes = [
    {
      id: 1,
      inversion: 50,
      retorno: 100,
      ganancia: 50,
      nombre: 'Pack 50',
      descripcion: 'Ideal para comenzar',
      caracteristicas: [
        'ROI hasta 1% diario',
        'Retorno: $100 USDT',
        'Ganancia: $50 USDT',
        'Rendimiento: hasta 1% diario',
        'Comisiones multinivel',
        'Soporte 24/7'
      ],
      popular: false,
      color: 'from-slate-500 to-slate-600'
    },
    {
      id: 2,
      inversion: 100,
      retorno: 200,
      ganancia: 100,
      nombre: 'Pack 100',
      descripcion: 'El más elegido',
      caracteristicas: [
        'ROI hasta 1% diario',
        'Retorno: $200 USDT',
        'Ganancia: $100 USDT',
        'Rendimiento: hasta 1% diario',
        'Comisiones multinivel',
        'Herramientas premium'
      ],
      popular: true,
      color: 'from-blue-500 to-blue-600'
    },
    {
      id: 3,
      inversion: 200,
      retorno: 400,
      ganancia: 200,
      nombre: 'Pack 200',
      descripcion: 'Para inversores serios',
      caracteristicas: [
        'ROI hasta 1% diario',
        'Retorno: $400 USDT',
        'Ganancia: $200 USDT',
        'Rendimiento: hasta 1% diario',
        'Comisiones multinivel',
        'Acceso a ruleta de premios'
      ],
      popular: false,
      color: 'from-slate-600 to-slate-700'
    },
    {
      id: 4,
      inversion: 300,
      retorno: 600,
      ganancia: 300,
      nombre: 'Pack 300',
      descripcion: 'Ganancias aceleradas',
      caracteristicas: [
        'ROI hasta 1% diario',
        'Retorno: $600 USDT',
        'Ganancia: $300 USDT',
        'Rendimiento: hasta 1% diario',
        'Comisiones multinivel',
        'Productos exclusivos'
      ],
      popular: false,
      color: 'from-blue-600 to-blue-700'
    },
    {
      id: 5,
      inversion: 500,
      retorno: 1000,
      ganancia: 500,
      nombre: 'Pack 500',
      descripcion: 'Máximo rendimiento',
      caracteristicas: [
        'ROI hasta 1% diario',
        'Retorno: $1,000 USDT',
        'Ganancia: $500 USDT',
        'Rendimiento: hasta 1% diario',
        'Comisiones multinivel',
        'Bonos especiales'
      ],
      popular: false,
      destacado: true,
      color: 'from-slate-700 to-slate-800'
    },
    {
      id: 6,
      inversion: 1000,
      retorno: 2000,
      ganancia: 1000,
      nombre: 'Pack 1k',
      descripcion: 'Para líderes de red',
      caracteristicas: [
        'ROI hasta 1% diario',
        'Retorno: $2,000 USDT',
        'Ganancia: $1,000 USDT',
        'Rendimiento: hasta 1% diario',
        'Comisiones multinivel',
        'Asesoría personalizada'
      ],
      popular: false,
      destacado: true,
      color: 'from-blue-700 to-blue-800'
    },
    {
      id: 7,
      inversion: 5000,
      retorno: 10000,
      ganancia: 5000,
      nombre: 'Pack 5k',
      descripcion: 'Inversión corporativa',
      caracteristicas: [
        'ROI hasta 1% diario',
        'Retorno: $10,000 USDT',
        'Ganancia: $5,000 USDT',
        'Rendimiento: hasta 1% diario',
        'Comisiones multinivel',
        'Eventos VIP exclusivos'
      ],
      popular: false,
      premium: true,
      color: 'from-slate-800 to-slate-900'
    },
    {
      id: 8,
      inversion: 10000,
      retorno: 20000,
      ganancia: 10000,
      nombre: 'Pack 10k',
      descripcion: 'Máxima categoría',
      caracteristicas: [
        'ROI hasta 1% diario',
        'Retorno: $20,000 USDT',
        'Ganancia: $10,000 USDT',
        'Rendimiento: hasta 1% diario',
        'Comisiones multinivel',
        'Beneficios VIP ilimitados'
      ],
      popular: false,
      premium: true,
      color: 'from-blue-800 to-blue-900'
    }
  ];

  return (
    <section id="productos" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl text-slate-900 mb-4">
            Paquetes de Inversión
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Invierte desde $50 hasta $10,000 USDT y genera hasta 100% de rentabilidad. 
            Si inviertes $100, ganas hasta $100 adicionales.
          </p>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-4 gap-4">
          {paquetes.map((paquete) => (
            <Card
              key={paquete.id}
              className={`relative p-4 bg-white border-2 shadow-lg hover:shadow-xl transition-all ${
                paquete.popular 
                  ? 'border-blue-600' 
                  : paquete.destacado
                    ? 'border-blue-500'
                    : paquete.premium
                      ? 'border-slate-800'
                      : 'border-slate-200'
              }`}
            >
              {/* Badge */}
              {paquete.popular && (
                <div className="absolute -top-2 -right-2">
                  <span className="bg-blue-600 text-white px-2 py-0.5 rounded-full text-xs shadow-lg">
                    ⭐
                  </span>
                </div>
              )}
              {paquete.destacado && (
                <div className="absolute -top-2 -right-2">
                  <span className="bg-blue-700 text-white px-2 py-0.5 rounded-full text-xs shadow-lg">
                    🔥
                  </span>
                </div>
              )}
              {paquete.premium && (
                <div className="absolute -top-2 -right-2">
                  <span className="bg-slate-800 text-white px-2 py-0.5 rounded-full text-xs shadow-lg">
                    👑
                  </span>
                </div>
              )}

              {/* Icon */}
              <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${paquete.color} flex items-center justify-center text-white shadow-lg mb-3 mx-auto`}>
                <DollarSign className="w-5 h-5" />
              </div>

              {/* Info */}
              <div className="text-center mb-3">
                <h3 className="text-slate-900 mb-1">{paquete.nombre}</h3>
                <p className="text-slate-600 text-xs mb-2">{paquete.descripcion}</p>
                <div className="mb-2">
                  <span className="text-2xl text-slate-900">${paquete.inversion}</span>
                  <span className="text-slate-600 text-xs"> USDT</span>
                </div>
                
                {/* Retorno */}
                <div className={`p-2 rounded-lg bg-gradient-to-r ${paquete.color} text-white`}>
                  <p className="text-xs text-white/80">Retorno</p>
                  <p className="font-semibold">${paquete.retorno}</p>
                  <div className="flex items-center justify-center gap-1 mt-0.5">
                    <ArrowUpRight className="w-2.5 h-2.5" />
                    <span className="text-xs">+${paquete.ganancia}</span>
                  </div>
                </div>
              </div>

              {/* Features - Reducido */}
              <ul className="space-y-1 mb-3">
                {paquete.caracteristicas.slice(0, 3).map((feature, index) => (
                  <li key={index} className="flex items-start gap-1 text-slate-700">
                    <div className="w-3 h-3 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <Check className="w-2 h-2 text-blue-600" />
                    </div>
                    <span className="text-xs">{feature}</span>
                  </li>
                ))}
              </ul>

              {/* Rentabilidad Badge */}
              <div className="flex items-center justify-center gap-1 p-1.5 bg-slate-800 rounded-lg">
                <span className="text-white text-xs">100%</span>
              </div>
            </Card>
          ))}
        </div>

        {/* Comparación */}
        <Card className="mt-16 p-8 bg-white border-slate-200 shadow-xl">
          <h3 className="text-2xl text-slate-900 mb-6 text-center">📊 Comparación de Paquetes</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b-2 border-slate-200">
                  <th className="text-left py-3 px-2 text-slate-600 whitespace-nowrap">Paquete</th>
                  <th className="text-center py-3 px-2 text-slate-600 whitespace-nowrap">Inversión</th>
                  <th className="text-center py-3 px-2 text-slate-600 whitespace-nowrap">Ganancia</th>
                  <th className="text-right py-3 px-2 text-slate-600 whitespace-nowrap">Retorno Total</th>
                </tr>
              </thead>
              <tbody>
                {paquetes.map((paquete) => (
                  <tr key={paquete.id} className="border-b border-slate-100 hover:bg-slate-50">
                    <td className="py-3 px-2 whitespace-nowrap">
                      <span className={`inline-flex items-center justify-center px-3 py-1 rounded-lg bg-gradient-to-r ${paquete.color} text-white text-xs min-w-[75px]`}>
                        {paquete.nombre}
                      </span>
                    </td>
                    <td className="text-center py-3 px-2 text-slate-800 whitespace-nowrap">
                      ${paquete.inversion}
                    </td>
                    <td className="text-center py-3 px-2 whitespace-nowrap">
                      <span className="text-blue-600 font-medium">
                        +${paquete.ganancia}
                      </span>
                    </td>
                    <td className="text-right py-3 px-2 whitespace-nowrap">
                      <span className="text-slate-900 font-semibold">
                        ${paquete.retorno}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        {/* Información Importante */}
        <Card className="mt-8 p-6 bg-gradient-to-br from-amber-500 to-orange-600 border-0 shadow-xl text-white">
          <h3 className="text-xl mb-4 text-center">⚠️ Información Importante</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <ul className="space-y-2">
              <li className="flex items-start gap-2">
                <span className="shrink-0">✅</span>
                <span>Rendimiento diario de hasta 1% sobre tu inversión</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="shrink-0">✅</span>
                <span>Ganancias por comisiones multinivel (10 niveles)</span>
              </li>
            </ul>
            <ul className="space-y-2">
              <li className="flex items-start gap-2">
                <span className="shrink-0">✅</span>
                <span>Rentabilidad máxima del 100% de tu inversión</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="shrink-0">⚡</span>
                <span>Invierte desde $50 hasta $10,000 USDT</span>
              </li>
            </ul>
          </div>
        </Card>
      </div>
    </section>
  );
}