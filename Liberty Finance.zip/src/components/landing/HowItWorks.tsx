import { Card } from '../ui/card';
import { UserPlus, Package, TrendingUp, Users, DollarSign, Gift, Check } from 'lucide-react';

export function HowItWorks() {
  const features = [
    {
      icon: Package,
      title: 'Productos Digitales',
      description: 'Acceso a herramientas y servicios digitales avanzados para potenciar tu negocio'
    },
    {
      icon: Users,
      title: 'Comunidad y Crecimiento',
      description: 'Pertenece a una comunidad global de emprendedores con mentalidad de crecimiento'
    },
    {
      icon: TrendingUp,
      title: 'Ingresos Residuales',
      description: 'Construye un flujo de ingresos constante y escalable que crece con el tiempo'
    }
  ];

  const steps = [
    {
      number: '1',
      icon: UserPlus,
      title: 'Regístrate Gratis',
      description: 'Completa el formulario de pre-registro y asegura tu posición en Liberty Finance'
    },
    {
      number: '2',
      icon: Package,
      title: 'Elige tu Pack',
      description: 'Selecciona el pack de inversión que mejor se adapte a tus objetivos financieros'
    },
    {
      number: '3',
      icon: TrendingUp,
      title: 'Recibe Rendimientos',
      description: 'Comienza a recibir rendimientos diarios desde el primer día de tu inversión'
    },
    {
      number: '4',
      icon: Users,
      title: 'Construye tu Red',
      description: 'Invita personas a tu red y gana comisiones por cada referido que se una'
    },
    {
      number: '5',
      icon: DollarSign,
      title: 'Retira tus Ganancias',
      description: 'Solicita retiros cuando quieras y recibe tus fondos en tu wallet USDT'
    },
    {
      number: '6',
      icon: Gift,
      title: 'Beneficios Extra',
      description: 'Accede a productos exclusivos, ruleta de premios y bonificaciones especiales'
    }
  ];

  return (
    <section id="funcionamiento" className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl text-slate-900 mb-4">
            ¿Cómo funciona Liberty Finance?
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Un sistema simple y transparente diseñado para que generes ingresos 
            desde el primer día
          </p>
        </div>

        {/* Features Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <Card
                key={index}
                className="p-8 bg-white border-2 border-slate-200 shadow-lg hover:shadow-xl transition-shadow"
              >
                <div className="w-16 h-16 rounded-2xl bg-blue-600 flex items-center justify-center mb-6 shadow-lg">
                  <Icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl text-slate-900 mb-3">{feature.title}</h3>
                <p className="text-slate-600">{feature.description}</p>
              </Card>
            );
          })}
        </div>

        {/* Steps Process */}
        <div className="mb-16">
          <h3 className="text-3xl text-slate-900 text-center mb-12">
            Comienza en 6 Simples Pasos
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {steps.map((step) => {
              const Icon = step.icon;
              
              return (
                <div key={step.number} className="relative">
                  <Card className="p-6 bg-white border-2 border-slate-200 shadow-lg hover:shadow-xl transition-all h-full">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 rounded-xl bg-blue-600 flex items-center justify-center flex-shrink-0 text-white shadow-lg">
                        <span className="text-xl">{step.number}</span>
                      </div>
                      <div className="flex-1">
                        <div className="w-10 h-10 rounded-lg bg-slate-100 flex items-center justify-center mb-3">
                          <Icon className="w-5 h-5 text-slate-700" />
                        </div>
                        <h4 className="text-xl text-slate-900 mb-2">{step.title}</h4>
                        <p className="text-slate-600 text-sm">{step.description}</p>
                      </div>
                    </div>
                  </Card>
                </div>
              );
            })}
          </div>
        </div>

        {/* Ecosystem Card */}
        <Card className="p-8 md:p-12 bg-slate-900 border-0 shadow-2xl text-white">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-3xl mb-6">Únete al Ecosistema Liberty Finance</h3>
              <p className="text-slate-300 text-lg mb-6">
                Genera ingresos diarios de forma sostenible mientras construyes una red 
                de personas comprometidas con su libertad financiera.
              </p>
              <ul className="space-y-4">
                {[
                  'Rendimientos diarios garantizados sobre tu inversión inicial',
                  'Sistema de comisiones multinivel por tu red de referidos',
                  'Plataforma intuitiva para gestionar todas tus ganancias',
                  'Retiros rápidos y seguros directo a tu wallet USDT'
                ].map((item, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-blue-600 flex items-center justify-center flex-shrink-0 mt-1">
                      <Check className="w-4 h-4" />
                    </div>
                    <span className="text-slate-300">{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="relative">
              <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20">
                <div className="text-center mb-8">
                  <div className="w-20 h-20 rounded-full bg-blue-600 flex items-center justify-center mx-auto mb-4 shadow-xl">
                    <Users className="w-10 h-10 text-white" />
                  </div>
                  <p className="text-white/80 text-sm">TÚ (Líder)</p>
                </div>

                <div className="grid grid-cols-3 gap-4 mb-4">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="text-center">
                      <div className="w-14 h-14 rounded-full bg-slate-700 flex items-center justify-center mx-auto mb-2 shadow-lg">
                        <Users className="w-7 h-7 text-white" />
                      </div>
                      <p className="text-white/60 text-xs">Nivel 1</p>
                    </div>
                  ))}
                </div>

                <div className="grid grid-cols-3 gap-2">
                  {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((i) => (
                    <div key={i} className="text-center">
                      <div className="w-10 h-10 rounded-full bg-slate-400 flex items-center justify-center mx-auto shadow-lg">
                        <Users className="w-5 h-5 text-white" />
                      </div>
                    </div>
                  ))}
                </div>

                <p className="text-center text-white/70 text-sm mt-6">
                  Crecimiento exponencial de tu red
                </p>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </section>
  );
}