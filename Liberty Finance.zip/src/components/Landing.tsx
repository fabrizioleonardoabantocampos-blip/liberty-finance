import { Navigation } from './landing/Navigation';
import { Hero } from './landing/Hero';
import { LifestyleShowcase } from './landing/LifestyleShowcase';
import { HowItWorks } from './landing/HowItWorks';
import { Products } from './landing/Products';
import { Commissions } from './landing/Commissions';
import { Footer } from './landing/Footer';

interface LandingProps {
  onLoginClick: () => void;
}

export function Landing({ onLoginClick }: LandingProps) {
  return (
    <div className="min-h-screen">
      <Navigation onLoginClick={onLoginClick} />
      <LifestyleShowcase />
      <Hero onLoginClick={onLoginClick} />
      <HowItWorks />
      <Products />
      <Commissions />
      <Footer />
    </div>
  );
}