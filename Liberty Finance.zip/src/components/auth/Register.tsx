import { useState, useEffect } from 'react';
import { User, Mail, Lock, Eye, EyeOff, Phone, ArrowLeft, FileText } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Checkbox } from '../ui/checkbox';
import { useLogo } from '../../hooks/useLogo';
import { callServer } from '../../utils/api';
import { TerminosCondiciones } from './TerminosCondiciones';

interface RegisterProps {
  onBack: () => void;
  referralCode?: string;
}

export function Register({ onBack, referralCode = '' }: RegisterProps) {
  const [formData, setFormData] = useState({
    nombre: '',
    apellido: '',
    email: '',
    telefono: '',
    wallet: '',
    password: '',
    confirmPassword: '',
    codigo_patrocinador: referralCode
  });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [aceptaTerminos, setAceptaTerminos] = useState(false);
  const [showTerminos, setShowTerminos] = useState(false);
  const { logoUrl } = useLogo();

  // Actualizar el código de patrocinador cuando cambia el prop
  useEffect(() => {
    if (referralCode) {
      console.log('🔗 Código de referido detectado:', referralCode);
      setFormData(prev => ({ ...prev, codigo_patrocinador: referralCode }));
    }
  }, [referralCode]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // 🛡️ PROTECCIÓN CRÍTICA: Prevenir doble-submit
    if (loading) {
      console.warn('⚠️ Registro ya en proceso, ignorando click adicional');
      return;
    }
    
    if (formData.password !== formData.confirmPassword) {
      toast.error('Las contraseñas no coinciden');
      return;
    }

    if (formData.password.length < 8) {
      toast.error('La contraseña debe tener al menos 8 caracteres');
      return;
    }

    if (!aceptaTerminos) {
      toast.error('Debes aceptar los términos y condiciones');
      return;
    }

    setLoading(true);

    try {
      // Buscar el referidor por su código si se proporcionó
      let referidoPor = undefined;
      if (formData.codigo_patrocinador) {
        // El codigo_patrocinador es el id_unico del referidor
        // El servidor buscará al usuario por su id_unico
        referidoPor = formData.codigo_patrocinador;
      }

      const response = await callServer('/auth/register', 'POST', {
        nombre: formData.nombre,
        apellido: formData.apellido,
        email: formData.email,
        telefono: formData.telefono,
        wallet: formData.wallet,
        password: formData.password,
        referralCode: formData.codigo_patrocinador, // Código propio del nuevo usuario (opcional)
        referidoPor // Código del patrocinador
      });

      if (response.error) {
        toast.error(response.error);
        setLoading(false);
        return;
      }

      if (response.success) {
        toast.success('¡Registro exitoso! Ahora puedes iniciar sesión');
        setTimeout(() => onBack(), 1500);
      }
    } catch (error) {
      console.error('Error en registro:', error);
      toast.error('Error al registrar usuario. Por favor intenta de nuevo.');
      setLoading(false); // ⚠️ Solo resetear loading en error
    }
    // ⚠️ NO resetear loading en success para evitar doble-click
  };

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 py-12">
      <div className="w-full max-w-2xl">
        {/* Header */}
        <div className="mb-8 text-center">
          <div className="w-20 h-20 rounded-2xl bg-white/10 backdrop-blur-sm border border-white/20 flex items-center justify-center mx-auto mb-4 p-3">
            <img 
              src={logoUrl} 
              alt="Liberty Finance" 
              className="w-full h-auto"
            />
          </div>
          <h1 className="text-4xl text-white mb-2">Crear Cuenta</h1>
          <p className="text-blue-300">Únete a Liberty Finance</p>
        </div>

        {/* Register Form */}
        <div className="bg-white/10 backdrop-blur-xl rounded-3xl p-8 shadow-2xl border border-white/20">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Name Row */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label className="text-white">Nombre</Label>
                <div className="relative">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-blue-300" />
                  <Input
                    type="text"
                    value={formData.nombre}
                    onChange={(e) => handleChange('nombre', e.target.value)}
                    placeholder="Tu nombre"
                    className="pl-12 bg-white/5 border-white/10 text-white placeholder:text-blue-300/50 h-12 rounded-xl focus:border-blue-400 focus:ring-blue-400"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-white">Apellido</Label>
                <div className="relative">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-blue-300" />
                  <Input
                    type="text"
                    value={formData.apellido}
                    onChange={(e) => handleChange('apellido', e.target.value)}
                    placeholder="Tu apellido"
                    className="pl-12 bg-white/5 border-white/10 text-white placeholder:text-blue-300/50 h-12 rounded-xl focus:border-blue-400 focus:ring-blue-400"
                    required
                  />
                </div>
              </div>
            </div>

            {/* Email & Phone */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label className="text-white">Email</Label>
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-blue-300" />
                  <Input
                    type="email"
                    value={formData.email}
                    onChange={(e) => handleChange('email', e.target.value)}
                    placeholder="tu@email.com"
                    className="pl-12 bg-white/5 border-white/10 text-white placeholder:text-blue-300/50 h-12 rounded-xl focus:border-blue-400 focus:ring-blue-400"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-white">Teléfono</Label>
                <div className="relative">
                  <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-blue-300" />
                  <Input
                    type="tel"
                    value={formData.telefono}
                    onChange={(e) => handleChange('telefono', e.target.value)}
                    placeholder="+52 123 456 7890"
                    className="pl-12 bg-white/5 border-white/10 text-white placeholder:text-blue-300/50 h-12 rounded-xl focus:border-blue-400 focus:ring-blue-400"
                    required
                  />
                </div>
              </div>
            </div>

            {/* Referral Code */}
            <div className="space-y-2">
              <Label className="text-white">Código de Patrocinador (Opcional)</Label>
              <div className="relative">
                <Input
                  type="text"
                  value={formData.codigo_patrocinador}
                  onChange={(e) => handleChange('codigo_patrocinador', e.target.value)}
                  placeholder="LF1234567890"
                  disabled={!!referralCode} // Bloquear si viene de un link de referido
                  className={`bg-white/5 border-white/10 text-white placeholder:text-blue-300/50 h-12 rounded-xl focus:border-blue-400 focus:ring-blue-400 ${
                    referralCode ? 'opacity-70 cursor-not-allowed bg-white/10' : ''
                  }`}
                />
                {referralCode && (
                  <Lock className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-blue-300/70" />
                )}
              </div>
            </div>

            {/* Wallet */}
            <div className="space-y-2">
              <Label className="text-white">Billetera (Opcional)</Label>
              <Input
                type="text"
                value={formData.wallet}
                onChange={(e) => handleChange('wallet', e.target.value)}
                placeholder="0x1234567890abcdef..."
                className="bg-white/5 border-white/10 text-white placeholder:text-blue-300/50 h-12 rounded-xl focus:border-blue-400 focus:ring-blue-400"
              />
            </div>

            {/* Passwords */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label className="text-white">Contraseña</Label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-blue-300" />
                  <Input
                    type={showPassword ? 'text' : 'password'}
                    value={formData.password}
                    onChange={(e) => handleChange('password', e.target.value)}
                    placeholder="Mínimo 8 caracteres"
                    className="pl-12 pr-12 bg-white/5 border-white/10 text-white placeholder:text-blue-300/50 h-12 rounded-xl focus:border-blue-400 focus:ring-blue-400"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-blue-300 hover:text-white transition-colors"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-white">Confirmar Contraseña</Label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-blue-300" />
                  <Input
                    type={showConfirmPassword ? 'text' : 'password'}
                    value={formData.confirmPassword}
                    onChange={(e) => handleChange('confirmPassword', e.target.value)}
                    placeholder="Confirma tu contraseña"
                    className="pl-12 pr-12 bg-white/5 border-white/10 text-white placeholder:text-blue-300/50 h-12 rounded-xl focus:border-blue-400 focus:ring-blue-400"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-blue-300 hover:text-white transition-colors"
                  >
                    {showConfirmPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>
            </div>

            {/* Terms and Conditions Checkbox */}
            <div className="pt-2">
              <div className="flex items-start gap-3 p-4 bg-white/5 rounded-xl border border-white/10">
                <Checkbox
                  id="terminos"
                  checked={aceptaTerminos}
                  onCheckedChange={(checked) => setAceptaTerminos(!!checked)}
                  className="mt-1 border-white/20 data-[state=checked]:bg-blue-500 data-[state=checked]:border-blue-500"
                />
                <div className="flex-1">
                  <label htmlFor="terminos" className="text-white text-sm cursor-pointer">
                    Acepto los{' '}
                    <button
                      type="button"
                      onClick={() => setShowTerminos(true)}
                      className="text-blue-300 hover:text-blue-400 underline font-medium inline-flex items-center gap-1"
                    >
                      <FileText className="w-4 h-4" />
                      Términos y Condiciones
                    </button>
                    {' '}de Liberty Finance
                  </label>
                  <p className="text-blue-200/70 text-xs mt-1">
                    Es obligatorio aceptar los términos para completar el registro
                  </p>
                </div>
              </div>
            </div>

            {/* Buttons */}
            <div className="space-y-4 pt-4">
              <Button
                type="submit"
                className="w-full h-14 bg-gradient-to-r from-blue-500 to-cyan-400 hover:from-blue-600 hover:to-cyan-500 text-white rounded-xl text-lg shadow-lg shadow-blue-500/50"
                disabled={loading}
              >
                {loading ? 'Registrando...' : 'Crear Cuenta'}
              </Button>

              <Button
                type="button"
                onClick={onBack}
                variant="outline"
                className="w-full h-12 border-white/20 text-slate-900 hover:bg-white/10 hover:text-slate-900 rounded-xl bg-white/90"
              >
                <ArrowLeft className="w-5 h-5 mr-2" />
                Volver al Login
              </Button>
            </div>
          </form>
        </div>
      </div>

      {/* Terms and Conditions Modal */}
      <TerminosCondiciones 
        isOpen={showTerminos} 
        onClose={() => setShowTerminos(false)} 
      />
    </div>
  );
}