import { useState } from 'react';
import { Mail, Lock, ArrowLeft, Key, Shield } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { useLogo } from '../../hooks/useLogo';
import { callServer } from '../../utils/api';

interface RecuperarPasswordProps {
  onBackToLogin: () => void;
}

type Step = 'email' | 'codigo' | 'nueva-password';

export function RecuperarPassword({ onBackToLogin }: RecuperarPasswordProps) {
  const [step, setStep] = useState<Step>('email');
  const [email, setEmail] = useState('');
  const [codigo, setCodigo] = useState('');
  const [nuevaPassword, setNuevaPassword] = useState('');
  const [confirmarPassword, setConfirmarPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { logoUrl } = useLogo();

  // Paso 1: Solicitar código de recuperación
  const handleSolicitarCodigo = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email.trim()) {
      toast.error('Por favor ingresa tu correo electrónico');
      return;
    }

    setLoading(true);
    try {
      const response = await callServer('/auth/solicitar-recuperacion', 'POST', { email });
      
      if (response.error) {
        toast.error(response.error);
        return;
      }

      if (response.success) {
        toast.success('📧 Código enviado a tu correo electrónico');
        setStep('codigo');
      }
    } catch (error) {
      console.error('Error al solicitar código:', error);
      toast.error('Error al enviar el código. Intenta de nuevo.');
    } finally {
      setLoading(false);
    }
  };

  // Paso 2: Verificar código
  const handleVerificarCodigo = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!codigo.trim()) {
      toast.error('Por favor ingresa el código recibido');
      return;
    }

    if (codigo.length !== 6) {
      toast.error('El código debe tener 6 dígitos');
      return;
    }

    setLoading(true);
    try {
      const response = await callServer('/auth/verificar-codigo', 'POST', { email, codigo });
      
      if (response.error) {
        toast.error(response.error);
        return;
      }

      if (response.success) {
        toast.success('✅ Código verificado correctamente');
        setStep('nueva-password');
      }
    } catch (error) {
      console.error('Error al verificar código:', error);
      toast.error('Error al verificar el código. Intenta de nuevo.');
    } finally {
      setLoading(false);
    }
  };

  // Paso 3: Establecer nueva contraseña
  const handleCambiarPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!nuevaPassword.trim() || !confirmarPassword.trim()) {
      toast.error('Por favor completa todos los campos');
      return;
    }

    if (nuevaPassword.length < 6) {
      toast.error('La contraseña debe tener al menos 6 caracteres');
      return;
    }

    if (nuevaPassword !== confirmarPassword) {
      toast.error('Las contraseñas no coinciden');
      return;
    }

    setLoading(true);
    try {
      const response = await callServer('/auth/restablecer-password', 'POST', {
        email,
        codigo,
        nuevaPassword
      });
      
      if (response.error) {
        toast.error(response.error);
        return;
      }

      if (response.success) {
        toast.success('🎉 Contraseña actualizada exitosamente');
        setTimeout(() => {
          onBackToLogin();
        }, 1500);
      }
    } catch (error) {
      console.error('Error al cambiar contraseña:', error);
      toast.error('Error al cambiar la contraseña. Intenta de nuevo.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo/Brand */}
        <div className="mb-8 text-center">
          <div className="w-20 h-20 rounded-2xl bg-white/10 backdrop-blur-sm border border-white/20 flex items-center justify-center mx-auto mb-4 p-3">
            <img 
              src={logoUrl} 
              alt="Liberty Finance" 
              className="w-full h-auto"
            />
          </div>
          <h1 className="text-white text-2xl mb-2">Recuperar Contraseña</h1>
          <p className="text-blue-300">
            {step === 'email' && 'Ingresa tu correo para recibir el código'}
            {step === 'codigo' && 'Revisa tu correo e ingresa el código'}
            {step === 'nueva-password' && 'Establece tu nueva contraseña'}
          </p>
        </div>

        {/* Form Container */}
        <div className="bg-white/10 backdrop-blur-xl rounded-3xl p-8 shadow-2xl border border-white/20">
          {/* PASO 1: Solicitar código */}
          {step === 'email' && (
            <form onSubmit={handleSolicitarCodigo} className="space-y-6">
              <div className="space-y-2">
                <Label className="text-white">Correo Electrónico</Label>
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-blue-300" />
                  <Input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="tu@correo.com"
                    className="pl-12 bg-white/5 border-white/10 text-white placeholder:text-blue-300/50 h-14 rounded-xl focus:border-blue-400 focus:ring-blue-400"
                    required
                  />
                </div>
              </div>

              <Button
                type="submit"
                className="w-full h-14 bg-gradient-to-r from-blue-500 to-cyan-400 hover:from-blue-600 hover:to-cyan-500 text-white rounded-xl text-lg shadow-lg shadow-blue-500/50"
                disabled={loading}
              >
                {loading ? 'Enviando...' : 'Enviar Código'}
              </Button>
            </form>
          )}

          {/* PASO 2: Verificar código */}
          {step === 'codigo' && (
            <form onSubmit={handleVerificarCodigo} className="space-y-6">
              <div className="bg-blue-500/20 rounded-xl border border-blue-400/30 p-4 mb-4">
                <p className="text-blue-200 text-sm text-center">
                  📧 Hemos enviado un código de 6 dígitos a<br />
                  <strong className="text-white">{email}</strong>
                </p>
              </div>

              <div className="space-y-2">
                <Label className="text-white">Código de Verificación</Label>
                <div className="relative">
                  <Key className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-blue-300" />
                  <Input
                    type="text"
                    value={codigo}
                    onChange={(e) => setCodigo(e.target.value.replace(/\D/g, '').slice(0, 6))}
                    placeholder="000000"
                    className="pl-12 bg-white/5 border-white/10 text-white placeholder:text-blue-300/50 h-14 rounded-xl focus:border-blue-400 focus:ring-blue-400 text-center text-2xl tracking-widest"
                    maxLength={6}
                    required
                  />
                </div>
              </div>

              <Button
                type="submit"
                className="w-full h-14 bg-gradient-to-r from-blue-500 to-cyan-400 hover:from-blue-600 hover:to-cyan-500 text-white rounded-xl text-lg shadow-lg shadow-blue-500/50"
                disabled={loading}
              >
                {loading ? 'Verificando...' : 'Verificar Código'}
              </Button>

              <Button
                type="button"
                variant="ghost"
                onClick={() => setStep('email')}
                className="w-full text-blue-200 hover:text-white"
              >
                ← Cambiar correo
              </Button>
            </form>
          )}

          {/* PASO 3: Nueva contraseña */}
          {step === 'nueva-password' && (
            <form onSubmit={handleCambiarPassword} className="space-y-6">
              <div className="bg-green-500/20 rounded-xl border border-green-400/30 p-4 mb-4">
                <p className="text-green-200 text-sm text-center flex items-center justify-center gap-2">
                  <Shield className="w-4 h-4" />
                  Código verificado. Establece tu nueva contraseña
                </p>
              </div>

              <div className="space-y-2">
                <Label className="text-white">Nueva Contraseña</Label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-blue-300" />
                  <Input
                    type="password"
                    value={nuevaPassword}
                    onChange={(e) => setNuevaPassword(e.target.value)}
                    placeholder="Mínimo 6 caracteres"
                    className="pl-12 bg-white/5 border-white/10 text-white placeholder:text-blue-300/50 h-14 rounded-xl focus:border-blue-400 focus:ring-blue-400"
                    required
                    minLength={6}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-white">Confirmar Contraseña</Label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-blue-300" />
                  <Input
                    type="password"
                    value={confirmarPassword}
                    onChange={(e) => setConfirmarPassword(e.target.value)}
                    placeholder="Repite tu contraseña"
                    className="pl-12 bg-white/5 border-white/10 text-white placeholder:text-blue-300/50 h-14 rounded-xl focus:border-blue-400 focus:ring-blue-400"
                    required
                    minLength={6}
                  />
                </div>
              </div>

              <Button
                type="submit"
                className="w-full h-14 bg-gradient-to-r from-blue-500 to-cyan-400 hover:from-blue-600 hover:to-cyan-500 text-white rounded-xl text-lg shadow-lg shadow-blue-500/50"
                disabled={loading}
              >
                {loading ? 'Actualizando...' : 'Cambiar Contraseña'}
              </Button>
            </form>
          )}

          {/* Volver al login */}
          <div className="mt-6 text-center">
            <button
              onClick={onBackToLogin}
              className="text-blue-200 hover:text-white transition-colors flex items-center justify-center gap-2 mx-auto"
            >
              <ArrowLeft className="w-4 h-4" />
              Volver al inicio de sesión
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}