import { useState } from 'react';
import { User, Lock, Eye, EyeOff, LogIn } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { useLogo } from '../../hooks/useLogo';
import { callServer } from '../../utils/api';

interface LoginProps {
  onLogin: (type: 'user' | 'admin') => void;
  onRegister: () => void;
  onForgotPassword?: () => void;
}

export function Login({ onLogin, onRegister, onForgotPassword }: LoginProps) {
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const { logoUrl } = useLogo();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      const response = await callServer('/auth/login', 'POST', { email: identifier, password });
      
      if (response.error) {
        toast.error(response.error);
        setLoading(false);
        return;
      }
      
      if (response.success && response.user) {
        // Guardar usuario en localStorage
        localStorage.setItem('currentUser', JSON.stringify(response.user));
        localStorage.setItem('userId', response.user.id);
        
        // Determinar tipo de usuario
        const userType = identifier === 'admin@libertyfinance.com' ? 'admin' : 'user';
        
        toast.success('¡Bienvenido a Liberty Finance!');
        
        // ✅ Llamar a onLogin que activará el LoadingScreen global en App.tsx
        onLogin(userType);
      }
    } catch (error) {
      console.error('Error en login:', error);
      toast.error('Error al iniciar sesión. Por favor intenta de nuevo.');
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo/Brand */}
        <div className="mb-8 text-center">
          <div className="w-20 h-20 rounded-2xl bg-white/10 backdrop-blur-sm border border-white/20 flex items-center justify-center mx-auto mb-4 p-3">
            <img 
              src={logoUrl} 
              alt="Liberty Finance" 
              className="w-full h-auto"
            />
          </div>
          <p className="text-blue-300">Inicia sesión en tu cuenta</p>
        </div>

        {/* Login Form */}
        <div className="bg-white/10 backdrop-blur-xl rounded-3xl p-8 shadow-2xl border border-white/20">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Username */}
            <div className="space-y-2">
              <Label className="text-white">Usuario</Label>
              <div className="relative">
                <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-blue-300" />
                <Input
                  type="email"
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  placeholder="Ingresa tu correo electrónico"
                  className="pl-12 bg-white/5 border-white/10 text-white placeholder:text-blue-300/50 h-14 rounded-xl focus:border-blue-400 focus:ring-blue-400"
                  required
                />
              </div>
            </div>

            {/* Password */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-white">Contraseña</Label>
                {onForgotPassword && (
                  <button
                    type="button"
                    onClick={onForgotPassword}
                    className="text-sm text-blue-300 hover:text-blue-200 transition-colors"
                  >
                    ¿Olvidaste tu contraseña?
                  </button>
                )}
              </div>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-blue-300" />
                <Input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Ingresa tu contraseña"
                  className="pl-12 pr-12 bg-white/5 border-white/10 text-white placeholder:text-blue-300/50 h-14 rounded-xl focus:border-blue-400 focus:ring-blue-400"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-blue-300 hover:text-blue-200 transition-colors"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            {/* Login Button */}
            <Button
              type="submit"
              disabled={loading}
              className="w-full h-14 bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white rounded-xl transition-all duration-300 shadow-lg hover:shadow-xl"
            >
              {loading ? (
                <div className="flex items-center gap-2">
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  <span>Iniciando sesión...</span>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <LogIn className="w-5 h-5" />
                  <span>Iniciar Sesión</span>
                </div>
              )}
            </Button>
          </form>

          {/* Register Link */}
          <div className="mt-6 text-center">
            <p className="text-blue-200">
              ¿No tienes cuenta?{' '}
              <button
                onClick={onRegister}
                className="text-blue-300 hover:text-blue-200 transition-colors underline"
              >
                Regístrate aquí
              </button>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
