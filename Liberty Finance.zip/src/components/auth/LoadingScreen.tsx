import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Loader2, TrendingUp, DollarSign, Users, Award, Rocket, Star } from 'lucide-react';
import { useLogo } from '../../hooks/useLogo';

interface LoadingScreenProps {
  isVisible: boolean;
  message?: string;
  onComplete?: () => void;
  maxDuration?: number; // Duración máxima en ms
}

// 💡 Mensajes motivacionales dinámicos
const motivationalMessages = [
  { icon: Rocket, text: 'Bienvenido a Liberty Finance...', color: 'text-blue-400' },
  { icon: TrendingUp, text: 'Invierte hoy, cosecha mañana 💎', color: 'text-green-400' },
  { icon: DollarSign, text: 'Tu dinero trabajando para ti 24/7', color: 'text-yellow-400' },
  { icon: Users, text: 'Construye tu red, multiplica tus ingresos', color: 'text-purple-400' },
  { icon: Award, text: 'Cada inversión te acerca a tus metas', color: 'text-orange-400' },
  { icon: Star, text: 'El futuro financiero comienza ahora', color: 'text-pink-400' }
];

export function LoadingScreen({ 
  isVisible, 
  message = "Cargando tu información...", 
  onComplete,
  maxDuration = 90000 // ⚡ Timeout máximo de 90 segundos (aumentado para carga inicial del caché)
}: LoadingScreenProps) {
  const [progress, setProgress] = useState(0);
  const [timeElapsed, setTimeElapsed] = useState(0);
  const [dashboardReady, setDashboardReady] = useState(false);
  const [minTimeElapsed, setMinTimeElapsed] = useState(false);
  const [currentMessageIndex, setCurrentMessageIndex] = useState(0);
  const { logoUrl } = useLogo();

  // ✅ TIEMPO MÍNIMO DE CARGA: 8 segundos
  const MIN_LOADING_TIME = 8000;

  useEffect(() => {
    if (!isVisible) return;

    // ✅ Timer para tiempo mínimo
    const minTimeTimer = setTimeout(() => {
      console.log('✅ LoadingScreen: Tiempo mínimo de 8s alcanzado');
      setMinTimeElapsed(true);
    }, MIN_LOADING_TIME);

    // Animación de progreso más rápida (8 segundos)
    const progressInterval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 90) return prev; // No llegar al 100% hasta que realmente termine
        return prev + Math.random() * 3; // Ajustado para ~8s
      });
    }, 300);

    // Timer para timeout
    const timeoutTimer = setInterval(() => {
      setTimeElapsed(prev => prev + 100);
    }, 100);

    // Timeout de seguridad
    const timeout = setTimeout(() => {
      console.warn(`⚠️ LoadingScreen alcanzó timeout máximo de ${maxDuration/1000}s`);
      if (onComplete) onComplete();
    }, maxDuration);
    
    // ✅ ESCUCHAR EVENTO DE DASHBOARD LISTO
    const handleDashboardReady = () => {
      console.log('✅ LoadingScreen: Dashboard listo señalado');
      setDashboardReady(true);
    };
    
    window.addEventListener('dashboardReady', handleDashboardReady);

    return () => {
      clearTimeout(minTimeTimer);
      clearInterval(progressInterval);
      clearInterval(timeoutTimer);
      clearTimeout(timeout);
      window.removeEventListener('dashboardReady', handleDashboardReady);
    };
  }, [isVisible, maxDuration, onComplete]);

  // ✅ SOLO OCULTAR CUANDO AMBAS CONDICIONES SE CUMPLAN
  useEffect(() => {
    if (dashboardReady && minTimeElapsed) {
      console.log('✅ LoadingScreen: Ambas condiciones cumplidas (dashboard listo + 8s transcurridos), ocultando...');
      setProgress(100);
      
      // Pequeño delay para la animación de completado
      setTimeout(() => {
        if (onComplete) onComplete();
      }, 500);
    }
  }, [dashboardReady, minTimeElapsed, onComplete]);

  // ✅ Cambiar mensajes motivacionales cada 2 segundos
  useEffect(() => {
    if (!isVisible) return;
    
    const messageInterval = setInterval(() => {
      setCurrentMessageIndex((prev) => (prev + 1) % motivationalMessages.length);
    }, 2000);

    return () => clearInterval(messageInterval);
  }, [isVisible]);

  // Cuando se completa, llevar al 100%
  useEffect(() => {
    if (!isVisible && progress > 0) {
      setProgress(100);
      setTimeout(() => {
        setProgress(0);
        setDashboardReady(false);
        setMinTimeElapsed(false);
        setTimeElapsed(0);
        setCurrentMessageIndex(0);
      }, 500);
    }
  }, [isVisible, progress]);

  const currentMessage = motivationalMessages[currentMessageIndex];
  const MessageIcon = currentMessage.icon;

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="fixed inset-0 z-[9999] flex items-center justify-center bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900"
        >
          {/* Patrón de fondo sutil */}
          <div className="absolute inset-0 opacity-5">
            <div className="absolute inset-0" style={{
              backgroundImage: `radial-gradient(circle at 2px 2px, white 1px, transparent 0)`,
              backgroundSize: '40px 40px'
            }} />
          </div>

          {/* Partículas flotantes de fondo */}
          <div className="absolute inset-0 overflow-hidden">
            {[...Array(20)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute w-2 h-2 bg-primary/20 rounded-full"
                initial={{
                  x: Math.random() * window.innerWidth,
                  y: Math.random() * window.innerHeight,
                }}
                animate={{
                  y: [null, Math.random() * window.innerHeight],
                  x: [null, Math.random() * window.innerWidth],
                }}
                transition={{
                  duration: Math.random() * 10 + 10,
                  repeat: Infinity,
                  ease: "linear",
                }}
              />
            ))}
          </div>

          {/* Contenido centrado */}
          <div className="relative z-10 flex flex-col items-center justify-center px-6">
            {/* Logo con animación */}
            <motion.div
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ 
                duration: 0.6,
                ease: [0.34, 1.56, 0.64, 1] // Spring effect
              }}
              className="mb-8"
            >
              {/* Logo Liberty Finance */}
              <div className="relative">
                {/* Glow effect */}
                <motion.div
                  animate={{
                    scale: [1, 1.2, 1],
                    opacity: [0.3, 0.5, 0.3]
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                  className="absolute inset-0 bg-primary/30 blur-3xl rounded-full"
                />
                
                {/* Logo principal */}
                <div className="relative w-24 h-24 md:w-32 md:h-32 bg-white rounded-2xl flex items-center justify-center shadow-2xl p-4 border-4 border-primary/20">
                  <img 
                    src={logoUrl} 
                    alt="Liberty Finance" 
                    className="w-full h-full object-contain"
                  />
                </div>
              </div>
            </motion.div>

            {/* Texto Liberty Finance */}
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.3, duration: 0.6 }}
              className="text-center mb-8"
            >
              <h1 className="text-3xl md:text-5xl font-bold text-white mb-2 tracking-tight">
                Liberty Finance
              </h1>
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.6, duration: 0.6 }}
                className="text-slate-400 text-sm md:text-base"
              >
                Oficina Virtual
              </motion.p>
            </motion.div>

            {/* Spinner y mensaje motivacional */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.8, duration: 0.6 }}
              className="flex flex-col items-center gap-4"
            >
              {/* Spinner animado */}
              <div className="relative">
                <Loader2 className="w-8 h-8 text-primary animate-spin" />
                <motion.div
                  animate={{
                    scale: [1, 1.3, 1],
                    opacity: [0.5, 0, 0.5]
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                  className="absolute inset-0 border-2 border-primary rounded-full"
                />
              </div>

              {/* Mensaje motivacional con animación */}
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentMessageIndex}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.5 }}
                  className="flex items-center gap-3"
                >
                  <MessageIcon className={`w-5 h-5 ${currentMessage.color}`} />
                  <p className={`text-sm md:text-base font-medium ${currentMessage.color}`}>
                    {currentMessage.text}
                  </p>
                </motion.div>
              </AnimatePresence>

              {/* Mensaje de estado del dashboard */}
              {dashboardReady && !minTimeElapsed && (
                <motion.p
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="text-green-400 text-xs"
                >
                  ✅ Dashboard listo, finalizando...
                </motion.p>
              )}

              {/* Barra de progreso */}
              <div className="w-64 md:w-80 h-1.5 bg-slate-700/50 rounded-full overflow-hidden shadow-lg">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${progress}%` }}
                  transition={{ duration: 0.3 }}
                  className="h-full bg-gradient-to-r from-primary via-blue-500 to-primary rounded-full relative"
                >
                  {/* Shine effect */}
                  <motion.div
                    animate={{
                      x: ['-100%', '200%']
                    }}
                    transition={{
                      duration: 1.5,
                      repeat: Infinity,
                      ease: "linear"
                    }}
                    className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent"
                  />
                </motion.div>
              </div>

              {/* Porcentaje */}
              <motion.p
                className="text-slate-400 text-xs font-mono"
              >
                {Math.round(progress)}%
              </motion.p>

              {/* Advertencia si tarda más de 20 segundos */}
              {timeElapsed > 20000 && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="mt-4 px-4 py-2 bg-orange-500/20 border border-orange-500/50 rounded-lg"
                >
                  <p className="text-orange-300 text-xs text-center">
                    ⚠️ Cargando datos extensos, por favor espera...
                  </p>
                </motion.div>
              )}
            </motion.div>

            {/* Footer */}
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1.2, duration: 0.6 }}
              className="mt-12 text-slate-600 text-xs text-center"
            >
              © {new Date().getFullYear()} Liberty Finance. Todos los derechos reservados.
            </motion.p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}