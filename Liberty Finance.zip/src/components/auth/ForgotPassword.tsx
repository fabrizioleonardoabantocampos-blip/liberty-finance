import { useState } from 'react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Mail, ArrowLeft, CheckCircle } from 'lucide-react';

interface ForgotPasswordProps {
  onBack: () => void;
}

export function ForgotPassword({ onBack }: ForgotPasswordProps) {
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate sending email
    setTimeout(() => {
      setSent(true);
    }, 1000);
  };

  if (sent) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <div className="bg-white/10 backdrop-blur-xl rounded-3xl p-8 shadow-2xl border border-white/20 text-center">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-green-500/20 mb-6">
              <CheckCircle className="w-10 h-10 text-green-400" />
            </div>
            <h2 className="text-2xl text-white mb-4">Email Enviado</h2>
            <p className="text-blue-200 mb-8">
              Hemos enviado un enlace de recuperación a <strong>{email}</strong>. 
              Por favor revisa tu bandeja de entrada y sigue las instrucciones.
            </p>
            <Button
              onClick={onBack}
              className="w-full h-12 bg-gradient-to-r from-blue-500 to-cyan-400 hover:from-blue-600 hover:to-cyan-500 text-white rounded-xl"
            >
              Volver al Login
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-400 mb-4 shadow-2xl shadow-blue-500/50">
            <span className="text-3xl">🌐</span>
          </div>
          <h1 className="text-4xl text-white mb-2">Recuperar Contraseña</h1>
          <p className="text-blue-300">Ingresa tu email para recuperar tu cuenta</p>
        </div>

        {/* Form */}
        <div className="bg-white/10 backdrop-blur-xl rounded-3xl p-8 shadow-2xl border border-white/20">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label className="text-white">Email</Label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-blue-300" />
                <Input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="tu@email.com"
                  className="pl-12 bg-white/5 border-white/10 text-white placeholder:text-blue-300/50 h-14 rounded-xl focus:border-blue-400 focus:ring-blue-400"
                  required
                />
              </div>
            </div>

            <div className="space-y-4 pt-4">
              <Button
                type="submit"
                className="w-full h-14 bg-gradient-to-r from-blue-500 to-cyan-400 hover:from-blue-600 hover:to-cyan-500 text-white rounded-xl text-lg shadow-lg shadow-blue-500/50"
              >
                Enviar Enlace de Recuperación
              </Button>

              <Button
                type="button"
                onClick={onBack}
                variant="outline"
                className="w-full h-12 border-white/20 text-white hover:bg-white/10 rounded-xl"
              >
                <ArrowLeft className="w-5 h-5 mr-2" />
                Volver al Login
              </Button>
            </div>
          </form>

          <div className="mt-6 p-4 bg-blue-500/20 rounded-xl border border-blue-400/30">
            <p className="text-blue-200 text-sm">
              Si no recibes el email en unos minutos, revisa tu carpeta de spam o contacta a soporte.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
