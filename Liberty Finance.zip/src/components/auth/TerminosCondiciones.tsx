import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '../ui/dialog';
import { ScrollArea } from '../ui/scroll-area';

interface TerminosCondicionesProps {
  isOpen: boolean;
  onClose: () => void;
}

export function TerminosCondiciones({ isOpen, onClose }: TerminosCondicionesProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="text-2xl text-primary">
            Términos y Condiciones - Liberty Finance
          </DialogTitle>
          <DialogDescription>
            Por favor, lea cuidadosamente estos términos y condiciones antes de utilizar nuestros servicios.
          </DialogDescription>
        </DialogHeader>
        
        <ScrollArea className="h-[calc(90vh-120px)] pr-4">
          <div className="space-y-6 text-sm">
            {/* 1. ACEPTACIÓN DE LOS TÉRMINOS */}
            <section>
              <h3 className="font-bold text-primary mb-2">1. ACEPTACIÓN DE LOS TÉRMINOS</h3>
              <div className="space-y-2 text-slate-700">
                <p><strong>1.1.</strong> La presente normativa regula el uso de los servicios proporcionados por Liberty Finance, plataforma dedicada a la gestión de paquetes de inversión y a la participación en un plan de marketing multinivel.</p>
                <p><strong>1.2.</strong> Al registrarse, el usuario declara haber leído, comprendido y aceptado plenamente estos Términos y Condiciones, sin reservas ni limitaciones.</p>
                <p><strong>1.3.</strong> Liberty Finance se reserva el derecho de actualizar, modificar o reemplazar estos Términos en cualquier momento, notificándolo mediante canales oficiales.</p>
                <p><strong>1.4.</strong> El uso continuo de la plataforma tras una actualización constituye la aceptación automática de los cambios.</p>
              </div>
            </section>

            {/* 2. NATURALEZA DEL SERVICIO */}
            <section>
              <h3 className="font-bold text-primary mb-2">2. NATURALEZA DEL SERVICIO</h3>
              <div className="space-y-2 text-slate-700">
                <p><strong>2.1.</strong> Liberty Finance ofrece un sistema de paquetes de inversión que generan rendimientos variables a través de operativa con CFDs (Contratos por Diferencia), instrumentos financieros apalancados de alto riesgo.</p>
                <p><strong>2.2.</strong> El modelo incorpora un plan de marketing multinivel (MLM) con bonificaciones en matriz 3×3 hasta 10 niveles.</p>
                <p><strong>2.3.</strong> Liberty Finance no es un banco, no ofrece productos de ahorro regulados, ni garantiza rentabilidades fijas.</p>
                <p><strong>2.4.</strong> La empresa no brinda asesoría financiera ni recomendaciones de inversión.</p>
                <p><strong>2.5.</strong> El usuario acepta que los rendimientos dependen de condiciones de mercado y pueden variar o suspenderse temporalmente.</p>
              </div>
            </section>

            {/* 3. POLÍTICA DE PAQUETE ÚNICO ACTIVO */}
            <section>
              <h3 className="font-bold text-primary mb-2">3. POLÍTICA DE PAQUETE ÚNICO ACTIVO</h3>
              <div className="space-y-2 text-slate-700">
                <p><strong>3.1.</strong> Cada usuario solo puede poseer un (1) paquete activo a la vez.</p>
                <p><strong>3.2.</strong> El paquete debe completar su ciclo del 200% para ser cerrado.</p>
                <p><strong>3.3.</strong> Solo al concluir el ciclo, el usuario podrá adquirir un nuevo paquete.</p>
                <p><strong>3.4.</strong> El nuevo paquete debe ser de igual o mayor valor que el anterior.</p>
                <p><strong>3.5.</strong> Esta política garantiza el equilibrio financiero y evita sobreexposición.</p>
              </div>
            </section>

            {/* 4. RENDIMIENTO DIARIO VARIABLE */}
            <section>
              <h3 className="font-bold text-primary mb-2">4. RENDIMIENTO DIARIO VARIABLE – HASTA 1%</h3>
              <div className="space-y-2 text-slate-700">
                <p><strong>4.1.</strong> Los paquetes generan un rendimiento variable con un máximo del 1% diario.</p>
                <p><strong>4.2.</strong> Los rendimientos no son fijos y pueden variar según condiciones internas y externas.</p>
                <p><strong>4.3.</strong> Puede haber días con rendimientos menores o incluso nulos debido a volatilidad o gestión de riesgo.</p>
                <p><strong>4.4.</strong> La plataforma no está obligada a revelar estrategias operativas, algoritmos ni posiciones del mercado.</p>
              </div>
            </section>

            {/* 5. CICLO DEL PAQUETE */}
            <section>
              <h3 className="font-bold text-primary mb-2">5. CICLO DEL PAQUETE – TOPE DEL 200%</h3>
              <div className="space-y-2 text-slate-700">
                <p><strong>5.1.</strong> Cada paquete tiene un ciclo máximo de 200%, compuesto por:</p>
                <ul className="list-disc ml-6 space-y-1">
                  <li>100% capital inicial</li>
                  <li>100% ganancia acumulada</li>
                </ul>
                <p><strong>5.2.</strong> Una vez alcanzado este límite, el sistema cierra automáticamente el paquete.</p>
                <p><strong>5.3.</strong> El usuario puede retirar las ganancias o adquirir un nuevo paquete que cumpla las políticas vigentes.</p>
                <p><strong>5.4.</strong> El límite del 200% protege la sostenibilidad del sistema y su liquidez operativa.</p>
              </div>
            </section>

            {/* 6. RETIROS DE FONDOS */}
            <section>
              <h3 className="font-bold text-primary mb-2">6. RETIROS DE FONDOS</h3>
              <div className="space-y-2 text-slate-700">
                <p><strong>6.1.</strong> Los retiros se procesan según las políticas internas y disponibilidad de liquidez.</p>
                <p><strong>6.2.</strong> Pueden aplicarse mínimos, máximos y comisiones administrativas o blockchain.</p>
                <p><strong>6.3.</strong> Los tiempos de procesamiento pueden variar por auditorías, demanda o seguridad.</p>
                <p><strong>6.4.</strong> Los errores en la dirección de retiro son responsabilidad exclusiva del usuario.</p>
                <p><strong>6.5.</strong> Liberty Finance no garantiza retiros inmediatos en periodos de alta volatilidad o mantenimiento.</p>
              </div>
            </section>

            {/* 7. BONO DIRECTO */}
            <section>
              <h3 className="font-bold text-primary mb-2">7. BONO DIRECTO – 10%</h3>
              <div className="space-y-2 text-slate-700">
                <p><strong>7.1.</strong> El usuario recibe un 10% por cada paquete adquirido por un referido directo.</p>
                <p><strong>7.2.</strong> Este bono se acredita inmediatamente.</p>
                <p><strong>7.3.</strong> El usuario debe tener un paquete activo para calificar.</p>
                <p><strong>7.4.</strong> Este bono es independiente del bono matriz.</p>
              </div>
            </section>

            {/* 8. BONO MATRIZ */}
            <section>
              <h3 className="font-bold text-primary mb-2">8. BONO MATRIZ 3×3 – HASTA 10 NIVELES</h3>
              <div className="space-y-2 text-slate-700">
                <p><strong>8.1.</strong> El sistema de matriz 3×3 permite obtener comisiones por compras de paquetes dentro de la estructura.</p>
                <p><strong>8.2.</strong> Los porcentajes son:</p>
                <ul className="list-disc ml-6 space-y-1">
                  <li>Nivel 1 → 8%</li>
                  <li>Nivel 2 → 6%</li>
                  <li>Nivel 3 → 4%</li>
                  <li>Nivel 4 → 2%</li>
                  <li>Niveles 5 al 8 → 1%</li>
                  <li>Niveles 9 y 10 → 0.5%</li>
                </ul>
                <p><strong>8.3.</strong> Los usuarios pueden ingresar a la matriz por referidos directos, indirectos o derrame automático.</p>
                <p><strong>8.4.</strong> Los bonos se calculan por cada compra y no reemplazan al bono directo.</p>
              </div>
            </section>

            {/* 9. SISTEMA DE DERRAME */}
            <section>
              <h3 className="font-bold text-primary mb-2">9. SISTEMA DE DERRAME AUTOMÁTICO (SPILLOVER)</h3>
              <div className="space-y-2 text-slate-700">
                <p><strong>9.1.</strong> Cada usuario puede tener solo tres (3) directos en su primer nivel personal.</p>
                <p><strong>9.2.</strong> A partir del cuarto directo, el sistema colocará automáticamente al nuevo referido en el primer espacio disponible de la matriz 3×3.</p>
                <p><strong>9.3.</strong> El derrame no puede ser manipulado ni ubicado manualmente.</p>
                <p><strong>9.4.</strong> Este sistema beneficia a todos los niveles mediante comisiones adicionales.</p>
                <p><strong>9.5.</strong> El objetivo es distribuir el crecimiento de manera equitativa.</p>
              </div>
            </section>

            {/* 10. GANANCIAS DE MATRIZ */}
            <section>
              <h3 className="font-bold text-primary mb-2">10. LAS GANANCIAS DE LA MATRIZ FORMAN PARTE DEL CICLO DEL 200%</h3>
              <div className="space-y-2 text-slate-700">
                <p><strong>10.1.</strong> Todas las comisiones generadas en la matriz, en cualquiera de los 10 niveles, forman parte del rendimiento total del paquete activo.</p>
                <p><strong>10.2.</strong> Estas ganancias se suman a los rendimientos diarios variables del sistema de inversión.</p>
                <p><strong>10.3.</strong> Las comisiones de matriz aceleran la llegada al ciclo del 200%, ya que incrementan el total acumulado del paquete activo.</p>
                <p><strong>10.4.</strong> Una vez que el conjunto de rendimientos + ganancias de matriz alcanza el 200%, el paquete se cierra automáticamente.</p>
                <p><strong>10.5.</strong> El usuario entiende que la matriz es un mecanismo complementario de crecimiento del ciclo, no un ingreso independiente.</p>
              </div>
            </section>

            {/* 11. REQUISITOS PARA COMISIONES */}
            <section>
              <h3 className="font-bold text-primary mb-2">11. REQUISITOS PARA RECIBIR COMISIONES</h3>
              <div className="space-y-2 text-slate-700">
                <p><strong>11.1.</strong> El usuario debe tener un paquete activo.</p>
                <p><strong>11.2.</strong> Debe estar en cumplimiento total de estos términos.</p>
                <p><strong>11.3.</strong> No se permiten cuentas duplicadas, bots ni manipulación del sistema.</p>
                <p><strong>11.4.</strong> Las comisiones pueden ser suspendidas durante auditorías internas o revisiones de seguridad.</p>
              </div>
            </section>

            {/* 12. PROHIBICIONES */}
            <section>
              <h3 className="font-bold text-primary mb-2">12. PROHIBICIONES</h3>
              <div className="space-y-2 text-slate-700">
                <p><strong>12.1.</strong> Queda estrictamente prohibido:</p>
                <ul className="list-disc ml-6 space-y-1">
                  <li>Crear múltiples cuentas personales</li>
                  <li>Engañar o manipular el sistema</li>
                  <li>Ofrecer rentabilidad garantizada a terceros</li>
                  <li>Utilizar la plataforma para actividades ilegales</li>
                  <li>Divulgar información falsa o distorsionada</li>
                </ul>
                <p><strong>12.2.</strong> El incumplimiento puede llevar al cierre permanente de la cuenta y pérdida de beneficios.</p>
              </div>
            </section>

            {/* 13. INVERSIONES DE ALTO RIESGO */}
            <section>
              <h3 className="font-bold text-primary mb-2">13. INVERSIONES DE ALTO RIESGO Y POSIBLE PÉRDIDA TOTAL DEL CAPITAL</h3>
              <div className="space-y-2 text-slate-700">
                <p><strong>13.1.</strong> El usuario reconoce que invertir en mercados financieros, particularmente mediante CFDs, es una actividad de ALTO RIESGO.</p>
                <p><strong>13.2.</strong> Los CFDs usan apalancamiento, lo cual puede generar ganancias rápidas, pero también pérdidas significativas.</p>
                <p><strong>13.3.</strong> Al aceptar estos términos, el usuario admite plenamente que puede perder parcial o totalmente su inversión.</p>
                <p><strong>13.4.</strong> Liberty Finance no garantiza resultados, no asegura retorno de capital ni establece rentabilidad fija.</p>
                <p><strong>13.5.</strong> Cualquier operación puede resultar en disminución del capital por condiciones del mercado.</p>
              </div>
            </section>

            {/* 14. RESPONSABILIDADES DEL USUARIO */}
            <section>
              <h3 className="font-bold text-primary mb-2">14. RESPONSABILIDADES DEL USUARIO</h3>
              <div className="space-y-2 text-slate-700">
                <p><strong>14.1.</strong> Mantener la seguridad de su cuenta y credenciales.</p>
                <p><strong>14.2.</strong> Proporcionar información real, verificable y actualizada.</p>
                <p><strong>14.3.</strong> Enviar fondos únicamente a direcciones oficiales.</p>
                <p><strong>14.4.</strong> Ser consciente de los riesgos financieros antes de invertir.</p>
                <p><strong>14.5.</strong> Cumplir con las leyes locales relacionadas al uso de plataformas digitales.</p>
              </div>
            </section>

            {/* 15. MODIFICACIÓN DEL PROGRAMA */}
            <section>
              <h3 className="font-bold text-primary mb-2">15. MODIFICACIÓN DEL PROGRAMA</h3>
              <div className="space-y-2 text-slate-700">
                <p><strong>15.1.</strong> Liberty Finance podrá modificar políticas, porcentajes, comisiones o dinámicas operativas sin previo aviso en caso de que las condiciones de mercado lo requieran.</p>
                <p><strong>15.2.</strong> Los cambios serán comunicados a través de canales oficiales.</p>
                <p><strong>15.3.</strong> La continuidad del uso implica aceptación total.</p>
              </div>
            </section>

            {/* 16. LIMITACIÓN DE RESPONSABILIDAD */}
            <section>
              <h3 className="font-bold text-primary mb-2">16. LIMITACIÓN DE RESPONSABILIDAD</h3>
              <div className="space-y-2 text-slate-700">
                <p><strong>16.1.</strong> Liberty Finance no será responsable por:</p>
                <ul className="list-disc ml-6 space-y-1">
                  <li>Pérdidas generadas por volatilidad del mercado</li>
                  <li>Fallas externas en brokers, wallets o procesadores de pago</li>
                  <li>Errores cometidos por el usuario</li>
                  <li>Fallos temporales del sistema</li>
                  <li>Fuerza mayor, ataques cibernéticos u otros eventos fuera de control</li>
                </ul>
                <p><strong>16.2.</strong> El usuario asume el riesgo total de participar voluntariamente.</p>
              </div>
            </section>

            {/* 17. SUSPENSIÓN O CIERRE */}
            <section>
              <h3 className="font-bold text-primary mb-2">17. SUSPENSIÓN O CIERRE DE CUENTA</h3>
              <div className="space-y-2 text-slate-700">
                <p><strong>17.1.</strong> La empresa podrá suspender o cerrar cuentas por:</p>
                <ul className="list-disc ml-6 space-y-1">
                  <li>Fraude</li>
                  <li>Actividades ilícitas</li>
                  <li>Duplicación de cuentas</li>
                  <li>Incumplimiento de términos</li>
                </ul>
                <p><strong>17.2.</strong> Los fondos relacionados con actividades sospechosas pueden ser congelados para investigación.</p>
              </div>
            </section>

            {/* 18. POLÍTICA DE NO REEMBOLSOS */}
            <section>
              <h3 className="font-bold text-primary mb-2">18. POLÍTICA DE NO REEMBOLSOS</h3>
              <div className="space-y-2 text-slate-700">
                <p><strong>18.1.</strong> Las inversiones realizadas no son reembolsables, dado que el capital se integra directamente a la operativa financiera.</p>
                <p><strong>18.2.</strong> El usuario debe evaluar cuidadosamente antes de invertir.</p>
              </div>
            </section>

            {/* 19. JURISDICCIÓN */}
            <section>
              <h3 className="font-bold text-primary mb-2">19. JURISDICCIÓN Y LEY APLICABLE</h3>
              <div className="space-y-2 text-slate-700">
                <p><strong>19.1.</strong> Este documento se rige por normativa internacional de comercio digital.</p>
                <p><strong>19.2.</strong> Cualquier disputa será resuelta mediante arbitraje o instancias legales designadas por la empresa.</p>
              </div>
            </section>

            {/* 20. ACEPTACIÓN FINAL */}
            <section>
              <h3 className="font-bold text-primary mb-2">20. ACEPTACIÓN FINAL</h3>
              <div className="space-y-2 text-slate-700">
                <p>Al registrarse y participar en la plataforma, el usuario declara haber leído y aceptado voluntariamente todos los puntos establecidos en este documento.</p>
              </div>
            </section>

            {/* Footer */}
            <div className="pt-6 border-t border-slate-200">
              <p className="text-slate-600 text-xs mb-4">
                <strong>Última actualización:</strong> Noviembre 19, 2025
              </p>
              <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                <p className="text-blue-900 text-sm">
                  Al hacer clic en <strong>"Acepto los términos y condiciones"</strong> durante el registro, usted confirma que ha leído, comprendido y aceptado estar legalmente vinculado por estos Términos y Condiciones.
                </p>
              </div>
            </div>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
