import { UserData } from '../data/mockData';
import { Card } from './ui/card';
import { Award, Users, DollarSign, Check, Lock, Trophy } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { useState, useEffect, useMemo } from 'react';
import { rangosAPI, callServer } from '../utils/api';

interface RangosProps {
  userData: UserData;
}

interface Rango {
  id: string;
  nombre: string;
  directos: number;
  volumen: number;
  premio: string;
  color: string;
  gradient: string;
  icon: string;
  imagen: string;
}

export function Rangos({ userData }: RangosProps) {
  const [rangos, setRangos] = useState<Rango[]>([]);
  const [loading, setLoading] = useState(true);
  const [referidosDirectosReales, setReferidosDirectosReales] = useState<any[]>([]);

  useEffect(() => {
    cargarRangos();
    cargarReferidosDirectos();
  }, []);
  
  const cargarReferidosDirectos = async () => {
    if (!userData.id) return;
    try {
      const directosReales = await callServer(`/users/${userData.id}/referidos`, 'GET');
      setReferidosDirectosReales(directosReales || []);
      console.log('✅ [Rangos] Referidos directos reales cargados:', directosReales.length);
    } catch (err) {
      console.warn('⚠️ [Rangos] No se pudieron cargar referidos directos');
    }
  };

  const cargarRangos = async () => {
    try {
      const data = await rangosAPI.getAll();
      setRangos(data);
    } catch (error) {
      console.error('Error al cargar rangos:', error);
    } finally {
      setLoading(false);
    }
  };

  const rangoActualIndex = rangos.findIndex(r => r.nombre === userData.rango);
  
  // CALCULAR REFERIDOS DIRECTOS CON INVERSIÓN (PACK ACTIVO)
  // IMPORTANTE: Contar SOLO los referidos directos reales (nivel 1) que tienen pack activo
  const directosActuales = useMemo(() => {
    // ✅ CORREGIDO: Usar userData.directosConPack del backend (ya calculado correctamente)
    if (userData.directosConPack !== undefined) {
      console.log('✅ [Rangos] Usando directosConPack del backend:', userData.directosConPack);
      return userData.directosConPack;
    }
    
    // Fallback: calcular localmente solo si el backend no lo envió
    console.log('⚠️ [Rangos] Calculando directosActuales localmente (fallback)');
    if (!referidosDirectosReales.length) return 0;
    return referidosDirectosReales.filter((d: any) => {
      // Buscar en userData.directos para ver si tiene inversión
      const refEnDatos = userData.directos.find((ud: any) => ud.id_unico === d.id_unico);
      return refEnDatos && refEnDatos.inversion > 0;
    }).length;
  }, [userData.directosConPack, referidosDirectosReales, userData.directos]);
  
  // Calcular volumen de TODOS (directos + indirectos) con inversión histórica
  const volumenActual = userData.directos
    .reduce((sum: number, d: any) => sum + (d.inversion || 0), 0);

  // Regla de negocio: Si tiene menos de 3 directos, no tiene rango (es "Sin Rango")
  const isSinRango = directosActuales < 3;

  const verificarRango = (rango: Rango, index: number) => {
    return directosActuales >= rango.directos && volumenActual >= rango.volumen;
  };

  const calcularProgreso = (rango: Rango) => {
    const progresoDirectos = rango.directos > 0 ? Math.min((directosActuales / rango.directos) * 100, 100) : 100;
    const progresoVolumen = rango.volumen > 0 ? Math.min((volumenActual / rango.volumen) * 100, 100) : 100;
    return Math.min(progresoDirectos, progresoVolumen);
  };
  
  const renderIcon = (icon: string | undefined, alt: string) => {
    if (!icon) return <span className="text-3xl">⭐</span>;
    
    // Si es imagen (data, http, o cadena larga que parece base64)
    if (icon.startsWith('data:image') || icon.startsWith('http') || icon.length > 20) {
      return (
        <ImageWithFallback
          src={icon}
          alt={alt}
          className="w-full h-full object-cover"
        />
      );
    }
    
    // Emoji
    return <span className="text-3xl">{icon}</span>;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-600 to-blue-700 flex items-center justify-center shadow-lg">
          <Trophy className="w-6 h-6 text-white" />
        </div>
        <div>
          <h1 className="text-3xl font-bold text-slate-500">Rangos y Categorías</h1>
          <p className="text-slate-600 font-medium">Tu progreso en el sistema multinivel</p>
        </div>
      </div>

      {/* Rango Actual */}
      <Card className="p-6">
        <div className="flex items-center justify-between p-4 bg-[#e0f2fe] rounded-xl border-2 border-primary/20">
          <div className="flex items-center gap-3">
            <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center text-3xl border-2 border-primary overflow-hidden">
              {isSinRango ? (
                <span className="text-3xl">⭐</span>
              ) : (
                renderIcon(rangos[rangoActualIndex]?.icon, rangos[rangoActualIndex]?.nombre || 'Rango')
              )}
            </div>
            <div>
              <p className="text-slate-600 text-sm">Tu Rango Actual</p>
              <h2 className="text-2xl text-primary">{isSinRango ? 'Sin Rango' : (userData.rango || 'Sin Rango')}</h2>
            </div>
          </div>
          <Award className="w-12 h-12 text-primary/30" />
        </div>
        
        <div className="grid grid-cols-2 gap-4 mt-6">
          <div className="p-4 bg-[#e0f2fe] rounded-xl border-2 border-primary/20">
            <div className="flex items-center gap-2 mb-1">
              <Users className="w-4 h-4 text-primary" />
              <p className="text-slate-600 text-xs">Referidos Directos</p>
            </div>
            <p className="text-2xl text-primary">{directosActuales}</p>
          </div>
          <div className="p-4 bg-[#e0f2fe] rounded-xl border-2 border-primary/20">
            <div className="flex items-center gap-2 mb-1">
              <DollarSign className="w-4 h-4 text-primary" />
              <p className="text-slate-600 text-xs">Volumen de Red</p>
            </div>
            <p className="text-2xl text-primary">${(volumenActual / 1000).toFixed(0)}K</p>
          </div>
        </div>
      </Card>

      {/* Todos los Rangos */}
      <div className="space-y-4">
        <h3 className="text-slate-800 text-xl">Todos los Rangos</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {rangos.map((rango, index) => {
            const alcanzado = verificarRango(rango, index);
            const esActual = rango.nombre === userData.rango;
            const progreso = calcularProgreso(rango);

            return (
              <Card
                key={rango.nombre}
                className={`relative overflow-hidden transition-all hover:shadow-lg ${
                  esActual
                    ? 'border-2 border-blue-600'
                    : alcanzado
                    ? 'border-slate-200'
                    : 'border-slate-200'
                }`}
              >
                {/* Imagen de Fondo */}
                <div className="absolute inset-0 z-0">
                  <ImageWithFallback
                    src={rango.imagen}
                    alt={rango.nombre}
                    className="w-full h-full object-cover"
                  />
                  {/* Overlay con gradiente - Reducido para ver más la imagen */}
                  <div className={`absolute inset-0 bg-gradient-to-br ${rango.gradient} ${alcanzado ? 'opacity-40' : 'opacity-50'}`}></div>
                </div>

                {/* Contenido */}
                <div className="relative z-10 p-5">
                  <div className="flex items-start gap-4">
                    {/* Icon */}
                    <div className={`w-14 h-14 rounded-xl bg-white/30 backdrop-blur-sm flex items-center justify-center text-2xl shrink-0 border-2 border-white/50 overflow-hidden`}>
                      {renderIcon(rango.icon, rango.nombre)}
                    </div>

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2">
                        <h4 className="text-white text-lg drop-shadow-lg">{rango.nombre}</h4>
                        {alcanzado && (
                          <div className="w-6 h-6 rounded-full bg-white flex items-center justify-center">
                            <Check className="w-4 h-4 text-blue-600" />
                          </div>
                        )}
                        {!alcanzado && (
                          <Lock className="w-5 h-5 text-white/70" />
                        )}
                        {esActual && (
                          <span className="px-2 py-1 bg-white text-blue-600 text-xs rounded-lg font-semibold">
                            Actual
                          </span>
                        )}
                      </div>

                      {/* Requisitos */}
                      <div className="space-y-1 mb-3">
                        <div className="flex items-center gap-2 text-sm">
                          <Users className="w-4 h-4 text-white" />
                          <span className="text-white drop-shadow">
                            {rango.directos} Referidos Directos
                          </span>
                          {directosActuales >= rango.directos && (
                            <Check className="w-4 h-4 text-white" />
                          )}
                        </div>
                        <div className="flex items-center gap-2 text-sm">
                          <DollarSign className="w-4 h-4 text-white" />
                          <span className="text-white drop-shadow">
                            ${rango.volumen.toLocaleString()} Volumen
                          </span>
                          {volumenActual >= rango.volumen && (
                            <Check className="w-4 h-4 text-white" />
                          )}
                        </div>
                      </div>

                      {/* Premio */}
                      <div className="p-3 rounded-lg bg-white/90 backdrop-blur-sm border border-white/50">
                        <p className="text-xs text-slate-600 mb-1">Premio</p>
                        <p className="text-sm text-slate-800 font-semibold">
                          🎁 {rango.premio}
                        </p>
                      </div>

                      {/* Barra de Progreso */}
                      {!alcanzado && (
                        <div className="mt-3">
                          <div className="flex justify-between items-center mb-1">
                            <span className="text-xs text-white drop-shadow">Progreso</span>
                            <span className="text-xs text-white drop-shadow font-semibold">{progreso.toFixed(0)}%</span>
                          </div>
                          <div className="h-2 bg-white/30 rounded-full overflow-hidden backdrop-blur-sm">
                            <div
                              className="h-full bg-white rounded-full transition-all shadow-lg"
                              style={{ width: `${progreso}%` }}
                            ></div>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Info */}
      <Card className="p-6 bg-gradient-to-br from-slate-800 to-slate-900 border-0 text-white">
        <h3 className="text-lg mb-4">📋 Información Importante</h3>
        <ul className="space-y-2 text-sm text-white/80">
          <li className="flex items-start gap-2">
            <span className="text-blue-400 shrink-0">•</span>
            <span>Los rangos se alcanzan cumpliendo ambos requisitos: número de referidos directos y volumen de red.</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-blue-400 shrink-0">•</span>
            <span>El volumen de red incluye todas las inversiones de tu red multinivel (10 niveles).</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-blue-400 shrink-0">•</span>
            <span>Los premios se entregan automáticamente al alcanzar cada rango.</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-blue-400 shrink-0">•</span>
            <span>Puedes mantener tu rango invitando más personas y aumentando el volumen de tu red.</span>
          </li>
        </ul>
      </Card>
    </div>
  );
}