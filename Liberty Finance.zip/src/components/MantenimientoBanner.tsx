import { useState, useEffect } from 'react';
import { AlertTriangle, Clock } from 'lucide-react';
import logoImage from 'figma:asset/ae011bd8c8ee731107978c5fe892f24a22d34163.png';

export function MantenimientoBanner() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const checkMantenimiento = () => {
      // MANTENIMIENTO DESACTIVADO - Banner oculto permanentemente
      setIsVisible(false);
      
      /* CÓDIGO ANTERIOR PARA REACTIVAR SI ES NECESARIO:
      const ahora = new Date();
      
      // Fecha y hora de inicio: 20 de diciembre de 2025, 00:30 AM
      const inicioMantenimiento = new Date('2025-12-20T00:30:00');
      
      // Fecha y hora de fin: 20 de diciembre de 2025, 04:30 AM
      const finMantenimiento = new Date('2025-12-20T04:30:00');
      
      // Verificar si estamos dentro del período de mantenimiento
      const enMantenimiento = ahora >= inicioMantenimiento && ahora < finMantenimiento;
      
      setIsVisible(enMantenimiento);
      */
    };

    // Verificar inmediatamente
    checkMantenimiento();

    // Verificar cada minuto por si cambia el estado
    const interval = setInterval(checkMantenimiento, 60000);

    return () => clearInterval(interval);
  }, []);

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 z-[9999] bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center p-4">
      <div className="max-w-2xl w-full">
        {/* Logo */}
        <div className="flex justify-center mb-8">
          <div className="bg-white rounded-3xl p-8 shadow-2xl animate-pulse">
            <img 
              src={logoImage} 
              alt="Liberty Finance" 
              className="h-24 w-auto"
            />
          </div>
        </div>

        {/* Card de Mantenimiento */}
        <div className="bg-white rounded-3xl shadow-2xl overflow-hidden">
          {/* Header con gradiente */}
          <div className="bg-gradient-to-r from-amber-500 to-orange-500 p-6 text-center">
            <div className="flex items-center justify-center gap-3 mb-2">
              <AlertTriangle className="w-8 h-8 text-white animate-bounce" />
              <h1 className="text-3xl text-white">Mantenimiento Programado</h1>
            </div>
          </div>

          {/* Contenido */}
          <div className="p-8 text-center">
            <div className="mb-6">
              <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-amber-100 mb-4">
                <Clock className="w-10 h-10 text-amber-600" />
              </div>
              <h2 className="text-2xl text-slate-800 mb-4">
                La plataforma de <span className="font-bold bg-gradient-to-r from-blue-600 to-cyan-500 bg-clip-text text-transparent">LIBERTY FINANCE</span> se encuentra en mantenimiento
              </h2>
            </div>

            <div className="space-y-4 mb-6">
              <div className="p-4 bg-slate-50 rounded-xl border-2 border-slate-200">
                <p className="text-slate-700 mb-2">
                  <span className="font-semibold">Horario de Mantenimiento:</span>
                </p>
                <p className="text-2xl text-slate-900">
                  <span className="font-bold text-amber-600">00:30 AM</span>
                  <span className="mx-3">→</span>
                  <span className="font-bold text-green-600">04:30 AM</span>
                </p>
                <p className="text-sm text-slate-600 mt-2">
                  20 de Diciembre de 2025
                </p>
              </div>

              <div className="p-4 bg-blue-50 rounded-xl border-2 border-blue-200">
                <p className="text-blue-800">
                  ⏰ <strong>Estaremos de vuelta a las 4:30 AM</strong>
                </p>
                <p className="text-sm text-blue-700 mt-1">
                  Estamos mejorando nuestros sistemas para servirte mejor
                </p>
              </div>
            </div>

            <div className="space-y-2 text-sm text-slate-600">
              <p>Disculpa las molestias ocasionadas.</p>
              <p className="font-semibold text-slate-800">
                Gracias por tu paciencia 🙏
              </p>
            </div>
          </div>

          {/* Footer */}
          <div className="bg-slate-50 p-4 text-center border-t">
            <p className="text-xs text-slate-500">
              Liberty Finance © 2025 - Inversiones Seguras
            </p>
          </div>
        </div>

        {/* Mensaje adicional */}
        <div className="mt-6 text-center">
          <p className="text-white text-sm opacity-80">
            Si tienes alguna urgencia, por favor contacta a soporte después del mantenimiento
          </p>
        </div>
      </div>
    </div>
  );
}