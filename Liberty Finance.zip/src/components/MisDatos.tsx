import { UserData } from '../data/mockData';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { MapPin, Mail, Wallet, Lock, Edit2, User, Shield, TrendingUp, Copy, Check } from 'lucide-react';
import { useState } from 'react';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { toast } from 'sonner@2.0.3';

interface MisDatosProps {
  userData: UserData;
  updateUserData: (field: string, value: string) => void;
}

export function MisDatos({ userData, updateUserData }: MisDatosProps) {
  const [editing, setEditing] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [formValues, setFormValues] = useState({
    ciudad: userData.ciudad,
    correo: userData.correo,
    wallet: userData.wallet,
    password: ''
  });

  const handleEdit = (field: string) => {
    setEditing(field);
  };

  const handleCopyIdUnico = () => {
    navigator.clipboard.writeText(userData.id_unico);
    setCopied(true);
    toast.success('ID Único copiado al portapapeles');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSave = (field: string) => {
    if (formValues[field as keyof typeof formValues]) {
      updateUserData(field, formValues[field as keyof typeof formValues]);
      setEditing(null);
      
      // Reset password field after save
      if (field === 'password') {
        setFormValues(prev => ({ ...prev, password: '' }));
      }
    }
  };

  const handleCancel = () => {
    setFormValues({
      ciudad: userData.ciudad,
      correo: userData.correo,
      wallet: userData.wallet,
      password: ''
    });
    setEditing(null);
  };

  const fields = [
    {
      id: 'ciudad',
      label: 'Ciudad',
      icon: MapPin,
      value: userData.ciudad,
      type: 'text',
      color: 'blue'
    },
    {
      id: 'correo',
      label: 'Correo Electrónico',
      icon: Mail,
      value: userData.correo,
      type: 'email',
      color: 'slate'
    },
    {
      id: 'wallet',
      label: 'Wallet (USDT)',
      icon: Wallet,
      value: userData.wallet,
      type: 'text',
      color: 'darkblue'
    },
    {
      id: 'password',
      label: 'Contraseña',
      icon: Lock,
      value: '••••••••',
      type: 'password',
      color: 'dark'
    }
  ];

  const getColorClasses = (color: string) => {
    const colors: Record<string, { bg: string; text: string; iconBg: string }> = {
      blue: { bg: 'from-blue-50 to-blue-100', text: 'text-blue-600', iconBg: 'bg-blue-100' },
      slate: { bg: 'from-slate-50 to-slate-100', text: 'text-slate-700', iconBg: 'bg-slate-100' },
      darkblue: { bg: 'from-blue-900/10 to-blue-800/10', text: 'text-blue-700', iconBg: 'bg-blue-100' },
      dark: { bg: 'from-slate-900/10 to-slate-800/10', text: 'text-slate-800', iconBg: 'bg-slate-100' }
    };
    return colors[color];
  };

  // Calcular ganancia total vs inversión
  const gananciaTotal = userData.rendimiento_diario + userData.comisiones_red;
  const inversion = userData.cantidad || 0; // Mostrar 0 si no hay inversión
  const porcentajeGanancia = inversion > 0 ? (gananciaTotal / inversion) * 100 : 0;
  const porcentajeLimitado = Math.min(porcentajeGanancia, 100); // Máximo 100%

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-600 to-blue-700 flex items-center justify-center shadow-lg">
          <User className="w-6 h-6 text-white" />
        </div>
        <div>
          <h1 className="text-3xl font-bold text-slate-500">Mis Datos</h1>
          <p className="text-slate-600 font-medium">Gestiona tu información personal</p>
        </div>
      </div>

      {/* User Info Card */}
      <Card className="p-6 bg-gradient-to-br from-blue-600 to-blue-700 border-0 shadow-xl text-white">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-20 h-20 rounded-full bg-white/20 flex items-center justify-center text-3xl border-4 border-white/30 backdrop-blur-sm">
              <span className="text-white">
                {userData.nombre[0]}{userData.apellido[0]}
              </span>
            </div>
            <div>
              <h2 className="text-2xl mb-1">
                {userData.nombre} {userData.apellido}
              </h2>
              <div className="flex items-center gap-2">
                <p className="text-white/80">ID: {userData.id_unico}</p>
                <button
                  onClick={handleCopyIdUnico}
                  className="p-1.5 hover:bg-white/10 rounded-lg transition-colors"
                  title="Copiar ID Único"
                >
                  {copied ? (
                    <Check className="w-4 h-4 text-green-300" />
                  ) : (
                    <Copy className="w-4 h-4 text-white/70" />
                  )}
                </button>
              </div>
              <p className="text-white/70 text-sm">Usuario: {userData.usuario}</p>
            </div>
          </div>
        </div>
      </Card>

      {/* Data Fields */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {fields.map((field) => {
          const Icon = field.icon;
          const isEditing = editing === field.id;
          const colors = getColorClasses(field.color);

          return (
            <Card key={field.id} className="p-6 bg-white border-slate-200 shadow-lg">
              <div className="flex items-start gap-4">
                <div className={`p-3 rounded-xl ${colors.iconBg}`}>
                  <Icon className={`w-5 h-5 ${colors.text}`} />
                </div>

                <div className="flex-1">
                  <Label className="text-slate-700 mb-2">{field.label}</Label>
                  
                  {isEditing ? (
                    <div className="space-y-3 mt-2">
                      <Input
                        type={field.type}
                        value={formValues[field.id as keyof typeof formValues]}
                        onChange={(e) =>
                          setFormValues((prev) => ({
                            ...prev,
                            [field.id]: e.target.value
                          }))
                        }
                        placeholder={`Ingresa tu ${field.label.toLowerCase()}`}
                        className="bg-slate-50 border-slate-300"
                      />
                      <div className="flex gap-2">
                        <Button
                          onClick={() => handleSave(field.id)}
                          className="bg-blue-600 hover:bg-blue-700 text-white"
                          size="sm"
                        >
                          Guardar
                        </Button>
                        <Button
                          onClick={handleCancel}
                          variant="outline"
                          className="border-slate-300 text-slate-700 hover:bg-slate-50"
                          size="sm"
                        >
                          Cancelar
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="mt-2">
                      <div className={`p-3 bg-gradient-to-r ${colors.bg} rounded-xl mb-2 border border-slate-200`}>
                        <p className="text-slate-800 break-all">{field.value}</p>
                      </div>
                      <Button
                        onClick={() => handleEdit(field.id)}
                        variant="ghost"
                        size="sm"
                        className="text-blue-600 hover:bg-blue-50"
                      >
                        <Edit2 className="w-4 h-4 mr-2" />
                        Editar
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Account Info */}
      <Card className="p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center">
            <User className="w-5 h-5 text-blue-600" />
          </div>
          <h3 className="text-slate-800 text-lg">Información de Cuenta</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-4 bg-[#e0f2fe] rounded-xl border-2 border-primary/20">
            <p className="text-slate-600 text-sm mb-1">Pack Actual</p>
            <p className="text-primary text-lg">{userData.pack}</p>
          </div>
          <div className="p-4 bg-[#e0f2fe] rounded-xl border-2 border-primary/20">
            <p className="text-slate-600 text-sm mb-1">Inversión</p>
            <p className="text-slate-800 text-lg">${inversion.toFixed(2)} USDT</p>
          </div>
          <div className="p-4 bg-[#e0f2fe] rounded-xl border-2 border-primary/20">
            <p className="text-slate-600 text-sm mb-1">Estado</p>
            <span
              className={`inline-block px-3 py-1 rounded-lg text-sm ${
                userData.estatus === 'activo'
                  ? 'bg-blue-100 text-blue-700 border border-blue-200'
                  : 'bg-slate-100 text-slate-700 border border-slate-200'
              }`}
            >
              {userData.estatus.toUpperCase()}
            </span>
          </div>
          <div className="p-4 bg-[#e0f2fe] rounded-xl border-2 border-primary/20">
            <p className="text-slate-600 text-sm mb-1">% Rendimiento</p>
            <p className="text-slate-800 text-lg">{userData.porcentaje_rendimiento}%</p>
          </div>
        </div>
      </Card>

      {/* Barra de Progreso de Ganancia */}
      <Card className="p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center">
            <TrendingUp className="w-5 h-5 text-blue-600" />
          </div>
          <h3 className="text-slate-800 text-lg">Progreso de Ganancia</h3>
        </div>
        
        <div className="space-y-4">
          {/* Info */}
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 bg-gradient-to-r from-blue-50 to-blue-100 rounded-xl border border-blue-200">
              <p className="text-slate-600 text-sm mb-1">Inversión Inicial</p>
              <p className="text-2xl text-blue-700">${inversion.toFixed(2)}</p>
            </div>
            <div className="p-4 bg-gradient-to-r from-slate-50 to-slate-100 rounded-xl border border-slate-200">
              <p className="text-slate-600 text-sm mb-1">Ganancia Acumulada</p>
              <p className="text-2xl text-slate-800">${gananciaTotal.toFixed(2)}</p>
            </div>
          </div>

          {/* Progress Bar */}
          <div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-slate-600">Progreso al límite (100%)</span>
              <span className={`text-sm font-semibold ${
                porcentajeGanancia >= 100 ? 'text-blue-600' : 'text-slate-700'
              }`}>
                {porcentajeLimitado.toFixed(2)}%
              </span>
            </div>
            <div className="h-4 bg-slate-200 rounded-full overflow-hidden">
              <div
                className={`h-full rounded-full transition-all duration-500 ${
                  porcentajeGanancia >= 100 
                    ? 'bg-gradient-to-r from-blue-600 to-blue-700' 
                    : 'bg-gradient-to-r from-slate-600 to-slate-700'
                }`}
                style={{ width: `${porcentajeLimitado}%` }}
              ></div>
            </div>
          </div>

          {/* Status Message */}
          {porcentajeGanancia >= 100 ? (
            <div className="p-4 bg-gradient-to-r from-blue-600 to-blue-700 rounded-xl text-white">
              <p className="text-sm">
                🎉 <span className="font-semibold">¡Felicidades!</span> Has alcanzado el 100% de ganancia sobre tu inversión.
                {porcentajeGanancia > 100 && (
                  <span> Ya superaste el límite con ${(gananciaTotal - inversion).toFixed(2)} adicionales.</span>
                )}
              </p>
              <p className="text-xs text-white/80 mt-2">
                💡 Para seguir generando ganancias, considera aumentar tu inversión con un nuevo pack.
              </p>
            </div>
          ) : (
            <div className="p-4 bg-gradient-to-r from-slate-50 to-slate-100 rounded-xl border border-slate-200">
              <p className="text-sm text-slate-700">
                📈 Te faltan <span className="font-semibold text-blue-600">${((inversion * 2) - gananciaTotal).toFixed(2)}</span> para alcanzar el 200% de rentabilidad.
              </p>
            </div>
          )}
        </div>
      </Card>

      {/* Security Notice */}
      <Card className="p-6 bg-gradient-to-br from-slate-800 to-slate-900 border-0 shadow-xl text-white">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center flex-shrink-0 backdrop-blur-sm">
            <Shield className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-lg mb-2">🔒 Seguridad</h3>
            <p className="text-white/90 text-sm">
              Mantén tu información actualizada y segura. Nunca compartas tu contraseña o 
              información de tu wallet con terceros. Liberty Finance nunca te solicitará estos 
              datos por correo o mensajes.
            </p>
          </div>
        </div>
      </Card>
    </div>
  );
}