import { UserData } from '../data/mockData';
import { Card } from './ui/card';
import { Users, TrendingUp, DollarSign, X } from 'lucide-react';
import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { Button } from './ui/button';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface MiCicloProps {
  userData: UserData;
  matrizData?: any; // ✅ NUEVO: Matriz pre-cargada desde UserDashboard
}

// Porcentajes de comisión por nivel
const COMISION_POR_NIVEL = [8, 6, 4, 2, 1, 1, 1, 1, 0.5, 0.5];

export function MiCiclo({ userData, matrizData }: MiCicloProps) {
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [showUserNetwork, setShowUserNetwork] = useState(false);
  const [loadingUserNetwork, setLoadingUserNetwork] = useState(false);
  
  // NUEVO: Estado para la matriz del usuario actual
  const [matrizUsuario, setMatrizUsuario] = useState<any>(null);
  const [loadingMatriz, setLoadingMatriz] = useState(true);
  const [referidosDirectos, setReferidosDirectos] = useState<any[]>([]);

  // NUEVO: Cargar la matriz del usuario actual al montar el componente
  useEffect(() => {
    const cargarMatrizUsuario = async () => {
      // ✅ Si ya tenemos matriz pre-cargada, usarla directamente
      if (matrizData?.userMatriz) {
        console.log('✅ [MiCiclo] Usando matriz pre-cargada desde UserDashboard');
        setMatrizUsuario(matrizData.userMatriz);
        setReferidosDirectos(matrizData.userMatriz.directos || []);
        setLoadingMatriz(false);
        return;
      }
      
      // ⚠️ Fallback: Si no hay matriz pre-cargada, cargarla ahora
      try {
        setLoadingMatriz(true);
        console.log(`🔍 [MiCiclo] Cargando matriz para usuario actual: ${userData.id}`);
        
        // OPTIMIZACIÓN CRÍTICA: Solicitar solo 3 niveles para evitar timeout
        // 3 niveles = 3+9+27 = 39 posiciones (procesamiento rápido)
        // 4 niveles = 3+9+27+81 = 120 posiciones (puede causar timeout con muchos usuarios)
        const response = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-9f68532a/users/${userData.id}/matriz?niveles=3`,
          {
            headers: {
              'Authorization': `Bearer ${publicAnonKey}`,
              'Content-Type': 'application/json'
            }
          }
        );
        
        if (!response.ok) {
          throw new Error('Error al obtener matriz del usuario');
        }
        
        const data = await response.json();
        
        console.log(`✅ [MiCiclo] Matriz cargada:`, data);
        
        setMatrizUsuario(data);
        setReferidosDirectos(data.directos || []);
        
        setLoadingMatriz(false);
      } catch (error) {
        console.error('❌ [MiCiclo] Error al cargar matriz:', error);
        setLoadingMatriz(false);
      }
    };

    if (userData?.id) {
      cargarMatrizUsuario();
    }
  }, [userData?.id, matrizData]);

  const handleUserClick = async (user: any) => {
    if (user) {
      setLoadingUserNetwork(true);
      setShowUserNetwork(true);
      
      try {
        // Consultar la matriz del usuario al backend
        // IMPORTANTE: Usar internalId (UUID) si está disponible, ya que el endpoint espera UUID.
        // Si viene de un nodo del árbol, user.id es el ID público (LF...), pero user.internalId es el UUID.
        const userIdToFetch = user.internalId || user.id;
        console.log(`🔍 Consultando matriz para usuario: ${userIdToFetch} (Display ID: ${user.id})`);
        
        const response = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-9f68532a/users/${userIdToFetch}/matriz`,
          {
            headers: {
              'Authorization': `Bearer ${publicAnonKey}`,
              'Content-Type': 'application/json'
            }
          }
        );
        
        if (!response.ok) {
          throw new Error('Error al obtener matriz del usuario');
        }
        
        const data = await response.json();
        
        // Combinar datos del usuario con su matriz
        setSelectedUser({
          ...user,
          cycle: data.cycle,
          directos: data.directos,
          inversion: data.inversion,
          pack: data.pack
        });
        
        console.log(`✅ Matriz cargada:`, data);
      } catch (error) {
        console.error('Error al cargar matriz del usuario:', error);
        // Si falla, mostrar solo con datos básicos
        setSelectedUser(user);
      } finally {
        setLoadingUserNetwork(false);
      }
    }
  };

  const renderNode = (referral: any, level: number, index: number) => {
    const isEmpty = !referral;
    
    if (isEmpty) {
      return (
        <div className="flex flex-col items-center" key={`empty-${level}-${index}`}>
          <div className="w-10 h-10 rounded-full border border-dashed border-slate-300 flex items-center justify-center bg-slate-50 hover:border-blue-400 hover:bg-blue-50 transition-all cursor-pointer">
            <span className="text-slate-400 text-xs">+</span>
          </div>
        </div>
      );
    }

    const nivelColors = [
      'from-blue-600 to-blue-700',
      'from-slate-600 to-slate-700',
      'from-blue-500 to-blue-600',
      'from-slate-500 to-slate-600',
      'from-blue-400 to-blue-500',
      'from-slate-400 to-slate-500',
      'from-blue-300 to-blue-400',
      'from-slate-300 to-slate-400',
      'from-blue-200 to-blue-300',
      'from-slate-200 to-slate-300'
    ];

    return (
      <div className="flex flex-col items-center group relative" key={`node-${level}-${index}`}>
        <div 
          onClick={() => handleUserClick(referral)}
          className={`w-10 h-10 rounded-full flex items-center justify-center text-white shadow-md hover:scale-110 hover:ring-2 hover:ring-blue-400 transition-all cursor-pointer bg-gradient-to-br ${nivelColors[level - 1] || 'from-slate-600 to-slate-700'}`}
        >
          <span className="text-xs">
            {referral.nombre[0]}{referral.apellido[0]}
          </span>
        </div>
        
        {/* Tooltip */}
        <div className="opacity-0 group-hover:opacity-100 transition-opacity absolute -top-2 left-1/2 -translate-x-1/2 -translate-y-full bg-slate-800 text-white text-xs px-3 py-2 rounded-lg shadow-xl z-10 whitespace-nowrap pointer-events-none">
          <p className="font-medium">{referral.nombre} {referral.apellido}</p>
          <p className="text-slate-300">{referral.pack}</p>
          <p className="text-slate-300">${referral.inversion}</p>
          <p className="text-blue-400 text-[10px] mt-1">Clic para ver su red</p>
        </div>
      </div>
    );
  };

  // Calcular estadísticas de niveles
  const estadisticasNiveles = () => {
    const levels = ['level1', 'level2', 'level3', 'level4', 'level5', 'level6', 'level7', 'level8', 'level9', 'level10'];
    
    // USAR LA MATRIZ CARGADA LOCALMENTE en lugar de userData.cycle
    if (!matrizUsuario) {
      return levels.map((_, index) => ({
        nivel: index + 1,
        activos: 0,
        total: 0,
        comision: COMISION_POR_NIVEL[index],
        volumen: 0,
        ganancia: 0
      }));
    }
    
    return levels.map((levelKey, index) => {
      // ✅ CORREGIDO: Acceder a matrizUsuario.cycle[levelKey]
      const level = matrizUsuario.cycle?.[levelKey];
      const activos = Array.isArray(level) ? level.filter(r => r !== null).length : 0;
      const total = Array.isArray(level) ? level.length : 0;
      const comision = COMISION_POR_NIVEL[index];
      
      let volumen = 0;
      if (Array.isArray(level)) {
        level.forEach((referral) => {
          if (referral && referral.inversion) {
            volumen += referral.inversion;
          }
        });
      }
      
      const ganancia = volumen * (comision / 100);
      
      return {
        nivel: index + 1,
        activos,
        total,
        comision,
        volumen,
        ganancia
      };
    });
  };

  const stats = estadisticasNiveles();
  
  // CORRECCIÓN: Contar usuarios únicos en la matriz (no posiciones)
  const totalRed = stats.reduce((sum, s) => {
    // s.activos cuenta las posiciones NO VACÍAS en cada nivel
    // Esto es correcto para la matriz visual
    return sum + s.activos;
  }, 0);

  // 🔥 CORREGIDO: Usar SOLO el pack activo, NO la inversión total histórica
  const inversion = userData.packMonto || 0; // Monto del PACK ACTIVO actual
  
  // 🔥 CORREGIDO: Usar LA MISMA lógica que UserHome.tsx
  // userData.ganancia_acumulada YA incluye TODAS las comisiones del pack activo
  // (rendimientos + comisiones de red + patrocinio + rangos)
  const gananciaTotalGenerada = userData.ganancia_acumulada || 
    ((userData.comisiones_red || 0) + (userData.comisiones_patrocinio || 0) + (userData.rendimiento_diario || 0));
  
  const gananciaTotal = gananciaTotalGenerada;
  
  console.log(`💰 [MiCiclo] Inversión del pack activo: $${inversion}`);
  console.log(`💰 [MiCiclo] Ganancia total generada: $${gananciaTotal}`);
  console.log(`💰 [MiCiclo] Desglose: Rendimientos=$${userData.rendimiento_diario || 0}, Red=$${userData.comisiones_red || 0}, Patrocinio=$${userData.comisiones_patrocinio || 0}`);
  
  const porcentajeGanancia = inversion > 0 ? (gananciaTotal / inversion) * 100 : 0;
  const puedeRetirar = inversion > 0 && gananciaTotal >= inversion;

  // MOSTRAR INDICADOR DE CARGA SI LA MATRIZ AÚN SE ESTÁ CARGANDO
  if (loadingMatriz) {
    return (
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-600 to-blue-700 flex items-center justify-center shadow-lg">
            <Users className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-3xl text-slate-800">Mi Matriz</h1>
            <p className="text-slate-600">Cargando tu red multinivel...</p>
          </div>
        </div>
        
        {/* Loading Indicator */}
        <Card className="p-6">
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-blue-600"></div>
            <p className="ml-4 text-slate-600 text-lg">Cargando tu matriz...</p>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-600 to-blue-700 flex items-center justify-center shadow-lg">
          <Users className="w-6 h-6 text-white" />
        </div>
        <div>
          <h1 className="text-3xl font-bold text-slate-500">Mi Matriz</h1>
          <p className="text-slate-600 font-medium">Red multinivel de {totalRed} usuarios activos</p>
        </div>
      </div>

      {/* Progreso de Ganancia */}
      <Card className="p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center">
            <TrendingUp className="w-5 h-5 text-blue-600" />
          </div>
          <h3 className="text-slate-800 text-lg">Progreso de Rentabilidad</h3>
        </div>
        
        <div className="space-y-4">
          {/* Info */}
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 bg-[#e0f2fe] rounded-xl border-2 border-primary/20">
              <p className="text-slate-600 text-sm mb-1">Inversión Inicial</p>
              <p className="text-2xl text-primary">${inversion.toFixed(2)}</p>
            </div>
            <div className="p-4 bg-[#e0f2fe] rounded-xl border-2 border-primary/20">
              <p className="text-slate-600 text-sm mb-1">Ganancia Acumulada</p>
              <p className="text-2xl text-slate-800">${gananciaTotal.toFixed(2)}</p>
            </div>
          </div>

          {/* Progress Bar */}
          <div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-slate-600">Rentabilidad Total</span>
              <span className={`text-sm font-semibold ${puedeRetirar ? 'text-blue-600' : 'text-slate-700'}`}>
                {porcentajeGanancia.toFixed(2)}% de 200%
              </span>
            </div>
            
            {/* Barra de progreso - 200% */}
            <div className="relative h-6 bg-slate-200 rounded-full overflow-hidden">
              {/* Marcador 100% (mitad de la barra) */}
              <div className="absolute left-1/2 top-0 bottom-0 w-px bg-slate-400 z-10"></div>
              <div className="absolute left-1/2 -top-6 transform -translate-x-1/2 text-[10px] text-slate-500 font-medium">
                100%
              </div>
              
              {/* Relleno de la barra */}
              <div
                className={`h-full rounded-full transition-all duration-500 relative ${
                  porcentajeGanancia >= 100 
                    ? 'bg-gradient-to-r from-slate-400 via-slate-500 to-blue-600' 
                    : 'bg-gradient-to-r from-slate-500 to-slate-600'
                }`}
                style={{ width: `${Math.min((porcentajeGanancia / 200) * 100, 100)}%` }}
              >
                {/* Etiqueta dentro de la barra */}
                {porcentajeGanancia > 5 && (
                  <div className="absolute right-2 top-1/2 -translate-y-1/2 text-white text-xs font-semibold">
                    ${gananciaTotal.toFixed(2)}
                  </div>
                )}
              </div>
            </div>
            
            {/* Leyenda debajo de la barra */}
            <div className="flex justify-between items-center mt-2 text-xs">
              <span className="text-slate-500">$0</span>
              <span className="text-slate-600 font-medium">
                Meta: ${(inversion * 2).toFixed(2)} (200%)
              </span>
            </div>
            
            {/* Detalle de progreso */}
            <div className="grid grid-cols-2 gap-3 mt-3">
              <div className="p-3 bg-slate-100 rounded-lg border border-slate-200">
                <p className="text-xs text-slate-600 mb-1">💰 Inversión Inicial</p>
                <p className="text-lg text-slate-800">${inversion.toFixed(2)}</p>
                <p className="text-xs text-slate-500">Tu capital base</p>
              </div>
              <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                <p className="text-xs text-slate-600 mb-1">📈 Rentabilidad</p>
                <p className="text-lg text-blue-700">${gananciaTotal.toFixed(2)}</p>
                <p className="text-xs text-slate-500">{porcentajeGanancia.toFixed(2)}% de tu inversión</p>
              </div>
            </div>
          </div>

          {/* Status Message */}
          {puedeRetirar ? (
            <div className="p-4 bg-gradient-to-r from-blue-600 to-blue-700 rounded-xl text-white">
              <p className="text-sm">
                ✅ <span className="font-semibold">¡Retiros disponibles!</span> Has alcanzado rentabilidad sobre tu inversión.
                {porcentajeGanancia >= 200 && (
                  <span> Has alcanzado el límite del 200%. Compra un nuevo pack para seguir generando ganancias.</span>
                )}
              </p>
              <p className="text-xs text-white/80 mt-2">
                💡 Puedes retirar hasta ${(inversion * 2).toFixed(2)} (200% de tu inversión total). Para aumentar tu límite, compra un nuevo pack.
              </p>
            </div>
          ) : (
            <div className="p-4 bg-gradient-to-r from-slate-50 to-slate-100 rounded-xl border border-slate-200">
              <p className="text-sm text-slate-700">
                📈 Te faltan <span className="font-semibold text-blue-600">${((inversion * 2) - gananciaTotal).toFixed(2)}</span> para alcanzar el 200% de rentabilidad.
              </p>
              <p className="text-xs text-slate-500 mt-1">
                ⚠️ Sigue invitando personas para acelerar tus ganancias y alcanzar tu meta del 200%.
              </p>
            </div>
          )}
        </div>
      </Card>

      {/* Network Visualization - Compacta */}
      <Card className="p-6 overflow-x-auto">
        <h3 className="text-slate-800 text-lg mb-6 text-center">Red Multinivel (10 Niveles)</h3>
        
        {/* DEBUG: Verificar estado de matrizUsuario */}
        {(() => {
          console.log('🔍 DEBUG RENDERIZADO:');
          console.log('  - matrizUsuario:', matrizUsuario);
          console.log('  - matrizUsuario es null?', matrizUsuario === null);
          console.log('  - matrizUsuario es undefined?', matrizUsuario === undefined);
          console.log('  - stats length:', stats.length);
          console.log('  - stats[0]:', stats[0]);
          
          if (matrizUsuario?.cycle) {
            console.log('  - cycle existe?', true);
            console.log('  - cycle.level1 value:', matrizUsuario.cycle.level1);
            console.log('  - cycle.level1 es array?', Array.isArray(matrizUsuario.cycle.level1));
          }
          
          return null; // Este bloque solo imprime logs
        })()}
        
        {/* NUEVA SECCIÓN: Referidos Directos */}
        {referidosDirectos.filter((r: any) => r.inversion > 0).length > 0 && (
          <div className="mb-8 pb-6 border-b-2 border-dashed border-blue-200">
            <div className="flex items-center justify-center gap-2 mb-4">
              <Users className="w-5 h-5 text-purple-600" />
              <h4 className="text-purple-900 font-semibold">
                Tus Referidos Directos ({referidosDirectos.filter((r: any) => r.inversion > 0).length})
              </h4>
            </div>
            <div className="bg-gradient-to-br from-purple-50 to-blue-50 rounded-xl p-4 border-2 border-purple-200">
              <p className="text-xs text-purple-800 mb-3 text-center">
                💡 Estos son TODOS los usuarios que se registraron con tu código de referido y compraron pack.
                <br />
                Debido al spillover, algunos pueden aparecer en diferentes niveles de tu matriz.
              </p>
              <div className="flex flex-wrap gap-3 justify-center">
                {referidosDirectos
                  .filter((r: any) => r.inversion > 0)
                  .map((directo: any, idx: number) => (
                    <div 
                      key={idx}
                      className="flex flex-col items-center p-3 bg-white rounded-lg border-2 border-purple-300 hover:border-purple-500 transition-all cursor-pointer hover:shadow-lg"
                      title={`${directo.nombre} ${directo.apellido} - ${directo.pack} - $${directo.inversion}`}
                    >
                      <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-600 to-purple-700 flex items-center justify-center text-white mb-2 shadow-md">
                        <span className="text-sm font-bold">
                          {directo.nombre?.[0]}{directo.apellido?.[0]}
                        </span>
                      </div>
                      <p className="text-xs text-slate-800 font-medium truncate max-w-[80px]">
                        {directo.nombre}
                      </p>
                      <p className="text-[10px] text-slate-500">
                        {directo.pack}
                      </p>
                      <p className="text-xs text-purple-700 font-semibold mt-1">
                        ${directo.inversion}
                      </p>
                      <div className="mt-1 px-2 py-0.5 bg-purple-100 text-purple-700 rounded-full text-[9px] font-bold">
                        DIRECTO
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        )}
        
        <div className="flex flex-col items-center space-y-4 min-w-max">
          {/* User (You) */}
          <div className="flex flex-col items-center">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-600 to-blue-700 flex flex-col items-center justify-center text-white shadow-xl border-4 border-white">
              <span className="text-lg">TÚ</span>
            </div>
            <p className="text-xs text-slate-800 mt-2">{userData.nombre}</p>
          </div>

          {/* Niveles 1-10 */}
          {stats.map((stat, index) => {
            const levelKey = `level${stat.nivel}`;
            // ✅ CORREGIDO: Acceder a matrizUsuario.cycle.level1
            const level = matrizUsuario?.cycle?.[levelKey] || null;
            
            // DEBUG: Log cada nivel
            console.log(`🔍 Renderizando Nivel ${stat.nivel}:`, {
              levelKey,
              levelExists: level !== null,
              isArray: Array.isArray(level),
              length: Array.isArray(level) ? level.length : 'N/A',
              activosCount: stat.activos
            });
            
            if (!Array.isArray(level)) {
              console.log(`⚠️ Nivel ${stat.nivel} NO es array, saltando...`);
              return null;
            }

            // ✅ OPTIMIZACIÓN CRÍTICA: Solo renderizar niveles con usuarios activos
            // Esto evita renderizar 88,000+ nodos vacíos que congelan el navegador
            if (stat.activos === 0) {
              console.log(`⏩ Nivel ${stat.nivel} está vacío (0 usuarios), saltando renderizado...`);
              return null;
            }

            console.log(`✅ Nivel ${stat.nivel} SE VA A RENDERIZAR con ${stat.activos} usuarios activos de ${level.length} posiciones`);

            return (
              <div key={stat.nivel} className="flex flex-col items-center">
                {/* Línea conectora */}
                <div className="w-px h-3 bg-slate-300"></div>
                
                {/* Badge del nivel */}
                <div className={`inline-flex px-3 py-1 rounded-full text-xs mb-2 ${
                  stat.nivel <= 4 
                    ? 'bg-gradient-to-r from-blue-50 to-blue-100 border border-blue-200 text-blue-700'
                    : 'bg-gradient-to-r from-slate-50 to-slate-100 border border-slate-200 text-slate-700'
                }`}>
                  Nivel {stat.nivel} - {stat.comision}% | {stat.activos}/{stat.total}
                </div>
                
                {/* Nodos del nivel - OPTIMIZADO: Solo mostrar nodos no vacíos */}
                <div className="flex gap-2 flex-wrap justify-center max-w-full">
                  {level
                    .map((referral, idx) => ({ referral, idx }))
                    .filter(({ referral }) => referral !== null) // Solo nodos activos
                    .map(({ referral, idx }) => (
                      <div key={idx}>
                        {renderNode(referral, stat.nivel, idx)}
                      </div>
                    ))}
                </div>
              </div>
            );
          })}
        </div>

        {/* Info */}
        <div className="mt-6 p-4 bg-blue-50 rounded-xl border border-blue-100">
          <p className="text-blue-800 text-sm mb-2">
            💡 <strong>Importante:</strong> Solo aparecen en tu ciclo los referidos que han activado un pack (depósito aprobado).
          </p>
          <p className="text-blue-700 text-xs">
            Los referidos registrados sin pack no generan comisiones hasta que realicen su primer depósito.
          </p>
        </div>
        
        {/* Sistema de Derrame (Spillover) */}
        <div className="mt-4 p-4 bg-gradient-to-r from-purple-50 to-blue-50 rounded-xl border-2 border-purple-200">
          <h4 className="text-purple-900 mb-2 flex items-center gap-2">
            <span className="text-lg">🌊</span>
            <strong>Sistema de Derrame Automático (Spillover)</strong>
          </h4>
          <div className="space-y-2 text-sm">
            <p className="text-purple-800">
              <strong>¿Cómo funciona?</strong> Cuando tu Nivel 1 está completo (3/3), tus nuevos referidos "se derraman" automáticamente al siguiente nivel disponible.
            </p>
            <div className="bg-white/60 rounded-lg p-3 border border-purple-200">
              <p className="text-purple-900 font-medium mb-2">📌 Ejemplo práctico:</p>
              <ul className="space-y-1 text-purple-800 text-xs">
                <li className="flex items-start gap-2">
                  <span className="shrink-0">1️⃣</span>
                  <span><strong>Juan</strong> refiere a David, Estefano y Milagros → <strong>Nivel 1 COMPLETO</strong> (3/3) ✅</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="shrink-0">2️⃣</span>
                  <span><strong>Juan</strong> refiere a Fernando (4to referido)</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="shrink-0">3️⃣</span>
                  <span><strong>Fernando se derrama</strong> al Nivel 1 de alguno de los referidos directos de Juan</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="shrink-0">4️</span>
                  <span><strong>Resultado:</strong> Fernando aparece en el <strong>Nivel 2 de Juan</strong>, pero en el <strong>Nivel 1 de David/Estefano/Milagros</strong></span>
                </li>
              </ul>
            </div>
            <p className="text-purple-700 text-xs mt-2">
              💡 <strong>Ventaja:</strong> Tus referidos ayudan a construir la red de tu equipo automáticamente. ¡Todos ganan!
            </p>
          </div>
        </div>
      </Card>

      {/* Estadísticas de Comisiones por Nivel */}
      <Card className="p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center">
            <DollarSign className="w-5 h-5 text-blue-600" />
          </div>
          <h3 className="text-slate-800 text-lg">Ganancias por Nivel</h3>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200">
                <th className="text-left py-3 px-2 text-slate-600">Nivel</th>
                <th className="text-center py-3 px-2 text-slate-600">Referidos</th>
                <th className="text-center py-3 px-2 text-slate-600">Comisión</th>
                <th className="text-right py-3 px-2 text-slate-600">Volumen</th>
                <th className="text-right py-3 px-2 text-slate-600">Ganancia</th>
              </tr>
            </thead>
            <tbody>
              {stats.map((stat) => (
                <tr key={stat.nivel} className="border-b border-slate-100 hover:bg-slate-50">
                  <td className="py-3 px-2">
                    <span className={`inline-flex items-center justify-center w-8 h-8 rounded-lg ${
                      stat.nivel <= 4 
                        ? 'bg-blue-100 text-blue-700'
                        : 'bg-slate-100 text-slate-700'
                    }`}>
                      {stat.nivel}
                    </span>
                  </td>
                  <td className="text-center py-3 px-2 text-slate-800">
                    {stat.activos} / {stat.total}
                  </td>
                  <td className="text-center py-3 px-2">
                    <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded-lg">
                      {stat.comision}%
                    </span>
                  </td>
                  <td className="text-right py-3 px-2 text-slate-800">
                    ${stat.volumen.toLocaleString()}
                  </td>
                  <td className="text-right py-3 px-2">
                    <span className="text-blue-600 font-medium">
                      ${stat.ganancia.toFixed(2)}
                    </span>
                  </td>
                </tr>
              ))}
              <tr className="bg-gradient-to-r from-blue-50 to-blue-100 border-t-2 border-blue-200">
                <td colSpan={3} className="py-3 px-2 text-slate-800 font-semibold">
                  Total Red
                </td>
                <td className="text-right py-3 px-2 text-slate-800 font-semibold">
                  ${stats.reduce((sum, s) => sum + s.volumen, 0).toLocaleString()}
                </td>
                <td className="text-right py-3 px-2 text-blue-700 font-semibold">
                  ${stats.reduce((sum, s) => sum + s.ganancia, 0).toFixed(2)}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </Card>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="p-6">
          <div className="flex items-center justify-between p-4 bg-[#e0f2fe] rounded-xl border-2 border-primary/20">
            <div>
              <p className="text-slate-600 text-sm mb-1">Total en Red</p>
              <p className="text-4xl text-primary">{totalRed}</p>
              <p className="text-slate-600 text-xs mt-1">usuarios activos en 10 niveles</p>
            </div>
            <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center border-2 border-primary">
              <Users className="w-7 h-7 text-primary" />
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between p-4 bg-[#e0f2fe] rounded-xl border-2 border-primary/20">
            <div>
              <p className="text-slate-600 text-sm mb-1">Referidos Directos con Pack</p>
              <p className="text-4xl text-primary">{referidosDirectos.filter((r: any) => r.inversion > 0).length}</p>
              <p className="text-slate-600 text-xs mt-1">{referidosDirectos.length} registrados | {referidosDirectos.filter((r: any) => r.inversion > 0).length} con pack activo</p>
            </div>
            <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center border-2 border-primary">
              <Users className="w-7 h-7 text-primary" />
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between p-4 bg-[#e0f2fe] rounded-xl border-2 border-primary/20">
            <div>
              <p className="text-slate-600 text-sm mb-1">Volumen Total</p>
              <p className="text-4xl text-primary">${(userData.volumen_red / 1000).toFixed(0)}K</p>
              <p className="text-slate-600 text-xs mt-1">inversión total de tu red</p>
            </div>
            <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center border-2 border-primary">
              <DollarSign className="w-7 h-7 text-primary" />
            </div>
          </div>
        </Card>
      </div>

      {/* Commission Info */}
      <Card className="p-6">
        <h3 className="text-slate-800 text-lg mb-4">📊 Sistema de Comisiones Multinivel</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div className="p-3 bg-[#e0f2fe] rounded-lg border-2 border-primary/20">
            <p className="text-primary text-xs mb-1">Nivel 1</p>
            <p className="text-xl text-primary">8%</p>
          </div>
          <div className="p-3 bg-[#e0f2fe] rounded-lg border-2 border-primary/20">
            <p className="text-primary text-xs mb-1">Nivel 2</p>
            <p className="text-xl text-primary">6%</p>
          </div>
          <div className="p-3 bg-[#e0f2fe] rounded-lg border-2 border-primary/20">
            <p className="text-primary text-xs mb-1">Nivel 3</p>
            <p className="text-xl text-primary">4%</p>
          </div>
          <div className="p-3 bg-[#e0f2fe] rounded-lg border-2 border-primary/20">
            <p className="text-primary text-xs mb-1">Nivel 4</p>
            <p className="text-xl text-primary">2%</p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-w-md mx-auto mt-3">
          <div className="p-3 bg-[#e0f2fe] rounded-lg border-2 border-primary/20">
            <p className="text-primary text-xs mb-1">Niveles 5-8</p>
            <p className="text-xl text-primary">1%</p>
          </div>
          <div className="p-3 bg-[#e0f2fe] rounded-lg border-2 border-primary/20">
            <p className="text-primary text-xs mb-1">Niveles 9-10</p>
            <p className="text-xl text-primary">0.5%</p>
          </div>
        </div>
        <div className="mt-3 p-3 bg-slate-50 rounded-lg border border-slate-200">
          <p className="text-slate-600 text-xs">
            💡 Puedes retirar hasta alcanzar el 200% de tu inversión (inversión + 100% de ganancias). Para aumentar tu límite, invierte más dinero con un nuevo pack.
          </p>
        </div>
      </Card>

      {/* Modal: Red del Usuario Seleccionado */}
      <Dialog open={showUserNetwork} onOpenChange={setShowUserNetwork}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-600 to-blue-700 flex items-center justify-center text-white">
                {selectedUser?.nombre?.[0]}{selectedUser?.apellido?.[0]}
              </div>
              <div>
                <p className="text-lg">Red de {selectedUser?.nombre} {selectedUser?.apellido}</p>
                <p className="text-sm text-slate-500">Resumen de su matriz multinivel</p>
              </div>
            </DialogTitle>
            <DialogDescription>
              Información detallada del usuario y su árbol multinivel completo
            </DialogDescription>
          </DialogHeader>

          {selectedUser && (() => {
            // Calcular estadísticas de la red del usuario seleccionado
            const calcularEstadisticasUsuario = () => {
              const levels = ['level1', 'level2', 'level3', 'level4', 'level5', 'level6', 'level7', 'level8', 'level9', 'level10'];
              
              // Si no hay cycle cargado, retornar niveles vacíos
              if (!selectedUser.cycle) {
                return levels.map((_, index) => ({
                  nivel: index + 1,
                  activos: 0,
                  total: 0,
                  comision: COMISION_POR_NIVEL[index],
                  volumen: 0,
                  ganancia: 0
                }));
              }
              
              return levels.map((levelKey, index) => {
                const level = selectedUser.cycle?.[levelKey];
                const activos = Array.isArray(level) ? level.filter((r: any) => r !== null).length : 0;
                const total = Array.isArray(level) ? level.length : 0;
                const comision = COMISION_POR_NIVEL[index];
                
                let volumen = 0;
                if (Array.isArray(level)) {
                  level.forEach((referral: any) => {
                    if (referral && referral.inversion) {
                      volumen += referral.inversion;
                    }
                  });
                }
                
                return {
                  nivel: index + 1,
                  activos,
                  total,
                  comision,
                  volumen,
                  levelKey
                };
              });
            };

            const userStats = calcularEstadisticasUsuario();
            const totalRedUsuario = userStats.reduce((sum, s) => sum + s.activos, 0);

            return (
              <div className="space-y-6 mt-4">
                {/* Indicador de carga */}
                {loadingUserNetwork && (
                  <div className="flex items-center justify-center py-8">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
                    <p className="ml-4 text-slate-600">Cargando red del usuario...</p>
                  </div>
                )}

                {!loadingUserNetwork && (
                  <>
                    {/* Info del usuario */}
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="p-4 bg-blue-50 rounded-xl border border-blue-200">
                        <p className="text-xs text-slate-600 mb-1">Pack</p>
                        <p className="text-lg text-blue-700">{selectedUser.pack || 'N/A'}</p>
                      </div>
                      <div className="p-4 bg-green-50 rounded-xl border border-green-200">
                        <p className="text-xs text-slate-600 mb-1">Inversión</p>
                        <p className="text-lg text-green-700">${selectedUser.inversion || 0}</p>
                      </div>
                      <div className="p-4 bg-purple-50 rounded-xl border border-purple-200">
                        <p className="text-xs text-slate-600 mb-1">Email</p>
                        <p className="text-sm text-purple-700 truncate">{selectedUser.email || 'N/A'}</p>
                      </div>
                      <div className="p-4 bg-orange-50 rounded-xl border border-orange-200">
                        <p className="text-xs text-slate-600 mb-1">Total en Red</p>
                        <p className="text-lg text-orange-700">{totalRedUsuario}</p>
                      </div>
                    </div>

                    {/* Árbol/Matriz del Usuario */}
                    <div className="border-t pt-4">
                      <h4 className="text-md text-slate-800 mb-4">🌳 Árbol de Matriz Multinivel</h4>
                      
                      <div className="bg-slate-50 rounded-xl p-6 overflow-x-auto border-2 border-slate-200">
                        <div className="flex flex-col items-center space-y-4 min-w-max">
                          {/* Usuario seleccionado (raíz del árbol) */}
                          <div className="flex flex-col items-center">
                            <div className="w-14 h-14 rounded-full bg-gradient-to-br from-blue-600 to-blue-700 flex items-center justify-center text-white shadow-xl border-4 border-white">
                              <span className="text-xs">{selectedUser.nombre?.[0]}{selectedUser.apellido?.[0]}</span>
                            </div>
                            <p className="text-xs text-slate-800 mt-2">{selectedUser.nombre}</p>
                          </div>

                          {/* Si tiene cycle, mostrar niveles */}
                          {selectedUser.cycle && userStats.some((s) => s.activos > 0) ? (
                            <>
                              {userStats.map((stat) => {
                                const level = selectedUser.cycle[stat.levelKey];
                                
                                if (!Array.isArray(level) || stat.activos === 0) return null;

                                return (
                                  <div key={stat.nivel} className="flex flex-col items-center">
                                    {/* Línea conectora */}
                                    <div className="w-px h-3 bg-slate-300"></div>
                                    
                                    {/* Badge del nivel */}
                                    <div className={`inline-flex px-3 py-1 rounded-full text-xs mb-2 ${
                                      stat.nivel <= 4 
                                        ? 'bg-gradient-to-r from-blue-50 to-blue-100 border border-blue-200 text-blue-700'
                                        : 'bg-gradient-to-r from-slate-50 to-slate-100 border border-slate-200 text-slate-700'
                                    }`}>
                                      Nivel {stat.nivel} - {stat.comision}% | {stat.activos}/{stat.total}
                                    </div>
                                    
                                    {/* Nodos del nivel */}
                                    <div className="flex gap-2">
                                      {level.map((referral: any, idx: number) => (
                                        <div key={idx}>
                                          {renderNode(referral, stat.nivel, idx)}
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                );
                              })}
                            </>
                          ) : (
                            /* Árbol vacío - Sin referidos */
                            <div className="text-center py-6">
                              <div className="w-px h-3 bg-slate-300 mx-auto mb-3"></div>
                              <div className="inline-flex px-3 py-1 rounded-full text-xs mb-4 bg-gradient-to-r from-slate-50 to-slate-100 border border-slate-200 text-slate-700">
                                Nivel 1 - 8% | 0/3
                              </div>
                              <div className="flex gap-2 justify-center mb-4">
                                {[0, 1, 2].map((idx) => (
                                  <div key={idx} className="flex flex-col items-center">
                                    <div className="w-10 h-10 rounded-full border border-dashed border-slate-300 flex items-center justify-center bg-slate-50">
                                      <span className="text-slate-400 text-xs">+</span>
                                    </div>
                                  </div>
                                ))}
                              </div>
                              <Users className="w-12 h-12 text-slate-300 mx-auto mb-2" />
                              <p className="text-slate-600 text-sm font-medium">Este usuario aún no tiene referidos activos</p>
                              <p className="text-slate-500 text-xs mt-1">Su red aparecerá aquí cuando refiera personas</p>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Usuarios en su Red (Lista) */}
                    <div className="border-t pt-4">
                      <h4 className="text-md text-slate-800 mb-4">👥 Usuarios en su Red</h4>
                      
                      {selectedUser.directos && selectedUser.directos.length > 0 ? (
                        <div className="space-y-3">
                          {/* Referidos directos */}
                          <div>
                            <p className="text-sm text-slate-600 mb-2">Referidos Directos ({selectedUser.directos.length})</p>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                              {selectedUser.directos.map((directo: any, idx: number) => (
                                <div key={idx} className="p-3 bg-slate-50 rounded-lg border border-slate-200 flex items-center gap-3">
                                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center text-white flex-shrink-0">
                                    <span className="text-xs">
                                      {directo.nombre?.[0]}{directo.apellido?.[0]}
                                    </span>
                                  </div>
                                  <div className="flex-1 min-w-0">
                                    <p className="text-sm text-slate-800 truncate">{directo.nombre} {directo.apellido}</p>
                                    <p className="text-xs text-slate-500">{directo.pack || 'Sin pack'}</p>
                                  </div>
                                  <div className="text-right flex-shrink-0">
                                    <p className="text-xs text-slate-600">Inversión</p>
                                    <p className="text-sm text-blue-600">${directo.inversion || 0}</p>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>

                          {/* Estadísticas de su matriz */}
                          {selectedUser.cycle && totalRedUsuario > 0 && (
                            <div className="mt-4">
                              <p className="text-sm text-slate-600 mb-2">Estadísticas por Nivel</p>
                              <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                                {userStats.slice(0, 5).map((stat) => (
                                  <div key={stat.nivel} className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                                    <p className="text-xs text-slate-600 mb-1">Nivel {stat.nivel}</p>
                                    <p className="text-lg text-blue-700">{stat.activos}/{stat.total}</p>
                                    <p className="text-xs text-slate-500">{stat.comision}%</p>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      ) : (
                        <div className="text-center py-8 bg-slate-50 rounded-lg">
                          <Users className="w-12 h-12 text-slate-300 mx-auto mb-2" />
                          <p className="text-slate-600">Este usuario aún no tiene referidos en su red</p>
                        </div>
                      )}
                    </div>

                    {/* Botón cerrar */}
                    <div className="flex justify-end pt-4 border-t">
                      <Button
                        onClick={() => setShowUserNetwork(false)}
                        className="bg-slate-700 hover:bg-slate-800"
                      >
                        Cerrar
                      </Button>
                    </div>
                  </>
                )}
              </div>
            );
          })()}
        </DialogContent>
      </Dialog>
    </div>
  );
}