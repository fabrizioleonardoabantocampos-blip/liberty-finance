import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { AlertCircle, CheckCircle2, Info, X } from 'lucide-react';

interface CustomDialogProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  message: string;
  type?: 'success' | 'error' | 'info' | 'warning' | 'prompt';
  onConfirm?: (value?: string) => void;
  confirmText?: string;
  cancelText?: string;
  inputLabel?: string;
  inputPlaceholder?: string;
  inputDefaultValue?: string;
}

export function CustomDialog({
  isOpen,
  onClose,
  title,
  message,
  type = 'info',
  onConfirm,
  confirmText = 'Aceptar',
  cancelText = 'Cancelar',
  inputLabel,
  inputPlaceholder,
  inputDefaultValue = ''
}: CustomDialogProps) {
  const [inputValue, setInputValue] = React.useState(inputDefaultValue);

  React.useEffect(() => {
    setInputValue(inputDefaultValue);
  }, [inputDefaultValue, isOpen]);

  const handleConfirm = () => {
    if (onConfirm) {
      onConfirm(type === 'prompt' ? inputValue : undefined);
    }
    onClose();
  };

  const getIcon = () => {
    switch (type) {
      case 'success':
        return <CheckCircle2 className="w-12 h-12 text-green-500" />;
      case 'error':
        return <AlertCircle className="w-12 h-12 text-red-500" />;
      case 'warning':
        return <AlertCircle className="w-12 h-12 text-yellow-500" />;
      default:
        return <Info className="w-12 h-12 text-blue-500" />;
    }
  };

  const getBackgroundColor = () => {
    switch (type) {
      case 'success':
        return 'bg-green-50';
      case 'error':
        return 'bg-red-50';
      case 'warning':
        return 'bg-yellow-50';
      default:
        return 'bg-blue-50';
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px] bg-white rounded-3xl border-0 shadow-2xl">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 rounded-full p-1 hover:bg-gray-100 transition-colors"
        >
          <X className="w-5 h-5 text-gray-500" />
        </button>

        <DialogHeader className="space-y-4 pt-6">
          <div className={`mx-auto w-20 h-20 rounded-full ${getBackgroundColor()} flex items-center justify-center`}>
            {getIcon()}
          </div>
          {title && (
            <DialogTitle className="text-center text-2xl">{title}</DialogTitle>
          )}
        </DialogHeader>

        <DialogDescription className="text-center text-gray-600 px-4 whitespace-pre-line">
          {message}
        </DialogDescription>

        {type === 'prompt' && (
          <div className="space-y-2 px-4">
            {inputLabel && <Label>{inputLabel}</Label>}
            <Input
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder={inputPlaceholder}
              className="h-12 rounded-xl border-gray-300 focus:border-blue-500 focus:ring-blue-500"
              autoFocus
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  handleConfirm();
                }
              }}
            />
          </div>
        )}

        <DialogFooter className="flex gap-2 px-4 pb-6">
          {type === 'prompt' && (
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="flex-1 h-12 rounded-xl border-gray-300 hover:bg-gray-100"
            >
              {cancelText}
            </Button>
          )}
          <Button
            type="button"
            onClick={handleConfirm}
            className={`flex-1 h-12 rounded-xl text-white ${
              type === 'success'
                ? 'bg-green-600 hover:bg-green-700'
                : type === 'error'
                ? 'bg-red-600 hover:bg-red-700'
                : type === 'warning'
                ? 'bg-yellow-600 hover:bg-yellow-700'
                : 'bg-blue-600 hover:bg-blue-700'
            }`}
          >
            {confirmText}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// Hook para usar el dialog
import React from 'react';

interface DialogState {
  isOpen: boolean;
  title?: string;
  message?: string;
  description?: string;
  type?: 'success' | 'error' | 'info' | 'warning' | 'prompt';
  onConfirm?: (value?: string) => void;
  confirmText?: string;
  cancelText?: string;
  inputLabel?: string;
  inputPlaceholder?: string;
  inputDefaultValue?: string;
}

export function useCustomDialog() {
  const [dialogState, setDialogState] = React.useState<DialogState>({
    isOpen: false,
    message: '',
    type: 'info'
  });

  const showDialog = React.useCallback((options: Omit<DialogState, 'isOpen'>) => {
    setDialogState({ ...options, isOpen: true });
  }, []);

  const closeDialog = React.useCallback(() => {
    setDialogState(prev => ({ ...prev, isOpen: false }));
  }, []);

  const showSuccess = React.useCallback((message: string, title?: string) => {
    showDialog({ message, title, type: 'success' });
  }, [showDialog]);

  const showError = React.useCallback((message: string, title?: string) => {
    showDialog({ message, title, type: 'error' });
  }, [showDialog]);

  const showInfo = React.useCallback((message: string, title?: string) => {
    showDialog({ message, title, type: 'info' });
  }, [showDialog]);

  const showWarning = React.useCallback((message: string, title?: string) => {
    showDialog({ message, title, type: 'warning' });
  }, [showDialog]);

  const showPrompt = React.useCallback(
    (
      message: string,
      onConfirm: (value: string) => void,
      options?: {
        title?: string;
        inputLabel?: string;
        inputPlaceholder?: string;
        inputDefaultValue?: string;
        confirmText?: string;
        cancelText?: string;
      }
    ) => {
      showDialog({
        message,
        type: 'prompt',
        onConfirm,
        ...options
      });
    },
    [showDialog]
  );

  return {
    dialogState,
    showDialog,
    closeDialog,
    showSuccess,
    showError,
    showInfo,
    showWarning,
    showPrompt,
    DialogComponent: () => (
      <CustomDialog
        isOpen={dialogState.isOpen}
        onClose={closeDialog}
        message={dialogState.message || dialogState.description || ''}
        {...dialogState}
      />
    )
  };
}