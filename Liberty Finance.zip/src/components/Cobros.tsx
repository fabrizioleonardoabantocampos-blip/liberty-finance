import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { ArrowUpRight, DollarSign, Clock, CheckCircle, XCircle, Loader2, Wallet, AlertTriangle, TrendingUp, Dices } from 'lucide-react';
import { useState, useEffect } from 'react';
import { cobrosAPI, comisionesAPI, ruletaAPI } from '../utils/api';
import { toast } from 'sonner@2.0.3';
import { UserData } from '../data/mockData';

interface Cobro {
  id: string;
  userId: string;
  monto: number;
  wallet: string;
  estado: 'pendiente' | 'aprobado' | 'rechazado' | 'completado';
  fecha: string;
  fechaProcesado?: string;
  txHash?: string;
  imagen?: string;
}

interface CobrosProps {
  userData?: UserData;
}

export function Cobros({ userData: userDataProp }: CobrosProps = {}) {
  // Obtener usuario actual del localStorage o de props
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [cobros, setCobros] = useState<Cobro[]>([]);
  const [loadingCobros, setLoadingCobros] = useState(false); // Cambiar a false
  const [dialogOpen, setDialogOpen] = useState(false);
  const [walletRetiro, setWalletRetiro] = useState('');
  const [montoRetiro, setMontoRetiro] = useState('');
  const [procesando, setProcesando] = useState(false);
  const [totalGastadoRuleta, setTotalGastadoRuleta] = useState(0);
  const [totalGanadoRuleta, setTotalGanadoRuleta] = useState(0);

  // LÍMITE MÁXIMO DE RETIRO
  const LIMITE_MAXIMO_RETIRO = 10000;
  
  // LÍMITE MÍNIMO DE RETIRO
  const LIMITE_MINIMO_RETIRO = 1;
  
  // COMISIÓN DE RETIRO (10%)
  const COMISION_RETIRO = 0.10; // 10%

  useEffect(() => {
    // Priorizar userData de props, sino buscar en localStorage
    if (userDataProp) {
      setCurrentUser(userDataProp);
    } else {
      // Intentar ambas claves de localStorage
      const userData = localStorage.getItem('userData');
      const currentUserData = localStorage.getItem('currentUser');
      
      if (userData) {
        const parsed = JSON.parse(userData);
        setCurrentUser(parsed);
      } else if (currentUserData) {
        const parsed = JSON.parse(currentUserData);
        setCurrentUser(parsed);
      }
    }
  }, [userDataProp]);

  // Cargar cobros del usuario
  useEffect(() => {
    if (currentUser?.id) {
      loadCobros();
      // Pre-cargar wallet del usuario
      if (currentUser.wallet) {
        setWalletRetiro(currentUser.wallet);
      }
    }
  }, [currentUser]);

  const loadCobros = async () => {
    if (!currentUser?.id) return;
    
    setLoadingCobros(true);
    try {
      const cobrosData = await cobrosAPI.getByUserId(currentUser.id);
      setCobros(cobrosData || []);
      
      // Cargar gastos de ruleta y ganancias
      try {
        const gastos = await ruletaAPI.getGastos(currentUser.id);
        if (Array.isArray(gastos)) {
          const totalGastos = gastos.reduce((sum: number, g: any) => sum + g.monto, 0);
          setTotalGastadoRuleta(totalGastos);
        }

        const historial = await ruletaAPI.getHistorial(currentUser.id);
        if (Array.isArray(historial)) {
          const totalGanado = historial
            .filter((item: any) => item.premio && item.puntos)
            .reduce((sum: number, item: any) => sum + (item.puntos || 0), 0);
          setTotalGanadoRuleta(totalGanado);
        }
      } catch (err) {
        console.error('Error cargando datos ruleta en Cobros', err);
      }
    } catch (error) {
      console.error('Error al cargar cobros:', error);
      setCobros([]);
    } finally {
      setLoadingCobros(false);
    }
  };

  // Calcular si el usuario alcanzó el 100% de rentabilidad
  const calcularEstadoRentabilidad = () => {
    if (!currentUser) return { alcanzado100: false, rendimientoTotal: 0, capitalInicial: 0, porcentaje: 0, comisionesRed: 0, comisionesPatrocinio: 0, gananciaTotalHistorica: 0, gananciaCicloActual: 0 };
    
    // IMPORTANTE: Capital inicial (inversión total del ciclo actual)
    const capitalInicial = currentUser.cantidad || 0;
    
    // 1. Ganancia Histórica Total (para cálculo de Saldo Wallet Global)
    const gananciaTotalHistorica = currentUser.ganancia_total || ((currentUser.rendimiento_diario || 0) + (currentUser.comisiones_red || 0) + (currentUser.comisiones_patrocinio || 0));
    
    // 2. Ganancia del Ciclo Actual (para cálculo de Rentabilidad del Pack Actual)
    // Si no existe ganancia_acumulada, asumimos que es igual a la histórica (si es el primer ciclo) o 0
    const gananciaCicloActual = currentUser.ganancia_acumulada || 0;
    
    const rendimientoTotal = currentUser.rendimiento_diario || 0;
    const comisionesRed = currentUser.comisiones_red || 0;
    const comisionesPatrocinio = currentUser.comisiones_patrocinio || 0;
    
    // Porcentaje alcanzado (basado en GANANCIA DEL CICLO vs capital actual)
    const porcentaje = capitalInicial > 0 ? (gananciaCicloActual / capitalInicial) * 100 : 0;
    
    // Alcanzó el 200% (Ciclo Completo)
    const alcanzado200 = porcentaje >= 200;
    
    return {
      alcanzado200,
      rendimientoTotal,
      capitalInicial,
      porcentaje, 
      comisionesRed,
      comisionesPatrocinio,
      gananciaTotalHistorica,
      gananciaCicloActual
    };
  };

  const estadoRentabilidad = calcularEstadoRentabilidad();
  
  // Calcular montos disponibles para retiro
  const calcularMontosRetiro = () => {
    const { alcanzado200, gananciaTotalHistorica, gananciaCicloActual, capitalInicial, comisionesRed, comisionesPatrocinio } = estadoRentabilidad;
    
    // IMPORTANTE: Calcular ganancia total generada HISTÓRICA (Incluye premios Ruleta)
    const gananciaTotalGenerada = gananciaTotalHistorica + totalGanadoRuleta;
    
    // IMPORTANTE: Calcular cuánto ya se ha retirado o gastado (Withdrawals + Wallet Purchases)
    const totalEgresos = cobros
      .filter(c => c.estado === 'completado' || c.estado === 'pendiente' || c.estado === 'aprobado')
      .reduce((sum, c) => sum + c.monto, 0);
      
    // Recuperar saldo retenido del usuario si existe
    const saldoRetenido = currentUser?.saldo_retenido || 0;

    // Saldo Real Disponible = (Ganado Histórico - Egresos Históricos - GastadoEnRuleta - Retenido)
    // Aseguramos que no sea negativo
    const saldoRealDisponible = Math.max(0, gananciaTotalGenerada - totalEgresos - totalGastadoRuleta - saldoRetenido);

    if (alcanzado200) {
      // Al 200% del ciclo actual: Puede retirar todo lo permitido (200%).
      const limiteGanancia = capitalInicial * 2;
      
      // Disponible es el saldo real wallet
      const montoDisponible = saldoRealDisponible;
      
      // Bloqueo solo si hay saldo retenido
      const gananciaBloqueada = saldoRetenido > 0 ? saldoRetenido : Math.max(0, gananciaCicloActual - limiteGanancia);

      return {
        montoDisponible: montoDisponible,
        montoNeto: Math.min(montoDisponible, LIMITE_MAXIMO_RETIRO),
        comision: 0,
        incluyeCapital: true,
        alcanzado200: true,
        gananciaBloqueada: gananciaBloqueada,
        saldoAnterior: false,
        desglose: {
          rendimiento: estadoRentabilidad.rendimientoTotal,
          comisionesRed: comisionesRed + comisionesPatrocinio,
          capital: capitalInicial,
          gananciaDisponible: montoDisponible
        }
      };
    } else {
      // Antes del 200%:
      // Si hay saldo disponible pero NO se alcanzó el 200% del ciclo actual
      const esSaldoAnterior = saldoRealDisponible > 0 && gananciaCicloActual < (capitalInicial * 0.1); // Heurística simple

      return {
        montoDisponible: saldoRealDisponible,
        montoNeto: 0, 
        comision: 0, 
        incluyeCapital: false,
        alcanzado200: false,
        gananciaBloqueada: saldoRetenido, // Puede haber retenido de ciclos anteriores?
        saldoAnterior: esSaldoAnterior,
        desglose: {
          rendimiento: estadoRentabilidad.rendimientoTotal,
          comisionesRed: comisionesRed + comisionesPatrocinio,
          capital: 0 
        }
      };
    }
  };

  const montosRetiro = calcularMontosRetiro();

  // CÁLCULO DE DESGLOSE DE SALDOS (Waterfall Logic)
  // 1. Saldo Wallet = Disponible calculado arriba
  // 2. Saldo Ruleta = Premios Ruleta (solo informativo, ya está sumado en el total)
  
  // Usamos el mismo cálculo unificado para displayWalletBalance
  // Esto asegura que coincida con UserHome y Ruleta
  const displayWalletBalance = montosRetiro.montoDisponible;
  
  // Para visualizar qué parte viene de ruleta (informativo)
  const displayRouletteBalance = totalGanadoRuleta; // Solo histórico de ruleta


  // Calcular comisión y monto neto basado en el monto ingresado
  const calcularComisionYNeto = (monto: number) => {
    // CORRECCIÓN: Siempre aplicar comisión del 10% en todos los retiros
    const comision = monto * COMISION_RETIRO;
    const montoNeto = monto - comision;
    return {
      comision,
      montoNeto
    };
  };

  const montoIngresado = parseFloat(montoRetiro) || 0;
  const { comision: comisionCalculada, montoNeto: montoNetoCalculado } = calcularComisionYNeto(montoIngresado);

  const handleSolicitarRetiro = async () => {
    if (!currentUser) {
      toast.error('Error: Usuario no autenticado');
      return;
    }

    const monto = parseFloat(montoRetiro);

    if (!monto || monto <= 0) {
      toast.error('Ingresa un monto válido');
      return;
    }

    if (monto > montosRetiro.montoDisponible) {
      toast.error('No tienes saldo suficiente. Verifica tus retiros pendientes.');
      return;
    }

    // Validar si el saldo disponible es cero
    if (montosRetiro.montoDisponible <= 0) {
      toast.error('No tienes saldo disponible para retirar.');
      return;
    }

    // Validar límite máximo de retiro
    if (monto > LIMITE_MAXIMO_RETIRO) {
      toast.error(`El monto máximo de retiro es $${LIMITE_MAXIMO_RETIRO.toLocaleString()} USDT`);
      return;
    }

    // Validar límite mínimo de retiro
    if (monto < LIMITE_MINIMO_RETIRO) {
      toast.error(`El monto mínimo de retiro es $${LIMITE_MINIMO_RETIRO.toLocaleString()} USDT`);
      return;
    }

    if (!walletRetiro || walletRetiro.length < 10) {
      toast.error('Ingresa una wallet válida');
      return;
    }

    setProcesando(true);
    try {
      await cobrosAPI.create({
        userId: currentUser.id,
        monto,
        wallet: walletRetiro
      });

      // Siempre mostrar mensaje de comisión del 10%
      const mensajeComision = `Comisión del 10%: $${comisionCalculada.toFixed(2)} - Recibirás: $${montoNetoCalculado.toFixed(2)}`;

      toast.success(`¡Solicitud de retiro enviada! ${mensajeComision}. Será procesada en 5-10 minutos.`);
      setDialogOpen(false);
      setMontoRetiro('');
      await loadCobros();
    } catch (error: any) {
      console.error('Error al solicitar retiro:', error);
      toast.error(error.message || 'Error al solicitar retiro');
    } finally {
      setProcesando(false);
    }
  };

  const totalRetirado = cobros
    .filter(c => c.estado === 'completado')
    .reduce((sum, c) => sum + c.monto, 0);

  const retirosPendientes = cobros.filter(c => c.estado === 'pendiente').length;
  const retirosCompletados = cobros.filter(c => c.estado === 'completado').length;

  if (!currentUser) {
    return (
      <div className="flex items-center justify-center py-12">
        <Card className="p-8 text-center max-w-md">
          <Wallet className="w-16 h-16 text-slate-300 mx-auto mb-4" />
          <h3 className="text-slate-800 mb-2">Sesión no encontrada</h3>
          <p className="text-slate-600">
            Por favor, inicia sesión para ver tus retiros
          </p>
        </Card>
      </div>
    );
  }

  if (loadingCobros) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-600 to-blue-700 flex items-center justify-center shadow-lg">
            <DollarSign className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-slate-500">Retiros</h1>
            <p className="text-slate-600 font-medium">Solicita el retiro de tus ganancias</p>
          </div>
        </div>
        <Button
          onClick={() => setDialogOpen(true)}
          className="bg-gradient-to-r from-blue-600 to-blue-700 hover:opacity-90"
          disabled={montosRetiro.montoDisponible <= 0}
        >
          <ArrowUpRight className="mr-2 h-4 w-4" />
          Solicitar Retiro
        </Button>
      </div>

      {/* Alerta: Estado de Rentabilidad */}
      {montosRetiro.alcanzado200 ? (
        <Card className="p-6 bg-gradient-to-r from-green-500 to-emerald-600 border-0 shadow-xl text-white">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center flex-shrink-0">
              <TrendingUp className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="text-xl mb-2">🎉 ¡Alcanzaste el 200% de Rentabilidad!</h3>
              <p className="text-white/90 mb-3">
                Has completado el ciclo de tu pack. Puedes retirar tu <strong>retorno total (200%)</strong> sin comisión.
              </p>
              
              {/* Desglose de Ganancias Generadas */}
              <div className="bg-white/20 rounded-lg p-3 text-sm space-y-1 mb-3">
                <p className="font-semibold mb-1">📊 Ganancias Generadas:</p>
                <p className="pl-4">💰 Rendimiento: ${montosRetiro.desglose.rendimiento.toFixed(2)} USDT</p>
                <p className="pl-4">🌐 Comisiones y Bonos: ${montosRetiro.desglose.comisionesRed.toFixed(2)} USDT</p>
                {totalGanadoRuleta > 0 && (
                  <p className="pl-4">🎲 Premios Ruleta: ${totalGanadoRuleta.toFixed(2)} USDT</p>
                )}
                <div className="border-t border-white/30 my-1"></div>
                <p className="pl-4"><strong>Total Ganado: ${(montosRetiro.desglose.rendimiento + montosRetiro.desglose.comisionesRed + totalGanadoRuleta).toFixed(2)} USDT</strong></p>
              </div>

              {/* Lo que puede retirar */}
              <div className="bg-white/20 rounded-lg p-3 text-sm space-y-1">
                <p className="font-semibold mb-1">💵 Estado de Retiro:</p>
                <p className="pl-4">✅ Retorno Total Permitido (200%): ${(montosRetiro.desglose.capital * 2).toFixed(2)} USDT</p>
                <div className="border-t border-white/30 my-1"></div>
                <p className="pl-4"><strong>Total Disponible: ${montosRetiro.montoDisponible.toFixed(2)} USDT</strong></p>
                
                {montosRetiro.gananciaBloqueada > 0 && (
                  <>
                    <div className="border-t border-white/30 my-2"></div>
                    <p className="text-orange-100">
                      🔒 <strong>Saldo Bloqueado: ${montosRetiro.gananciaBloqueada.toFixed(2)} USDT</strong>
                    </p>
                    <p className="text-xs text-white/80 pl-4 mt-1">
                      ⚠️ Has excedido el límite del 200%. Este saldo se liberará y sumará a tu wallet cuando compres un nuevo pack.
                    </p>
                  </>
                )}
              </div>
            </div>
          </div>
        </Card>
      ) : montosRetiro.saldoAnterior ? (
        /* NUEVO CASO: Saldo de Pack Anterior */
        <Card className="p-6 bg-gradient-to-r from-blue-500 to-indigo-600 border-0 shadow-xl text-white">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center flex-shrink-0">
              <Wallet className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="text-xl mb-2">💳 Tienes Saldo Disponible Anterior</h3>
              <p className="text-white/90 mb-2">
                Tienes <strong>${montosRetiro.montoDisponible.toFixed(2)} USDT</strong> disponibles, provenientes de ganancias o packs anteriores.
              </p>
              <p className="text-white/80 text-sm mb-3">
                Tu pack actual aún está generando rendimientos ({estadoRentabilidad.porcentaje.toFixed(1)}% de 200%).
                Mientras tanto, puedes retirar este saldo disponible (sujeto a comisión del 10%).
              </p>
              
              <div className="bg-white/20 rounded-lg p-3 text-sm">
                <p>📊 Progreso Pack Actual: {estadoRentabilidad.porcentaje.toFixed(1)}%</p>
                <p>💰 Saldo Disponible para Retiro: <strong>${montosRetiro.montoDisponible.toFixed(2)} USDT</strong></p>
                <p className="mt-2 border-t border-white/30 pt-2 text-white/90 text-xs">
                  * Comisión del 10% aplica en retiros antes de completar el ciclo (200%).
                </p>
              </div>
            </div>
          </div>
        </Card>
      ) : (
        <Card className="p-6 bg-gradient-to-r from-orange-500 to-red-500 border-0 shadow-xl text-white">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center flex-shrink-0">
              <AlertTriangle className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="text-xl mb-2">⚠️ Ciclo en Progreso - Comisión del 10%</h3>
              <p className="text-white/90 mb-2">
                Aún no has alcanzado el 200% de rentabilidad. Puedes retirar tus ganancias con una comisión del 10%.
              </p>
              <div className="bg-white/20 rounded-lg p-3 text-sm">
                <p>📊 Progreso: {estadoRentabilidad.porcentaje.toFixed(1)}% de 200%</p>
                <p>💰 Ganancias Disponibles: ${montosRetiro.montoDisponible.toFixed(2)} USDT</p>
                <div className="mt-2 border-t border-white/30 pt-2 text-white">
                  {montosRetiro.gananciaBloqueada > 0 ? (
                     <p className="text-orange-200">
                        🔒 <strong>Saldo Bloqueado: ${montosRetiro.gananciaBloqueada.toFixed(2)} USDT</strong> (Excede el 200%)
                     </p>
                  ) : (
                     <p><strong>⚠️ Se cobrará 10% de comisión en cada retiro</strong></p>
                  )}
                </div>
              </div>
            </div>
          </div>
        </Card>
      )}

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Card 1: Saldo Wallet (Comisiones) */}
        <Card className="p-6">
          <div className="flex items-center justify-between p-4 bg-[#e0f2fe] rounded-xl border-2 border-blue-200">
            <div>
              <p className="text-slate-600 text-xs font-bold uppercase mb-1">Saldo Wallet</p>
              <p className="text-2xl font-bold text-blue-700">${displayWalletBalance.toFixed(2)}</p>
              <p className="text-[10px] text-blue-600/80 mt-1">Comisiones y Rendimientos</p>
            </div>
            <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center border-2 border-blue-600">
              <Wallet className="w-5 h-5 text-blue-600" />
            </div>
          </div>
        </Card>

        {/* Card 2: Saldo Premios (Ruleta) */}
        <Card className="p-6">
          <div className="flex items-center justify-between p-4 bg-purple-50 rounded-xl border-2 border-purple-200">
            <div>
              <p className="text-slate-600 text-xs font-bold uppercase mb-1">Saldo Premios</p>
              <p className="text-2xl font-bold text-purple-700">${displayRouletteBalance.toFixed(2)}</p>
              <p className="text-[10px] text-purple-600/80 mt-1">Ganancias de Ruleta</p>
            </div>
            <div className="w-10 h-10 rounded-xl bg-purple-100 flex items-center justify-center border-2 border-purple-600">
              <Dices className="w-5 h-5 text-purple-600" />
            </div>
          </div>
        </Card>

        {/* Card 3: Total Retirado */}
        <Card className="p-6">
          <div className="flex items-center justify-between p-4 bg-green-50 rounded-xl border-2 border-green-200">
            <div>
              <p className="text-slate-600 text-xs font-bold uppercase mb-1">Total Retirado</p>
              <p className="text-2xl font-bold text-green-700">${totalRetirado.toFixed(2)}</p>
            </div>
            <div className="w-10 h-10 rounded-xl bg-green-100 flex items-center justify-center border-2 border-green-600">
              <CheckCircle className="w-5 h-5 text-green-600" />
            </div>
          </div>
        </Card>

        {/* Card 4: Retiros Pendientes */}
        <Card className="p-6">
          <div className="flex items-center justify-between p-4 bg-yellow-50 rounded-xl border-2 border-yellow-200">
            <div>
              <p className="text-slate-600 text-xs font-bold uppercase mb-1">Pendientes</p>
              <p className="text-2xl font-bold text-yellow-700">{retirosPendientes}</p>
            </div>
            <div className="w-10 h-10 rounded-xl bg-yellow-100 flex items-center justify-center border-2 border-yellow-600">
              <Clock className="w-5 h-5 text-yellow-600" />
            </div>
          </div>
        </Card>
      </div>

      {/* History Table */}
      <Card className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl text-slate-800">Historial de Retiros</h2>
          <div className="flex gap-2">
            <span className="text-sm text-slate-600">
              Total: {cobros.length} retiros
            </span>
          </div>
        </div>

        <div className="space-y-4">
          {cobros.length === 0 ? (
            <div className="text-center py-12 bg-slate-50 rounded-lg">
              <Wallet className="w-16 h-16 text-slate-300 mx-auto mb-4" />
              <h3 className="text-slate-800 mb-2">No hay retiros registrados</h3>
              <p className="text-slate-600">
                Solicita tu primer retiro cuando tengas saldo disponible
              </p>
            </div>
          ) : (
            cobros.map((cobro) => (
              <Card key={cobro.id} className="p-4">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 space-y-2">
                    {/* Estado */}
                    <div className="flex items-center gap-3">
                      {cobro.estado === 'pendiente' && (
                        <span className="px-3 py-1 bg-yellow-100 text-yellow-700 rounded-full text-sm flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          En Proceso
                        </span>
                      )}
                      {cobro.estado === 'completado' && (
                        <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm flex items-center gap-1">
                          <CheckCircle className="h-3 w-3" />
                          Completado
                        </span>
                      )}
                      {cobro.estado === 'rechazado' && (
                        <span className="px-3 py-1 bg-red-100 text-red-700 rounded-full text-sm flex items-center gap-1">
                          <XCircle className="h-3 w-3" />
                          Rechazado
                        </span>
                      )}
                      <span className="text-sm text-slate-500">
                        {new Date(cobro.fecha).toLocaleString('es-PE')}
                      </span>
                    </div>

                    {/* Monto */}
                    <div>
                      <p className="text-sm text-slate-500">Monto</p>
                      <p className="text-2xl text-primary">${cobro.monto.toFixed(2)} USDT</p>
                    </div>

                    {/* Wallet */}
                    <div>
                      <p className="text-sm text-slate-500">Wallet de Destino</p>
                      <p className="text-sm font-mono bg-slate-50 p-2 rounded border">
                        {cobro.wallet}
                      </p>
                    </div>

                    {/* Hash de transacción */}
                    {cobro.txHash && (
                      <div>
                        <p className="text-sm text-slate-500">Hash de Transacción</p>
                        <p className="text-sm font-mono bg-slate-50 p-2 rounded border">
                          {cobro.txHash}
                        </p>
                      </div>
                    )}

                    {/* Imagen Comprobante */}
                    {cobro.imagen && (
                      <div>
                        <p className="text-sm text-slate-500 mb-1">Comprobante de Pago</p>
                        <div className="relative w-full max-w-[200px] h-32 bg-slate-100 rounded-lg overflow-hidden border">
                          <img 
                            src={cobro.imagen} 
                            alt="Comprobante" 
                            className="w-full h-full object-cover cursor-pointer hover:opacity-90 transition-opacity"
                            onClick={() => window.open(cobro.imagen, '_blank')}
                          />
                        </div>
                      </div>
                    )}

                    {/* Mensaje según estado */}
                    {cobro.estado === 'pendiente' && (
                      <div className="bg-yellow-50 border border-yellow-200 rounded p-3">
                        <p className="text-sm text-yellow-800">
                          ⏱️ Tu retiro está en proceso. Será aprobado por el administrador en 5-10 minutos.
                        </p>
                      </div>
                    )}

                    {cobro.estado === 'completado' && cobro.fechaProcesado && (
                      <div className={`border rounded p-3 ${
                        cobro.wallet === 'Sistema Interno' 
                          ? 'bg-blue-50 border-blue-200' 
                          : 'bg-green-50 border-green-200'
                      }`}>
                        <p className={`text-sm ${
                          cobro.wallet === 'Sistema Interno' ? 'text-blue-800' : 'text-green-800'
                        }`}>
                          {cobro.wallet === 'Sistema Interno' 
                            ? `🛍️ Compra de Pack completada el ${new Date(cobro.fechaProcesado).toLocaleString('es-PE')}`
                            : `✅ Retiro completado el ${new Date(cobro.fechaProcesado).toLocaleString('es-PE')}`
                          }
                        </p>
                        {cobro.wallet === 'Sistema Interno' && (
                          <p className="text-xs text-blue-700 mt-1">
                             El saldo fue utilizado para la compra/renovación de un pack.
                          </p>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </Card>
            ))
          )}
        </div>
      </Card>

      {/* Info Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="p-6 bg-gradient-to-br from-blue-600 to-blue-700 border-0 shadow-xl text-white">
          <h3 className="text-lg mb-2">💰 ¿Cómo funciona el retiro?</h3>
          <ul className="text-white/90 text-sm space-y-2">
            <li className="flex items-start gap-2">
              <span className="shrink-0">1.</span>
              <span>Solicita tu retiro indicando el monto y tu wallet TRC20.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="shrink-0">2.</span>
              <span>El administrador procesará tu solicitud en 5-10 minutos.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="shrink-0">3.</span>
              <span>Recibirás el USDT en tu wallet TRC20 directamente.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="shrink-0">⚠️</span>
              <span><strong>Todos los retiros:</strong> Se cobra 10% de comisión.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="shrink-0">✅</span>
              <span><strong>Al 100%:</strong> Puedes retirar ganancias + capital.</span>
            </li>
          </ul>
        </Card>

        <Card className="p-6 bg-gradient-to-br from-slate-800 to-slate-900 border-0 shadow-xl text-white">
          <h3 className="text-lg mb-2">⚠️ Información Importante</h3>
          <ul className="text-white/90 text-sm space-y-2">
            <li className="flex items-start gap-2">
              <span className="shrink-0">•</span>
              <span>Retiros mínimos desde 1 USDT.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="shrink-0">•</span>
              <span>Límite máximo: $10,000 USDT por retiro.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="shrink-0">•</span>
              <span><strong>Comisión del 10% en todos los retiros.</strong></span>
            </li>
            <li className="flex items-start gap-2">
              <span className="shrink-0">•</span>
              <span>Capital se libera solo al 100%.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="shrink-0">•</span>
              <span>Asegúrate de que tu wallet sea TRC20 (Tron).</span>
            </li>
          </ul>
        </Card>
      </div>

      {/* Dialog Solicitar Retiro */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Solicitar Retiro</DialogTitle>
            <DialogDescription>
              Ingresa el monto que deseas retirar y tu wallet TRC20
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {/* Estado de Rentabilidad */}
            {montosRetiro.alcanzado100 ? (
              <div className="bg-blue-50 border-2 border-blue-500 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="w-5 h-5 text-blue-600" />
                  <h4 className="text-blue-900">✅ 100% Alcanzado - Comisión del 10%</h4>
                </div>
                <p className="text-sm text-blue-800">
                  Puedes retirar tus ganancias + capital. Se aplica una comisión del 10% en todos los retiros.
                </p>
              </div>
            ) : (
              <div className="bg-orange-50 border-2 border-orange-500 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <AlertTriangle className="w-5 h-5 text-orange-600" />
                  <h4 className="text-orange-900">⚠️ Antes del 100% - Comisión del 10%</h4>
                </div>
                <p className="text-sm text-orange-800 mb-2">
                  Antes del 100% se cobra una comisión del 10% en cada retiro.
                </p>
                <p className="text-xs text-orange-700">
                  Progreso actual: {estadoRentabilidad.porcentaje.toFixed(1)}% de 100%
                </p>
              </div>
            )}

            {/* Saldo disponible y Límite de Retiro */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm text-blue-900">Saldo Disponible</p>
                <p className="text-3xl text-blue-600">${montosRetiro.montoDisponible.toFixed(2)}</p>
                {!montosRetiro.alcanzado100 && (
                  <p className="text-xs text-orange-600 mt-1">Con comisión 10%</p>
                )}
              </div>
              <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                <p className="text-sm text-purple-900">Límite Máximo</p>
                <p className="text-3xl text-purple-600">${LIMITE_MAXIMO_RETIRO.toLocaleString()}</p>
              </div>
            </div>

            {/* Monto */}
            <div>
              <Label htmlFor="monto">Monto a Retirar (USDT)</Label>
              <Input
                id="monto"
                type="number"
                value={montoRetiro}
                onChange={(e) => setMontoRetiro(e.target.value)}
                placeholder="0.00"
                min="1"
                max={montosRetiro.montoDisponible}
                step="0.01"
              />
              <p className="text-sm text-slate-500 mt-1">
                Mínimo: 1 USDT - Máximo disponible: ${montosRetiro.montoDisponible.toFixed(2)} USDT
              </p>
            </div>

            {/* Cálculo de Comisión y Monto Neto */}
            {montoIngresado > 0 && (
              <div className="rounded-lg p-4 border-2 bg-orange-50 border-orange-200">
                <h4 className="mb-2 text-orange-900">
                  Resumen del Retiro
                </h4>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span className="text-slate-600">Monto solicitado:</span>
                    <span className="text-slate-800">${montoIngresado.toFixed(2)} USDT</span>
                  </div>
                  <div className="flex justify-between text-orange-700">
                    <span>Comisión (10%):</span>
                    <span>-${comisionCalculada.toFixed(2)} USDT</span>
                  </div>
                  <div className="border-t border-orange-300 pt-1 mt-1"></div>
                  <div className="flex justify-between text-orange-800">
                    <span><strong>Recibirás:</strong></span>
                    <span><strong>${montoNetoCalculado.toFixed(2)} USDT</strong></span>
                  </div>
                </div>
              </div>
            )}

            {/* Wallet */}
            <div>
              <Label htmlFor="wallet">Wallet de Destino (TRC20)</Label>
              <Input
                id="wallet"
                value={walletRetiro}
                onChange={(e) => setWalletRetiro(e.target.value)}
                placeholder="TXXXXXXXXXxxxxxxxxx"
                className="font-mono"
              />
              <p className="text-sm text-slate-500 mt-1">
                Red: TRC20 (Tron) - Solo USDT
              </p>
            </div>

            {/* Info */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
              <p className="text-sm text-blue-800">
                ⏱️ Tu retiro será procesado por el administrador en 5-10 minutos y recibirás el USDT en tu wallet.
              </p>
            </div>

            {/* Botones */}
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => setDialogOpen(false)}
                className="flex-1"
                disabled={procesando}
              >
                Cancelar
              </Button>
              <Button
                onClick={handleSolicitarRetiro}
                className="flex-1 bg-[#0EA5E9] hover:bg-[#0EA5E9]/90"
                disabled={procesando}
              >
                {procesando ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Procesando...
                  </>
                ) : (
                  <>
                    <ArrowUpRight className="mr-2 h-4 w-4" />
                    Solicitar Retiro
                  </>
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}