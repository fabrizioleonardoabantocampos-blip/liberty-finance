import { TrendingUp, DollarSign, Package, ArrowUpRight } from 'lucide-react';
import { useState, useEffect } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { ComprarPack } from './user/ComprarPack';
import { HistorialDepositos } from './user/HistorialDepositos';
import { depositosAPI, comisionesAPI, cobrosAPI, packsAPI } from '../utils/api';

interface ProductosProps {
  userId?: string;
  onRefresh?: () => Promise<void>;
  reinvertPack?: string | null;
  reinvertMonto?: number;
  currentPack?: string;
  isPackCompleted?: boolean;
  saldoWallet?: number; // NUEVO: Saldo de wallet pasado desde UserDashboard
}

export function Productos({ userId, onRefresh, reinvertPack, reinvertMonto = 0, currentPack, isPackCompleted = false, saldoWallet: saldoWalletProp = 0 }: ProductosProps = {}) {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [showHistorial, setShowHistorial] = useState(false);
  const [hasPendingDeposit, setHasPendingDeposit] = useState(false);
  const [loadingCheck, setLoadingCheck] = useState(false); // Cambiar a false
  const [saldoWallet, setSaldoWallet] = useState(saldoWalletProp);
  
  // Si el pack está completado (200%), permitimos comprar uno nuevo
  const hasActivePack = currentPack && currentPack !== 'Sin pack' && !isPackCompleted;
  
  // NUEVO: Bloquear si tiene pack activo O si tiene depósito pendiente
  const canPurchase = !hasActivePack && !hasPendingDeposit;
  
  // Obtener userId de localStorage si no se proporciona
  const currentUserId = userId || (() => {
    const userStr = localStorage.getItem('currentUser');
    if (userStr) {
      const user = JSON.parse(userStr);
      return user.id;
    }
    return 'user-001'; // Fallback
  })();

  // Actualizar saldoWallet cuando cambie el prop
  useEffect(() => {
    if (saldoWalletProp > 0) {
      setSaldoWallet(saldoWalletProp);
    }
  }, [saldoWalletProp]);

  // Verificar si tiene depósitos pendientes
  useEffect(() => {
    const checkPendingDeposits = async () => {
      try {
        setLoadingCheck(true);
        const depositos = await depositosAPI.getByUserId(currentUserId);
        const pending = depositos.some((d: any) => d.estado === 'pendiente');
        setHasPendingDeposit(pending);
        
        // Si el prop es 0, calcular desde la API (fallback)
        if (saldoWalletProp === 0) {
          try {
            // Intentar obtener gastos de ruleta
            let gastosRuleta = [];
            try {
              const response = await fetch(
                `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/make-server-9f68532a/users/${currentUserId}/gastos-ruleta`,
                {
                  headers: {
                    'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`
                  }
                }
              );
              if (response.ok) {
                gastosRuleta = await response.json();
              }
            } catch (e) {
              console.log('⚠️ No se pudieron obtener gastos de ruleta');
            }

            const [comisiones, cobros, packs] = await Promise.all([
              comisionesAPI.getByUserId(currentUserId),
              cobrosAPI.getByUserId(currentUserId),
              packsAPI.getByUserId(currentUserId)
            ]);
            
            const totalGanado = comisiones.reduce((sum: number, c: any) => sum + c.monto, 0);
            const totalRetirado = cobros
              .filter((c: any) => c.estado === 'completado' || c.estado === 'pendiente')
              .reduce((sum: number, c: any) => sum + c.monto, 0);
            const totalGastadoRuleta = gastosRuleta.reduce((sum: number, g: any) => sum + (g.monto || 0), 0);
            
            // Saldo disponible (Sin límite de retiro para visualización, igual que en UserHome y Backend actualizado)
            const saldo = Math.max(0, totalGanado - totalRetirado - totalGastadoRuleta);
            
            console.log('📊 Productos - Saldo calculado:', {
              totalGanado,
              totalRetirado,
              totalGastadoRuleta,
              saldo
            });
            
            setSaldoWallet(saldo);
          } catch (error) {
            console.error('Error calculando saldo wallet:', error);
          }
        }
      } catch (error) {
        console.error('Error al verificar depósitos pendientes:', error);
      } finally {
        setLoadingCheck(false);
      }
    };

    if (currentUserId) {
      checkPendingDeposits();
    }
  }, [currentUserId, dialogOpen, saldoWalletProp]); // Agregar saldoWalletProp como dependencia

  // Función para revalidar depósitos pendientes
  const recheckPendingDeposits = async () => {
    try {
      const depositos = await depositosAPI.getByUserId(currentUserId);
      const pending = depositos.some((d: any) => d.estado === 'pendiente');
      setHasPendingDeposit(pending);
    } catch (error) {
      console.error('Error al verificar depósitos pendientes:', error);
    }
  };

  // Auto-abrir el modal cuando viene de reinvertir
  useEffect(() => {
    if (reinvertPack && reinvertPack !== 'Sin pack') {
      setDialogOpen(true);
    }
  }, [reinvertPack]);

  const paquetes = [
    {
      id: 1,
      nombre: 'Pack 50',
      inversion: 50,
      retorno: 100,
      ganancia: 50,
      rentabilidad: 100,
      color: 'from-slate-500 to-slate-600',
    },
    {
      id: 2,
      nombre: 'Pack 100',
      inversion: 100,
      retorno: 200,
      ganancia: 100,
      rentabilidad: 100,
      color: 'from-blue-500 to-blue-600',
      popular: true,
    },
    {
      id: 3,
      nombre: 'Pack 200',
      inversion: 200,
      retorno: 400,
      ganancia: 200,
      rentabilidad: 100,
      color: 'from-slate-600 to-slate-700',
    },
    {
      id: 4,
      nombre: 'Pack 300',
      inversion: 300,
      retorno: 600,
      ganancia: 300,
      rentabilidad: 100,
      color: 'from-blue-600 to-blue-700',
    },
    {
      id: 5,
      nombre: 'Pack 500',
      inversion: 500,
      retorno: 1000,
      ganancia: 500,
      rentabilidad: 100,
      color: 'from-slate-700 to-slate-800',
    },
    {
      id: 6,
      nombre: 'Pack 1k',
      inversion: 1000,
      retorno: 2000,
      ganancia: 1000,
      rentabilidad: 100,
      color: 'from-blue-700 to-blue-800',
      destacado: true,
    },
    {
      id: 7,
      nombre: 'Pack 5k',
      inversion: 5000,
      retorno: 10000,
      ganancia: 5000,
      rentabilidad: 100,
      color: 'from-slate-800 to-slate-900',
      premium: true,
    },
    {
      id: 8,
      nombre: 'Pack 10k',
      inversion: 10000,
      retorno: 20000,
      ganancia: 10000,
      rentabilidad: 100,
      color: 'from-blue-800 to-blue-900',
      premium: true,
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-600 to-blue-700 flex items-center justify-center shadow-lg">
            <Package className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-slate-500">Paquetes de Inversión</h1>
            <p className="text-slate-600 font-medium">Invierte y genera hasta 100% de rentabilidad</p>
          </div>
        </div>
        <div className="flex gap-3">
          <Button
            onClick={() => setShowHistorial(!showHistorial)}
            variant="outline"
            className="border-blue-600 text-blue-600 hover:bg-blue-50"
          >
            {showHistorial ? 'Ver Paquetes' : 'Ver Historial'}
          </Button>
          <Button
            onClick={() => setDialogOpen(true)}
            className={`bg-gradient-to-r from-blue-600 to-blue-700 hover:opacity-90 ${canPurchase ? '' : 'opacity-50 cursor-not-allowed'}`}
            disabled={!canPurchase}
          >
            <DollarSign className="mr-2 h-4 w-4" />
            {hasActivePack ? 'Pack Activo' : hasPendingDeposit ? 'Depósito Pendiente' : 'Comprar Pack'}
          </Button>
        </div>
      </div>

      {showHistorial ? (
        /* Historial de Depósitos */
        <div>
          <h2 className="text-2xl text-slate-800 mb-4">Historial de Depósitos</h2>
          {currentUserId && <HistorialDepositos userId={currentUserId} />}
        </div>
      ) : (
        <>
          {/* Info Banner Pack Activo */}
          {hasActivePack && (
            <Card className="p-6 bg-amber-50 border border-amber-200 shadow-sm mb-4">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-amber-100 flex items-center justify-center flex-shrink-0">
                  <Package className="w-5 h-5 text-amber-600" />
                </div>
                <div>
                  <h3 className="text-lg font-medium text-amber-800 mb-1">Tienes un pack activo: {currentPack}</h3>
                  <p className="text-amber-700 text-sm">
                    No puedes adquirir un nuevo pack hasta que tu inversión actual finalice (200% de rendimiento).
                    Podrás reinvertir una vez completado el ciclo.
                  </p>
                </div>
              </div>
            </Card>
          )}

          {/* Info Banner Depósito Pendiente */}
          {!hasActivePack && hasPendingDeposit && (
            <Card className="p-6 bg-blue-50 border border-blue-200 shadow-sm mb-4">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0">
                  <Package className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <h3 className="text-lg font-medium text-blue-800 mb-1">Tienes un depósito pendiente de aprobación</h3>
                  <p className="text-blue-700 text-sm">
                    No puedes realizar otra compra hasta que tu depósito actual sea verificado y aprobado por el administrador (5-10 minutos).
                    Puedes verificar el estado en el "Historial de Depósitos".
                  </p>
                </div>
              </div>
            </Card>
          )}

          {!hasActivePack && !hasPendingDeposit && (
            <Card className="p-6 bg-gradient-to-br from-slate-800 to-slate-900 border-0 shadow-xl text-white mb-6">
              <div className="flex items-start gap-4">
                <TrendingUp className="w-8 h-8 flex-shrink-0" />
                <div>
                  <h3 className="text-lg mb-2">💡 ¿Cómo funciona?</h3>
                  <ul className="text-white/80 text-sm space-y-2">
                    <li className="flex items-start gap-2">
                      <span className="text-blue-400 shrink-0">•</span>
                      <span>Selecciona el pack que deseas comprar y haz tu depósito en USDT (TRC20).</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-blue-400 shrink-0">•</span>
                      <span>Tu depósito será verificado en 5-10 minutos. Una vez aprobado, tu pack se activa automáticamente.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-blue-400 shrink-0">•</span>
                      <span>Las comisiones se distribuyen a tu red (10 niveles) + bono del 10% a tu patrocinador.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-blue-400 shrink-0">•</span>
                      <span>Ganancias hasta 100% de tu inversión + comisiones de red + matriz 3x3.</span>
                    </li>
                  </ul>
                </div>
              </div>
            </Card>
          )}

          {/* Paquetes Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {paquetes.map((paquete) => (
              <Card 
                key={paquete.id} 
                className={`p-4 bg-white border-2 shadow-lg transition-all relative overflow-hidden ${
                  !canPurchase 
                    ? 'border-slate-200 opacity-70' 
                    : paquete.popular 
                      ? 'border-blue-600 ring-2 ring-blue-600 ring-offset-2 hover:shadow-xl' 
                      : paquete.destacado
                        ? 'border-blue-500 ring-2 ring-blue-500 ring-offset-2 hover:shadow-xl'
                        : paquete.premium
                          ? 'border-slate-800 ring-2 ring-slate-800 ring-offset-2 hover:shadow-xl'
                          : 'border-slate-200 hover:shadow-xl'
                }`}
              >
                {/* Badge */}
                {paquete.popular && (
                  <div className="absolute -top-2 -right-2 bg-blue-600 text-white text-xs px-2 py-0.5 rounded-full shadow-lg rotate-12">
                    ⭐
                  </div>
                )}
                {paquete.destacado && (
                  <div className="absolute -top-2 -right-2 bg-blue-700 text-white text-xs px-2 py-0.5 rounded-full shadow-lg rotate-12">
                    🔥
                  </div>
                )}
                {paquete.premium && (
                  <div className="absolute -top-2 -right-2 bg-slate-800 text-white text-xs px-2 py-0.5 rounded-full shadow-lg rotate-12">
                    👑
                  </div>
                )}

                {/* Icon */}
                <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${paquete.color} flex items-center justify-center text-white shadow-md mb-3`}>
                  <DollarSign className="w-5 h-5" />
                </div>

                {/* Pack Title */}
                <h3 className="text-slate-800 mb-1">{paquete.nombre}</h3>
                <p className="text-slate-600 text-xs mb-3">Inversión en USDT</p>

                {/* Stats */}
                <div className="space-y-2 mb-3">
                  <div className="p-2 bg-gradient-to-r from-blue-50 to-blue-100 rounded-lg border border-blue-200">
                    <p className="text-slate-600 text-xs">Inversión</p>
                    <p className="text-blue-700">${paquete.inversion.toLocaleString()}</p>
                  </div>

                  <div className="p-2 bg-gradient-to-r from-slate-50 to-slate-100 rounded-lg border border-slate-200">
                    <p className="text-slate-600 text-xs">Ganancia</p>
                    <p className="text-slate-800">+${paquete.ganancia.toLocaleString()}</p>
                  </div>

                  <div className={`p-2 rounded-lg bg-gradient-to-r ${paquete.color}`}>
                    <p className="text-white/80 text-xs">Retorno Total</p>
                    <p className="text-white font-semibold">${paquete.retorno.toLocaleString()}</p>
                  </div>
                </div>

                {/* Button */}
                <Button
                  onClick={() => canPurchase && setDialogOpen(true)}
                  className={`w-full text-sm h-8 text-white ${
                    !canPurchase 
                      ? 'bg-slate-400 cursor-not-allowed' 
                      : `bg-gradient-to-r ${paquete.color} hover:opacity-90`
                  }`}
                  disabled={!canPurchase}
                >
                  {!canPurchase ? (
                    'Bloqueado'
                  ) : (
                    <>
                      <ArrowUpRight className="w-3 h-3 mr-1" />
                      Comprar Ahora
                    </>
                  )}
                </Button>
              </Card>
            ))}
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="p-6 bg-gradient-to-br from-blue-600 to-blue-700 border-0 shadow-xl text-white">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <p className="text-white/80 text-sm mb-1">Paquetes Disponibles</p>
                  <p className="text-4xl">{paquetes.length}</p>
                </div>
                <div className="w-14 h-14 rounded-xl bg-white/20 flex items-center justify-center backdrop-blur-sm">
                  <Package className="w-7 h-7" />
                </div>
              </div>
              <p className="text-white/70 text-xs">Opciones de inversión activas</p>
            </Card>

            <Card className="p-6 bg-gradient-to-br from-slate-700 to-slate-800 border-0 shadow-xl text-white">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <p className="text-white/80 text-sm mb-1">Inversión Mínima</p>
                  <p className="text-4xl">$50</p>
                </div>
                <div className="w-14 h-14 rounded-xl bg-white/20 flex items-center justify-center backdrop-blur-sm">
                  <DollarSign className="w-7 h-7" />
                </div>
              </div>
              <p className="text-white/70 text-xs">USDT para comenzar</p>
            </Card>

            <Card className="p-6 bg-gradient-to-br from-slate-900 to-blue-900 border-0 shadow-xl text-white">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <p className="text-white/80 text-sm mb-1">Rentabilidad</p>
                  <p className="text-4xl">100%</p>
                </div>
                <div className="w-14 h-14 rounded-xl bg-white/20 flex items-center justify-center backdrop-blur-sm">
                  <TrendingUp className="w-7 h-7" />
                </div>
              </div>
              <p className="text-white/70 text-xs">Ganancias hasta 100% de tu inversión</p>
            </Card>
          </div>

          {/* Comparación de Paquetes */}
          <Card className="p-6">
            <h3 className="text-slate-800 text-lg mb-4">📊 Comparación de Paquetes</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-slate-200">
                    <th className="text-left py-3 px-2 text-slate-600">Paquete</th>
                    <th className="text-center py-3 px-2 text-slate-600">Inversión</th>
                    <th className="text-center py-3 px-2 text-slate-600">Ganancia</th>
                    <th className="text-right py-3 px-2 text-slate-600">Retorno Total</th>
                    <th className="text-center py-3 px-2 text-slate-600">Rentabilidad</th>
                  </tr>
                </thead>
                <tbody>
                  {paquetes.map((paquete) => (
                    <tr key={paquete.id} className="border-b border-slate-100 hover:bg-slate-50">
                      <td className="py-3 px-2">
                        <span className={`inline-flex items-center justify-center px-3 py-1 rounded-lg bg-gradient-to-r ${paquete.color} text-white text-sm`}>
                          {paquete.nombre}
                        </span>
                      </td>
                      <td className="text-center py-3 px-2 text-slate-800">
                        ${paquete.inversion.toLocaleString()}
                      </td>
                      <td className="text-center py-3 px-2">
                        <span className="text-blue-600 font-medium">
                          +${paquete.ganancia.toLocaleString()}
                        </span>
                      </td>
                      <td className="text-right py-3 px-2">
                        <span className="text-slate-800 font-semibold">
                          ${paquete.retorno.toLocaleString()}
                        </span>
                      </td>
                      <td className="text-center py-3 px-2">
                        <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded-lg">
                          {paquete.rentabilidad}%
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>

          {/* Información Importante */}
          <Card className="p-6 bg-gradient-to-br from-blue-600 to-blue-700 border-0 shadow-xl text-white">
            <h3 className="text-lg mb-3">⚠️ Información Importante</h3>
            <ul className="space-y-2 text-sm text-white/90">
              <li className="flex items-start gap-2">
                <span className="shrink-0">•</span>
                <span>Al comprar un pack, depositas USDT (TRC20) y esperas la verificación del administrador (5-10 min).</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="shrink-0">•</span>
                <span>Una vez verificado, tu pack se activa automáticamente y las comisiones se distribuyen a tu red.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="shrink-0">•</span>
                <span>Ganas rendimiento diario + comisiones multinivel (10 niveles) + matriz 3x3.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="shrink-0">•</span>
                <span>Retiros desde 1 USDT con verificación del administrador.</span>
              </li>
            </ul>
          </Card>
        </>
      )}

      {/* Dialog Comprar Pack */}
      {currentUserId && (
        <ComprarPack
          open={dialogOpen}
          onOpenChange={setDialogOpen}
          userId={currentUserId}
          packActual={currentPack}
          montoActual={reinvertMonto}
          isPackCompleted={isPackCompleted}
          saldoWallet={saldoWallet}
          onSuccess={() => {
            setShowHistorial(true);
            if (onRefresh) {
              onRefresh();
            }
          }}
        />
      )}
    </div>
  );
}