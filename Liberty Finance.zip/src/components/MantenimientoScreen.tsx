import { Wrench, Clock, Calendar } from 'lucide-react';

interface MantenimientoScreenProps {
  horaActual: string;
  tiempoRestante: string;
}

export function MantenimientoScreen({ horaActual, tiempoRestante }: MantenimientoScreenProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center p-4">
      <div className="max-w-2xl w-full">
        {/* Card principal */}
        <div className="bg-white/10 backdrop-blur-xl rounded-3xl p-8 md:p-12 border border-white/20 shadow-2xl">
          {/* Icono animado */}
          <div className="flex justify-center mb-8">
            <div className="relative">
              <div className="w-24 h-24 bg-gradient-to-br from-orange-500 to-orange-600 rounded-full flex items-center justify-center shadow-xl animate-pulse">
                <Wrench className="w-12 h-12 text-white" />
              </div>
              {/* Círculo animado */}
              <div className="absolute inset-0 rounded-full border-4 border-orange-400/30 animate-ping"></div>
            </div>
          </div>

          {/* Título */}
          <h1 className="text-4xl md:text-5xl text-white text-center mb-4">
            Mantenimiento Programado
          </h1>
          
          <p className="text-xl text-white/80 text-center mb-8">
            Estamos mejorando nuestros sistemas para brindarte una mejor experiencia
          </p>

          {/* Info de tiempo */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            {/* Hora actual */}
            <div className="bg-white/10 rounded-2xl p-6 border border-white/10">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 bg-blue-500/20 rounded-xl flex items-center justify-center">
                  <Clock className="w-5 h-5 text-blue-300" />
                </div>
                <p className="text-white/60 text-sm">Hora Actual</p>
              </div>
              <p className="text-2xl text-white font-mono">{horaActual}</p>
            </div>

            {/* Tiempo restante */}
            <div className="bg-white/10 rounded-2xl p-6 border border-white/10">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 bg-green-500/20 rounded-xl flex items-center justify-center">
                  <Calendar className="w-5 h-5 text-green-300" />
                </div>
                <p className="text-white/60 text-sm">Tiempo Restante</p>
              </div>
              <p className="text-2xl text-white font-mono">{tiempoRestante || 'Calculando...'}</p>
            </div>
          </div>

          {/* Mensaje de finalización */}
          <div className="bg-gradient-to-r from-green-500/20 to-emerald-500/20 rounded-2xl p-6 border border-green-400/30">
            <p className="text-white/90 text-center text-lg">
              ✨ <span className="font-semibold">Estaremos de vuelta a las 10:00 AM</span>
            </p>
            <p className="text-white/70 text-center text-sm mt-2">
              Horario de mantenimiento: 1:00 AM - 10:00 AM
            </p>
          </div>

          {/* Logo/Nombre de la empresa */}
          <div className="mt-8 text-center">
            <p className="text-white/50 text-sm">Liberty Finance</p>
            <p className="text-white/30 text-xs mt-1">Gracias por tu paciencia</p>
          </div>
        </div>

        {/* Indicador de auto-actualización */}
        <div className="mt-6 text-center">
          <p className="text-white/40 text-xs">
            🔄 La página se actualizará automáticamente cuando el mantenimiento termine
          </p>
        </div>
      </div>
    </div>
  );
}