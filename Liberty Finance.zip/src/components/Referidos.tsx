import { UserData } from '../data/mockData';
import { Card } from './ui/card';
import { Users, Copy, Check } from 'lucide-react';
import { useState, useEffect, useMemo } from 'react';
import { Button } from './ui/button';
import { copyToClipboard } from '../utils/clipboard';
import { callServer } from '../utils/api';

interface ReferidosProps {
  userData: UserData;
}

export function Referidos({ userData }: ReferidosProps) {
  const [copied, setCopied] = useState(false);
  const [referidosDirectosReales, setReferidosDirectosReales] = useState<any[]>([]);
  const [loading, setLoading] = useState(false); // Cambiar a false

  useEffect(() => {
    // Intentar caché primero
    const cacheKey = `referidos_${userData.id}`;
    const cachedData = sessionStorage.getItem(cacheKey);
    const cachedTimestamp = sessionStorage.getItem(`${cacheKey}_time`);
    
    if (cachedData && cachedTimestamp) {
      const cacheAge = Date.now() - parseInt(cachedTimestamp);
      if (cacheAge < 2 * 60 * 1000) { // 2 minutos
        setReferidosDirectosReales(JSON.parse(cachedData));
        // Cargar datos frescos en segundo plano
        setTimeout(() => cargarReferidosDirectos(), 100);
        return;
      }
    }
    
    cargarReferidosDirectos();
  }, [userData.id]);
  
  const cargarReferidosDirectos = async () => {
    if (!userData.id) return;
    try {
      const directosReales = await callServer(`/users/${userData.id}/referidos`, 'GET');
      setReferidosDirectosReales(directosReales || []);
      
      // Guardar en caché
      const cacheKey = `referidos_${userData.id}`;
      sessionStorage.setItem(cacheKey, JSON.stringify(directosReales || []));
      sessionStorage.setItem(`${cacheKey}_time`, Date.now().toString());
    } catch (err) {
      console.warn('⚠️ [Referidos] No se pudieron cargar referidos directos');
    }
  };

  // Link de referidos con dominio oficial
  const referralLink = `https://libertyfinance.life?ref=${userData.id_unico}`;

  const handleCopyLink = () => {
    copyToClipboard(referralLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getInitials = (nombre: string) => {
    if (!nombre) return '??';
    
    const parts = nombre.trim().split(' ').filter(p => p && p !== 'undefined');
    if (parts.length >= 2) {
      return `${parts[0][0]}${parts[1][0]}`.toUpperCase();
    }
    if (parts.length === 1) {
      return parts[0].substring(0, 2).toUpperCase();
    }
    return '??';
  };
  
  // CREAR SET DE IDs DIRECTOS REALES
  const idsDirectosReales = useMemo(() => {
    return new Set(referidosDirectosReales.map((d: any) => d.id_unico));
  }, [referidosDirectosReales]);
  
  // CALCULAR DIRECTOS REALES (con pack activo)
  const directosConPack = useMemo(() => {
    // ✅ CORREGIDO: Usar userData.directosConPack del backend (ya calculado correctamente)
    if (userData.directosConPack !== undefined) {
      console.log('✅ [Referidos] Usando directosConPack del backend:', userData.directosConPack);
      return userData.directosConPack;
    }
    
    // Fallback: calcular localmente solo si el backend no lo envió
    console.log('⚠️ [Referidos] Calculando directosConPack localmente (fallback)');
    if (!referidosDirectosReales.length) return 0;
    return referidosDirectosReales.filter((d: any) => {
      const refEnDatos = userData.directos.find((ud: any) => ud.id_unico === d.id_unico);
      return refEnDatos && refEnDatos.inversion > 0;
    }).length;
  }, [userData.directosConPack, referidosDirectosReales, userData.directos]);
  
  // CALCULAR MATRIZ ACTIVA (usuarios con pack activo - TODOS los niveles)
  const matrizActiva = useMemo(() => {
    console.log('🔍 [Referidos] userData.directos length:', userData.directos?.length || 0);
    console.log('🔍 [Referidos] userData.directos:', userData.directos);
    const activos = userData.directos.filter((d: any) => d.inversion > 0).length;
    console.log('🔍 [Referidos] matrizActiva calculada:', activos);
    return activos;
  }, [userData.directos]);

  return (
    <div className="space-y-4 md:space-y-6 w-full max-w-full overflow-hidden">
      {/* Header */}
      <div className="flex items-center gap-3 md:gap-4">
        <div className="w-10 h-10 md:w-12 md:h-12 rounded-xl bg-gradient-to-br from-blue-600 to-blue-700 flex items-center justify-center shadow-lg shrink-0">
          <Users className="w-5 h-5 md:w-6 md:h-6 text-white" />
        </div>
        <div className="min-w-0 flex-1">
          <h1 className="text-2xl md:text-3xl text-slate-500 truncate font-bold">Mis Referidos</h1>
          <p className="text-xs md:text-base text-slate-600 truncate font-medium">Gestiona y visualiza tus referidos</p>
        </div>
      </div>

      {/* Referral Link Card */}
      <Card className="p-4 md:p-6 bg-gradient-to-br from-blue-600 to-blue-700 border-0 shadow-xl">
        <div className="flex flex-col sm:flex-row items-start gap-4">
          <div className="p-3 rounded-lg bg-white/20 backdrop-blur-sm shrink-0 hidden sm:block">
            <Users className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1 w-full min-w-0">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 rounded-lg bg-white/20 backdrop-blur-sm shrink-0 sm:hidden">
                <Users className="w-5 h-5 text-white" />
              </div>
              <h3 className="text-white text-lg font-semibold">Tu Enlace de Referido</h3>
            </div>
            <p className="text-white/80 text-sm mb-4">
              Comparte este enlace para invitar a nuevos miembros a tu red
            </p>
            <div className="flex flex-col sm:flex-row gap-2 w-full">
              <div className="flex-1 px-3 py-2 rounded-lg bg-white/10 border border-white/20 text-white truncate backdrop-blur-sm text-sm font-mono min-w-0">
                {referralLink}
              </div>
              <Button
                onClick={handleCopyLink}
                className="bg-white hover:bg-white/90 text-blue-700 shrink-0 w-full sm:w-auto"
              >
                {copied ? (
                  <>
                    <Check className="w-4 h-4 mr-2" />
                    Copiado
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4 mr-2" />
                    Copiar
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
        <Card className="p-4 md:p-6">
          <div className="p-3 md:p-4 bg-[#e0f2fe] rounded-xl border-2 border-primary/20">
            <h3 className="text-slate-600 text-xs md:text-sm mb-1 md:mb-2">Referidos con Pack Activo</h3>
            <p className="text-2xl md:text-3xl text-primary font-bold">
              {directosConPack}
            </p>
            <p className="text-xs text-slate-500 mt-1">
              {referidosDirectosReales.length} directos registrados
            </p>
          </div>
        </Card>

        <Card className="p-4 md:p-6">
          <div className="p-3 md:p-4 bg-[#e0f2fe] rounded-xl border-2 border-primary/20">
            <h3 className="text-slate-600 text-xs md:text-sm mb-1 md:mb-2">Matriz Total</h3>
            <p className="text-2xl md:text-3xl text-primary font-bold">
              {matrizActiva}
            </p>
            <p className="text-xs text-slate-500 mt-1">
              {userData.directos.length} usuarios en red
            </p>
          </div>
        </Card>

        <Card className="p-4 md:p-6">
          <div className="p-3 md:p-4 bg-[#e0f2fe] rounded-xl border-2 border-primary/20">
            <h3 className="text-slate-600 text-xs md:text-sm mb-1 md:mb-2">Comisiones Generadas</h3>
            <p className="text-2xl md:text-3xl text-primary font-bold break-all">
              ${(userData.comisiones_red || 0).toFixed(2)}
            </p>
          </div>
        </Card>
      </div>

      {/* Info importante sobre rangos */}
      <Card className="p-4 md:p-6 bg-gradient-to-br from-blue-50 to-cyan-50 border-2 border-blue-200">
        <div className="flex items-start gap-3">
          <div className="p-2 rounded-lg bg-blue-600 shrink-0">
            <Users className="w-5 h-5 text-white" />
          </div>
          <div className="flex-1">
            <h3 className="text-blue-900 font-semibold mb-2">💡 Importante sobre tu Rango</h3>
            <div className="text-sm text-blue-800 space-y-2">
              <p>
                <strong>Para avanzar en rangos:</strong> Solo cuentan los referidos directos que han comprado un pack y tienen inversión activa.
              </p>
              <p>
                Los usuarios que solo se registraron pero no compraron pack aparecerán como <span className="px-2 py-0.5 rounded bg-orange-100 text-orange-700 font-semibold">⏳ PENDIENTE</span> y no cuentan para tu rango hasta que activen su cuenta.
              </p>
            </div>
          </div>
        </div>
      </Card>

      {/* Referidos List */}
      <Card className="p-4 md:p-6">
        <h2 className="text-lg md:text-xl text-slate-800 mb-4 md:mb-6 font-semibold">Referidos Directos e Indirectos</h2>

        {!userData.directos || userData.directos.length === 0 ? (
          <div className="text-center py-8 md:py-12">
            <Users className="w-12 h-12 md:w-16 md:h-16 text-slate-400 mx-auto mb-4" />
            <h3 className="text-slate-800 mb-2 text-sm md:text-base">Aún no tienes referidos</h3>
            <p className="text-slate-600 mb-2 text-xs md:text-sm">
              Comparte tu enlace de referido para empezar a construir tu red
            </p>
            <p className="text-xs text-orange-600 mb-6">
              ⚠️ Debug: userData.directos = {JSON.stringify(userData.directos?.length || 0)} usuarios
            </p>
            <Button onClick={handleCopyLink} className="bg-blue-600 hover:bg-blue-700 text-white text-sm">
              <Copy className="w-4 h-4 mr-2" />
              Copiar Enlace
            </Button>
          </div>
        ) : (
          <div className="space-y-3">
            {userData.directos.map((referido, index) => {
              const tienePack = referido.pack && referido.pack !== 'Sin pack';
              // ✅ CORREGIDO: Un referido es DIRECTO si es nivel 1
              const esDirectoReal = referido.nivel === 1 || idsDirectosReales.has(referido.id_unico);
              
              return (
                <div
                  key={index}
                  className={`group relative flex flex-col sm:flex-row items-start sm:items-center gap-3 sm:gap-4 p-3 sm:p-4 rounded-lg border transition-all ${
                    tienePack 
                      ? 'bg-slate-50 border-slate-200 hover:border-blue-300 hover:bg-blue-50'
                      : 'bg-orange-50 border-orange-200 hover:border-orange-300'
                  }`}
                >
                  {/* Avatar */}
                  <div className={`w-10 h-10 sm:w-12 sm:h-12 rounded-full flex items-center justify-center text-white shrink-0 ${
                    tienePack
                      ? 'bg-gradient-to-br from-blue-600 to-blue-700'
                      : 'bg-gradient-to-br from-orange-500 to-orange-600'
                  }`}>
                    {getInitials(referido.nombre)}
                  </div>

                  {/* Info */}
                  <div className="flex-1 w-full min-w-0">
                    <div className="flex flex-wrap items-center gap-2 mb-1">
                      <h4 className="text-slate-900 font-medium truncate max-w-[150px] sm:max-w-none">{referido.nombre}</h4>
                      {/* Badge de Tipo de Referido (Directo / Indirecto) */}
                      {esDirectoReal ? (
                        <span className="px-1.5 py-0.5 rounded text-[10px] sm:text-xs bg-purple-100 text-purple-700 border border-purple-200 font-semibold whitespace-nowrap">
                          DIRECTO
                        </span>
                      ) : (
                        <span className="px-1.5 py-0.5 rounded text-[10px] sm:text-xs bg-gray-100 text-gray-600 border border-gray-200 whitespace-nowrap">
                          INDIRECTO (Nivel {referido.nivel})
                        </span>
                      )}
                      
                      {tienePack ? (
                        <span className="px-1.5 py-0.5 rounded text-[10px] sm:text-xs bg-blue-100 text-blue-700 border border-blue-200 whitespace-nowrap">
                          ✅ ACTIVO
                        </span>
                      ) : (
                        <span className="px-1.5 py-0.5 rounded text-[10px] sm:text-xs bg-orange-100 text-orange-700 border border-orange-200 whitespace-nowrap">
                          ⏳ PENDIENTE
                        </span>
                      )}
                    </div>
                    <div className="flex flex-wrap gap-x-3 gap-y-1 text-xs sm:text-sm text-slate-600">
                      <span className="truncate">ID: {referido.id}</span>
                      <span>Nivel: {referido.nivel}</span>
                      <span className={`${tienePack ? 'text-blue-600 font-medium' : 'text-orange-600'} truncate`}>
                        Pack: {referido.pack}
                      </span>
                    </div>
                  </div>

                  {/* Hover Tooltip */}
                  <div className="absolute top-full left-0 mt-2 px-4 py-3 bg-slate-900 rounded-lg shadow-xl opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-10 border border-slate-700 whitespace-nowrap">
                    <p className="text-white mb-1">{referido.nombre}</p>
                    <p className="text-sm text-blue-300">Pack: {referido.pack}</p>
                    <p className="text-sm text-slate-400">ID: {referido.id}</p>
                    {!tienePack && (
                      <p className="text-xs text-orange-300 mt-1">⚠️ Pendiente de depósito</p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </Card>

      {/* Info */}
      <Card className="p-6 bg-gradient-to-r from-slate-50 to-blue-50 border-blue-200 shadow-lg">
        <h3 className="text-slate-800 mb-3">💡 Información Importante</h3>
        <ul className="space-y-2 text-slate-600 text-sm">
          <li className="flex items-start gap-2">
            <span className="text-blue-600 shrink-0">✅</span>
            <span><strong>Referidos con Pack:</strong> Solo los referidos que han activado un pack aparecen en tu ciclo multinivel y generan comisiones.</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-orange-600 shrink-0">⏳</span>
            <span><strong>Referidos sin Pack:</strong> Están registrados pero aún no han realizado ningún depósito. Motívalos a activar su pack para comenzar a ganar comisiones.</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-blue-600 shrink-0">💰</span>
            <span>Cada referido activo genera comisiones automáticas en 10 niveles de tu red.</span>
          </li>
        </ul>
      </Card>
    </div>
  );
}