import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '../ui/dialog';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Copy, Check, Upload, Loader2, CreditCard, Wallet, ArrowRight, ExternalLink, DollarSign } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { depositosAPI, configuracionAPI, nowpaymentsAPI, productosAPI, packsAPI, usersAPI } from '../../utils/api';
import { copyToClipboard } from '../../utils/clipboard';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { Card } from '../ui/card';

interface ComprarPackProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess?: () => void;
  userId: string;
  packActual?: string | null; // Pack actual del usuario
  montoActual?: number; // Monto del pack actual
  isPackCompleted?: boolean; // Indica si el pack actual ha completado su ciclo
  saldoWallet?: number; // NUEVO: Saldo disponible en wallet
}

interface Producto {
  id: string;
  nombre: string;
  precio: number;
  descripcion: string;
  imagen?: string;
  stock: number;
  activo: boolean;
}

export function ComprarPack({ open, onOpenChange, onSuccess, userId, packActual, montoActual = 0, isPackCompleted = false, saldoWallet = 0 }: ComprarPackProps) {
  const [step, setStep] = useState<'select' | 'payment-method' | 'wallet' | 'manual' | 'nowpayments'>('select');
  const [selectedPack, setSelectedPack] = useState<string | null>(null);
  const [selectedMonto, setSelectedMonto] = useState<number>(0);
  const [comprobante, setComprobante] = useState<File | null>(null);
  const [txHash, setTxHash] = useState('');
  const [walletAdmin, setWalletAdmin] = useState('');
  const [qrCodeUrl, setQrCodeUrl] = useState('');
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(false);
  const [loadingPacks, setLoadingPacks] = useState(true);
  const [productos, setProductos] = useState<Producto[]>([]);
  const [nowPaymentUrl, setNowPaymentUrl] = useState('');
  const [saldoDisponible, setSaldoDisponible] = useState(saldoWallet);

  // DEBUG: Ver qué props recibe ComprarPack
  useEffect(() => {
    console.log('🔍 ComprarPack PROPS:', {
      packActual,
      montoActual,
      isPackCompleted,
      saldoWallet,
      userId
    });
  }, [packActual, montoActual, isPackCompleted, saldoWallet, userId]);

  useEffect(() => {
    if (open) {
      cargarConfiguracion();
      cargarProductos();
      cargarSaldoWallet();
    }
  }, [open]);

  // Actualizar saldoDisponible cuando cambie el prop saldoWallet
  useEffect(() => {
    if (saldoWallet !== undefined && saldoWallet !== null) {
      setSaldoDisponible(saldoWallet);
    }
  }, [saldoWallet]);

  const cargarSaldoWallet = async () => {
    try {
      console.log('🔍 ComprarPack - saldoWallet prop recibido:', saldoWallet);
      
      // Si el saldo es mayor a 0, usarlo
      if (saldoWallet > 0) {
        console.log('✅ Usando saldo del prop:', saldoWallet);
        setSaldoDisponible(saldoWallet);
        return;
      }
      
      console.log('⚙️ Obteniendo saldo desde API...');
      // Obtener saldo desde el endpoint dedicado
      const response = await usersAPI.getSaldoWallet(userId);
      
      console.log('📊 Saldo wallet desde servidor:', response);
      
      setSaldoDisponible(response.saldo || 0);
    } catch (error) {
      console.error('Error al cargar saldo de wallet:', error);
      setSaldoDisponible(0);
    }
  };

  const cargarConfiguracion = async () => {
    try {
      const config = await configuracionAPI.get();
      setWalletAdmin(config.walletPrincipal || '');
      setQrCodeUrl(config.qrCodeUrl || '');
    } catch (error) {
      console.error('Error al cargar configuración:', error);
      toast.error('Error al cargar la configuración');
    }
  };

  const cargarProductos = async () => {
    setLoadingPacks(true);
    try {
      const productosData = await productosAPI.getAll();
      setProductos(productosData);
    } catch (error) {
      console.error('Error al cargar productos:', error);
      toast.error('Error al cargar los packs disponibles');
    } finally {
      setLoadingPacks(false);
    }
  };

    const handleSelectPack = (pack: Producto) => {
    // Verificar si el usuario ya tiene un pack activo y NO está completado
    if (packActual && packActual !== 'Sin pack' && !isPackCompleted) {
      toast.error(`⚠️ Ya tienes un pack activo (${packActual}). Debes esperar a que finalice para adquirir uno nuevo.`);
      return;
    }
    
    // NUEVA VALIDACIÓN: Si está reinvirtiendo, verificar que el pack sea >= al actual
    const esReinversion = packActual && packActual !== 'Sin pack' && isPackCompleted;
    if (esReinversion && pack.precio < montoActual) {
      toast.error(`⚠️ No puedes seleccionar un pack de menor valor. Tu pack actual es de $${montoActual.toLocaleString()}. Debes elegir el mismo valor o mayor.`);
      return;
    }
    
    setSelectedPack(pack.nombre);
    setSelectedMonto(pack.precio);
    setStep('payment-method'); // Ir a selección de método de pago
  };

  const handleSelectMetodo = (metodo: 'wallet' | 'manual' | 'nowpayments') => {
    setStep(metodo);
    if (metodo === 'wallet') {
      setStep('wallet'); // Pagar con wallet
    } else if (metodo === 'manual') {
      setStep('manual'); // Depósito manual
    } else {
      handleNowPayments(); // Ir directamente a NOWPayments
    }
  };

  const handleCopyWallet = async () => {
    if (!walletAdmin) {
      toast.error('No hay wallet definida para copiar');
      return;
    }

    // ESTRATEGIA DE COPIA ROBUSTA (Móviles + Modales)
    
    // 1. Intentar copiar desde el input visible (Más fiable en iOS/Android dentro de Modales)
    const inputElement = document.getElementById('wallet-address-input') as HTMLInputElement;
    if (inputElement) {
      try {
        inputElement.focus();
        inputElement.select();
        inputElement.setSelectionRange(0, 99999); // Crucial para iOS
        
        const successful = document.execCommand('copy');
        if (successful) {
          setCopied(true);
          toast.success('Wallet copiada al portapapeles');
          setTimeout(() => setCopied(false), 2000);
          // Quitar selección para que no se vea feo
          window.getSelection()?.removeAllRanges();
          return;
        }
      } catch (err) {
        console.warn('Fallo al copiar desde input visible, intentando siguiente método:', err);
      }
    }
    
    // 2. Intentar API moderna (navigator.clipboard)
    if (navigator.clipboard && navigator.clipboard.writeText) {
      try {
        await navigator.clipboard.writeText(walletAdmin);
        setCopied(true);
        toast.success('Wallet copiada al portapapeles');
        setTimeout(() => setCopied(false), 2000);
        return;
      } catch (err) {
        console.warn('Fallo navigator.clipboard:', err);
      }
    }
    
    // 3. Último recurso (Utility fallback con textarea oculto)
    const success = await copyToClipboard(walletAdmin);
    if (success) {
      setCopied(true);
      toast.success('Wallet copiada al portapapeles');
      setTimeout(() => setCopied(false), 2000);
    } else {
      toast.error('No se pudo copiar automáticamente. Por favor selecciona y copia manualmente.');
    }
  };

  const handleConfirmarDepositoManual = async () => {
    if (!selectedPack || !selectedMonto) return;

    if (!txHash.trim()) {
      toast.error('El hash de transacción es obligatorio para verificar el pago');
      return;
    }

    // NUEVA VALIDACIÓN: Verificar si ya tiene un depósito pendiente antes de continuar
    try {
      const depositos = await depositosAPI.getByUserId(userId);
      const hasPending = depositos.some((d: any) => d.estado === 'pendiente');
      
      if (hasPending) {
        toast.error('⚠️ Ya tienes un depósito pendiente de aprobación. Debes esperar a que sea verificado antes de hacer otra compra.');
        return;
      }
    } catch (error) {
      console.error('Error al verificar depósitos pendientes:', error);
      toast.error('No se pudo verificar el estado de tus depósitos. Por favor, intenta de nuevo.');
      return;
    }

    setLoading(true);
    try {
      let comprobanteUrl = '';

      // Subir comprobante si existe
      if (comprobante) {
        try {
          toast.info('Subiendo comprobante...');
          const uploadResult = await depositosAPI.uploadComprobante(comprobante);
          comprobanteUrl = uploadResult.url;
        } catch (error) {
          console.error('Error al subir comprobante:', error);
          toast.error('No se pudo subir el comprobante, pero se intentará registrar el depósito.');
          // Continuar aunque falle la subida? O detener?
          // Si es opcional, continuamos pero sin la imagen.
        }
      }

      const depositoData = {
        userId: userId,
        packNombre: selectedPack,
        monto: selectedMonto,
        walletDestino: walletAdmin,
        comprobante: comprobanteUrl,
        txHash: txHash || ''
      };

      await depositosAPI.create(depositoData);

      toast.success('¡Depósito registrado! En verificación...');
      resetForm();
      onOpenChange(false);
      
      if (onSuccess) {
        onSuccess();
      }
    } catch (error: any) {
      console.error('Error al registrar depósito:', error);
      toast.error(error.message || 'Error al registrar depósito');
    } finally {
      setLoading(false);
    }
  };

  const handleComprarConWallet = async () => {
    if (!selectedPack || !selectedMonto) return;

    setLoading(true);
    try {
      // Verificar saldo suficiente
      if (saldoDisponible < selectedMonto) {
        toast.error(`Saldo insuficiente. Tienes $${saldoDisponible.toFixed(2)} y necesitas $${selectedMonto.toFixed(2)}`);
        return;
      }

      const response = await packsAPI.comprarConWallet({
        userId,
        packNombre: selectedPack,
        monto: selectedMonto
      });

      console.log('✅ Pack comprado con wallet:', response);
      
      toast.success(`¡Pack ${selectedPack} comprado exitosamente!`);
      
      // Actualizar inmediatamente y cerrar
      resetForm();
      onOpenChange(false);
      
      // Recargar datos del usuario
      if (onSuccess) {
        await onSuccess();
      }

    } catch (error: any) {
      console.error('Error al comprar con wallet:', error);
      toast.error(error.message || 'Error al procesar la compra con wallet');
    } finally {
      setLoading(false);
    }
  };

  const handleNowPayments = async () => {
    if (!selectedPack || !selectedMonto) return;

    setLoading(true);
    setStep('nowpayments'); // Mostrar pantalla de NOWPayments
    
    try {
      const response = await nowpaymentsAPI.createPayment({
        userId,
        packNombre: selectedPack,
        monto: selectedMonto
      });

      console.log('💳 Pago creado en NOWPayments:', response);
      
      // NOWPayments devuelve un invoice_url o pay_address
      const paymentUrl = response.payment?.invoice_url || response.payment?.pay_url;
      
      if (paymentUrl) {
        setNowPaymentUrl(paymentUrl);
        toast.success('¡Pago creado! Redirigiendo a NOWPayments...');
        
        // Abrir en nueva ventana
        setTimeout(() => {
          window.open(paymentUrl, '_blank');
        }, 1000);
      } else {
        toast.info('Pago registrado. El depósito está siendo procesado.');
      }

      // Cerrar el dialog después de un momento
      setTimeout(() => {
        resetForm();
        onOpenChange(false);
        if (onSuccess) {
          onSuccess();
        }
      }, 2000);

    } catch (error: any) {
      console.error('Error al crear pago con NOWPayments:', error);
      toast.error(error.message || 'Error al procesar pago con NOWPayments');
      setStep('payment-method'); // Volver a selección de método
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setStep('select');
    setSelectedPack(null);
    setSelectedMonto(0);
    setComprobante(null);
    setTxHash('');
    setNowPaymentUrl('');
  };

  const handleClose = () => {
    resetForm();
    onOpenChange(false);
  };

  if (loadingPacks) {
    return (
      <Dialog open={open} onOpenChange={handleClose}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Cargando packs</DialogTitle>
            <DialogDescription>
              Por favor espera mientras cargamos los packs disponibles...
            </DialogDescription>
          </DialogHeader>
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        {/* PASO 1: Seleccionar Pack */}
        {step === 'select' && (
          <>
            <DialogHeader>
              <DialogTitle>
                {packActual && packActual !== 'Sin pack' && !isPackCompleted ? 'Reinvertir en tu Pack' : 'Comprar Pack de Inversión'}
              </DialogTitle>
              <DialogDescription>
                {packActual && packActual !== 'Sin pack' && !isPackCompleted ? (
                  <span className="text-amber-600 font-medium">
                    ⚠️ Tienes un pack activo ({packActual}). Debes esperar a que finalice para adquirir uno nuevo.
                  </span>
                ) : (
                  'Selecciona el pack que deseas adquirir'
                )}
              </DialogDescription>
            </DialogHeader>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
              {productos
                .sort((a, b) => a.precio - b.precio)
                .map((pack) => {
                // Lógica modificada: Si tiene pack activo y NO está completado, NO puede comprar nada
                const tienePackActivo = packActual && packActual !== 'Sin pack';
                
                // NUEVA LÓGICA: Si está reinvirtiendo (pack completado), solo puede comprar packs >= al actual
                const esReinversion = tienePackActivo && isPackCompleted;
                const packMenorAlActual = esReinversion && pack.precio < montoActual;
                
                // Puede comprar si: NO tiene pack activo O (tiene pack completado Y pack >= actual)
                const puedeComprar = !tienePackActivo || (isPackCompleted && !packMenorAlActual);
                
                // Determinar tipo de badge
                let badgeInfo = null;
                if (tienePackActivo && !isPackCompleted) {
                  badgeInfo = { text: '🔒 Pack Activo', color: 'bg-gray-500' };
                } else if (packMenorAlActual) {
                  badgeInfo = { text: '⚠️ Muy Bajo', color: 'bg-red-500' };
                } else if (esReinversion && pack.precio === montoActual) {
                  badgeInfo = { text: '🔄 Mismo Pack', color: 'bg-blue-500' };
                } else if (esReinversion && pack.precio > montoActual) {
                  badgeInfo = { text: '⬆️ Upgrade', color: 'bg-green-500' };
                }

                return (
                  <div
                    key={pack.nombre}
                    className={`border-2 rounded-lg p-6 transition-all relative ${
                      !puedeComprar
                        ? 'border-gray-300 bg-gray-50 opacity-60 cursor-not-allowed' 
                        : 'border-gray-200 hover:border-[#0EA5E9] hover:shadow-lg cursor-pointer'
                    }`}
                    onClick={() => puedeComprar && handleSelectPack(pack)}
                  >
                    {/* Badge dinámico */}
                    {badgeInfo && (
                       <div className="absolute -top-2 -right-2">
                        <span className={`${badgeInfo.color} text-white px-2 py-1 rounded-full text-xs shadow-lg`}>
                          {badgeInfo.text}
                        </span>
                      </div>
                    )}

                    <h3 className="text-xl mb-2">{pack.nombre}</h3>
                    <p className="text-gray-600 text-sm mb-3">{pack.descripcion}</p>
                    <div className={`text-3xl mb-2 ${!puedeComprar ? 'text-gray-400' : 'text-[#0EA5E9]'}`}>
                      ${pack.precio.toLocaleString()}
                    </div>
                    <p className="text-sm text-gray-500">USDT</p>
                    <Button 
                      className={`w-full mt-4 ${
                        !puedeComprar
                          ? 'bg-gray-400 cursor-not-allowed'
                          : 'bg-[#0EA5E9] hover:bg-[#0EA5E9]/90'
                      }`}
                      disabled={!puedeComprar}
                    >
                      {tienePackActivo && !isPackCompleted 
                        ? 'Tienes un Pack Activo' 
                        : packMenorAlActual 
                        ? 'Pack Menor No Permitido'
                        : 'Seleccionar'}
                    </Button>
                  </div>
                );
              })}
            </div>

            {/* Info adicional */}
            {packActual && packActual !== 'Sin pack' && !isPackCompleted && (
              <div className="mt-4 p-4 bg-amber-50 border border-amber-200 rounded-lg">
                <p className="text-sm text-amber-800">
                  💡 <strong>Recordatorio:</strong> Solo puedes tener un pack activo a la vez. 
                  El sistema detecta que ya tienes el pack <strong>{packActual}</strong> activo.
                  Deberás esperar a que este finalice para poder realizar una nueva inversión.
                </p>
              </div>
            )}
            
            {/* NUEVO: Info para reinversión */}
            {packActual && packActual !== 'Sin pack' && isPackCompleted && (
              <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg">
                <p className="text-sm text-green-800">
                  🎉 <strong>¡Felicidades! Has completado tu pack {packActual}.</strong>
                  <br />
                  💰 Al reinvertir, puedes elegir el mismo pack (${montoActual.toLocaleString()} USDT) o uno de mayor valor para aumentar tus ganancias.
                  <br />
                  ⚠️ <strong>Nota:</strong> No puedes seleccionar packs de menor valor que tu inversión anterior (${montoActual.toLocaleString()} USDT).
                </p>
              </div>
            )}
          </>
        )}

        {/* PASO 2: Seleccionar Método de Pago */}
        {step === 'payment-method' && (
          <>
            <DialogHeader>
              <DialogTitle>Método de Pago - {selectedPack}</DialogTitle>
              <DialogDescription>
                Elige cómo deseas realizar tu pago de ${selectedMonto} USDT
              </DialogDescription>
            </DialogHeader>

            {/* Grid dinámico: 2 columnas si es reinversión, 3 si hay saldo disponible */}
            <div className={`grid grid-cols-1 gap-4 mt-4 ${
              saldoDisponible > 0 && !isPackCompleted 
                ? 'lg:grid-cols-3' 
                : 'lg:grid-cols-2 max-w-4xl mx-auto'
            }`}>
              {/* OPCIÓN 1: Usar Saldo de Wallet - NO mostrar en reinversiones */}
              {saldoDisponible > 0 && !isPackCompleted && (
                <Card
                  onClick={() => saldoDisponible >= selectedMonto && handleSelectMetodo('wallet')}
                  className={`relative p-4 hover:shadow-xl transition-all duration-300 cursor-pointer ${
                    saldoDisponible >= selectedMonto 
                      ? 'border-2 border-blue-500 hover:border-blue-600 bg-gradient-to-br from-blue-50 to-white' 
                      : 'border-2 border-gray-200 bg-gray-50 opacity-75 cursor-not-allowed'
                  }`}
                >
                  {/* Badge Instantáneo */}
                  <div className="absolute -top-2 -right-2 z-10">
                    <span className="bg-gradient-to-r from-blue-600 to-blue-700 text-white px-3 py-1 rounded-full text-xs font-semibold shadow-lg">
                      💰 Instantáneo
                    </span>
                  </div>

                  {/* Icono */}
                  <div className="flex items-center justify-center w-16 h-16 rounded-xl bg-gradient-to-br from-blue-100 to-blue-200 mb-3 mx-auto shadow-md">
                    <DollarSign className="w-8 h-8 text-blue-600" />
                  </div>

                  {/* Título */}
                  <h3 className="text-center mb-2 text-slate-800">Usar Mi Saldo</h3>
                  <p className="text-center text-slate-600 text-xs mb-3">
                    Compra con tu saldo disponible
                  </p>

                  {/* Saldo Disponible - COMPACTO */}
                  <div className={`p-3 rounded-lg mb-3 border-2 ${
                    saldoDisponible >= selectedMonto
                      ? 'bg-gradient-to-br from-blue-100 to-blue-50 border-blue-300'
                      : 'bg-gray-100 border-gray-300'
                  }`}>
                    <p className="text-xs text-slate-600 text-center mb-1">Saldo Disponible</p>
                    <p className={`text-2xl text-center font-bold ${
                      saldoDisponible >= selectedMonto ? 'text-blue-700' : 'text-gray-500'
                    }`}>
                      ${saldoDisponible.toFixed(2)}
                    </p>
                  </div>

                  {/* Características - COMPACTAS */}
                  <ul className="space-y-1.5 mb-3">
                    <li className="flex items-center gap-2 text-xs text-slate-700">
                      <span className={`w-4 h-4 rounded-full flex items-center justify-center text-xs ${
                        saldoDisponible >= selectedMonto ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'
                      }`}>
                        {saldoDisponible >= selectedMonto ? '✓' : '✗'}
                      </span>
                      <span>{saldoDisponible >= selectedMonto ? 'Saldo suficiente' : 'Saldo insuficiente'}</span>
                    </li>
                    <li className="flex items-center gap-2 text-xs text-slate-700">
                      <span className="w-4 h-4 rounded-full bg-green-100 text-green-600 flex items-center justify-center text-xs">✓</span>
                      <span>Sin comisiones</span>
                    </li>
                    <li className="flex items-center gap-2 text-xs text-slate-700">
                      <span className="w-4 h-4 rounded-full bg-green-100 text-green-600 flex items-center justify-center text-xs">✓</span>
                      <span>Activación inmediata</span>
                    </li>
                  </ul>

                  {/* Botón */}
                  <Button 
                    className={`w-full h-10 text-sm font-semibold shadow-lg transition-all ${
                      saldoDisponible >= selectedMonto 
                        ? 'bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800' 
                        : 'bg-gray-400 cursor-not-allowed'
                    }`}
                    disabled={saldoDisponible < selectedMonto}
                  >
                    {saldoDisponible >= selectedMonto ? (
                      <span className="flex items-center justify-center gap-1">
                        Usar Saldo <ArrowRight className="w-4 h-4" />
                      </span>
                    ) : (
                      'Saldo Insuficiente'
                    )}
                  </Button>
                </Card>
              )}

              {/* Depósito Manual */}
              <Card
                onClick={() => handleSelectMetodo('manual')}
                className="relative p-4 border-2 border-gray-200 hover:border-blue-500 hover:shadow-xl transition-all duration-300 cursor-pointer bg-white"
              >
                {/* Badge Rápido */}
                <div className="absolute -top-2 -right-2 z-10">
                  <span className="bg-gradient-to-r from-green-500 to-green-600 text-white px-3 py-1 rounded-full text-xs font-semibold shadow-lg">
                    ⚡ Rápido
                  </span>
                </div>

                {/* Icono */}
                <div className="flex items-center justify-center w-16 h-16 rounded-xl bg-gradient-to-br from-slate-100 to-slate-200 mb-3 mx-auto shadow-md">
                  <Wallet className="w-8 h-8 text-slate-600" />
                </div>

                {/* Título */}
                <h3 className="text-center mb-2 text-slate-800">Depósito Manual</h3>
                <p className="text-center text-slate-600 text-xs mb-3">
                  Transfiere USDT (TRC20) directamente
                </p>

                {/* Espaciador compacto */}
                <div className="h-16 mb-3 flex items-center justify-center">
                  <p className="text-center text-slate-500 text-xs">Red TRC20</p>
                </div>

                {/* Características */}
                <ul className="space-y-1.5 mb-3">
                  <li className="flex items-center gap-2 text-xs text-slate-700">
                    <span className="w-4 h-4 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center text-xs">✓</span>
                    <span>Red TRC20 (Tron)</span>
                  </li>
                  <li className="flex items-center gap-2 text-xs text-slate-700">
                    <span className="w-4 h-4 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center text-xs">✓</span>
                    <span>Verificación manual</span>
                  </li>
                  <li className="flex items-center gap-2 text-xs text-slate-700">
                    <span className="w-4 h-4 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center text-xs">✓</span>
                    <span>Confirmación en 5-10 min</span>
                  </li>
                </ul>

                {/* Botón */}
                <Button className="w-full h-10 bg-gradient-to-r from-slate-600 to-slate-700 hover:from-slate-700 hover:to-slate-800 text-sm font-semibold shadow-lg">
                  Continuar <ArrowRight className="w-4 h-4 ml-1" />
                </Button>
              </Card>

              {/* NOWPayments */}
              <Card
                onClick={() => {
                  toast.info('Próximamente disponible');
                  // handleSelectMetodo('nowpayments'); // Deshabilitado temporalmente
                }}
                className="relative p-4 border-2 border-gray-200 bg-gray-50 opacity-90 transition-all duration-300 cursor-not-allowed"
              >
                {/* Badge Próximamente */}
                <div className="absolute -top-2 -right-2 z-10">
                  <span className="bg-gradient-to-r from-slate-500 to-slate-600 text-white px-3 py-1 rounded-full text-xs font-semibold shadow-lg">
                    🕒 Próximamente
                  </span>
                </div>

                {/* Icono */}
                <div className="flex items-center justify-center w-16 h-16 rounded-xl bg-gradient-to-br from-gray-100 to-gray-200 mb-3 mx-auto shadow-md grayscale">
                  <CreditCard className="w-8 h-8 text-gray-500" />
                </div>

                {/* Título */}
                <h3 className="text-center mb-2 text-slate-500">NOWPayments</h3>
                <p className="text-center text-slate-500 text-xs mb-3">
                  Paga con múltiples criptomonedas
                </p>

                {/* Espaciador compacto */}
                <div className="h-16 mb-3 flex items-center justify-center">
                  <p className="text-center text-slate-400 text-xs">BTC, ETH, USDT y más</p>
                </div>

                {/* Características */}
                <ul className="space-y-1.5 mb-3 opacity-50">
                  <li className="flex items-center gap-2 text-xs text-slate-500">
                    <span className="w-4 h-4 rounded-full bg-gray-200 text-gray-500 flex items-center justify-center text-xs">✓</span>
                    <span>BTC, ETH, USDT y más</span>
                  </li>
                  <li className="flex items-center gap-2 text-xs text-slate-500">
                    <span className="w-4 h-4 rounded-full bg-gray-200 text-gray-500 flex items-center justify-center text-xs">✓</span>
                    <span>Verificación automática</span>
                  </li>
                  <li className="flex items-center gap-2 text-xs text-slate-500">
                    <span className="w-4 h-4 rounded-full bg-gray-200 text-gray-500 flex items-center justify-center text-xs">✓</span>
                    <span>Activación inmediata</span>
                  </li>
                </ul>

                {/* Botón */}
                <Button className="w-full h-10 bg-gray-400 text-white text-sm font-semibold shadow-none cursor-not-allowed" disabled>
                  No disponible
                </Button>
              </Card>
            </div>

            <Button
              variant="outline"
              onClick={() => setStep('select')}
              className="w-full mt-4"
            >
              Volver a Packs
            </Button>
          </>
        )}

        {/* PASO 3A: Pagar con Wallet */}
        {step === 'wallet' && (
          <>
            <DialogHeader>
              <DialogTitle>Confirmar Compra con Saldo - {selectedPack}</DialogTitle>
              <DialogDescription>
                Estás a punto de comprar usando tu saldo disponible en wallet
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-6 mt-4">
              {/* Información del pack */}
              <div className="bg-gradient-to-r from-blue-50 to-blue-100 border-2 border-blue-200 rounded-xl p-6">
                <h4 className="text-blue-900 text-lg mb-2">📦 Pack seleccionado:</h4>
                <p className="text-3xl text-blue-600 font-bold mb-1">{selectedPack}</p>
                <p className="text-4xl text-blue-900 font-bold">
                  ${selectedMonto.toLocaleString()} USDT
                </p>
              </div>

              {/* Resumen de saldo */}
              <div className="bg-white border-2 border-slate-200 rounded-xl p-6">
                <h4 className="text-slate-700 text-lg mb-4">💰 Resumen de Saldo</h4>
                <div className="space-y-3">
                  <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                    <span className="text-slate-600">Saldo Actual:</span>
                    <span className="text-xl text-green-600 font-bold">
                      ${saldoDisponible.toFixed(2)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-red-50 rounded-lg">
                    <span className="text-slate-600">Monto a Pagar:</span>
                    <span className="text-xl text-red-600 font-bold">
                      -${selectedMonto.toFixed(2)}
                    </span>
                  </div>
                  <div className="h-px bg-slate-300 my-2"></div>
                  <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg border-2 border-blue-300">
                    <span className="text-slate-700 font-medium">Saldo Restante:</span>
                    <span className="text-2xl text-blue-700 font-bold">
                      ${(saldoDisponible - selectedMonto).toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>

              {/* Beneficios */}
              <div className="bg-gradient-to-r from-green-50 to-emerald-50 border-2 border-green-200 rounded-xl p-6">
                <h4 className="text-green-900 text-lg mb-3">✅ Beneficios de esta compra:</h4>
                <ul className="space-y-2 text-sm text-green-800">
                  <li className="flex items-start gap-2">
                    <span className="text-green-600 shrink-0">•</span>
                    <span>Tu pack se activa <strong>instantáneamente</strong> sin esperar verificación.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-600 shrink-0">•</span>
                    <span>Las comisiones se distribuyen automáticamente a tu red (10 niveles).</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-600 shrink-0">•</span>
                    <span>Comienzas a generar rendimiento diario de inmediato.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-600 shrink-0">•</span>
                    <span>No se cobra ninguna comisión adicional por usar tu saldo.</span>
                  </li>
                </ul>
              </div>

              {/* Botones */}
              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={() => setStep('payment-method')}
                  className="flex-1"
                  disabled={loading}
                >
                  Volver
                </Button>
                <Button
                  onClick={handleComprarConWallet}
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
                  disabled={loading || saldoDisponible < selectedMonto}
                >
                  {loading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Procesando...
                    </>
                  ) : (
                    <>
                      <Check className="mr-2 h-4 w-4" />
                      Confirmar Compra
                    </>
                  )}
                </Button>
              </div>

              {/* Aviso de seguridad */}
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-4">
                <p className="text-sm text-slate-700">
                   <strong>Transacción segura:</strong> El saldo se descontará de tu wallet y el pack se activará automáticamente. 
                  Esta operación es irreversible, asegúrate de seleccionar el pack correcto.
                </p>
              </div>
            </div>
          </>
        )}

        {/* PASO 3B: Depósito Manual */}
        {step === 'manual' && (
          <>
            <DialogHeader>
              <DialogTitle>Realizar Depósito Manual - {selectedPack}</DialogTitle>
              <DialogDescription>
                Transfiere ${selectedMonto} USDT a la siguiente wallet
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-6 mt-4">
              {/* Información del pack */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h4 className="mb-2 text-blue-900">Pack seleccionado:</h4>
                <p className="text-2xl text-blue-600">{selectedPack}</p>
                <p className="text-3xl text-blue-900 mt-2">
                  ${selectedMonto.toLocaleString()} USDT
                </p>
              </div>

              {/* Wallet del admin */}
              <div>
                <Label>Wallet de Depósito (TRC20 - USDT)</Label>
                <div className="flex gap-2 mt-2">
                  <Input
                    id="wallet-address-input"
                    value={walletAdmin}
                    readOnly
                    className="font-mono text-sm"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    size="icon"
                    onClick={handleCopyWallet}
                  >
                    {copied ? (
                      <Check className="h-4 w-4 text-green-600" />
                    ) : (
                      <Copy className="h-4 w-4" />
                    )}
                  </Button>
                </div>
                <p className="text-sm text-gray-500 mt-1">
                  Red: TRC20 (Tron) - Solo USDT
                </p>
              </div>

              {/* Código QR */}
              <div className="bg-white border-2 border-gray-200 rounded-lg p-4">
                <Label className="mb-3 block text-center">Escanea el código QR</Label>
                <div className="flex justify-center">
                  <div className="bg-white p-3 rounded-lg border-2 border-gray-300 inline-block">
                    <ImageWithFallback
                      src={qrCodeUrl}
                      alt="QR Code para depósito"
                      className="w-48 h-48 object-contain"
                    />
                  </div>
                </div>
                <p className="text-sm text-gray-500 mt-3 text-center">
                  Escanea este código con tu wallet para enviar el pago
                </p>
              </div>

              {/* Instrucciones */}
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <h4 className="text-yellow-900 mb-2">📋 Instrucciones:</h4>
                <ol className="list-decimal list-inside space-y-1 text-sm text-yellow-800">
                  <li>Copia la wallet de arriba</li>
                  <li>Abre tu wallet (TronLink, Trust Wallet, etc.)</li>
                  <li>Envía exactamente ${selectedMonto} USDT (red TRC20)</li>
                  <li>Opcionalmente, pega el hash de transacción abajo</li>
                  <li>Haz clic en "Confirmar Depósito"</li>
                </ol>
              </div>

              {/* Hash de transacción (Obligatorio) */}
              <div>
                <Label>Hash de Transacción <span className="text-red-500">*</span></Label>
                <Input
                  value={txHash}
                  onChange={(e) => setTxHash(e.target.value)}
                  placeholder="Ingrese el hash de la transacción (TxID)"
                  className="font-mono text-sm"
                  required
                />
                <p className="text-sm text-gray-500 mt-1">
                  Es necesario para verificar tu pago rápidamente
                </p>
              </div>

              {/* Comprobante (opcional) */}
              <div>
                <Label>Comprobante de Depósito (Opcional)</Label>
                <Input
                  type="file"
                  onChange={(e) => setComprobante(e.target.files?.[0] || null)}
                  className="font-mono text-sm"
                />
                <p className="text-sm text-gray-500 mt-1">
                  Sube una imagen del comprobante de pago
                </p>
              </div>

              {/* Botones */}
              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={() => setStep('payment-method')}
                  className="flex-1"
                  disabled={loading}
                >
                  Volver
                </Button>
                <Button
                  onClick={handleConfirmarDepositoManual}
                  className="flex-1 bg-[#0EA5E9] hover:bg-[#0EA5E9]/90"
                  disabled={loading}
                >
                  {loading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Procesando...
                    </>
                  ) : (
                    <>
                      <Check className="mr-2 h-4 w-4" />
                      Confirmar Depósito
                    </>
                  )}
                </Button>
              </div>

              {/* Aviso */}
              <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                <p className="text-sm text-gray-700">
                  ⏱️ <strong>Tu depósito será verificado en 5-10 minutos.</strong> Una vez aprobado, tu pack se activará automáticamente y las comisiones se distribuirán a tu red.
                </p>
              </div>
            </div>
          </>
        )}

        {/* PASO 4: NOWPayments */}
        {step === 'nowpayments' && (
          <>
            <DialogHeader>
              <DialogTitle>Procesando Pago con NOWPayments</DialogTitle>
              <DialogDescription>
                Redirigiendo a la pasarela de pagos...
              </DialogDescription>
            </DialogHeader>

            <div className="py-8 space-y-6">
              {loading ? (
                <div className="flex flex-col items-center justify-center">
                  <Loader2 className="h-12 w-12 animate-spin text-green-600 mb-4" />
                  <p className="text-gray-700">Creando tu pago seguro...</p>
                  <p className="text-sm text-gray-500 mt-2">Esto puede tomar unos segundos</p>
                </div>
              ) : nowPaymentUrl ? (
                <div className="text-center space-y-4">
                  <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto">
                    <Check className="w-8 h-8 text-green-600" />
                  </div>
                  <h3 className="text-xl">¡Pago Creado Exitosamente!</h3>
                  <p className="text-gray-600">Se ha abierto una nueva ventana con tu pago.</p>
                  <Button
                    onClick={() => window.open(nowPaymentUrl, '_blank')}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    <ExternalLink className="mr-2 w-4 h-4" />
                    Abrir Página de Pago
                  </Button>
                </div>
              ) : (
                <div className="text-center space-y-4">
                  <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center mx-auto">
                    <Check className="w-8 h-8 text-blue-600" />
                  </div>
                  <h3 className="text-xl">Pago Registrado</h3>
                  <p className="text-gray-600">
                    Tu solicitud ha sido registrada. Recibirás una notificación cuando el pago sea confirmado.
                  </p>
                </div>
              )}

              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <p className="text-sm text-green-800">
                  💡 <strong>Importante:</strong> Una vez que completes el pago en NOWPayments, tu pack se activará automáticamente en 1-5 minutos.
                </p>
              </div>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}