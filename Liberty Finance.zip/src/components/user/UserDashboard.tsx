import { useState, useEffect } from 'react';
import { UserSidebar } from './UserSidebar';
import { UserHome } from './UserHome';
import { MiCiclo } from '../MiCiclo';
import { Referidos } from '../Referidos';
import { MisDatos } from '../MisDatos';
import { Cobros } from '../Cobros';
import { Productos } from '../Productos';
import { Ruleta } from '../Ruleta';
import { Rangos } from '../Rangos';
import { mockUserData } from '../../data/mockData';
import { callServer } from '../../utils/api';
import { toast } from 'sonner@2.0.3';
import { Skeleton } from '../ui/skeleton';
import { CacheManager } from '../../utils/cache';

interface UserDashboardProps {
  onLogout: () => void;
}

export function UserDashboard({ onLogout }: UserDashboardProps) {
  const [activeSection, setActiveSection] = useState('inicio');
  const [userData, setUserData] = useState<any>(null);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [loading, setLoading] = useState(true); // ✅ Cambiar a true para mostrar skeleton loader inicialmente
  const [reinvertPack, setReinvertPack] = useState<string | null>(null);
  const [reinvestMonto, setReinvestMonto] = useState<number>(0);
  const [cacheTimestamp, setCacheTimestamp] = useState<number>(0);
  const [matrizData, setMatrizData] = useState<any>(null);

  useEffect(() => {
    // Cargar datos básicos del localStorage primero (INSTANTÁNEO)
    const userStr = localStorage.getItem('currentUser');
    if (userStr) {
      const user = JSON.parse(userStr);
      
      // Mostrar datos básicos inmediatamente con valores en 0
      setUserData({
        id: user.id,
        id_unico: user.id_unico,
        usuario: user.id_unico,
        nombre: user.nombre,
        apellido: user.apellido,
        correo: user.email,
        ciudad: user.ciudad || '',
        wallet: user.wallet || '',
        estatus: 'Cargando...',
        pack: 'Cargando...',
        cantidad: 0,
        rendimiento_diario: 0,
        comisiones_red: 0,
        comisiones_patrocinio: 0,
        ganancia_total: 0,
        saldo: 0,
        directos: [],
        historial: []
      });
    }
    
    // Cargar datos del servidor
    loadUserData(false);
  }, []); // Dependencias vacías = solo se ejecuta al montar

  // Actualizar URL para mostrar el link de referido del usuario actual
  useEffect(() => {
    if (userData?.id_unico) {
      const url = new URL(window.location.href);
      const currentRef = url.searchParams.get('ref');
      
      // Si el ref en la URL no coincide con el del usuario (o no existe, o es de otro)
      // Lo actualizamos para que el usuario vea SU link de referido en la barra
      // Esto soluciona que se quede pegado un link de referido ajeno y permite al usuario "entrar con su link"
      if (currentRef !== userData.id_unico) {
        url.searchParams.set('ref', userData.id_unico);
        window.history.replaceState({}, '', url);
      }
    }
  }, [userData]);

  const loadUserData = async (showLoading = true) => {
    try {
      if (showLoading) {
        setLoading(true);
      }
      
      // Obtener usuario de localStorage
      const userStr = localStorage.getItem('currentUser');
      if (!userStr) {
        toast.error('No hay sesión activa');
        onLogout();
        return;
      }

      const user = JSON.parse(userStr);

      // ⚡ ESTRATEGIA DE CARGA PROGRESIVA:
      // 1. Cargar datos críticos PRIMERO (dashboard-quick) - ~500ms
      // 2. Mostrar UI inmediatamente con datos básicos
      // 3. Cargar matriz completa en segundo plano
      
      console.log('⚡ [1/2] Cargando datos críticos...');
      const quickData = await callServer(`/users/${user.id}/dashboard-quick`, 'GET');
      
      // Mostrar datos básicos INMEDIATAMENTE
      setUserData({
        id: quickData.usuario.id,
        id_unico: quickData.usuario.id_unico,
        usuario: quickData.usuario.id_unico,
        nombre: quickData.usuario.nombre,
        apellido: quickData.usuario.apellido,
        email: quickData.usuario.email,
        correo: quickData.usuario.email,
        ciudad: '',
        wallet: '',
        estatus: 'activo',
        pack: quickData.pack.activo?.nombre || 'Sin Pack',
        packMonto: quickData.pack.activo?.monto || 0,
        packCompletado: quickData.pack.activo?.completado || false, // ✅ NUEVO: del backend
        cantidad: quickData.pack.inversionTotal || 0,
        inversion: quickData.pack.inversionTotal || 0,
        saldo: quickData.wallet.saldoDisponible,
        comisionesRed: quickData.comisiones.porTipo.red,
        comisiones_red: quickData.comisiones.porTipo.red,
        comisionesPatrocinio: quickData.comisiones.porTipo.patrocinio,
        comisiones_patrocinio: quickData.comisiones.porTipo.patrocinio,
        rendimientoDiario: quickData.comisiones.porTipo.rendimientoHoy || quickData.comisiones.porTipo.rendimiento,
        rendimiento_diario: quickData.comisiones.porTipo.rendimientoHoy || quickData.comisiones.porTipo.rendimiento,
        ganancia_total: quickData.comisiones.total, // 🔴 Total histórico de TODOS los packs
        ganancia_acumulada: quickData.comisiones.gananciaAcumulada || quickData.comisiones.total, // 🔥 Ganancia SOLO del pack activo
        limiteRetiro: quickData.wallet.limiteRetiro,
        directosConPack: quickData.red.directos?.conPack || quickData.red.directosConPack || 0,  // ✅ Compatible con ambos formatos
        totalRed: quickData.red.total || 0,
        rango: quickData.usuario.rango || 'Sin Rango',
        volumen_red: 0,
        porcentaje_rendimiento: 0.25,
        porcentaje_red: 10,
        directos: [],
        referidos: [],
        historial: [],
        historialActividades: [],
        packs: [],
        cycle: null,
        saldo_retenido: 0
      });
      
      console.log(`🔍 [QUICK] directosConPack from backend:`, quickData.red.directos?.conPack);
      console.log(`🔍 [QUICK] userData.directosConPack set to:`, quickData.red.directos?.conPack);
      
      // 🔥 DEBUG: Verificar valores de ganancia
      console.log(`💰 [DEBUG GANANCIA] comisiones.total (HISTÓRICO):`, quickData.comisiones.total);
      console.log(`💰 [DEBUG GANANCIA] comisiones.gananciaAcumulada (PACK ACTIVO):`, quickData.comisiones.gananciaAcumulada);
      console.log(`💰 [DEBUG GANANCIA] pack activo:`, quickData.pack.activo?.nombre, `$${quickData.pack.activo?.monto}`);
      console.log(`💰 [DEBUG GANANCIA] userData.ganancia_acumulada asignado:`, quickData.comisiones.gananciaAcumulada || quickData.comisiones.total);
      
      // ✅ NO ocultar el loading todavía, esperar a cargar datos completos
      console.log(`✅ [1/2] Datos críticos mostrados en ${quickData._meta.loadTime}ms`);
      
      // 🔄 Ahora cargar el dashboard completo en segundo plano
      console.log('⚡ [2/2] Cargando datos completos (matriz, historial)...');
      
      try {
        // ⚡ CARGAR EN PARALELO: Dashboard completo + Matriz del usuario (3 niveles)
        const dashboardPromise = callServer(`/users/${user.id}/dashboard-completo`, 'GET');
        const matrizPromise = callServer(`/users/${user.id}/matriz?niveles=3`, 'GET');
        
        // ⚡ Timeout de 150 segundos para permitir que el servidor complete la carga
        // (El timeout de fetchAPI es 120s, damos margen extra aquí)
        const timeoutPromise = new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Timeout cargando dashboard completo')), 150000)
        );
        
        // ⚡ Esperar AMBOS en paralelo
        console.log('⚡ [2/2a] Cargando dashboard + matriz en paralelo...');
        const [dashboardData, matrizDataResponse] = await Promise.race([
          Promise.all([dashboardPromise, matrizPromise]),
          timeoutPromise
        ]) as any[];
        
        // ⚡ Verificar si el backend retornó error de timeout
        if (dashboardData?.error || dashboardData?.code === 'REQUEST_TIMEOUT') {
          console.error('⚠️ Backend retornó error de timeout, manteniendo datos quick');
          throw new Error(dashboardData.error || 'Backend timeout');
        }
        
        console.log(`✅ [2/2] Dashboard completo cargado en ${dashboardData._meta.loadTime}ms`);
        console.log(`✅ [2/2] Matriz de usuario cargada:`, matrizDataResponse ? 'OK' : 'ERROR');
        
        // Guardar matriz binaria del dashboard (puede ser diferente a la matriz del usuario)
        setMatrizData({ 
          cycle: dashboardData.red.matriz,
          userMatriz: matrizDataResponse // ✅ NUEVA: matriz específica del usuario para MiCiclo
        });
        
        // 🔄 ACTUALIZAR UserData completo con todos los datos del backend (YA VIENEN CALCULADOS)
        const serverUser = dashboardData.usuario;
        const packActivo = dashboardData.pack.activo;
        const comisiones = dashboardData.comisiones.historial;
        const referidosConPacks = dashboardData.red.directos.lista;
        const redCompleta = dashboardData.red.completa?.lista || [];
        
        // Construir historial de actividades desde el backend (ya incluye TODO: comisiones, retiros, ruleta, packs)
        const historialActividades = comisiones
          .map((c: any) => ({
            id: c.id,
            fecha: c.fecha,
            concepto: c.concepto || c.descripcion || `${c.tipo}`,
            tipo: c.tipo, // 'rendimiento', 'red', 'patrocinio', 'rangos', 'retiro', 'ruleta_gasto', 'compra_pack'
            importe: c.monto, // Ya viene como número desde el backend
            monto: c.monto, // Duplicar para compatibilidad
            estado: c.estado, // Para retiros: 'pendiente', 'completado', 'rechazado'
            categoria: c.categoria, // 'ganancia', 'egreso', 'inversion'
            packId: c.packId // ✅ NUEVO: ID del pack asociado (para filtrar rendimientos por pack)
          }))
          .sort((a: any, b: any) => new Date(b.fecha).getTime() - new Date(a.fecha).getTime());
        
        // Actualizar userData con datos completos del backend
        const newUserData = {
          id: serverUser.id,
          id_unico: serverUser.id_unico,
          usuario: serverUser.id_unico,
          nombre: serverUser.nombre,
          apellido: serverUser.apellido,
          estatus: serverUser.activo ? 'activo' : 'inactivo',
          pack: packActivo ? packActivo.nombre : 'Sin pack',
          packMonto: packActivo ? packActivo.monto : 0,
          packCompletado: packActivo ? packActivo.completado : false, // ✅ NUEVO: del backend
          cantidad: dashboardData.pack.inversionTotal,
          inversion: dashboardData.pack.inversionTotal,
          
          // Comisiones (ya calculadas en el backend) - AMBOS formatos para compatibilidad
          rendimientoDiario: dashboardData.comisiones.porTipo.rendimientoHoy || dashboardData.comisiones.porTipo.rendimiento,
          rendimiento_diario: dashboardData.comisiones.porTipo.rendimientoHoy || dashboardData.comisiones.porTipo.rendimiento,
          comisionesRed: dashboardData.comisiones.porTipo.red,
          comisiones_red: dashboardData.comisiones.porTipo.red,
          comisionesPatrocinio: dashboardData.comisiones.porTipo.patrocinio,
          comisiones_patrocinio: dashboardData.comisiones.porTipo.patrocinio,
          ganancia_total: dashboardData.comisiones.total, // 🔴 Total histórico de TODOS los packs
          ganancia_acumulada: dashboardData.comisiones.gananciaAcumulada || dashboardData.comisiones.total, // 🔥 Ganancia SOLO del pack activo
          
          porcentaje_rendimiento: packActivo ? 0.25 : 0,
          porcentaje_red: 10,
          ciudad: serverUser.ciudad,
          correo: serverUser.email,
          wallet: serverUser.wallet,
          rango: serverUser.rango || 'Sin Rango',
          
          // Red (ya calculada en el backend)
          volumen_red: dashboardData.red.completa?.volumen || redCompleta.reduce((sum: number, r: any) => sum + (r.inversion || 0), 0),
          directosConPack: dashboardData.red.directos.conPack,
          totalRed: dashboardData.red.completa?.total || 0,
          
          cycle: null,
          directos: redCompleta, // ✅ Contiene TODA la red genealógica (directos + indirectos hasta 10 niveles)
          referidos: referidosConPacks, // Solo referidos directos (nivel 1)
          historial: historialActividades,
          historialActividades: historialActividades,
          packs: dashboardData.pack.todosLosPacks,
          
          // Wallet (ya calculado en el backend)
          saldo: dashboardData.wallet.saldoDisponible,
          saldo_retenido: 0,
          limiteRetiro: dashboardData.wallet.limiteRetiro
        };
        
        setUserData(newUserData);
        
        console.log(`🔍 [COMPLETO] directosConPack from backend:`, dashboardData.red.directos.conPack);
        console.log(`🔍 [COMPLETO] userData.directosConPack set to:`, dashboardData.red.directos.conPack);
        console.log(`🔍 [COMPLETO] Total directos:`, dashboardData.red.directos.total);
        console.log(`🔍 [COMPLETO] Directos lista:`, dashboardData.red.directos.lista?.length);

        // Actualizar localStorage
        localStorage.setItem('currentUser', JSON.stringify(serverUser));

        // 🔥 DEBUG: Verificar valores de ganancia (dashboard completo)
        console.log(`💰 [DEBUG GANANCIA COMPLETO] comisiones.total (HISTÓRICO):`, dashboardData.comisiones.total);
        console.log(`💰 [DEBUG GANANCIA COMPLETO] comisiones.gananciaAcumulada (PACK ACTIVO):`, dashboardData.comisiones.gananciaAcumulada);
        console.log(`💰 [DEBUG GANANCIA COMPLETO] userData.ganancia_acumulada final:`, newUserData.ganancia_acumulada);
        
        // Guardar en sessionStorage para cache
        sessionStorage.setItem('userDashboardCache', JSON.stringify(newUserData));
        sessionStorage.setItem('userDashboardCacheTime', Date.now().toString());

        setLoading(false);
        console.log('✅ [COMPLETO] Dashboard completamente cargado');
        
        // ✅ AHORA SÍ, DISPARAR EVENTO PARA OCULTAR LOADING SCREEN GLOBAL
        window.dispatchEvent(new CustomEvent('dashboardReady'));
      } catch (error) {
        console.error('Error al cargar datos completos del usuario:', error);
        toast.error('Error al cargar datos completos del usuario');
        setLoading(false);
        
        // ✅ Disparar evento incluso si hay error (para no dejar al usuario esperando infinitamente)
        console.log('✅ [UserDashboard] Disparando evento dashboardReady después de error');
        window.dispatchEvent(new CustomEvent('dashboardReady'));
      }
    } catch (error) {
      console.error('Error al cargar datos del usuario:', error);
      toast.error('Error al cargar datos del usuario');
      setLoading(false);
      
      // ✅ Disparar evento incluso si hay error en la carga inicial
      window.dispatchEvent(new CustomEvent('dashboardReady'));
    }
  };

  const updateUserData = (field: string, value: string) => {
    setUserData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  // Función de navegación personalizada para reinvertir
  const handleNavigate = (section: string, pack?: string) => {
    if (section === 'productos' && pack && userData) {
      setReinvertPack(pack);
      // Obtener el monto del pack según el nombre
      const packMontos: { [key: string]: number } = {
        'Pack 50': 50,
        'Pack 100': 100,
        'Pack 200': 200,
        'Pack 300': 300,
        'Pack 500': 500,
        'Pack 1k': 1000,
        'Pack 5k': 5000,
        'Pack 10k': 10000,
      };
      setReinvestMonto(packMontos[pack] || 0);
    } else {
      setReinvertPack(null);
      setReinvestMonto(0);
    }
    setActiveSection(section);
  };

  const renderSection = () => {
    // Mostrar loading mientras se cargan los datos
    if (loading || !userData) {
      return (
        <div className="space-y-6">
          <div className="space-y-2">
            <Skeleton className="h-8 w-64" />
            <Skeleton className="h-4 w-48" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Skeleton className="h-40 w-full" />
            <Skeleton className="h-40 w-full" />
            <Skeleton className="h-40 w-full" />
            <Skeleton className="h-40 w-full" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Skeleton className="h-60 w-full" />
            <Skeleton className="h-60 w-full" />
          </div>
        </div>
      );
    }

    switch (activeSection) {
      case 'inicio':
        return <UserHome userData={userData} onRefresh={loadUserData} onNavigate={handleNavigate} />;
      case 'ciclo':
        return <MiCiclo userData={userData} matrizData={matrizData} />;
      case 'referidos':
        return <Referidos userData={userData} />;
      case 'datos':
        return <MisDatos userData={userData} updateUserData={updateUserData} />;
      case 'cobros':
        return <Cobros userData={userData} />;
      case 'productos':
        // ✅ USAR EL CAMPO packCompletado QUE VIENE DEL BACKEND (ya calculado correctamente)
        const isPackCompleted = userData?.packCompletado || false;
        
        // DEBUG: Ver valores para detectar problema de reinversión
        console.log('🔍 DEBUG isPackCompleted:', {
          packCompletado_backend: userData?.packCompletado,
          isPackCompleted,
          ganancia_total: userData?.ganancia_total,
          cantidad: userData?.cantidad,
          limite200: userData?.cantidad ? userData.cantidad * 2 : 0,
          pack: userData?.pack
        });
        
        return (
          <Productos 
            userId={userData.id} 
            onRefresh={loadUserData} 
            reinvertPack={reinvertPack} 
            reinvertMonto={reinvestMonto}
            currentPack={userData.pack}
            isPackCompleted={isPackCompleted}
            saldoWallet={userData.saldo || 0}
          />
        );
      case 'ruleta':
        return <Ruleta userData={userData} onNavigate={setActiveSection} />;
      case 'rangos':
        return <Rangos userData={userData} />;
      default:
        return <UserHome userData={userData} onRefresh={loadUserData} onNavigate={handleNavigate} />;
    }
  };

  return (
    <div 
      className="min-h-screen bg-slate-50 overflow-x-hidden relative"
    >
      {/* Background Dot Pattern */}
      <div 
        className="fixed inset-0 z-0 pointer-events-none"
        style={{ 
          backgroundImage: 'radial-gradient(#2dd4bf 2px, transparent 2px)',
          backgroundSize: '16px 16px',
          opacity: 0.4
        }}
      />
      
      <div className="flex w-full relative z-10">
        <UserSidebar 
          userData={userData} 
          activeSection={activeSection}
          setActiveSection={setActiveSection}
          onLogout={onLogout}
          collapsed={sidebarCollapsed}
          setCollapsed={setSidebarCollapsed}
        />
        <main className={`flex-1 min-w-0 w-full p-4 pt-24 md:p-8 md:pt-24 transition-all duration-300 ${
          sidebarCollapsed ? 'md:ml-20' : 'md:ml-72'
        }`}>
          <div className="max-w-7xl mx-auto w-full">
            {renderSection()}
          </div>
        </main>
      </div>
    </div>
  );
}