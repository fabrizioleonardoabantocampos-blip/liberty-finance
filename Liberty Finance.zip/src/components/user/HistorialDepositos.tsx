import { useState, useEffect } from 'react';
import { Card } from '../ui/card';
import { Badge } from '../ui/badge';
import { Loader2, Clock, CheckCircle, XCircle, ExternalLink } from 'lucide-react';
import { depositosAPI } from '../../utils/api';

interface Deposito {
  id: string;
  userId: string;
  packNombre: string;
  monto: number;
  walletDestino: string;
  comprobante?: string;
  estado: 'pendiente' | 'verificado' | 'rechazado';
  fecha: string;
  fechaProcesado?: string;
}

interface HistorialDepositosProps {
  userId: string;
}

export function HistorialDepositos({ userId }: HistorialDepositosProps) {
  const [depositos, setDepositos] = useState<Deposito[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    cargarDepositos();
  }, [userId]);

  const cargarDepositos = async () => {
    try {
      const data = await depositosAPI.getByUserId(userId);
      setDepositos(data);
    } catch (error) {
      console.error('Error al cargar depósitos:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (depositos.length === 0) {
    return (
      <Card className="p-8 text-center">
        <p className="text-gray-500">No tienes depósitos registrados</p>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {depositos.map((deposito) => (
        <Card key={deposito.id} className="p-6">
          <div className="space-y-3">
            {/* Estado y fecha */}
            <div className="flex items-center justify-between">
              <Badge
                variant={
                  deposito.estado === 'pendiente' ? 'default' :
                  deposito.estado === 'verificado' ? 'default' :
                  'destructive'
                }
                className={
                  deposito.estado === 'pendiente' ? 'bg-yellow-500' :
                  deposito.estado === 'verificado' ? 'bg-green-500' :
                  'bg-red-500'
                }
              >
                {deposito.estado === 'pendiente' && (
                  <>
                    <Clock className="h-3 w-3 mr-1" />
                    En Verificación
                  </>
                )}
                {deposito.estado === 'verificado' && (
                  <>
                    <CheckCircle className="h-3 w-3 mr-1" />
                    Verificado
                  </>
                )}
                {deposito.estado === 'rechazado' && (
                  <>
                    <XCircle className="h-3 w-3 mr-1" />
                    Rechazado
                  </>
                )}
              </Badge>
              <span className="text-sm text-gray-500">
                {new Date(deposito.fecha).toLocaleString('es-PE')}
              </span>
            </div>

            {/* Pack y monto */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-gray-500">Pack</p>
                <p className="text-lg">{deposito.packNombre}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Monto</p>
                <p className="text-2xl text-[#0EA5E9]">
                  ${deposito.monto.toLocaleString()} USDT
                </p>
              </div>
            </div>

            {/* Comprobante */}
            {deposito.comprobante && (
              <div>
                <p className="text-sm text-gray-500">Hash de Transacción</p>
                <div className="flex items-center gap-2">
                  <p className="text-sm font-mono bg-gray-50 p-2 rounded border flex-1 truncate">
                    {deposito.comprobante}
                  </p>
                  <a
                    href={`https://tronscan.org/#/transaction/${deposito.comprobante}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[#0EA5E9] hover:underline"
                  >
                    <ExternalLink className="h-4 w-4" />
                  </a>
                </div>
              </div>
            )}

            {/* Mensaje de estado */}
            {deposito.estado === 'pendiente' && (
              <div className="bg-yellow-50 border border-yellow-200 rounded p-3">
                <p className="text-sm text-yellow-800">
                  ⏱️ Tu depósito está en proceso de verificación. Esto puede tardar de 5 a 10 minutos.
                </p>
              </div>
            )}

            {deposito.estado === 'verificado' && (
              <div className="bg-green-50 border border-green-200 rounded p-3">
                <p className="text-sm text-green-800">
                  ✅ ¡Depósito verificado! Tu pack está activo y las comisiones han sido distribuidas.
                </p>
                {deposito.fechaProcesado && (
                  <p className="text-sm text-green-700 mt-1">
                    Procesado el {new Date(deposito.fechaProcesado).toLocaleString('es-PE')}
                  </p>
                )}
              </div>
            )}

            {deposito.estado === 'rechazado' && (
              <div className="bg-red-50 border border-red-200 rounded p-3">
                <p className="text-sm text-red-800">
                  ❌ Este depósito ha sido rechazado. Por favor, contacta con soporte para más información.
                </p>
              </div>
            )}
          </div>
        </Card>
      ))}
    </div>
  );
}
