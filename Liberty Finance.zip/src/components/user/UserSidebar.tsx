import { Home, Network, Users, User, DollarSign, Menu, X, LogOut, Package, Target, Trophy, ChevronLeft, ChevronRight } from 'lucide-react';
import { useState } from 'react';
import { UserData } from '../../data/mockData';
import { Button } from '../ui/button';
import { useLogo } from '../../hooks/useLogo';

interface UserSidebarProps {
  userData: UserData | null; // Permitir null
  activeSection: string;
  setActiveSection: (section: string) => void;
  onLogout: () => void;
  collapsed: boolean;
  setCollapsed: (collapsed: boolean) => void;
}

export function UserSidebar({ userData, activeSection, setActiveSection, onLogout, collapsed, setCollapsed }: UserSidebarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const { logoUrl } = useLogo();

  const menuItems = [
    { id: 'inicio', label: 'Principal', icon: Home },
    { id: 'ciclo', label: 'Mi Matriz', icon: Network },
    { id: 'referidos', label: 'Referidos', icon: Users },
    { id: 'rangos', label: 'Rangos', icon: Trophy },
    { id: 'productos', label: 'Productos', icon: Package },
    { id: 'ruleta', label: 'Ruleta', icon: Target },
    { id: 'datos', label: 'Mis Datos', icon: User },
    { id: 'cobros', label: 'Cobros', icon: DollarSign }
  ];

  return (
    <>
      {/* Mobile menu button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="md:hidden fixed top-4 left-4 z-50 w-12 h-12 flex items-center justify-center rounded-2xl bg-blue-500 text-white shadow-lg shadow-blue-500/30 active:scale-90 transition-transform duration-100 hover:bg-blue-600"
        aria-label="Toggle menu"
      >
        {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
      </button>

      {/* Desktop Sidebar */}
      <aside
        className={`hidden md:block fixed top-0 left-0 h-full bg-white shadow-2xl transition-all duration-300 z-40 ${
          collapsed ? 'w-20' : 'w-72'
        }`}
      >
        {/* Toggle button for desktop */}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="absolute -right-3 top-8 w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-lg hover:bg-blue-700 transition-colors z-50"
        >
          {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
        </button>

        <div className="h-full flex flex-col">
          {/* Logo */}
          <div className={`p-4 border-b border-slate-200 transition-all duration-300 ${collapsed ? 'px-3' : ''}`}>
            {collapsed ? (
              <div className="flex justify-center">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-600 to-cyan-500 flex items-center justify-center shadow-lg">
                  <img 
                    src={logoUrl} 
                    alt="Liberty Finance" 
                    className="h-8 w-8 object-contain"
                  />
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl flex items-center justify-center">
                  <img 
                    src={logoUrl} 
                    alt="Liberty Finance" 
                    className="h-8 w-auto"
                  />
                </div>
                <div>
                  <h1 className="text-xl text-slate-800">Liberty Finance</h1>
                  <p className="text-xs text-slate-500">Oficina Virtual</p>
                </div>
              </div>
            )}
          </div>

          {/* User info */}
          <div className={`p-6 border-b border-slate-200 transition-all duration-300 ${collapsed ? 'px-3' : ''}`}>
            {collapsed ? (
              <div className="flex flex-col items-center gap-2">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center shadow-lg">
                  <span className="text-sm text-white">
                    {userData?.nombre[0]}{userData?.apellido[0]}
                  </span>
                </div>
                <div className={`w-3 h-3 rounded-full ${
                  userData?.estatus === 'activo' ? 'bg-green-500' : 'bg-red-500'
                }`}></div>
              </div>
            ) : (
              <>
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center shadow-lg">
                    <span className="text-xl text-white">
                      {userData?.nombre[0]}{userData?.apellido[0]}
                    </span>
                  </div>
                  <div className="flex-1">
                    <p className="text-slate-800">{userData?.nombre} {userData?.apellido}</p>
                    <p className="text-blue-600 text-sm">{userData?.id_unico}</p>
                  </div>
                </div>
                <div>
                  <span
                    className={`inline-flex px-3 py-1 rounded-lg text-xs ${
                      userData?.estatus === 'activo'
                        ? 'bg-green-100 text-green-700'
                        : 'bg-red-100 text-red-700'
                    }`}
                  >
                    {userData?.estatus === 'activo' ? '● ACTIVO' : '● INACTIVO'}
                  </span>
                </div>
              </>
            )}
          </div>

          {/* Menu items */}
          <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
            {menuItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveSection(item.id)}
                  className={`w-full flex items-center ${collapsed ? 'justify-center' : 'gap-3'} px-4 py-3 rounded-xl transition-all ${
                    activeSection === item.id
                      ? 'bg-gradient-to-r from-blue-500 to-cyan-400 text-white shadow-lg shadow-blue-500/30'
                      : 'text-slate-600 hover:bg-slate-100 hover:text-blue-600'
                  }`}
                  title={collapsed ? item.label : ''}
                >
                  <Icon className="w-5 h-5" />
                  {!collapsed && <span>{item.label}</span>}
                </button>
              );
            })}
          </nav>

          {/* Logout */}
          <div className={`p-4 border-t border-slate-200 ${collapsed ? 'px-2' : ''}`}>
            <Button
              onClick={onLogout}
              variant="outline"
              className={`w-full ${collapsed ? 'justify-center px-2' : 'justify-start gap-3'} text-red-600 border-red-200 hover:bg-red-50 hover:text-red-700`}
              title={collapsed ? 'Cerrar Sesión' : ''}
            >
              <LogOut className="w-5 h-5" />
              {!collapsed && 'Cerrar Sesión'}
            </Button>
          </div>
        </div>
      </aside>

      {/* Mobile Sidebar */}
      <aside
        className={`md:hidden fixed top-0 left-0 h-full w-72 bg-white shadow-2xl transform transition-transform duration-200 ease-out z-40 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="h-full flex flex-col">
          {/* Logo */}
          <div className="p-6 border-b border-slate-200">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-600 to-cyan-500 flex items-center justify-center shadow-lg">
                <span className="text-xl">🌐</span>
              </div>
              <div>
                <h1 className="text-xl text-slate-800">Liberty Finance</h1>
                <p className="text-xs text-slate-500">Oficina Virtual</p>
              </div>
            </div>
          </div>

          {/* User info */}
          <div className="p-6 border-b border-slate-200">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center shadow-lg">
                <span className="text-xl text-white">
                  {userData?.nombre[0]}{userData?.apellido[0]}
                </span>
              </div>
              <div className="flex-1">
                <p className="text-slate-800">{userData?.nombre} {userData?.apellido}</p>
                <p className="text-blue-600 text-sm">{userData?.id_unico}</p>
              </div>
            </div>
            <div>
              <span
                className={`inline-flex px-3 py-1 rounded-lg text-xs ${
                  userData?.estatus === 'activo'
                    ? 'bg-green-100 text-green-700'
                    : 'bg-red-100 text-red-700'
                }`}
              >
                {userData?.estatus === 'activo' ? '● ACTIVO' : '● INACTIVO'}
              </span>
            </div>
          </div>

          {/* Menu items */}
          <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
            {menuItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveSection(item.id);
                    setIsOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                    activeSection === item.id
                      ? 'bg-gradient-to-r from-blue-500 to-cyan-400 text-white shadow-lg shadow-blue-500/30'
                      : 'text-slate-600 hover:bg-slate-100 hover:text-blue-600'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Logout */}
          <div className="p-4 border-t border-slate-200">
            <Button
              onClick={onLogout}
              variant="outline"
              className="w-full justify-start gap-3 text-red-600 border-red-200 hover:bg-red-50 hover:text-red-700"
            >
              <LogOut className="w-5 h-5" />
              Cerrar Sesión
            </Button>
          </div>
        </div>
      </aside>

      {/* Overlay for mobile */}
      {isOpen && (
        <div
          className="md:hidden fixed inset-0 bg-black/50 z-30"
          onClick={() => setIsOpen(false)}
        />
      )}
    </>
  );
}