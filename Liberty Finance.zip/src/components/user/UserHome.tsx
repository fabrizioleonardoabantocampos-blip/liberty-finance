import { TrendingUp, Users as UsersIcon, Package, ArrowUpRight, Clock, Trophy, Medal, Crown, Gem, Star, History, FileText, ArrowDownRight, Dices } from 'lucide-react';
import { UserData } from '../../data/mockData';
import { Button } from '../ui/button';
import { Card } from '../ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from '../ui/dialog';
import { useState, useEffect, useMemo } from 'react';
import { toast } from 'sonner@2.0.3';
import { PieChart, Pie, Cell } from 'recharts';
import { rangosAPI, cobrosAPI, ruletaAPI, callServer } from '../../utils/api';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { useCountdown } from '../shared/CountdownTimer';

interface Rango {
  id: string;
  nombre: string;
  directos: number;
  volumen: number;
  premio: string;
  color: string;
  gradient: string;
  icon: string;
  imagen: string;
}

interface UserHomeProps {
  userData: UserData;
  onRefresh?: () => Promise<void>;
  onNavigate?: (section: string, pack?: string) => void;
}

export function UserHome({ userData, onRefresh, onNavigate }: UserHomeProps) {
  const [rangoInfo, setRangoInfo] = useState<Rango | null>(null);
  const [totalRetirado, setTotalRetirado] = useState(0);
  const [totalGastadoRuleta, setTotalGastadoRuleta] = useState(0);
  
  // Listas completas para el historial detallado
  const [listaRetiros, setListaRetiros] = useState<any[]>([]);
  const [listaGastosRuleta, setListaGastosRuleta] = useState<any[]>([]);

  // Estado para carga inicial para evitar parpadeo
  const [loading, setLoading] = useState(true);
  
  // NUEVO: Referidos directos REALES (solo nivel 1)
  const [referidosDirectosReales, setReferidosDirectosReales] = useState<any[]>([]);
  
  // 🆕 Estado para mostrar si hay datos siendo actualizados
  const [updatingData, setUpdatingData] = useState(false);

  // CALCULAR REFERIDOS DIRECTOS CON INVERSIÓN (PACK ACTIVO)
  // IMPORTANTE: Contar SOLO los referidos directos reales (nivel 1) que tienen pack activo
  const directosConPack = useMemo(() => {
    // ✅ CORREGIDO: Usar userData.directosConPack que viene del backend (ya calculado correctamente)
    if (userData.directosConPack !== undefined) {
      return userData.directosConPack;
    }
    
    // Fallback: calcular localmente solo si el backend no lo envió
    if (!referidosDirectosReales.length) return 0;
    return referidosDirectosReales.filter((d: any) => {
      // Buscar en userData.directos para ver si tiene inversión
      const refEnDatos = userData.directos.find((ud: any) => ud.id_unico === d.id_unico);
      return refEnDatos && refEnDatos.inversion > 0;
    }).length;
  }, [userData.directosConPack, referidosDirectosReales, userData.directos]);
  
  // CALCULAR VOLUMEN TOTAL
  // IMPORTANTE: Usar volumen del backend si está disponible, si no, calcular localmente
  const volumenTotal = userData.volumen_red || userData.directos.reduce((sum: number, d: any) => sum + (d.inversion || 0), 0);
  
  // DEBUG: Log para verificar datos
  console.log('🔍 DEBUG UserHome:', {
    rango: userData.rango,
    directosConPack,
    totalUsuariosEnRed: userData.directos.length,
    volumenTotal,
    volumenDesdeBackend: userData.volumen_red,
    volumenTotal,
    volumenFormateado: `$${(volumenTotal / 1000).toFixed(1)}K`,
    totalPersonasEnRed: userData.directos?.length || 0,
    desglose: {
      directos: userData.directos?.filter((d: any) => d.esDirecto).length || 0,
      indirectos: userData.directos?.filter((d: any) => !d.esDirecto).length || 0
    },
    // 🚨 NUEVO: Verificar valores críticos del dashboard
    valoresCriticos: {
      rendimiento_diario: userData.rendimiento_diario,
      comisiones_red: userData.comisiones_red,
      comisiones_patrocinio: userData.comisiones_patrocinio,
      ganancia_total: userData.ganancia_total,
      pack: userData.pack,
      cantidad: userData.cantidad,
      saldo: userData.saldo
    }
  });

  useEffect(() => {
    const loadData = async () => {
      try {
        // Cargar info de rangos
        const rangos = await rangosAPI.getAll();
        const found = rangos.find((r: Rango) => r.nombre.toLowerCase() === (userData.rango || '').toLowerCase());
        if (found) {
          setRangoInfo(found);
        }
        
        // NUEVO: Cargar referidos directos REALES (solo nivel 1)
        if (userData.id) {
          try {
            const directosReales = await callServer(`/users/${userData.id}/referidos`, 'GET');
            setReferidosDirectosReales(directosReales || []);
            console.log('✅ Referidos directos reales cargados:', directosReales.length);
          } catch (err) {
            console.warn('⚠️ No se pudieron cargar referidos directos');
          }
        }

        // Cargar retiros para calcular saldo real en wallet
        if (userData.id) {
          const cobros = await cobrosAPI.getByUserId(userData.id);
          // Guardamos la lista completa de retiros
          setListaRetiros(cobros || []);

          // Sumar retiros completados y pendientes
          const retirado = cobros
            .filter((c: any) => c.estado === 'completado' || c.estado === 'pendiente')
            .reduce((sum: number, c: any) => sum + c.monto, 0);
          setTotalRetirado(retirado);
          
          // Cargar gastos de ruleta
          try {
            const gastos = await ruletaAPI.getGastos(userData.id);
            if (Array.isArray(gastos)) {
              setListaGastosRuleta(gastos);
              const totalGastos = gastos.reduce((sum: number, g: any) => sum + g.monto, 0);
              setTotalGastadoRuleta(totalGastos);
            }
          } catch (err) {
            console.error('Error cargando gastos ruleta', err);
          }
        }
      } catch (error) {
        // Silently handle network errors for rangos to avoid console spam
        if (error instanceof Error && error.message.includes('Network connection lost')) {
          console.warn("Aviso: No se pudo conectar con el servicio de rangos (posible problema de red o servidor ocupado).");
        } else {
          console.error("Error cargando datos en UserHome:", error);
        }
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, [userData.rango, userData.id]);

  // Usar el hook compartido de cuenta regresiva
  const timeLeft = useCountdown();

  /* ❌ FUNCIÓN DESHABILITADA - El endpoint está deshabilitado en el servidor
  const [isSyncing, setIsSyncing] = useState(false);
  
  const handleSyncComisiones = async () => {
    try {
      setIsSyncing(true);
      toast.info("Sincronizando historial de comisiones...");
      
      const data = await callServer('/admin/recalculate-commissions', 'POST');
      
      toast.success(data.message || "Comisiones sincronizadas correctamente");
      if (onRefresh) await onRefresh();
      
    } catch (error) {
      console.error("Error syncing commissions:", error);
      toast.error("Ocurrió un error al procesar la solicitud");
    } finally {
      setIsSyncing(false);
    }
  };
  */
  
  const handleInvalidateCache = async () => {
    try {
      toast.info("Refrescando datos del servidor...");
      await callServer('/admin/invalidar-cache', 'POST');
      toast.success("Cache actualizado. Refrescando página...");
      setTimeout(() => {
        if (onRefresh) onRefresh();
      }, 500);
    } catch (error) {
      console.error("Error invalidating cache:", error);
      toast.error("Error al refrescar cache");
    }
  };

  const handleRetiro = (tipo: 'rendimiento' | 'red') => {
    // Redirigir a la sección de cobros
    if (onNavigate) {
      onNavigate('cobros');
    } else {
      toast.info('Redirigiendo a la sección de retiros...');
    }
  };

  // IMPORTANTE: userData.cantidad es el monto del pack ACTIVO actual
  // NO es la suma de todos los packs (eso sería inversionTotal)
  const packActivoMonto = userData.cantidad;
  
  // 🔥 CORRECCIÓN: Usar ganancia_total para mostrar el total histórico
  // ganancia_total = TODAS las ganancias históricas (de todos los packs)
  // ganancia_acumulada = SOLO las ganancias del pack activo actual
  const gananciaTotalGenerada = userData.ganancia_total || ((userData.comisiones_red || 0) + (userData.comisiones_patrocinio || 0) + (userData.rendimiento_diario || 0));
  
  // 🔥 NUEVA LÓGICA: Para calcular rentabilidad del PACK ACTIVO
  // Usar ganancia_acumulada si existe, si no, calcular desde ganancia_total
  const gananciaPackActivo = userData.ganancia_acumulada || gananciaTotalGenerada;
  const limiteRetiro = packActivoMonto * 2; // 200% del pack ACTIVO
  const porcentajeRentabilidad = packActivoMonto > 0 ? (gananciaPackActivo / packActivoMonto) * 100 : 0;
  const porcentajeLimitado = Math.min(porcentajeRentabilidad, 200); // Límite visual al 200%
  const alcanzado100 = porcentajeRentabilidad >= 100;
  const alcanzado200 = porcentajeRentabilidad >= 200;
  
  // Calcular ganancias disponibles y bloqueadas
  // Sistema del 200%: Usuario puede retirar hasta el 200% de su inversión.
  

  // 1. Calcular límite de retiro (generalmente 200% de la inversión activa)
  // Si no hay inversión activa pero hay histórica, ¿se aplica límite?
  // Asumiremos que el límite es 200% de la inversión actual activa.
  // Si invirtió 1000, límite es 2000.
  
  // 2. Usar ganancia TOTAL HISTÓRICA para el cálculo del saldo de wallet
  // userData.ganancia_total viene del Dashboard y es la suma de TODAS las comisiones históricas
  const gananciaTotalHistorica = userData.ganancia_total || 0;
  
  // Usamos ganancia_acumulada (ciclo actual) SOLO para la barra de progreso del 200%
  const gananciaCicloActual = userData.ganancia_acumulada || 0;
  
  // Cálculo de Saldo Wallet:
  // 1. Calculamos el tope teórico histórico (si aplica). 
  //    En muchos sistemas, el saldo viejo NO se pierde, solo se limita el NUEVO retiro.
  //    Pero aquí el sistema parece querer bloquear el excedente del 200%.
  //    La regla es: No puedes retirar más del 200% de tu inversión ACTIVA en total?
  //    O es por paquete?
  //    Asumiremos que el saldo es simplemente (Ganado - Gastado).
  //    El BLOQUEO se aplica al momento de retirar o se muestra visualmente.
  
  // Recalcular retiros y gastos localmente
  const cobrosTotales = listaRetiros
    .filter((c: any) => c.estado === 'completado' || c.estado === 'pendiente' || c.estado === 'aprobado');
    
  const totalRetiradoReal = cobrosTotales
    .filter((c: any) => c.metodo !== 'Compra con Wallet') // Excluir compras con wallet
    .reduce((sum: number, c: any) => sum + c.monto, 0);
    
  const totalComprasWallet = cobrosTotales
    .filter((c: any) => c.metodo === 'Compra con Wallet')
    .reduce((sum: number, c: any) => sum + c.monto, 0);
    
  // Saldo Disponible = Ganancia Total - Retiros - Gastos Ruleta - Compras Wallet
  // SIN aplicar el límite del 200% aquí para la visualización del saldo, 
  // porque el usuario ya pagó por ese saldo con su trabajo/inversión previa.
  // El límite del 200% aplica a CUANTO MÁS puedes ganar con el paquete actual.
  
  const saldoWalletDisponible = loading 
    ? 0 
    : Math.max(0, gananciaTotalHistorica - totalRetiradoReal - totalGastadoRuleta - totalComprasWallet);
    
  // Para la visualización de "Ganancia Bloqueada" (excedente del 200%)
  // Usar saldo_retenido del backend si existe, sino calcular estimado
  const saldoRetenidoReal = userData.saldo_retenido || 0;
  
  let gananciaBloqueada = saldoRetenidoReal;
  if (gananciaBloqueada === 0 && gananciaCicloActual > (packActivoMonto * 2)) {
    gananciaBloqueada = gananciaCicloActual - (packActivoMonto * 2);
  }
  
  const superaLimite = gananciaBloqueada > 0;

  // FIX: Definir rendimientoAlcanzado200 que se usa en el JSX
  const rendimientoAlcanzado200 = gananciaCicloActual >= (packActivoMonto * 2) || superaLimite;
  
  // Variables para la modal de historial
  const gananciaMostrarEnModal = gananciaTotalHistorica; 
  const retiradoMostrarEnModal = totalRetiradoReal + totalGastadoRuleta + totalComprasWallet;

  // Combinar y ordenar historial completo
  const historialCompleto = useMemo(() => {
    const items = [
      // 1. Ganancias (Ingresos)
      ...(userData.historial || []).map(h => ({
        tipo: 'ingreso',
        subtipo: h.tipo, // 'rendimiento', 'patrocinio', etc.
        fecha: h.fecha, // Ahora es ISO string directo desde Dashboard
        concepto: h.concepto,
        monto: Number(h.importe || 0),
        estado: 'completado'
      })),
      // 2. Retiros (Egresos)
      ...listaRetiros.map(r => ({
        tipo: 'egreso',
        subtipo: 'retiro',
        fecha: r.fecha_solicitud || r.created_at,
        concepto: r.metodo === 'Compra con Wallet' ? 'Compra de Pack (Wallet)' : `Retiro de fondos (${r.metodo})`,
        monto: Number(r.monto || 0),
        estado: r.estado
      })),
      // 3. Gastos Ruleta (Egresos)
      ...listaGastosRuleta.map(g => ({
        tipo: 'egreso',
        subtipo: 'juego',
        fecha: g.created_at,
        concepto: 'Apuesta en Ruleta',
        monto: Number(g.monto || 0),
        estado: 'completado'
      }))
    ];

    // Ordenar por fecha descendente
    return items.sort((a, b) => {
      const dateA = new Date(a.fecha).getTime();
      const dateB = new Date(b.fecha).getTime();
      // Manejo de fechas inválidas
      if (isNaN(dateA)) return 1;
      if (isNaN(dateB)) return -1;
      return dateB - dateA;
    });
  }, [userData.historial, listaRetiros, listaGastosRuleta]);


  // Datos para la dona
  const chartData = [
    { name: 'Completado', value: porcentajeLimitado },
    { name: 'Restante', value: 100 - porcentajeLimitado }
  ];
  const COLORS = ['#1e40af', '#e2e8f0']; // azul y gris claro

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl md:text-3xl font-bold text-slate-500 mb-2">Bienvenido, {userData.nombre}</h1>
        <p className="text-sm md:text-base text-slate-600 font-medium">Vista general de tu cuenta</p>
      </div>

      {/* Countdown Banner */}
      <Card className="relative overflow-hidden shadow-lg">
        <div className="p-4 md:p-8">
          <div className="flex items-center gap-2 mb-4">
            <Clock className="w-5 h-5 md:w-6 md:h-6 text-primary" />
            <h2 className="text-primary text-lg md:text-xl">Próximo Lanzamiento</h2>
          </div>
          
          <div className="grid grid-cols-4 gap-2 md:gap-4 mb-6">
            <div className="bg-primary/10 backdrop-blur-md rounded-xl md:rounded-2xl p-2 md:p-4 text-center border border-primary/50 md:border-2 md:border-primary">
              <div className="text-2xl md:text-4xl text-primary mb-1 font-bold">{timeLeft.days.toString().padStart(2, '0')}</div>
              <div className="text-primary/80 text-[10px] md:text-xs uppercase tracking-wider">Días</div>
            </div>
            <div className="bg-primary/10 backdrop-blur-md rounded-xl md:rounded-2xl p-2 md:p-4 text-center border border-primary/50 md:border-2 md:border-primary">
              <div className="text-2xl md:text-4xl text-primary mb-1 font-bold">{timeLeft.hours.toString().padStart(2, '0')}</div>
              <div className="text-primary/80 text-[10px] md:text-xs uppercase tracking-wider">Horas</div>
            </div>
            <div className="bg-primary/10 backdrop-blur-md rounded-xl md:rounded-2xl p-2 md:p-4 text-center border border-primary/50 md:border-2 md:border-primary">
              <div className="text-2xl md:text-4xl text-primary mb-1 font-bold">{timeLeft.minutes.toString().padStart(2, '0')}</div>
              <div className="text-primary/80 text-[10px] md:text-xs uppercase tracking-wider">Min</div>
            </div>
            <div className="bg-primary/10 backdrop-blur-md rounded-xl md:rounded-2xl p-2 md:p-4 text-center border border-primary/50 md:border-2 md:border-primary">
              <div className="text-2xl md:text-4xl text-primary mb-1 font-bold">{timeLeft.seconds.toString().padStart(2, '0')}</div>
              <div className="text-primary/80 text-[10px] md:text-xs uppercase tracking-wider">Seg</div>
            </div>
          </div>
          
          <p className="text-center text-primary text-base md:text-lg font-medium">
            🚀 ¡Liberty Finance ya está LIVE!
          </p>
        </div>
      </Card>

          {/* Rango Actual */}
      <Card className="p-4 md:p-6 shadow-lg">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-4 w-full sm:w-auto">
            <div className="w-12 h-12 md:w-16 md:h-16 rounded-xl bg-primary/10 flex items-center justify-center text-2xl md:text-3xl border-2 border-primary overflow-hidden shrink-0">
              {/* Mostrar icono/imagen del rango obtenido de la API */}
              {/* Si directosConPack < 3, forzamos Sin Rango */}
              {directosConPack < 3 ? (
                <Star className="w-6 h-6 md:w-8 md:h-8 text-slate-400" />
              ) : rangoInfo?.icon ? (
                /* Si el icono parece una imagen (URL o Base64 largo), lo mostramos como imagen */
                (rangoInfo.icon.startsWith('data:image') || rangoInfo.icon.startsWith('http') || rangoInfo.icon.length > 20) ? (
                  <ImageWithFallback 
                    src={rangoInfo.icon} 
                    alt={rangoInfo.nombre} 
                    className="w-full h-full object-cover"
                  />
                ) : (
                  /* Si es corto, asumimos que es un emoji */
                  <span className="text-2xl md:text-3xl">{rangoInfo.icon}</span>
                )
              ) : (
                /* Fallback si no hay rangoInfo cargado aún o no se encontró */
                <Star className="w-6 h-6 md:w-8 md:h-8 text-slate-400" />
              )}
            </div>
            <div>
              <p className="text-slate-600 text-xs md:text-sm mb-1 font-medium">Tu Rango Actual</p>
              <h2 className="text-2xl md:text-3xl text-primary font-bold">
                {/* Usar rangoInfo.nombre si existe para evitar mostrar basura, o Sin Rango */}
                {directosConPack < 3 
                  ? 'Sin Rango' 
                  : (rangoInfo?.nombre || 'Sin Rango')
                }
              </h2>
              <p className="text-slate-500 text-xs md:text-sm mt-1 font-medium">
                {directosConPack} Directos • ${(volumenTotal / 1000).toFixed(1)}K Volumen
              </p>
            </div>
          </div>
          <div className="hidden sm:block">
            {directosConPack < 3 ? <Star className="w-12 h-12 md:w-16 md:h-16 text-slate-200" /> : <Trophy className="w-12 h-12 md:w-16 md:h-16 text-primary/30" />}
          </div>
        </div>
      </Card>

      {/* Alerta: Rendimiento Bloqueado (Solo si alcanzó 200%) */}
      {rendimientoAlcanzado200 && (
        <Card className="p-4 md:p-6 bg-gradient-to-r from-orange-500 to-red-500 border-0 shadow-xl text-white">
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 md:w-12 md:h-12 rounded-xl bg-white/20 flex items-center justify-center flex-shrink-0">
              <Package className="w-5 h-5 md:w-6 md:h-6 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="text-lg md:text-xl mb-2 font-bold">🔒 Límite de Rentabilidad Alcanzado</h3>
              <p className="text-white/90 mb-3 text-sm md:text-base">
                Has alcanzado el <strong>200% de rentabilidad</strong> de tu pack actual (${(userData.cantidad || 0).toFixed(2)} USDT). 
                Tu pack ha completado su ciclo y no generarás más comisiones hasta que compres uno nuevo.
              </p>
              <p className="text-white/90 mb-4 text-sm md:text-base">
                ⚠️ <strong>Has alcanzado el 200% de rentabilidad, tienes un saldo de ${(gananciaBloqueada || 0).toFixed(2)} USDT que es lo que se te retuvo.</strong> 
                Este saldo se liberará y sumará a tu wallet cuando compres un nuevo pack.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <div className="flex-1">
                  <p className="text-white text-xs md:text-sm bg-white/20 p-3 rounded-lg">
                    💡 <strong>Para seguir generando ganancias:</strong> Compra un nuevo pack para aumentar tu límite de retiro.
                  </p>
                </div>
                <Button
                  onClick={() => onNavigate?.('productos', userData.pack)}
                  className="bg-white text-orange-600 hover:bg-white/90 shadow-lg whitespace-nowrap text-sm"
                >
                  <Package className="w-4 h-4 mr-2" />
                  Comprar Nuevo Pack
                </Button>
              </div>
            </div>
          </div>
        </Card>
      )}

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4 md:gap-6">
        {/* Progreso de Rentabilidad (Donut Chart) */}
        <Card className="p-4 md:p-6 shadow-lg col-span-2 sm:col-span-1">
          <p className="text-slate-600 text-xs md:text-sm mb-3 font-medium">Rentabilidad</p>
          <div className="flex flex-col items-center">
            {/* Donut Chart */}
            <div className="relative">
              <PieChart width={120} height={120}>
                <Pie
                  data={chartData}
                  cx={60}
                  cy={60}
                  innerRadius={35}
                  outerRadius={50}
                  paddingAngle={2}
                  dataKey="value"
                  startAngle={90}
                  endAngle={-270}
                >
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index]} />
                  ))}
                </Pie>
              </PieChart>
              {/* Centro de la dona */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-center">
                <div className="text-xl md:text-2xl leading-none text-primary font-bold">{porcentajeLimitado.toFixed(0)}%</div>
                <div className="text-[10px] text-slate-500 mt-0.5 font-medium">de 200%</div>
              </div>
            </div>
            {/* Mensaje */}
            {porcentajeRentabilidad >= 100 ? (
              <p className="text-xs text-slate-600 mt-2 text-center leading-tight font-medium">
                ✅ Retiro disponible
              </p>
            ) : (
              <p className="text-xs text-slate-600 mt-2 text-center leading-tight font-medium">
                Sigue invirtiendo para liberar más ganancias
              </p>
            )}
          </div>
        </Card>

        {/* Pack */}
        <Card className="p-4 md:p-6 shadow-lg">
          <div className="flex items-start justify-between mb-4">
            <div className="w-10 h-10 md:w-12 md:h-12 rounded-xl bg-primary/10 flex items-center justify-center border-2 border-primary">
              <Package className="w-5 h-5 md:w-6 md:h-6 text-primary" />
            </div>
          </div>
          <p className="text-slate-600 text-xs md:text-sm mb-1 font-medium">Pack Actual</p>
          <p className="text-2xl md:text-3xl text-primary font-bold break-words">{userData.pack}</p>
        </Card>

        {/* Rendimiento */}
        <Card className="p-4 md:p-6 shadow-lg">
          <div className="flex items-start justify-between mb-4">
            <div className="w-10 h-10 md:w-12 md:h-12 rounded-xl bg-primary/10 flex items-center justify-center border-2 border-primary">
              <TrendingUp className="w-5 h-5 md:w-6 md:h-6 text-primary" />
            </div>
          </div>
          <p className="text-slate-600 text-xs md:text-sm mb-1 font-medium">Rendimiento Diario</p>
          {loading ? (
            <div className="h-8 w-20 bg-slate-200 animate-pulse rounded"></div>
          ) : (
            <p className="text-2xl md:text-3xl text-primary font-bold">{(userData.rendimiento_diario || 0).toFixed(2)}</p>
          )}
        </Card>

        {/* Ganancia de Matriz */}
        <Card className="p-4 md:p-6 shadow-lg">
          <div className="flex items-start justify-between mb-4">
            <div className="w-10 h-10 md:w-12 md:h-12 rounded-xl bg-primary/10 flex items-center justify-center border-2 border-primary">
              <UsersIcon className="w-5 h-5 md:w-6 md:h-6 text-primary" />
            </div>
          </div>
          <p className="text-slate-600 text-xs md:text-sm mb-1 font-medium">Ganancia de Matriz</p>
          {loading ? (
            <div className="h-8 w-20 bg-slate-200 animate-pulse rounded"></div>
          ) : (
            <p className="text-2xl md:text-3xl text-primary font-bold">{(userData.comisiones_red || 0).toFixed(2)}</p>
          )}
        </Card>

        {/* Bonos Directos */}
        <Card className="p-4 md:p-6 shadow-lg relative">
          <div className="flex items-start justify-between mb-4">
            <div className="w-10 h-10 md:w-12 md:h-12 rounded-xl bg-blue-100 flex items-center justify-center border-2 border-blue-500">
              <UsersIcon className="w-5 h-5 md:w-6 md:h-6 text-blue-600" />
            </div>
          </div>
          <p className="text-slate-600 text-xs md:text-sm mb-1 font-medium">Bonos Directos</p>
          {loading ? (
            <div className="h-8 w-20 bg-slate-200 animate-pulse rounded mb-2"></div>
          ) : (
            <p className="text-2xl md:text-3xl text-blue-600 mb-2 font-bold">{userData.comisiones_patrocinio?.toFixed(2) || '0.00'}</p>
          )}
          
          {/* ❌ FUNCIÓN DESHABILITADA - El endpoint está deshabilitado en el servidor
          <button 
            onClick={handleSyncComisiones}
            disabled={isSyncing}
            className="text-[10px] text-blue-500 underline hover:text-blue-700 cursor-pointer font-medium"
          >
            {isSyncing ? 'Sincronizando...' : 'Sincronizar Historial'}
          </button>
          */}
        </Card>
      </div>

      {/* Actions Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Tu Wallet (Anteriormente Rendimiento Disponible) */}
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-slate-800">Tu Wallet</h3>
            
            {/* Botón de Historial Detallado */}
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="ghost" size="sm" className="h-8 px-2 text-slate-500 hover:text-primary hover:bg-blue-50">
                  <History className="w-4 h-4 mr-1" />
                  <span className="text-xs">Ver Movimientos</span>
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[80vh]">
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2">
                    <FileText className="w-5 h-5 text-primary" />
                    Historial Detallado de Wallet
                  </DialogTitle>
                  <DialogDescription>
                    Consulta todos tus ingresos, retiros y gastos de juego.
                  </DialogDescription>
                </DialogHeader>
                
                <div className="bg-slate-50 p-4 rounded-xl mb-4">
                  <p className="text-sm text-slate-600 mb-2">Resumen de saldo:</p>
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div className="bg-white p-2 rounded-lg border border-slate-200">
                      <p className="text-xs text-slate-500">Ganado</p>
                      <p className="font-bold text-green-600">
                        +${(userData.ganancia_total || 0).toFixed(2)}
                      </p>
                    </div>
                    <div className="bg-white p-2 rounded-lg border border-slate-200">
                      <p className="text-xs text-slate-500">Retirado/Gastado</p>
                      <p className="font-bold text-red-600">
                        -${(totalRetirado + totalGastadoRuleta).toFixed(2)}
                      </p>
                    </div>
                    <div className="bg-blue-50 p-2 rounded-lg border border-blue-200">
                      <p className="text-xs text-blue-600">Disponible</p>
                      <p className="font-bold text-blue-700">
                        ${saldoWalletDisponible.toFixed(2)}
                      </p>
                    </div>
                  </div>
                </div>

                <style>{`
                  .custom-scrollbar::-webkit-scrollbar {
                    width: 10px;
                    display: block;
                  }
                  .custom-scrollbar::-webkit-scrollbar-track {
                    background: #f1f5f9;
                    border-radius: 5px;
                  }
                  .custom-scrollbar::-webkit-scrollbar-thumb {
                    background: #94a3b8;
                    border-radius: 5px;
                    border: 2px solid #f1f5f9;
                  }
                  .custom-scrollbar::-webkit-scrollbar-thumb:hover {
                    background: #64748b;
                  }
                `}</style>
                {/* Scrollable History Container */}
                <div 
                  className="h-[400px] overflow-y-scroll pr-1 w-full border rounded-lg p-2 custom-scrollbar"
                  style={{ scrollbarWidth: 'thin', scrollbarColor: '#94a3b8 #f1f5f9' }}
                >
                  <div className="space-y-3">
                    {historialCompleto.length === 0 ? (
                      <p className="text-center text-slate-500 py-8">No hay movimientos registrados</p>
                    ) : (
                      historialCompleto.map((item, idx) => {
                        // Validar fecha
                        let fechaStr = 'Fecha desconocida';
                        try {
                          const fecha = new Date(item.fecha);
                          if (!isNaN(fecha.getTime())) {
                            fechaStr = fecha.toLocaleDateString();
                          } else {
                             // Fallback si la fecha es inválida pero es un cobro reciente
                             fechaStr = 'Reciente';
                          }
                        } catch (e) {
                          fechaStr = '-';
                        }
                        
                        return (
                        <div key={idx} className="flex items-center justify-between p-3 bg-white border border-slate-100 rounded-lg hover:shadow-sm transition-shadow">
                          <div className="flex items-start gap-3">
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                              item.tipo === 'ingreso' ? 'bg-green-100 text-green-600' : 
                              item.subtipo === 'juego' ? 'bg-purple-100 text-purple-600' :
                              'bg-red-100 text-red-600'
                            }`}>
                              {item.tipo === 'ingreso' ? <ArrowDownRight className="w-4 h-4" /> : 
                               item.subtipo === 'juego' ? <Dices className="w-4 h-4" /> :
                               <ArrowUpRight className="w-4 h-4" />}
                            </div>
                            <div>
                              <p className="text-sm font-medium text-slate-800">{item.concepto}</p>
                              <p className="text-xs text-slate-500">
                                {fechaStr} • {
                                  item.subtipo === 'rendimiento' ? 'Rendimiento Diario' :
                                  item.subtipo === 'patrocinio' ? 'Bono Directo' :
                                  item.subtipo === 'retiro' ? 'Retiro' :
                                  item.subtipo === 'juego' ? 'Juego Ruleta' : 'Comisión'
                                }
                                {item.estado === 'pendiente' && <span className="ml-2 text-orange-500 font-bold">(Pendiente)</span>}
                                {item.estado === 'rechazado' && <span className="ml-2 text-red-500 font-bold">(Rechazado)</span>}
                              </p>
                            </div>
                          </div>
                          <p className={`font-bold ${
                            item.estado === 'rechazado' ? 'text-slate-400 line-through' :
                            item.tipo === 'ingreso' ? 'text-green-600' : 'text-red-600'
                          }`}>
                            {item.tipo === 'ingreso' ? '+' : '-'}${Number(item.monto || 0).toFixed(2)}
                          </p>
                        </div>
                        );
                      })
                    )}
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
          <div className="flex items-center justify-between p-4 bg-[#e0f2fe] rounded-xl mb-4 border-2 border-primary/20">
            <div>
              <p className="text-slate-600 text-sm mb-1">Saldo Disponible para Retiro</p>
              <div className="h-8 flex items-center">
                {loading ? (
                  <div className="h-6 w-24 bg-blue-200 animate-pulse rounded"></div>
                ) : (
                  <p className="text-2xl text-primary">${saldoWalletDisponible.toFixed(2)}</p>
                )}
              </div>
              <p className="text-xs text-slate-500 mt-1">
                Solo ganancias (capital bloqueado)
              </p>
              {superaLimite && (
                <div className="mt-2 p-2 bg-orange-50 border border-orange-200 rounded-lg">
                  <p className="text-xs text-orange-800 flex items-start gap-1">
                    <span className="mt-0.5">🔒</span>
                    <span>
                      <strong>${gananciaBloqueada.toFixed(2)} bloqueados</strong> por llegar al 200%.
                      <br />
                      <span className="font-medium underline cursor-pointer hover:text-orange-900" onClick={() => onNavigate?.('productos', userData.pack)}>
                        Reinvierte para liberar saldo.
                      </span>
                    </span>
                  </p>
                </div>
              )}
            </div>
            <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center border-2 border-primary">
              <TrendingUp className="w-6 h-6 text-primary" />
            </div>
          </div>
          
          {/* Mensaje informativo */}
          {alcanzado200 ? (
            <>
              {/* Mensaje informativo: Mostrar siempre si alcanzó 200%, tenga o no saldo bloqueado */}
              <div className="mb-4 p-3 bg-orange-50 border-2 border-orange-200 rounded-xl">
                <p className="text-xs text-orange-800 leading-relaxed">
                  {superaLimite ? (
                    <>
                      💡 <strong>Has superado el límite del 200%</strong>. Para retirar los ${gananciaBloqueada.toFixed(2)} adicionales, compra otro pack.
                    </>
                  ) : (
                    <>
                      ⚠️ <strong>Has alcanzado el 200% de rentabilidad</strong>. Tu pack ha completado su ciclo y no generarás más comisiones hasta que compres uno nuevo.
                    </>
                  )}
                </p>
              </div>
              {/* Botones de acción */}
              <div className="grid grid-cols-2 gap-3">
                <Button
                  onClick={() => handleRetiro('rendimiento')}
                  className="w-full h-12 rounded-xl shadow-lg"
                >
                  <ArrowUpRight className="w-5 h-5 mr-2" />
                  Retirar Fondos
                </Button>
                {superaLimite && (
                  <Button
                    onClick={() => onNavigate?.('productos', userData.pack)}
                    className="w-full h-12 rounded-xl shadow-lg bg-orange-600 hover:bg-orange-700"
                  >
                    <Package className="w-5 h-5 mr-2" />
                    Reinvertir
                  </Button>
                )}
              </div>
            </>
          ) : (
            <>
              <div className="mb-4 p-3 bg-blue-50 border-2 border-blue-200 rounded-xl">
                <p className="text-xs text-blue-800 leading-relaxed">
                  💰 Puedes retirar tus ganancias con una comisión del 10%. Tu progreso actual es {porcentajeRentabilidad.toFixed(1)}% de 200%.
                </p>
              </div>
              <Button
                onClick={() => handleRetiro('rendimiento')}
                className="w-full h-12 rounded-xl shadow-lg"
                disabled={saldoWalletDisponible <= 0}
              >
                <ArrowUpRight className="w-5 h-5 mr-2" />
                {saldoWalletDisponible > 0 ? 'Retirar Fondos' : 'Sin Saldo Disponible'}
              </Button>
            </>
          )}
        </Card>
      </div>

      {/* Network Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="p-6">
          <div className="flex items-center justify-between p-4 bg-[#e0f2fe] rounded-xl border-2 border-primary/20">
            <div>
              <p className="text-slate-600 text-sm mb-1">Referidos Directos</p>
              <p className="text-2xl text-primary">{referidosDirectosReales.length || userData.directos.filter((d: any) => d.esDirecto).length}</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center border-2 border-primary">
              <UsersIcon className="w-6 h-6 text-primary" />
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between p-4 bg-[#e0f2fe] rounded-xl border-2 border-primary/20">
            <div>
              <p className="text-slate-600 text-sm mb-1">Red Total</p>
              <p className="text-2xl text-primary">
                {userData.cycle && userData.cycle.level1 && userData.cycle.level2
                  ? (userData.cycle.level1.filter((r: any) => r !== null).length +
                     userData.cycle.level2.filter((r: any) => r !== null).length)
                  : (userData.directos?.length || 0)}
              </p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center border-2 border-primary">
              <UsersIcon className="w-6 h-6 text-primary" />
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between p-4 bg-[#e0f2fe] rounded-xl border-2 border-primary/20">
            <div>
              <p className="text-slate-600 text-sm mb-1">Total Ganado</p>
              <p className="text-2xl text-primary">
                ${gananciaTotalGenerada.toFixed(2)}
              </p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center border-2 border-primary">
              <TrendingUp className="w-6 h-6 text-primary" />
            </div>
          </div>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-slate-800">Actividad Reciente</h3>
          {/* ❌ FUNCIÓN DESHABILITADA - El endpoint está deshabilitado en el servidor
          <button 
            onClick={handleSyncComisiones}
            disabled={isSyncing}
            className="text-sm text-blue-500 hover:text-blue-700 flex items-center gap-1 transition-colors"
          >
            <History className="w-4 h-4" />
            {isSyncing ? 'Sincronizando...' : 'Sincronizar'}
          </button>
          */}
        </div>
        <div className="overflow-auto max-h-[400px]">
          <table className="w-full">
            <thead className="sticky top-0 bg-white z-10 shadow-sm">
              <tr className="border-b border-slate-200">
                <th className="text-left py-3 px-4 text-slate-600 text-sm bg-white">Fecha</th>
                <th className="text-left py-3 px-4 text-slate-600 text-sm bg-white">Concepto</th>
                <th className="text-left py-3 px-4 text-slate-600 text-sm bg-white">Tipo</th>
                <th className="text-left py-3 px-4 text-slate-600 text-sm bg-white">Importe</th>
              </tr>
            </thead>
            <tbody>
              {userData.historial.length === 0 ? (
                <tr>
                  <td colSpan={4} className="text-center py-8 text-slate-500">
                    No hay actividades recientes
                  </td>
                </tr>
              ) : (
                userData.historial.map((item, index) => {
                  // Determinar el color y texto del badge según el tipo
                  let badgeClass = 'bg-purple-100 text-purple-700';
                  let badgeText = 'Comisión Red';
                  let montoClass = 'text-green-600';
                  
                  if (item.tipo === 'rendimiento') {
                    badgeClass = 'bg-green-100 text-green-700';
                    badgeText = 'Rendimiento';
                  } else if (item.tipo === 'patrocinio') {
                    badgeClass = 'bg-blue-100 text-blue-700';
                    badgeText = 'Bono Directo';
                  } else if (item.tipo === 'red') {
                    badgeClass = 'bg-purple-100 text-purple-700';
                    badgeText = 'Comisión Red';
                  } else if (item.tipo === 'rangos') {
                    badgeClass = 'bg-yellow-100 text-yellow-700';
                    badgeText = 'Comisión Rango';
                  } else if (item.tipo === 'retiro') {
                    badgeClass = 'bg-red-100 text-red-700';
                    badgeText = 'Retiro';
                    montoClass = 'text-red-600';
                  } else if (item.tipo === 'ruleta_gasto') {
                    badgeClass = 'bg-pink-100 text-pink-700';
                    badgeText = 'Ruleta';
                    montoClass = 'text-red-600';
                  } else if (item.tipo === 'compra_pack') {
                    badgeClass = 'bg-cyan-100 text-cyan-700';
                    badgeText = 'Inversión';
                    montoClass = 'text-slate-600';
                  } else if (item.tipo === 'excedente_retenido') {
                    badgeClass = 'bg-orange-100 text-orange-700';
                    badgeText = 'Retenido (Tope)';
                    montoClass = 'text-orange-600';
                  }
                  
                  // Formatear el importe (puede venir en item.importe o item.monto)
                  const importe = typeof item.importe === 'number' 
                    ? item.importe.toFixed(2) 
                    : (typeof item.monto === 'number' ? item.monto.toFixed(2) : item.importe);
                  
                  return (
                    <tr key={item.id || index} className="border-b border-slate-100 hover:bg-slate-50 transition-colors">
                      <td className="py-3 px-4 text-slate-600">{item.fecha}</td>
                      <td className="py-3 px-4 text-slate-800">{item.concepto}</td>
                      <td className="py-3 px-4">
                        <span className={`px-3 py-1 rounded-lg text-sm ${badgeClass}`}>
                          {badgeText}
                        </span>
                      </td>
                      <td className={`py-3 px-4 ${montoClass}`}>
                        {(item.tipo === 'retiro' || item.tipo === 'ruleta_gasto') ? '-' : ''}${importe}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Info Card */}
      <Card className="p-6 bg-gradient-to-r from-blue-500 to-cyan-500 border-0 shadow-lg text-white">
        <h3 className="text-lg mb-2">💡 Tu Código de Referido</h3>
        <p className="text-white/90 text-sm mb-3">
          Comparte tu código único para invitar nuevos miembros y aumentar tus ganancias.
        </p>
        <div className="bg-white/20 backdrop-blur-sm rounded-xl p-4 text-center">
          <p className="text-2xl tracking-wider">{userData.id_unico}</p>
        </div>
      </Card>
    </div>
  );
}