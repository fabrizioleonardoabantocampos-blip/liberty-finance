-- =============================================
-- Liberty Finance - Datos Iniciales
-- =============================================

-- =============================================
-- USUARIO ADMINISTRADOR
-- =============================================
-- Password: admin123 (hash bcrypt)
INSERT INTO `usuarios` (
  `id_unico`, 
  `nombre`, 
  `apellido`, 
  `email`, 
  `password_hash`, 
  `rol`,
  `ciudad`,
  `pais`,
  `rango`
) VALUES (
  'ADMIN001',
  'Administrador',
  'Sistema',
  'admin@libertyfinance.com',
  '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', -- admin123
  'admin',
  'Ciudad',
  'País',
  'Administrador'
);

-- =============================================
-- CONFIGURACIÓN INICIAL
-- =============================================

-- Porcentaje de rendimiento diario por defecto
INSERT INTO `configuracion` (`clave`, `valor`, `tipo`) VALUES
('rendimiento_diario_porcentaje', '0.0067', 'number'); -- 0.67% diario

-- Porcentaje de comisión directa (patrocinio)
INSERT INTO `configuracion` (`clave`, `valor`, `tipo`) VALUES
('comision_directa_porcentaje', '0.10', 'number'); -- 10%

-- Porcentaje de comisión binaria
INSERT INTO `configuracion` (`clave`, `valor`, `tipo`) VALUES
('comision_binaria_porcentaje', '0.10', 'number'); -- 10%

-- Máximo de retorno por pack (200%)
INSERT INTO `configuracion` (`clave`, `valor`, `tipo`) VALUES
('max_retorno_porcentaje', '2.0', 'number'); -- 200%

-- Wallet admin para depósitos
INSERT INTO `configuracion` (`clave`, `valor`, `tipo`) VALUES
('wallet_admin_usdt', 'TU_WALLET_AQUI', 'string');

-- Información de la empresa
INSERT INTO `configuracion` (`clave`, `valor`, `tipo`) VALUES
('empresa_nombre', 'Liberty Finance', 'string');

INSERT INTO `configuracion` (`clave`, `valor`, `tipo`) VALUES
('empresa_email', 'info@libertyfinance.com', 'string');

INSERT INTO `configuracion` (`clave`, `valor`, `tipo`) VALUES
('empresa_telefono', '+1 (555) 123-4567', 'string');

-- Términos y condiciones
INSERT INTO `configuracion` (`clave`, `valor`, `tipo`) VALUES
('terminos_condiciones', 'Términos y condiciones de Liberty Finance...', 'string');

-- Política de privacidad
INSERT INTO `configuracion` (`clave`, `valor`, `tipo`) VALUES
('politica_privacidad', 'Política de privacidad de Liberty Finance...', 'string');

-- =============================================
-- RANGOS DEL SISTEMA
-- =============================================
INSERT INTO `rangos` (`nombre`, `puntos_requeridos`, `bono_porcentaje`, `color`, `icono`, `orden`, `activo`) VALUES
('Nuevo', 0, 0, '#94A3B8', 'User', 1, TRUE),
('Bronce', 1000, 2, '#CD7F32', 'Award', 2, TRUE),
('Plata', 5000, 4, '#C0C0C0', 'Medal', 3, TRUE),
('Oro', 15000, 6, '#FFD700', 'Trophy', 4, TRUE),
('Platino', 50000, 8, '#E5E4E2', 'Crown', 5, TRUE),
('Diamante', 150000, 10, '#B9F2FF', 'Gem', 6, TRUE),
('Diamante Azul', 500000, 12, '#4169E1', 'Star', 7, TRUE),
('Diamante Negro', 1500000, 15, '#36454F', 'Sparkles', 8, TRUE),
('Presidencial', 5000000, 20, '#8B008B', 'Crown', 9, TRUE);

-- =============================================
-- PRODUCTOS (PACKS) DISPONIBLES
-- =============================================
INSERT INTO `productos` (`nombre`, `monto`, `rendimiento_diario`, `descripcion`, `activo`, `orden`) VALUES
('Pack Inicial', 50.00, 0.0067, 'Ideal para comenzar tu inversión en Liberty Finance', TRUE, 1),
('Pack Básico', 100.00, 0.0067, 'El punto de partida perfecto para inversores nuevos', TRUE, 2),
('Pack Estándar', 250.00, 0.0067, 'Rendimientos constantes y seguros', TRUE, 3),
('Pack Premium', 500.00, 0.0067, 'Mayor inversión, mayores rendimientos', TRUE, 4),
('Pack Elite', 1000.00, 0.0067, 'Para inversores serios', TRUE, 5),
('Pack VIP', 2500.00, 0.0067, 'Beneficios exclusivos y rendimientos superiores', TRUE, 6),
('Pack Diamante', 5000.00, 0.0067, 'La inversión de élite', TRUE, 7),
('Pack Presidencial', 10000.00, 0.0067, 'El paquete más exclusivo', TRUE, 8);

-- =============================================
-- DATOS DE PRUEBA (OPCIONAL - Comentar si no deseas)
-- =============================================

-- Usuario de prueba 1
INSERT INTO `usuarios` (
  `id_unico`, 
  `nombre`, 
  `apellido`, 
  `email`, 
  `password_hash`, 
  `rol`,
  `ciudad`,
  `sponsor_id`,
  `rango`
) VALUES (
  'USR001',
  'Juan',
  'Pérez',
  'juan@example.com',
  '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', -- admin123
  'usuario',
  'Ciudad de México',
  'ADMIN001',
  'Nuevo'
);

-- Pack de prueba para usuario 1
INSERT INTO `packs` (
  `usuario_id`,
  `monto_inicial`,
  `monto_actual`,
  `activo`
) VALUES (
  'USR001',
  100.00,
  100.00,
  TRUE
);

-- Usuario de prueba 2
INSERT INTO `usuarios` (
  `id_unico`, 
  `nombre`, 
  `apellido`, 
  `email`, 
  `password_hash`, 
  `rol`,
  `ciudad`,
  `sponsor_id`,
  `padre_binario_id`,
  `posicion_matriz`,
  `rango`
) VALUES (
  'USR002',
  'María',
  'González',
  'maria@example.com',
  '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', -- admin123
  'usuario',
  'Guadalajara',
  'USR001',
  'USR001',
  'izquierda',
  'Nuevo'
);

-- Pack de prueba para usuario 2
INSERT INTO `packs` (
  `usuario_id`,
  `monto_inicial`,
  `monto_actual`,
  `activo`
) VALUES (
  'USR002',
  250.00,
  250.00,
  TRUE
);

-- Actualizar hijos de usuario 1
UPDATE `usuarios` SET `hijo_izquierdo_id` = 'USR002' WHERE `id_unico` = 'USR001';

-- =============================================
-- ÍNDICES Y OPTIMIZACIONES
-- =============================================

-- Optimizar tablas
OPTIMIZE TABLE usuarios;
OPTIMIZE TABLE packs;
OPTIMIZE TABLE comisiones;
OPTIMIZE TABLE rendimientos_diarios;
OPTIMIZE TABLE retiros;
OPTIMIZE TABLE depositos;

-- =============================================
-- FIN DE DATOS INICIALES
-- =============================================
