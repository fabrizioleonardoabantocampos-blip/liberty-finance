-- =============================================
-- Liberty Finance - Esquema de Base de Datos MySQL
-- =============================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

-- =============================================
-- TABLA: usuarios
-- =============================================
CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `id_unico` VARCHAR(50) UNIQUE NOT NULL,
  `nombre` VARCHAR(100) NOT NULL,
  `apellido` VARCHAR(100) NOT NULL,
  `email` VARCHAR(255) UNIQUE NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `ciudad` VARCHAR(100) DEFAULT '',
  `pais` VARCHAR(100) DEFAULT '',
  `wallet` VARCHAR(255) DEFAULT '',
  `rol` ENUM('usuario', 'admin') DEFAULT 'usuario',
  `sponsor_id` VARCHAR(50) DEFAULT NULL,
  `posicion_matriz` ENUM('izquierda', 'derecha') DEFAULT NULL,
  `padre_binario_id` VARCHAR(50) DEFAULT NULL,
  `hijo_izquierdo_id` VARCHAR(50) DEFAULT NULL,
  `hijo_derecho_id` VARCHAR(50) DEFAULT NULL,
  `puntos_izquierda` DECIMAL(15,2) DEFAULT 0,
  `puntos_derecha` DECIMAL(15,2) DEFAULT 0,
  `puntos_personales` DECIMAL(15,2) DEFAULT 0,
  `rango` VARCHAR(50) DEFAULT 'Nuevo',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_id_unico (id_unico),
  INDEX idx_email (email),
  INDEX idx_sponsor (sponsor_id),
  INDEX idx_padre_binario (padre_binario_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================
-- TABLA: packs (inversiones de usuarios)
-- =============================================
CREATE TABLE IF NOT EXISTS `packs` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `usuario_id` VARCHAR(50) NOT NULL,
  `monto_inicial` DECIMAL(15,2) NOT NULL,
  `monto_actual` DECIMAL(15,2) NOT NULL,
  `rendimiento_acumulado` DECIMAL(15,2) DEFAULT 0,
  `comisiones_acumuladas` DECIMAL(15,2) DEFAULT 0,
  `total_acumulado` DECIMAL(15,2) DEFAULT 0,
  `porcentaje_completado` DECIMAL(5,2) DEFAULT 0,
  `activo` BOOLEAN DEFAULT TRUE,
  `fecha_compra` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `fecha_inactivacion` TIMESTAMP NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_usuario (usuario_id),
  INDEX idx_activo (activo),
  INDEX idx_fecha_compra (fecha_compra)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================
-- TABLA: rendimientos_diarios
-- =============================================
CREATE TABLE IF NOT EXISTS `rendimientos_diarios` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `usuario_id` VARCHAR(50) NOT NULL,
  `pack_id` INT NOT NULL,
  `monto` DECIMAL(15,2) NOT NULL,
  `porcentaje` DECIMAL(5,4) NOT NULL,
  `fecha` DATE NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY unique_rendimiento (usuario_id, pack_id, fecha),
  INDEX idx_usuario (usuario_id),
  INDEX idx_pack (pack_id),
  INDEX idx_fecha (fecha)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================
-- TABLA: comisiones
-- =============================================
CREATE TABLE IF NOT EXISTS `comisiones` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `usuario_id` VARCHAR(50) NOT NULL,
  `referido_id` VARCHAR(50) NOT NULL,
  `pack_id` INT NOT NULL,
  `tipo` ENUM('directa', 'binaria', 'rango') NOT NULL,
  `monto` DECIMAL(15,2) NOT NULL,
  `descripcion` TEXT,
  `fecha` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_usuario (usuario_id),
  INDEX idx_referido (referido_id),
  INDEX idx_tipo (tipo),
  INDEX idx_fecha (fecha)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================
-- TABLA: retiros
-- =============================================
CREATE TABLE IF NOT EXISTS `retiros` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `usuario_id` VARCHAR(50) NOT NULL,
  `monto` DECIMAL(15,2) NOT NULL,
  `wallet` VARCHAR(255) NOT NULL,
  `metodo` VARCHAR(50) DEFAULT 'USDT',
  `estado` ENUM('pendiente', 'aprobado', 'rechazado', 'procesado') DEFAULT 'pendiente',
  `comprobante_url` VARCHAR(500) DEFAULT NULL,
  `notas_admin` TEXT DEFAULT NULL,
  `fecha_solicitud` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `fecha_procesado` TIMESTAMP NULL,
  `procesado_por` VARCHAR(50) DEFAULT NULL,
  INDEX idx_usuario (usuario_id),
  INDEX idx_estado (estado),
  INDEX idx_fecha (fecha_solicitud)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================
-- TABLA: depositos
-- =============================================
CREATE TABLE IF NOT EXISTS `depositos` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `usuario_id` VARCHAR(50) NOT NULL,
  `monto` DECIMAL(15,2) NOT NULL,
  `comprobante_url` VARCHAR(500) DEFAULT NULL,
  `estado` ENUM('pendiente', 'aprobado', 'rechazado') DEFAULT 'pendiente',
  `notas_admin` TEXT DEFAULT NULL,
  `fecha_solicitud` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `fecha_procesado` TIMESTAMP NULL,
  `procesado_por` VARCHAR(50) DEFAULT NULL,
  INDEX idx_usuario (usuario_id),
  INDEX idx_estado (estado),
  INDEX idx_fecha (fecha_solicitud)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================
-- TABLA: configuracion (KV store genérico)
-- =============================================
CREATE TABLE IF NOT EXISTS `configuracion` (
  `clave` VARCHAR(100) PRIMARY KEY,
  `valor` TEXT NOT NULL,
  `tipo` ENUM('string', 'number', 'boolean', 'json') DEFAULT 'string',
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================
-- TABLA: bloqueo_rendimientos (prevenir duplicados)
-- =============================================
CREATE TABLE IF NOT EXISTS `bloqueo_rendimientos` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `fecha` DATE NOT NULL,
  `estado` ENUM('en_proceso', 'completado', 'error') DEFAULT 'en_proceso',
  `iniciado_en` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `completado_en` TIMESTAMP NULL,
  `usuarios_procesados` INT DEFAULT 0,
  `rendimientos_generados` INT DEFAULT 0,
  `errores` TEXT DEFAULT NULL,
  UNIQUE KEY unique_fecha (fecha),
  INDEX idx_fecha (fecha),
  INDEX idx_estado (estado)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================
-- TABLA: logs (registro de actividades importantes)
-- =============================================
CREATE TABLE IF NOT EXISTS `logs` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `tipo` VARCHAR(50) NOT NULL,
  `usuario_id` VARCHAR(50) DEFAULT NULL,
  `accion` VARCHAR(255) NOT NULL,
  `detalles` TEXT DEFAULT NULL,
  `ip` VARCHAR(50) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_tipo (tipo),
  INDEX idx_usuario (usuario_id),
  INDEX idx_fecha (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================
-- TABLA: rangos (configuración de rangos)
-- =============================================
CREATE TABLE IF NOT EXISTS `rangos` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `nombre` VARCHAR(100) NOT NULL UNIQUE,
  `puntos_requeridos` DECIMAL(15,2) NOT NULL,
  `bono_porcentaje` DECIMAL(5,2) DEFAULT 0,
  `color` VARCHAR(20) DEFAULT '#3B82F6',
  `icono` VARCHAR(50) DEFAULT 'Award',
  `orden` INT DEFAULT 0,
  `activo` BOOLEAN DEFAULT TRUE,
  INDEX idx_orden (orden)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================
-- TABLA: productos (packs disponibles)
-- =============================================
CREATE TABLE IF NOT EXISTS `productos` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `nombre` VARCHAR(100) NOT NULL,
  `monto` DECIMAL(15,2) NOT NULL,
  `rendimiento_diario` DECIMAL(5,4) NOT NULL,
  `descripcion` TEXT DEFAULT NULL,
  `activo` BOOLEAN DEFAULT TRUE,
  `imagen_url` VARCHAR(500) DEFAULT NULL,
  `orden` INT DEFAULT 0,
  INDEX idx_activo (activo),
  INDEX idx_orden (orden)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================
-- TABLA: documentos (documentos subidos por usuarios)
-- =============================================
CREATE TABLE IF NOT EXISTS `documentos` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `usuario_id` VARCHAR(50) NOT NULL,
  `tipo` VARCHAR(50) NOT NULL,
  `nombre` VARCHAR(255) NOT NULL,
  `url` VARCHAR(500) NOT NULL,
  `estado` ENUM('pendiente', 'aprobado', 'rechazado') DEFAULT 'pendiente',
  `notas_admin` TEXT DEFAULT NULL,
  `fecha_subida` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `fecha_revision` TIMESTAMP NULL,
  INDEX idx_usuario (usuario_id),
  INDEX idx_tipo (tipo),
  INDEX idx_estado (estado)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================
-- VISTAS ÚTILES
-- =============================================

-- Vista: Resumen de usuarios con sus totales
CREATE OR REPLACE VIEW vista_usuarios_resumen AS
SELECT 
  u.id,
  u.id_unico,
  u.nombre,
  u.apellido,
  u.email,
  u.rol,
  u.rango,
  u.sponsor_id,
  COUNT(DISTINCT p.id) as total_packs,
  SUM(CASE WHEN p.activo = 1 THEN p.monto_inicial ELSE 0 END) as inversion_activa,
  SUM(CASE WHEN p.activo = 1 THEN p.total_acumulado ELSE 0 END) as ganancia_total,
  (SELECT COUNT(*) FROM usuarios WHERE sponsor_id = u.id_unico) as directos,
  u.created_at
FROM usuarios u
LEFT JOIN packs p ON u.id_unico = p.usuario_id
GROUP BY u.id;

-- Vista: Comisiones por usuario
CREATE OR REPLACE VIEW vista_comisiones_usuario AS
SELECT 
  usuario_id,
  SUM(CASE WHEN tipo = 'directa' THEN monto ELSE 0 END) as comisiones_directas,
  SUM(CASE WHEN tipo = 'binaria' THEN monto ELSE 0 END) as comisiones_binarias,
  SUM(CASE WHEN tipo = 'rango' THEN monto ELSE 0 END) as comisiones_rango,
  SUM(monto) as comisiones_totales,
  COUNT(*) as total_comisiones
FROM comisiones
GROUP BY usuario_id;

-- =============================================
-- TRIGGERS
-- =============================================

-- Trigger: Actualizar puntos personales al crear pack
DELIMITER $$
CREATE TRIGGER after_pack_insert
AFTER INSERT ON packs
FOR EACH ROW
BEGIN
  UPDATE usuarios 
  SET puntos_personales = puntos_personales + NEW.monto_inicial
  WHERE id_unico = NEW.usuario_id;
END$$
DELIMITER ;

-- Trigger: Registrar log al cambiar estado de retiro
DELIMITER $$
CREATE TRIGGER after_retiro_update
AFTER UPDATE ON retiros
FOR EACH ROW
BEGIN
  IF NEW.estado != OLD.estado THEN
    INSERT INTO logs (tipo, usuario_id, accion, detalles)
    VALUES ('retiro', NEW.usuario_id, 'cambio_estado', 
      CONCAT('Estado cambiado de ', OLD.estado, ' a ', NEW.estado));
  END IF;
END$$
DELIMITER ;

-- =============================================
-- ÍNDICES ADICIONALES PARA OPTIMIZACIÓN
-- =============================================

-- Índices compuestos para consultas frecuentes
CREATE INDEX idx_packs_usuario_activo ON packs(usuario_id, activo);
CREATE INDEX idx_comisiones_usuario_fecha ON comisiones(usuario_id, fecha);
CREATE INDEX idx_rendimientos_fecha ON rendimientos_diarios(fecha, usuario_id);

-- =============================================
-- FIN DEL SCHEMA
-- =============================================
