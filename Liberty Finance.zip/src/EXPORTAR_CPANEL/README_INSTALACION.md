# 🚀 Instalación Liberty Finance en cPanel

## 📋 Requisitos

- **Hosting cPanel** con:
  - PHP 8.0 o superior
  - MySQL 5.7 o superior
  - Acceso a cron jobs
  - Certificado SSL (recomendado)

## 📦 Archivos Incluidos

```
EXPORTAR_CPANEL/
├── README_INSTALACION.md          (este archivo)
├── database/
│   ├── schema.sql                 (estructura de base de datos)
│   └── initial_data.sql           (datos iniciales)
├── api/
│   ├── config.php                 (configuración de DB)
│   ├── auth.php                   (endpoints de autenticación)
│   ├── users.php                  (endpoints de usuarios)
│   ├── admin.php                  (endpoints de admin)
│   ├── comisiones.php             (cálculo de comisiones)
│   ├── rendimientos.php           (rendimientos diarios)
│   └── utils.php                  (funciones auxiliares)
├── public_html/
│   ├── .htaccess                  (configuración Apache)
│   └── index.html                 (será generado por build)
└── cron/
    └── daily_yields.php           (script para cron job)
```

## 🔧 PASO 1: Crear Base de Datos MySQL

1. **Ingresa a cPanel → MySQL Databases**

2. **Crea una nueva base de datos:**
   - Nombre: `liberty_finance` (o el que prefieras)

3. **Crea un usuario MySQL:**
   - Usuario: `liberty_user`
   - Contraseña: (genera una segura)

4. **Asigna el usuario a la base de datos:**
   - Permisos: **ALL PRIVILEGES**

5. **Anota tus credenciales:**
   ```
   DB_HOST: localhost (o el que te dé cPanel)
   DB_NAME: tu_usuario_liberty_finance
   DB_USER: tu_usuario_liberty_user
   DB_PASS: tu_contraseña_generada
   ```

## 🗄️ PASO 2: Importar Estructura de Base de Datos

1. **Ve a cPanel → phpMyAdmin**

2. **Selecciona tu base de datos** (`liberty_finance`)

3. **Ve a la pestaña "Importar"**

4. **Importa estos archivos en orden:**
   - Primero: `database/schema.sql`
   - Segundo: `database/initial_data.sql`

5. **Verifica que las tablas se crearon:**
   - Deberías ver: `usuarios`, `packs`, `comisiones`, `retiros`, `depositos`, etc.

## ⚙️ PASO 3: Configurar Credenciales de Base de Datos

1. **Edita el archivo** `api/config.php`

2. **Reemplaza con tus credenciales:**
   ```php
   define('DB_HOST', 'localhost');
   define('DB_NAME', 'tu_usuario_liberty_finance');
   define('DB_USER', 'tu_usuario_liberty_user');
   define('DB_PASS', 'tu_contraseña_generada');
   ```

3. **Guarda el archivo**

## 📁 PASO 4: Subir Archivos al Servidor

### Opción A: Administrador de Archivos de cPanel

1. **Ve a cPanel → Administrador de Archivos**

2. **Navega a** `public_html`

3. **Sube la carpeta** `api/` completa

4. **Sube el archivo** `.htaccess`

5. **Permisos de archivos:**
   - Carpeta `api/`: 755
   - Archivos PHP: 644
   - `config.php`: 600 (solo lectura del propietario)

### Opción B: FTP/SFTP

1. **Conecta con FileZilla o similar**

2. **Sube a la raíz** `public_html/`:
   ```
   /public_html/
     /api/
     .htaccess
   ```

## 🏗️ PASO 5: Compilar el Frontend React

En tu máquina local (NO en cPanel):

1. **Modifica el archivo** `utils/api.ts` para apuntar a tu dominio:

```typescript
// Reemplaza esta línea:
const API_URL = `https://${projectId}.supabase.co/functions/v1/make-server-9f68532a`;

// Por esta:
const API_URL = 'https://tudominio.com/api';
```

2. **Instala dependencias:**
```bash
npm install
```

3. **Compila el proyecto:**
```bash
npm run build
```

4. **Sube el contenido de la carpeta** `dist/` a `public_html/`:
   - Sube TODOS los archivos de `dist/` directamente a `public_html/`
   - NO crees una carpeta `dist/` en el servidor
   - El `index.html` debe estar en la raíz de `public_html/`

## ⏰ PASO 6: Configurar Cron Job (Rendimientos Diarios)

1. **Ve a cPanel → Cron Jobs**

2. **Configuración recomendada:**
   - **Frecuencia:** Una vez al día a las 00:05 (5 minutos después de medianoche)
   - **Comando:**
   ```bash
   /usr/bin/php /home/tuusuario/public_html/cron/daily_yields.php
   ```

3. **Formato cron completo:**
   ```
   5 0 * * * /usr/bin/php /home/tuusuario/public_html/cron/daily_yields.php
   ```

   Explicación:
   - `5`: Minuto 5
   - `0`: Hora 0 (medianoche)
   - `* * *`: Todos los días, todos los meses, todos los días de la semana

4. **Verifica la ruta de PHP:**
   ```bash
   which php
   ```
   (Suele ser `/usr/bin/php` o `/usr/local/bin/php`)

## ✅ PASO 7: Verificar Instalación

1. **Prueba la API:**
   - Visita: `https://tudominio.com/api/test.php`
   - Deberías ver: `{"status":"ok","message":"API funcionando"}`

2. **Prueba el login:**
   - Ve a: `https://tudominio.com`
   - Login admin: `admin@libertyfinance.com` / `admin123`

3. **Revisa los logs:**
   - cPanel → Errores (Error Log)
   - Busca errores de PHP o MySQL

## 🔒 PASO 8: Seguridad (MUY IMPORTANTE)

1. **Protege config.php:**
```bash
chmod 600 api/config.php
```

2. **Habilita HTTPS:**
   - cPanel → SSL/TLS → Instala certificado (Let's Encrypt es gratis)

3. **Fuerza HTTPS en .htaccess** (ya incluido):
```apache
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
```

4. **Cambia las credenciales de admin:**
   - Ingresa como admin
   - Ve a "Mi Perfil" → Cambiar contraseña

5. **Configura copias de seguridad:**
   - cPanel → Copias de Seguridad → Generar copia completa
   - Programa copias automáticas semanales

## 🐛 Solución de Problemas Comunes

### Error: "Error de conexión a la base de datos"
- Verifica las credenciales en `api/config.php`
- Verifica que el usuario tenga permisos en la BD
- Revisa que el nombre de la BD incluya el prefijo de usuario

### Error 500 en la API
- Revisa los logs: cPanel → Errores
- Verifica la versión de PHP (debe ser 8.0+)
- Verifica permisos de archivos

### La página no carga (404)
- Verifica que `.htaccess` esté en la raíz de `public_html/`
- Verifica que `index.html` esté en la raíz
- Asegúrate de que mod_rewrite esté habilitado

### Los rendimientos diarios no se calculan
- Verifica que el cron job esté configurado
- Revisa los logs del cron: `/var/log/cron` o cPanel → Cron Jobs → Ver logs
- Ejecuta manualmente: `php /ruta/completa/cron/daily_yields.php`

### Error de CORS
- Verifica que el archivo `.htaccess` incluya los headers CORS
- Si usas subdominio, actualiza el header `Access-Control-Allow-Origin`

## 📊 Estructura Final en el Servidor

```
/home/tuusuario/public_html/
├── api/
│   ├── config.php
│   ├── auth.php
│   ├── users.php
│   ├── admin.php
│   ├── comisiones.php
│   ├── rendimientos.php
│   └── utils.php
├── cron/
│   └── daily_yields.php
├── assets/
│   ├── index-[hash].js
│   ├── index-[hash].css
│   └── ...
├── .htaccess
├── index.html
└── favicon.ico
```

## 📞 Soporte

Si encuentras problemas:

1. **Revisa los logs:**
   - cPanel → Errores
   - cPanel → Registros de acceso

2. **Verifica permisos:**
   - Archivos PHP: 644
   - Carpetas: 755
   - config.php: 600

3. **Prueba la conexión a BD:**
   - Ve a `api/test.php`
   - Debería mostrar "Conexión exitosa"

---

## 🎉 ¡Listo!

Tu instalación de Liberty Finance debería estar funcionando en:
- **Frontend:** `https://tudominio.com`
- **API:** `https://tudominio.com/api/`
- **Admin:** Login con `admin@libertyfinance.com` / `admin123`

**¡No olvides cambiar la contraseña de administrador!**
