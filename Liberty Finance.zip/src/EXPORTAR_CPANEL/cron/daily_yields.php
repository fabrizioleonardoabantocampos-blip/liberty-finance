<?php
/**
 * Cron Job: Cálculo de Rendimientos Diarios
 * Liberty Finance
 * 
 * Ejecutar diariamente a las 00:05 (5 minutos después de medianoche)
 * Comando cron: 5 0 * * * /usr/bin/php /ruta/completa/cron/daily_yields.php
 */

// Cambiar al directorio del script
chdir(__DIR__);

require_once __DIR__ . '/../api/config.php';
require_once __DIR__ . '/../api/comisiones.php';

// Ejecutar solo desde línea de comandos
if (php_sapi_name() !== 'cli') {
    die("Este script solo puede ejecutarse desde línea de comandos\n");
}

echo "======================================\n";
echo "CRON: Cálculo de Rendimientos Diarios\n";
echo "======================================\n";
echo "Fecha: " . date('Y-m-d H:i:s') . "\n\n";

try {
    $db = getDB();
    $db->beginTransaction();
    
    $fecha_hoy = date('Y-m-d');
    
    // Verificar si ya se procesaron los rendimientos de hoy
    $stmt = $db->prepare("
        SELECT estado 
        FROM bloqueo_rendimientos 
        WHERE fecha = ?
    ");
    $stmt->execute([$fecha_hoy]);
    $bloqueo = $stmt->fetch();
    
    if ($bloqueo) {
        if ($bloqueo['estado'] === 'completado') {
            echo "⚠️ Los rendimientos de hoy ya fueron procesados.\n";
            echo "Estado: {$bloqueo['estado']}\n";
            exit(0);
        } elseif ($bloqueo['estado'] === 'en_proceso') {
            echo "⚠️ Ya hay un proceso en ejecución.\n";
            exit(1);
        }
    }
    
    // Crear bloqueo
    $stmt = $db->prepare("
        INSERT INTO bloqueo_rendimientos (fecha, estado)
        VALUES (?, 'en_proceso')
        ON DUPLICATE KEY UPDATE estado = 'en_proceso', iniciado_en = NOW()
    ");
    $stmt->execute([$fecha_hoy]);
    
    echo "✅ Bloqueo creado para $fecha_hoy\n\n";
    
    // Obtener porcentaje de rendimiento diario
    $porcentaje_rendimiento = getConfig('rendimiento_diario_porcentaje', 0.0067); // 0.67% por defecto
    $max_retorno = getConfig('max_retorno_porcentaje', 2.0); // 200%
    
    echo "📊 Configuración:\n";
    echo "   - Rendimiento diario: " . ($porcentaje_rendimiento * 100) . "%\n";
    echo "   - Máximo retorno: " . ($max_retorno * 100) . "%\n\n";
    
    // Obtener todos los packs activos
    $stmt = $db->query("
        SELECT 
            p.id,
            p.usuario_id,
            p.monto_inicial,
            p.monto_actual,
            p.total_acumulado
        FROM packs p
        WHERE p.activo = 1
    ");
    $packs_activos = $stmt->fetchAll();
    
    $total_packs = count($packs_activos);
    echo "📦 Packs activos encontrados: $total_packs\n\n";
    
    if ($total_packs === 0) {
        echo "ℹ️ No hay packs activos para procesar.\n";
        
        $stmt = $db->prepare("
            UPDATE bloqueo_rendimientos 
            SET estado = 'completado', completado_en = NOW()
            WHERE fecha = ?
        ");
        $stmt->execute([$fecha_hoy]);
        
        $db->commit();
        exit(0);
    }
    
    $usuarios_procesados = [];
    $rendimientos_generados = 0;
    $monto_total_generado = 0;
    $packs_inactivados = 0;
    $errores = [];
    
    foreach ($packs_activos as $pack) {
        try {
            // Verificar si ya existe rendimiento para hoy
            $stmt = $db->prepare("
                SELECT COUNT(*) 
                FROM rendimientos_diarios 
                WHERE pack_id = ? AND fecha = ?
            ");
            $stmt->execute([$pack['id'], $fecha_hoy]);
            
            if ($stmt->fetchColumn() > 0) {
                echo "⚠️ Pack {$pack['id']} ya tiene rendimiento para hoy (duplicado detectado)\n";
                continue;
            }
            
            // Calcular rendimiento
            $rendimiento = $pack['monto_actual'] * $porcentaje_rendimiento;
            
            // Verificar si excede el 200%
            $nuevo_total = $pack['total_acumulado'] + $rendimiento;
            $max_permitido = $pack['monto_inicial'] * $max_retorno;
            
            if ($nuevo_total > $max_permitido) {
                // Ajustar para no exceder el 200%
                $rendimiento = $max_permitido - $pack['total_acumulado'];
                
                if ($rendimiento <= 0) {
                    // Pack ya está al 200%, inactivar
                    $stmt = $db->prepare("
                        UPDATE packs 
                        SET activo = 0, fecha_inactivacion = NOW(), porcentaje_completado = 200
                        WHERE id = ?
                    ");
                    $stmt->execute([$pack['id']]);
                    $packs_inactivados++;
                    
                    echo "🔒 Pack {$pack['id']} alcanzó 200% y fue inactivado\n";
                    continue;
                }
            }
            
            // Insertar rendimiento
            $stmt = $db->prepare("
                INSERT INTO rendimientos_diarios (
                    usuario_id, pack_id, monto, porcentaje, fecha
                ) VALUES (?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $pack['usuario_id'],
                $pack['id'],
                $rendimiento,
                $porcentaje_rendimiento,
                $fecha_hoy
            ]);
            
            // Actualizar pack
            $stmt = $db->prepare("
                UPDATE packs 
                SET 
                    monto_actual = monto_actual + ?,
                    rendimiento_acumulado = rendimiento_acumulado + ?,
                    total_acumulado = total_acumulado + ?,
                    porcentaje_completado = (total_acumulado + ?) / monto_inicial * 100
                WHERE id = ?
            ");
            $stmt->execute([
                $rendimiento,
                $rendimiento,
                $rendimiento,
                $rendimiento,
                $pack['id']
            ]);
            
            // Verificar si alcanzó el 200%
            $nuevo_total = $pack['total_acumulado'] + $rendimiento;
            if ($nuevo_total >= $max_permitido) {
                $stmt = $db->prepare("
                    UPDATE packs 
                    SET activo = 0, fecha_inactivacion = NOW(), porcentaje_completado = 200
                    WHERE id = ?
                ");
                $stmt->execute([$pack['id']]);
                $packs_inactivados++;
                
                echo "🔒 Pack {$pack['id']} alcanzó 200% y fue inactivado\n";
            }
            
            $rendimientos_generados++;
            $monto_total_generado += $rendimiento;
            
            if (!in_array($pack['usuario_id'], $usuarios_procesados)) {
                $usuarios_procesados[] = $pack['usuario_id'];
            }
            
            echo "✅ Pack {$pack['id']}: +$" . number_format($rendimiento, 2) . " (Usuario: {$pack['usuario_id']})\n";
            
        } catch (Exception $e) {
            $error_msg = "Error en pack {$pack['id']}: " . $e->getMessage();
            $errores[] = $error_msg;
            echo "❌ $error_msg\n";
        }
    }
    
    // Actualizar bloqueo con resultados
    $stmt = $db->prepare("
        UPDATE bloqueo_rendimientos 
        SET 
            estado = 'completado',
            completado_en = NOW(),
            usuarios_procesados = ?,
            rendimientos_generados = ?,
            errores = ?
        WHERE fecha = ?
    ");
    $stmt->execute([
        count($usuarios_procesados),
        $rendimientos_generados,
        empty($errores) ? null : implode("\n", $errores),
        $fecha_hoy
    ]);
    
    $db->commit();
    
    echo "\n======================================\n";
    echo "RESUMEN DE EJECUCIÓN\n";
    echo "======================================\n";
    echo "Usuarios procesados: " . count($usuarios_procesados) . "\n";
    echo "Rendimientos generados: $rendimientos_generados\n";
    echo "Monto total generado: $" . number_format($monto_total_generado, 2) . "\n";
    echo "Packs inactivados (200%): $packs_inactivados\n";
    echo "Errores: " . count($errores) . "\n";
    echo "Estado: ✅ COMPLETADO\n";
    echo "======================================\n";
    
    // Registrar en logs
    registrarLog(
        'sistema',
        'cron',
        'rendimientos_diarios',
        "Procesados: " . count($usuarios_procesados) . " usuarios, " .
        "Generados: $rendimientos_generados rendimientos, " .
        "Total: $" . number_format($monto_total_generado, 2)
    );
    
    exit(0);
    
} catch (Exception $e) {
    if ($db && $db->inTransaction()) {
        $db->rollBack();
    }
    
    echo "\n❌ ERROR CRÍTICO:\n";
    echo $e->getMessage() . "\n";
    echo $e->getTraceAsString() . "\n";
    
    // Actualizar bloqueo con error
    try {
        $stmt = $db->prepare("
            UPDATE bloqueo_rendimientos 
            SET 
                estado = 'error',
                errores = ?
            WHERE fecha = ?
        ");
        $stmt->execute([
            $e->getMessage(),
            date('Y-m-d')
        ]);
    } catch (Exception $e2) {
        echo "Error al actualizar bloqueo: " . $e2->getMessage() . "\n";
    }
    
    error_log("Error en cron de rendimientos diarios: " . $e->getMessage());
    exit(1);
}

?>
