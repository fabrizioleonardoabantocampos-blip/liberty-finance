<?php
/**
 * Endpoints de Autenticación
 * Liberty Finance
 */

require_once __DIR__ . '/config.php';

$method = $_SERVER['REQUEST_METHOD'];
$requestUri = $_SERVER['REQUEST_URI'];

// Eliminar query string
$uri = parse_url($requestUri, PHP_URL_PATH);
$uri = str_replace('/api/auth.php', '', $uri);
$uri = trim($uri, '/');

// Routing básico
switch ($method) {
    case 'POST':
        if ($uri === 'login' || $uri === '') {
            handleLogin();
        } elseif ($uri === 'register') {
            handleRegister();
        } elseif ($uri === 'validate-token') {
            handleValidateToken();
        } else {
            errorResponse('Endpoint no encontrado', 404);
        }
        break;
    
    default:
        errorResponse('Método no permitido', 405);
}

/**
 * Login de usuario
 */
function handleLogin() {
    $data = getRequestBody();
    
    $email = $data['email'] ?? '';
    $password = $data['password'] ?? '';
    
    if (empty($email) || empty($password)) {
        errorResponse('Email y contraseña son requeridos');
    }
    
    try {
        $db = getDB();
        
        // Buscar usuario por email
        $stmt = $db->prepare("
            SELECT 
                id,
                id_unico,
                nombre,
                apellido,
                email,
                password_hash,
                rol,
                ciudad,
                pais,
                wallet,
                rango,
                sponsor_id
            FROM usuarios 
            WHERE email = ?
        ");
        
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        
        if (!$user) {
            errorResponse('Credenciales incorrectas', 401);
        }
        
        // Verificar contraseña
        if (!verifyPassword($password, $user['password_hash'])) {
            errorResponse('Credenciales incorrectas', 401);
        }
        
        // Generar token JWT
        $token = generateJWT([
            'id' => $user['id'],
            'id_unico' => $user['id_unico'],
            'email' => $user['email'],
            'rol' => $user['rol']
        ]);
        
        // Registrar log
        registrarLog('auth', $user['id_unico'], 'login', 'Login exitoso');
        
        // Responder con datos del usuario y token
        unset($user['password_hash']); // No enviar el hash
        
        jsonResponse([
            'success' => true,
            'message' => 'Login exitoso',
            'user' => $user,
            'token' => $token
        ]);
        
    } catch (Exception $e) {
        error_log("Error en login: " . $e->getMessage());
        errorResponse('Error en el servidor', 500);
    }
}

/**
 * Registro de nuevo usuario
 */
function handleRegister() {
    $data = getRequestBody();
    
    $nombre = trim($data['nombre'] ?? '');
    $apellido = trim($data['apellido'] ?? '');
    $email = trim($data['email'] ?? '');
    $password = $data['password'] ?? '';
    $ciudad = trim($data['ciudad'] ?? '');
    $pais = trim($data['pais'] ?? '');
    $wallet = trim($data['wallet'] ?? '');
    $sponsor_id = trim($data['sponsor_id'] ?? '');
    $posicion_matriz = $data['posicion_matriz'] ?? null;
    
    // Validaciones
    if (empty($nombre) || empty($apellido) || empty($email) || empty($password)) {
        errorResponse('Nombre, apellido, email y contraseña son requeridos');
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        errorResponse('Email inválido');
    }
    
    if (strlen($password) < 6) {
        errorResponse('La contraseña debe tener al menos 6 caracteres');
    }
    
    try {
        $db = getDB();
        $db->beginTransaction();
        
        // Verificar si el email ya existe
        $stmt = $db->prepare("SELECT COUNT(*) FROM usuarios WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetchColumn() > 0) {
            $db->rollBack();
            errorResponse('El email ya está registrado');
        }
        
        // Generar ID único
        $id_unico = generateUniqueId('USR');
        
        // Verificar y obtener datos del sponsor
        $padre_binario_id = null;
        $sponsor_data = null;
        
        if (!empty($sponsor_id)) {
            $stmt = $db->prepare("SELECT id_unico, hijo_izquierdo_id, hijo_derecho_id FROM usuarios WHERE id_unico = ?");
            $stmt->execute([$sponsor_id]);
            $sponsor_data = $stmt->fetch();
            
            if (!$sponsor_data) {
                $db->rollBack();
                errorResponse('El código de referido no existe');
            }
            
            // Determinar posición en matriz binaria si no se especificó
            if (empty($posicion_matriz)) {
                if (empty($sponsor_data['hijo_izquierdo_id'])) {
                    $posicion_matriz = 'izquierda';
                    $padre_binario_id = $sponsor_id;
                } elseif (empty($sponsor_data['hijo_derecho_id'])) {
                    $posicion_matriz = 'derecha';
                    $padre_binario_id = $sponsor_id;
                } else {
                    // Sponsor lleno, buscar primer lugar disponible en la red
                    $padre_binario_id = encontrarPrimerLugarDisponible($db, $sponsor_id, $posicion_matriz);
                }
            } else {
                $padre_binario_id = $sponsor_id;
            }
        }
        
        // Hash de contraseña
        $password_hash = hashPassword($password);
        
        // Insertar usuario
        $stmt = $db->prepare("
            INSERT INTO usuarios (
                id_unico,
                nombre,
                apellido,
                email,
                password_hash,
                ciudad,
                pais,
                wallet,
                sponsor_id,
                padre_binario_id,
                posicion_matriz,
                rol,
                rango
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'usuario', 'Nuevo')
        ");
        
        $stmt->execute([
            $id_unico,
            $nombre,
            $apellido,
            $email,
            $password_hash,
            $ciudad,
            $pais,
            $wallet,
            $sponsor_id ?: null,
            $padre_binario_id,
            $posicion_matriz
        ]);
        
        // Actualizar hijo del padre binario
        if ($padre_binario_id && $posicion_matriz) {
            $campo = $posicion_matriz === 'izquierda' ? 'hijo_izquierdo_id' : 'hijo_derecho_id';
            $stmt = $db->prepare("UPDATE usuarios SET $campo = ? WHERE id_unico = ?");
            $stmt->execute([$id_unico, $padre_binario_id]);
        }
        
        $db->commit();
        
        // Registrar log
        registrarLog('auth', $id_unico, 'registro', 'Nuevo usuario registrado');
        
        // Generar token
        $token = generateJWT([
            'id' => $db->lastInsertId(),
            'id_unico' => $id_unico,
            'email' => $email,
            'rol' => 'usuario'
        ]);
        
        jsonResponse([
            'success' => true,
            'message' => 'Usuario registrado exitosamente',
            'user' => [
                'id_unico' => $id_unico,
                'nombre' => $nombre,
                'apellido' => $apellido,
                'email' => $email,
                'rol' => 'usuario'
            ],
            'token' => $token
        ]);
        
    } catch (Exception $e) {
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        error_log("Error en registro: " . $e->getMessage());
        errorResponse('Error en el servidor: ' . $e->getMessage(), 500);
    }
}

/**
 * Validar token JWT
 */
function handleValidateToken() {
    try {
        $decoded = validateToken();
        
        // Obtener datos actualizados del usuario
        $db = getDB();
        $stmt = $db->prepare("
            SELECT 
                id,
                id_unico,
                nombre,
                apellido,
                email,
                rol,
                ciudad,
                pais,
                wallet,
                rango,
                sponsor_id
            FROM usuarios 
            WHERE id_unico = ?
        ");
        
        $stmt->execute([$decoded['id_unico']]);
        $user = $stmt->fetch();
        
        if (!$user) {
            errorResponse('Usuario no encontrado', 404);
        }
        
        jsonResponse([
            'success' => true,
            'valid' => true,
            'user' => $user
        ]);
        
    } catch (Exception $e) {
        errorResponse('Token inválido', 401);
    }
}

/**
 * Encontrar primer lugar disponible en matriz binaria
 */
function encontrarPrimerLugarDisponible($db, $sponsor_id, &$posicion_matriz) {
    // BFS para encontrar el primer nodo con espacio
    $queue = [$sponsor_id];
    
    while (!empty($queue)) {
        $current = array_shift($queue);
        
        $stmt = $db->prepare("SELECT hijo_izquierdo_id, hijo_derecho_id FROM usuarios WHERE id_unico = ?");
        $stmt->execute([$current]);
        $node = $stmt->fetch();
        
        if (empty($node['hijo_izquierdo_id'])) {
            $posicion_matriz = 'izquierda';
            return $current;
        }
        
        if (empty($node['hijo_derecho_id'])) {
            $posicion_matriz = 'derecha';
            return $current;
        }
        
        // Agregar hijos a la cola
        if ($node['hijo_izquierdo_id']) {
            $queue[] = $node['hijo_izquierdo_id'];
        }
        if ($node['hijo_derecho_id']) {
            $queue[] = $node['hijo_derecho_id'];
        }
    }
    
    // No debería llegar aquí, pero por seguridad
    $posicion_matriz = 'izquierda';
    return $sponsor_id;
}

?>
