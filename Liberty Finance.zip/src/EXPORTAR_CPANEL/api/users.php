<?php
/**
 * Endpoints de Usuarios
 * Liberty Finance
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/comisiones.php';

$method = $_SERVER['REQUEST_METHOD'];
$requestUri = $_SERVER['REQUEST_URI'];

// Parse URI
$uri = parse_url($requestUri, PHP_URL_PATH);
$uri = str_replace('/api/users.php', '', $uri);
$uri = trim($uri, '/');
$segments = explode('/', $uri);

// Routing
switch ($method) {
    case 'GET':
        if (count($segments) >= 2 && $segments[1] === 'dashboard-quick') {
            handleDashboardQuick($segments[0]);
        } elseif (count($segments) >= 2 && $segments[1] === 'dashboard-complete') {
            handleDashboardComplete($segments[0]);
        } elseif (count($segments) >= 2 && $segments[1] === 'matriz') {
            handleGetMatriz($segments[0]);
        } elseif (count($segments) >= 2 && $segments[1] === 'directos') {
            handleGetDirectos($segments[0]);
        } elseif (count($segments) >= 1 && !empty($segments[0])) {
            handleGetUser($segments[0]);
        } else {
            errorResponse('Endpoint no encontrado', 404);
        }
        break;
        
    case 'POST':
        if (count($segments) >= 2 && $segments[1] === 'buy-pack') {
            handleBuyPack($segments[0]);
        } elseif (count($segments) >= 2 && $segments[1] === 'withdraw') {
            handleWithdraw($segments[0]);
        } else {
            errorResponse('Endpoint no encontrado', 404);
        }
        break;
        
    case 'PUT':
        if (count($segments) >= 1) {
            handleUpdateUser($segments[0]);
        } else {
            errorResponse('Endpoint no encontrado', 404);
        }
        break;
        
    default:
        errorResponse('Método no permitido', 405);
}

/**
 * Obtener datos rápidos del dashboard (solo lo esencial)
 */
function handleDashboardQuick($userId) {
    try {
        $db = getDB();
        
        // Datos básicos del usuario
        $stmt = $db->prepare("
            SELECT 
                id, id_unico, nombre, apellido, email, ciudad, pais, wallet, rol, rango, sponsor_id
            FROM usuarios 
            WHERE id = ? OR id_unico = ?
        ");
        $stmt->execute([$userId, $userId]);
        $user = $stmt->fetch();
        
        if (!$user) {
            errorResponse('Usuario no encontrado', 404);
        }
        
        // Packs activos (resumen)
        $stmt = $db->prepare("
            SELECT 
                COUNT(*) as total_packs,
                SUM(monto_inicial) as inversion_total,
                SUM(total_acumulado) as ganancia_total
            FROM packs 
            WHERE usuario_id = ? AND activo = 1
        ");
        $stmt->execute([$user['id_unico']]);
        $packsStats = $stmt->fetch();
        
        // Total de comisiones
        $stmt = $db->prepare("
            SELECT 
                SUM(CASE WHEN tipo = 'directa' THEN monto ELSE 0 END) as comisiones_directas,
                SUM(CASE WHEN tipo = 'binaria' THEN monto ELSE 0 END) as comisiones_binarias,
                SUM(CASE WHEN tipo = 'rango' THEN monto ELSE 0 END) as comisiones_rango,
                SUM(monto) as comisiones_totales
            FROM comisiones 
            WHERE usuario_id = ?
        ");
        $stmt->execute([$user['id_unico']]);
        $comisiones = $stmt->fetch();
        
        // Saldo disponible para retiro
        $saldo = ($packsStats['ganancia_total'] ?? 0) + ($comisiones['comisiones_totales'] ?? 0);
        
        jsonResponse([
            'success' => true,
            'user' => $user,
            'stats' => [
                'total_packs' => $packsStats['total_packs'] ?? 0,
                'inversion_total' => floatval($packsStats['inversion_total'] ?? 0),
                'ganancia_total' => floatval($packsStats['ganancia_total'] ?? 0),
                'comisiones_directas' => floatval($comisiones['comisiones_directas'] ?? 0),
                'comisiones_binarias' => floatval($comisiones['comisiones_binarias'] ?? 0),
                'comisiones_rango' => floatval($comisiones['comisiones_rango'] ?? 0),
                'comisiones_totales' => floatval($comisiones['comisiones_totales'] ?? 0),
                'saldo' => floatval($saldo)
            ]
        ]);
        
    } catch (Exception $e) {
        error_log("Error en dashboard-quick: " . $e->getMessage());
        errorResponse('Error en el servidor', 500);
    }
}

/**
 * Obtener datos completos del dashboard
 */
function handleDashboardComplete($userId) {
    try {
        $db = getDB();
        
        // Obtener datos quick primero
        $stmt = $db->prepare("
            SELECT 
                id, id_unico, nombre, apellido, email, ciudad, pais, wallet, rol, rango, sponsor_id
            FROM usuarios 
            WHERE id = ? OR id_unico = ?
        ");
        $stmt->execute([$userId, $userId]);
        $user = $stmt->fetch();
        
        if (!$user) {
            errorResponse('Usuario no encontrado', 404);
        }
        
        // Packs del usuario
        $stmt = $db->prepare("
            SELECT 
                id,
                monto_inicial,
                monto_actual,
                rendimiento_acumulado,
                comisiones_acumuladas,
                total_acumulado,
                porcentaje_completado,
                activo,
                fecha_compra,
                fecha_inactivacion
            FROM packs 
            WHERE usuario_id = ?
            ORDER BY fecha_compra DESC
        ");
        $stmt->execute([$user['id_unico']]);
        $packs = $stmt->fetchAll();
        
        // Comisiones recientes (últimas 50)
        $stmt = $db->prepare("
            SELECT 
                id, referido_id, tipo, monto, descripcion, fecha
            FROM comisiones 
            WHERE usuario_id = ?
            ORDER BY fecha DESC
            LIMIT 50
        ");
        $stmt->execute([$user['id_unico']]);
        $comisiones = $stmt->fetchAll();
        
        // Rendimientos recientes (últimos 30 días)
        $stmt = $db->prepare("
            SELECT 
                r.id, r.pack_id, r.monto, r.porcentaje, r.fecha,
                p.monto_inicial
            FROM rendimientos_diarios r
            JOIN packs p ON r.pack_id = p.id
            WHERE r.usuario_id = ?
            ORDER BY r.fecha DESC
            LIMIT 30
        ");
        $stmt->execute([$user['id_unico']]);
        $rendimientos = $stmt->fetchAll();
        
        // Directos (referidos directos)
        $stmt = $db->prepare("
            SELECT 
                id_unico, nombre, apellido, email, rango, created_at
            FROM usuarios 
            WHERE sponsor_id = ?
            ORDER BY created_at DESC
        ");
        $stmt->execute([$user['id_unico']]);
        $directos = $stmt->fetchAll();
        
        // Stats
        $packsStats = [
            'total_packs' => 0,
            'inversion_total' => 0,
            'ganancia_total' => 0
        ];
        
        foreach ($packs as $pack) {
            if ($pack['activo']) {
                $packsStats['total_packs']++;
                $packsStats['inversion_total'] += $pack['monto_inicial'];
                $packsStats['ganancia_total'] += $pack['total_acumulado'];
            }
        }
        
        $comisionesTotal = [
            'comisiones_directas' => 0,
            'comisiones_binarias' => 0,
            'comisiones_rango' => 0,
            'comisiones_totales' => 0
        ];
        
        foreach ($comisiones as $com) {
            $comisionesTotal['comisiones_totales'] += $com['monto'];
            if ($com['tipo'] === 'directa') {
                $comisionesTotal['comisiones_directas'] += $com['monto'];
            } elseif ($com['tipo'] === 'binaria') {
                $comisionesTotal['comisiones_binarias'] += $com['monto'];
            } elseif ($com['tipo'] === 'rango') {
                $comisionesTotal['comisiones_rango'] += $com['monto'];
            }
        }
        
        $saldo = $packsStats['ganancia_total'] + $comisionesTotal['comisiones_totales'];
        
        jsonResponse([
            'success' => true,
            'user' => $user,
            'packs' => $packs,
            'comisiones' => $comisiones,
            'rendimientos' => $rendimientos,
            'directos' => $directos,
            'stats' => array_merge($packsStats, $comisionesTotal, ['saldo' => $saldo])
        ]);
        
    } catch (Exception $e) {
        error_log("Error en dashboard-complete: " . $e->getMessage());
        errorResponse('Error en el servidor', 500);
    }
}

/**
 * Comprar pack
 */
function handleBuyPack($userId) {
    $data = getRequestBody();
    $monto = floatval($data['monto'] ?? 0);
    
    if ($monto <= 0) {
        errorResponse('Monto inválido');
    }
    
    try {
        $db = getDB();
        $db->beginTransaction();
        
        // Obtener usuario
        $stmt = $db->prepare("SELECT id_unico, sponsor_id FROM usuarios WHERE id = ? OR id_unico = ?");
        $stmt->execute([$userId, $userId]);
        $user = $stmt->fetch();
        
        if (!$user) {
            $db->rollBack();
            errorResponse('Usuario no encontrado', 404);
        }
        
        // Crear pack
        $stmt = $db->prepare("
            INSERT INTO packs (
                usuario_id, monto_inicial, monto_actual, activo
            ) VALUES (?, ?, ?, 1)
        ");
        $stmt->execute([$user['id_unico'], $monto, $monto]);
        $packId = $db->lastInsertId();
        
        // Actualizar puntos personales
        $stmt = $db->prepare("
            UPDATE usuarios 
            SET puntos_personales = puntos_personales + ?
            WHERE id_unico = ?
        ");
        $stmt->execute([$monto, $user['id_unico']]);
        
        // Calcular comisiones
        if (!empty($user['sponsor_id'])) {
            calcularComisionDirecta($db, $user['sponsor_id'], $user['id_unico'], $packId, $monto);
            calcularComisionesBinarias($db, $user['id_unico'], $monto);
        }
        
        $db->commit();
        
        registrarLog('pack', $user['id_unico'], 'compra_pack', "Pack de $$monto comprado");
        
        successResponse(['pack_id' => $packId], 'Pack comprado exitosamente');
        
    } catch (Exception $e) {
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        error_log("Error al comprar pack: " . $e->getMessage());
        errorResponse('Error al procesar la compra', 500);
    }
}

/**
 * Solicitar retiro
 */
function handleWithdraw($userId) {
    $data = getRequestBody();
    $monto = floatval($data['monto'] ?? 0);
    $wallet = trim($data['wallet'] ?? '');
    
    if ($monto <= 0) {
        errorResponse('Monto inválido');
    }
    
    if (empty($wallet)) {
        errorResponse('Wallet es requerida');
    }
    
    try {
        $db = getDB();
        
        // Obtener usuario y verificar saldo
        $stmt = $db->prepare("SELECT id_unico FROM usuarios WHERE id = ? OR id_unico = ?");
        $stmt->execute([$userId, $userId]);
        $user = $stmt->fetch();
        
        if (!$user) {
            errorResponse('Usuario no encontrado', 404);
        }
        
        // Calcular saldo disponible
        // TODO: Implementar cálculo de saldo real considerando retiros previos
        
        // Crear solicitud de retiro
        $stmt = $db->prepare("
            INSERT INTO retiros (
                usuario_id, monto, wallet, estado
            ) VALUES (?, ?, ?, 'pendiente')
        ");
        $stmt->execute([$user['id_unico'], $monto, $wallet]);
        
        registrarLog('retiro', $user['id_unico'], 'solicitud_retiro', "Retiro de $$monto solicitado");
        
        successResponse([], 'Solicitud de retiro enviada');
        
    } catch (Exception $e) {
        error_log("Error al solicitar retiro: " . $e->getMessage());
        errorResponse('Error al procesar el retiro', 500);
    }
}

/**
 * Obtener matriz binaria
 */
function handleGetMatriz($userId) {
    try {
        $db = getDB();
        
        // Obtener usuario
        $stmt = $db->prepare("
            SELECT id_unico, hijo_izquierdo_id, hijo_derecho_id, 
                   puntos_izquierda, puntos_derecha
            FROM usuarios 
            WHERE id = ? OR id_unico = ?
        ");
        $stmt->execute([$userId, $userId]);
        $user = $stmt->fetch();
        
        if (!$user) {
            errorResponse('Usuario no encontrado', 404);
        }
        
        // Construir árbol (3 niveles)
        $tree = buildMatrizTree($db, $user['id_unico'], 3);
        
        jsonResponse([
            'success' => true,
            'matriz' => $tree,
            'puntos' => [
                'izquierda' => floatval($user['puntos_izquierda']),
                'derecha' => floatval($user['puntos_derecha'])
            ]
        ]);
        
    } catch (Exception $e) {
        error_log("Error al obtener matriz: " . $e->getMessage());
        errorResponse('Error en el servidor', 500);
    }
}

function buildMatrizTree($db, $userId, $depth) {
    if ($depth === 0) {
        return null;
    }
    
    $stmt = $db->prepare("
        SELECT id_unico, nombre, apellido, hijo_izquierdo_id, hijo_derecho_id
        FROM usuarios 
        WHERE id_unico = ?
    ");
    $stmt->execute([$userId]);
    $node = $stmt->fetch();
    
    if (!$node) {
        return null;
    }
    
    return [
        'id_unico' => $node['id_unico'],
        'nombre' => $node['nombre'] . ' ' . $node['apellido'],
        'izquierda' => $node['hijo_izquierdo_id'] ? buildMatrizTree($db, $node['hijo_izquierdo_id'], $depth - 1) : null,
        'derecha' => $node['hijo_derecho_id'] ? buildMatrizTree($db, $node['hijo_derecho_id'], $depth - 1) : null
    ];
}

/**
 * Obtener directos
 */
function handleGetDirectos($userId) {
    try {
        $db = getDB();
        
        // Obtener usuario
        $stmt = $db->prepare("SELECT id_unico FROM usuarios WHERE id = ? OR id_unico = ?");
        $stmt->execute([$userId, $userId]);
        $user = $stmt->fetch();
        
        if (!$user) {
            errorResponse('Usuario no encontrado', 404);
        }
        
        // Obtener directos
        $stmt = $db->prepare("
            SELECT 
                id_unico, nombre, apellido, email, rango, 
                puntos_personales, created_at
            FROM usuarios 
            WHERE sponsor_id = ?
            ORDER BY created_at DESC
        ");
        $stmt->execute([$user['id_unico']]);
        $directos = $stmt->fetchAll();
        
        jsonResponse([
            'success' => true,
            'directos' => $directos
        ]);
        
    } catch (Exception $e) {
        error_log("Error al obtener directos: " . $e->getMessage());
        errorResponse('Error en el servidor', 500);
    }
}

/**
 * Obtener usuario
 */
function handleGetUser($userId) {
    try {
        $db = getDB();
        
        $stmt = $db->prepare("
            SELECT 
                id, id_unico, nombre, apellido, email, ciudad, pais, 
                wallet, rol, rango, sponsor_id, puntos_personales,
                puntos_izquierda, puntos_derecha, created_at
            FROM usuarios 
            WHERE id = ? OR id_unico = ?
        ");
        $stmt->execute([$userId, $userId]);
        $user = $stmt->fetch();
        
        if (!$user) {
            errorResponse('Usuario no encontrado', 404);
        }
        
        jsonResponse([
            'success' => true,
            'user' => $user
        ]);
        
    } catch (Exception $e) {
        error_log("Error al obtener usuario: " . $e->getMessage());
        errorResponse('Error en el servidor', 500);
    }
}

/**
 * Actualizar usuario
 */
function handleUpdateUser($userId) {
    $data = getRequestBody();
    
    try {
        $db = getDB();
        
        // Campos permitidos para actualizar
        $allowedFields = ['nombre', 'apellido', 'ciudad', 'pais', 'wallet'];
        $updates = [];
        $values = [];
        
        foreach ($allowedFields as $field) {
            if (isset($data[$field])) {
                $updates[] = "$field = ?";
                $values[] = $data[$field];
            }
        }
        
        if (empty($updates)) {
            errorResponse('No hay campos para actualizar');
        }
        
        $values[] = $userId;
        $values[] = $userId;
        
        $sql = "UPDATE usuarios SET " . implode(', ', $updates) . " WHERE id = ? OR id_unico = ?";
        $stmt = $db->prepare($sql);
        $stmt->execute($values);
        
        registrarLog('usuario', $userId, 'actualizacion', 'Datos actualizados');
        
        successResponse([], 'Usuario actualizado exitosamente');
        
    } catch (Exception $e) {
        error_log("Error al actualizar usuario: " . $e->getMessage());
        errorResponse('Error en el servidor', 500);
    }
}

?>
