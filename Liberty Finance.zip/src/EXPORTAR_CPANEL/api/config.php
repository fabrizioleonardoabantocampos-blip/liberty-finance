<?php
/**
 * Configuración de Base de Datos y Constantes Globales
 * Liberty Finance
 */

// =============================================
// CONFIGURACIÓN DE BASE DE DATOS
// =============================================
// ⚠️ IMPORTANTE: Cambia estos valores con tus credenciales de cPanel
define('DB_HOST', 'localhost');
define('DB_NAME', 'tu_usuario_liberty_finance'); // Incluye el prefijo de usuario
define('DB_USER', 'tu_usuario_liberty_user');
define('DB_PASS', 'tu_contraseña_aqui');
define('DB_CHARSET', 'utf8mb4');

// =============================================
// CONFIGURACIÓN DE APLICACIÓN
// =============================================
define('APP_NAME', 'Liberty Finance');
define('APP_URL', 'https://tudominio.com'); // Cambia por tu dominio

// =============================================
// CONFIGURACIÓN DE SEGURIDAD
// =============================================
define('JWT_SECRET', 'CAMBIA_ESTE_SECRET_POR_UNO_ALEATORIO_Y_SEGURO_123456789'); // ⚠️ CAMBIA ESTO
define('JWT_EXPIRATION', 86400 * 7); // 7 días en segundos

// =============================================
// CONFIGURACIÓN DE ZONA HORARIA
// =============================================
date_default_timezone_set('America/Mexico_City'); // Cambia según tu zona horaria

// =============================================
// CONFIGURACIÓN DE ERRORES
// =============================================
// En producción, desactiva los errores visibles
error_reporting(E_ALL);
ini_set('display_errors', '0'); // Cambiar a '0' en producción
ini_set('log_errors', '1');
ini_set('error_log', __DIR__ . '/../logs/php_errors.log');

// =============================================
// CONEXIÓN A BASE DE DATOS
// =============================================
class Database {
    private static $instance = null;
    private $connection;

    private function __construct() {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES " . DB_CHARSET
            ];

            $this->connection = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            error_log("Error de conexión a la base de datos: " . $e->getMessage());
            http_response_code(500);
            die(json_encode([
                'success' => false,
                'error' => 'Error de conexión a la base de datos'
            ]));
        }
    }

    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function getConnection() {
        return $this->connection;
    }

    // Prevenir clonación
    private function __clone() {}

    // Prevenir unserialize
    public function __wakeup() {
        throw new Exception("Cannot unserialize singleton");
    }
}

// =============================================
// HEADERS CORS
// =============================================
function setCorsHeaders() {
    // Permitir desde cualquier origen (ajustar en producción)
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization');
    header('Access-Control-Max-Age: 3600');
    header('Content-Type: application/json; charset=UTF-8');

    // Manejar preflight request
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(200);
        exit;
    }
}

// =============================================
// FUNCIONES AUXILIARES
// =============================================

/**
 * Obtener conexión PDO
 */
function getDB() {
    return Database::getInstance()->getConnection();
}

/**
 * Responder con JSON
 */
function jsonResponse($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

/**
 * Responder con error
 */
function errorResponse($message, $code = 400) {
    jsonResponse([
        'success' => false,
        'error' => $message
    ], $code);
}

/**
 * Responder con éxito
 */
function successResponse($data = [], $message = 'Operación exitosa') {
    jsonResponse([
        'success' => true,
        'message' => $message,
        'data' => $data
    ]);
}

/**
 * Obtener datos del cuerpo de la petición
 */
function getRequestBody() {
    $json = file_get_contents('php://input');
    return json_decode($json, true) ?? [];
}

/**
 * Validar JWT Token
 */
function validateToken() {
    $headers = getallheaders();
    $authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? '';

    if (empty($authHeader)) {
        errorResponse('Token no proporcionado', 401);
    }

    $token = str_replace('Bearer ', '', $authHeader);
    
    try {
        $decoded = decodeJWT($token);
        return $decoded;
    } catch (Exception $e) {
        errorResponse('Token inválido', 401);
    }
}

/**
 * Generar JWT Token (simple)
 */
function generateJWT($payload) {
    $header = json_encode(['typ' => 'JWT', 'alg' => 'HS256']);
    $payload['exp'] = time() + JWT_EXPIRATION;
    $payload = json_encode($payload);

    $base64UrlHeader = base64UrlEncode($header);
    $base64UrlPayload = base64UrlEncode($payload);

    $signature = hash_hmac('sha256', $base64UrlHeader . "." . $base64UrlPayload, JWT_SECRET, true);
    $base64UrlSignature = base64UrlEncode($signature);

    return $base64UrlHeader . "." . $base64UrlPayload . "." . $base64UrlSignature;
}

/**
 * Decodificar JWT Token
 */
function decodeJWT($jwt) {
    $tokenParts = explode('.', $jwt);
    if (count($tokenParts) !== 3) {
        throw new Exception('Token inválido');
    }

    $header = base64UrlDecode($tokenParts[0]);
    $payload = base64UrlDecode($tokenParts[1]);
    $signatureProvided = $tokenParts[2];

    $base64UrlHeader = base64UrlEncode($header);
    $base64UrlPayload = base64UrlEncode($payload);
    $signature = hash_hmac('sha256', $base64UrlHeader . "." . $base64UrlPayload, JWT_SECRET, true);
    $base64UrlSignature = base64UrlEncode($signature);

    if ($base64UrlSignature !== $signatureProvided) {
        throw new Exception('Firma inválida');
    }

    $payload = json_decode($payload, true);

    if (isset($payload['exp']) && $payload['exp'] < time()) {
        throw new Exception('Token expirado');
    }

    return $payload;
}

function base64UrlEncode($text) {
    return str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($text));
}

function base64UrlDecode($text) {
    return base64_decode(str_replace(['-', '_'], ['+', '/'], $text));
}

/**
 * Hash de contraseña
 */
function hashPassword($password) {
    return password_hash($password, PASSWORD_BCRYPT);
}

/**
 * Verificar contraseña
 */
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

/**
 * Generar ID único
 */
function generateUniqueId($prefix = 'USR') {
    $db = getDB();
    
    do {
        $id = $prefix . str_pad(mt_rand(1, 999999), 6, '0', STR_PAD_LEFT);
        $stmt = $db->prepare("SELECT COUNT(*) FROM usuarios WHERE id_unico = ?");
        $stmt->execute([$id]);
        $exists = $stmt->fetchColumn() > 0;
    } while ($exists);
    
    return $id;
}

/**
 * Registrar log
 */
function registrarLog($tipo, $usuario_id, $accion, $detalles = null, $ip = null) {
    try {
        $db = getDB();
        $ip = $ip ?? $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        
        $stmt = $db->prepare("
            INSERT INTO logs (tipo, usuario_id, accion, detalles, ip)
            VALUES (?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $tipo,
            $usuario_id,
            $accion,
            $detalles,
            $ip
        ]);
    } catch (Exception $e) {
        error_log("Error al registrar log: " . $e->getMessage());
    }
}

/**
 * Obtener configuración
 */
function getConfig($clave, $default = null) {
    try {
        $db = getDB();
        $stmt = $db->prepare("SELECT valor, tipo FROM configuracion WHERE clave = ?");
        $stmt->execute([$clave]);
        $result = $stmt->fetch();
        
        if (!$result) {
            return $default;
        }
        
        $valor = $result['valor'];
        $tipo = $result['tipo'];
        
        switch ($tipo) {
            case 'number':
                return floatval($valor);
            case 'boolean':
                return $valor === 'true' || $valor === '1';
            case 'json':
                return json_decode($valor, true);
            default:
                return $valor;
        }
    } catch (Exception $e) {
        error_log("Error al obtener configuración: " . $e->getMessage());
        return $default;
    }
}

/**
 * Establecer configuración
 */
function setConfig($clave, $valor, $tipo = 'string') {
    try {
        $db = getDB();
        
        if ($tipo === 'json') {
            $valor = json_encode($valor);
        } elseif ($tipo === 'boolean') {
            $valor = $valor ? 'true' : 'false';
        }
        
        $stmt = $db->prepare("
            INSERT INTO configuracion (clave, valor, tipo)
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE valor = ?, tipo = ?
        ");
        
        $stmt->execute([$clave, $valor, $tipo, $valor, $tipo]);
        return true;
    } catch (Exception $e) {
        error_log("Error al establecer configuración: " . $e->getMessage());
        return false;
    }
}

// =============================================
// INICIALIZAR HEADERS
// =============================================
setCorsHeaders();

?>
