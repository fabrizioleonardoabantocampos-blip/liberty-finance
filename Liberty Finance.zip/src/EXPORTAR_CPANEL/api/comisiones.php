<?php
/**
 * Sistema de Cálculo de Comisiones
 * Liberty Finance
 */

if (!function_exists('getDB')) {
    require_once __DIR__ . '/config.php';
}

/**
 * Calcular comisión directa (patrocinio)
 */
function calcularComisionDirecta($db, $sponsor_id, $referido_id, $pack_id, $monto) {
    try {
        // Obtener porcentaje de comisión directa
        $porcentaje = getConfig('comision_directa_porcentaje', 0.10); // 10% por defecto
        $comision = $monto * $porcentaje;
        
        // Registrar comisión
        $stmt = $db->prepare("
            INSERT INTO comisiones (
                usuario_id, referido_id, pack_id, tipo, monto, descripcion
            ) VALUES (?, ?, ?, 'directa', ?, ?)
        ");
        
        $descripcion = "Comisión directa por pack de $$monto de $referido_id";
        $stmt->execute([$sponsor_id, $referido_id, $pack_id, $comision, $descripcion]);
        
        // Distribuir la comisión entre los packs activos del sponsor
        distribuirComisionEntrePacks($db, $sponsor_id, $comision);
        
        error_log("✅ Comisión directa calculada: $sponsor_id recibe $$comision por $referido_id");
        
        return $comision;
        
    } catch (Exception $e) {
        error_log("Error al calcular comisión directa: " . $e->getMessage());
        throw $e;
    }
}

/**
 * Calcular comisiones binarias
 */
function calcularComisionesBinarias($db, $usuario_id, $monto) {
    try {
        // Obtener la cadena de padres binarios
        $padres = obtenerPadresBinarios($db, $usuario_id);
        
        $porcentaje = getConfig('comision_binaria_porcentaje', 0.10); // 10% por defecto
        
        foreach ($padres as $padre) {
            // Determinar en qué lado está el usuario
            $stmt = $db->prepare("
                SELECT 
                    hijo_izquierdo_id, 
                    hijo_derecho_id 
                FROM usuarios 
                WHERE id_unico = ?
            ");
            $stmt->execute([$padre['id_unico']]);
            $nodo = $stmt->fetch();
            
            // Determinar si es izquierda o derecha
            $esIzquierda = esHijoDeLado($db, $padre['id_unico'], $usuario_id, 'izquierda');
            
            // Actualizar puntos
            if ($esIzquierda) {
                $stmt = $db->prepare("
                    UPDATE usuarios 
                    SET puntos_izquierda = puntos_izquierda + ?
                    WHERE id_unico = ?
                ");
                $stmt->execute([$monto, $padre['id_unico']]);
            } else {
                $stmt = $db->prepare("
                    UPDATE usuarios 
                    SET puntos_derecha = puntos_derecha + ?
                    WHERE id_unico = ?
                ");
                $stmt->execute([$monto, $padre['id_unico']]);
            }
            
            // Verificar si hay comisión binaria
            $stmt = $db->prepare("
                SELECT puntos_izquierda, puntos_derecha 
                FROM usuarios 
                WHERE id_unico = ?
            ");
            $stmt->execute([$padre['id_unico']]);
            $puntos = $stmt->fetch();
            
            $menor = min($puntos['puntos_izquierda'], $puntos['puntos_derecha']);
            
            if ($menor >= 100) { // Umbral mínimo para comisión binaria
                $comision = $menor * $porcentaje;
                
                // Registrar comisión
                $stmt = $db->prepare("
                    INSERT INTO comisiones (
                        usuario_id, referido_id, pack_id, tipo, monto, descripcion
                    ) VALUES (?, ?, NULL, 'binaria', ?, ?)
                ");
                
                $descripcion = "Comisión binaria por emparejamiento ($menor puntos)";
                $stmt->execute([$padre['id_unico'], $usuario_id, $comision, $descripcion]);
                
                // Distribuir comisión
                distribuirComisionEntrePacks($db, $padre['id_unico'], $comision);
                
                // Resetear puntos emparejados
                $stmt = $db->prepare("
                    UPDATE usuarios 
                    SET 
                        puntos_izquierda = puntos_izquierda - ?,
                        puntos_derecha = puntos_derecha - ?
                    WHERE id_unico = ?
                ");
                $stmt->execute([$menor, $menor, $padre['id_unico']]);
                
                error_log("✅ Comisión binaria: {$padre['id_unico']} recibe $$comision");
            }
        }
        
    } catch (Exception $e) {
        error_log("Error al calcular comisiones binarias: " . $e->getMessage());
        throw $e;
    }
}

/**
 * Distribuir comisión entre packs activos del usuario
 */
function distribuirComisionEntrePacks($db, $usuario_id, $monto_comision) {
    try {
        // Obtener packs activos del usuario
        $stmt = $db->prepare("
            SELECT id, monto_inicial, total_acumulado 
            FROM packs 
            WHERE usuario_id = ? AND activo = 1
            ORDER BY fecha_compra ASC
        ");
        $stmt->execute([$usuario_id]);
        $packs = $stmt->fetchAll();
        
        if (empty($packs)) {
            error_log("⚠️ Usuario $usuario_id no tiene packs activos para recibir comisión");
            return;
        }
        
        $max_retorno = getConfig('max_retorno_porcentaje', 2.0); // 200%
        $monto_restante = $monto_comision;
        
        foreach ($packs as $pack) {
            if ($monto_restante <= 0) break;
            
            // Calcular cuánto puede recibir este pack
            $max_permitido = ($pack['monto_inicial'] * $max_retorno) - $pack['total_acumulado'];
            
            if ($max_permitido <= 0) {
                // Pack ya llegó al 200%, inactivar
                $stmt = $db->prepare("
                    UPDATE packs 
                    SET activo = 0, fecha_inactivacion = NOW()
                    WHERE id = ?
                ");
                $stmt->execute([$pack['id']]);
                continue;
            }
            
            // Asignar el menor entre lo que puede recibir y lo que queda por distribuir
            $asignar = min($max_permitido, $monto_restante);
            
            // Actualizar pack
            $stmt = $db->prepare("
                UPDATE packs 
                SET 
                    comisiones_acumuladas = comisiones_acumuladas + ?,
                    total_acumulado = total_acumulado + ?,
                    porcentaje_completado = (total_acumulado + ?) / monto_inicial * 100
                WHERE id = ?
            ");
            $stmt->execute([$asignar, $asignar, $asignar, $pack['id']]);
            
            $monto_restante -= $asignar;
            
            // Verificar si llegó al 200%
            $nuevo_total = $pack['total_acumulado'] + $asignar;
            if ($nuevo_total >= $pack['monto_inicial'] * $max_retorno) {
                $stmt = $db->prepare("
                    UPDATE packs 
                    SET activo = 0, fecha_inactivacion = NOW(), porcentaje_completado = 200
                    WHERE id = ?
                ");
                $stmt->execute([$pack['id']]);
                
                error_log("✅ Pack {$pack['id']} alcanzó el 200% y fue inactivado");
            }
        }
        
        if ($monto_restante > 0) {
            error_log("⚠️ Sobraron $$monto_restante de comisión para $usuario_id (todos los packs al 200%)");
        }
        
    } catch (Exception $e) {
        error_log("Error al distribuir comisión: " . $e->getMessage());
        throw $e;
    }
}

/**
 * Obtener cadena de padres binarios
 */
function obtenerPadresBinarios($db, $usuario_id, $niveles = 10) {
    $padres = [];
    $actual = $usuario_id;
    
    for ($i = 0; $i < $niveles; $i++) {
        $stmt = $db->prepare("
            SELECT padre_binario_id, id_unico 
            FROM usuarios 
            WHERE id_unico = ?
        ");
        $stmt->execute([$actual]);
        $usuario = $stmt->fetch();
        
        if (!$usuario || empty($usuario['padre_binario_id'])) {
            break;
        }
        
        $padres[] = ['id_unico' => $usuario['padre_binario_id']];
        $actual = $usuario['padre_binario_id'];
    }
    
    return $padres;
}

/**
 * Verificar si un usuario es hijo del lado especificado
 */
function esHijoDeLado($db, $padre_id, $usuario_id, $lado) {
    $stmt = $db->prepare("
        SELECT hijo_izquierdo_id, hijo_derecho_id 
        FROM usuarios 
        WHERE id_unico = ?
    ");
    $stmt->execute([$padre_id]);
    $padre = $stmt->fetch();
    
    if (!$padre) {
        return false;
    }
    
    if ($lado === 'izquierda') {
        // Verificar si el usuario está en el árbol izquierdo
        return esDescendiente($db, $padre['hijo_izquierdo_id'], $usuario_id);
    } else {
        // Verificar si el usuario está en el árbol derecho
        return esDescendiente($db, $padre['hijo_derecho_id'], $usuario_id);
    }
}

/**
 * Verificar si un usuario es descendiente de otro
 */
function esDescendiente($db, $raiz_id, $usuario_id) {
    if (empty($raiz_id)) {
        return false;
    }
    
    if ($raiz_id === $usuario_id) {
        return true;
    }
    
    $stmt = $db->prepare("
        SELECT hijo_izquierdo_id, hijo_derecho_id 
        FROM usuarios 
        WHERE id_unico = ?
    ");
    $stmt->execute([$raiz_id]);
    $nodo = $stmt->fetch();
    
    if (!$nodo) {
        return false;
    }
    
    return esDescendiente($db, $nodo['hijo_izquierdo_id'], $usuario_id) ||
           esDescendiente($db, $nodo['hijo_derecho_id'], $usuario_id);
}

?>
