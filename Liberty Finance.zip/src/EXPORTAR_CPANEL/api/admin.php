<?php
/**
 * Endpoints de Administración
 * Liberty Finance
 */

require_once __DIR__ . '/config.php';

// Validar que sea admin
$user = validateToken();
if ($user['rol'] !== 'admin') {
    errorResponse('Acceso denegado', 403);
}

$method = $_SERVER['REQUEST_METHOD'];
$requestUri = $_SERVER['REQUEST_URI'];

// Parse URI
$uri = parse_url($requestUri, PHP_URL_PATH);
$uri = str_replace('/api/admin.php', '', $uri);
$uri = trim($uri, '/');
$segments = explode('/', $uri);

// Routing
switch ($method) {
    case 'GET':
        if ($uri === 'dashboard-stats' || $uri === '') {
            handleDashboardStats();
        } elseif ($uri === 'users' || $uri === 'users-complete') {
            handleGetUsers();
        } elseif ($uri === 'retiros') {
            handleGetRetiros();
        } elseif ($uri === 'depositos') {
            handleGetDepositos();
        } else {
            errorResponse('Endpoint no encontrado', 404);
        }
        break;
    
    case 'PUT':
        if (count($segments) >= 2 && $segments[0] === 'retiros') {
            handleUpdateRetiro($segments[1]);
        } elseif (count($segments) >= 2 && $segments[0] === 'depositos') {
            handleUpdateDeposito($segments[1]);
        } else {
            errorResponse('Endpoint no encontrado', 404);
        }
        break;
    
    default:
        errorResponse('Método no permitido', 405);
}

/**
 * Estadísticas del dashboard de admin
 */
function handleDashboardStats() {
    try {
        $db = getDB();
        
        // Total de usuarios
        $stmt = $db->query("SELECT COUNT(*) as total FROM usuarios WHERE rol = 'usuario'");
        $totalUsuarios = $stmt->fetch()['total'];
        
        // Total de inversión activa
        $stmt = $db->query("SELECT SUM(monto_inicial) as total FROM packs WHERE activo = 1");
        $inversionActiva = $stmt->fetch()['total'] ?? 0;
        
        // Total de ganancias generadas
        $stmt = $db->query("SELECT SUM(total_acumulado) as total FROM packs");
        $gananciasGeneradas = $stmt->fetch()['total'] ?? 0;
        
        // Retiros pendientes
        $stmt = $db->query("SELECT COUNT(*) as total, SUM(monto) as monto FROM retiros WHERE estado = 'pendiente'");
        $retirosPendientes = $stmt->fetch();
        
        // Depósitos pendientes
        $stmt = $db->query("SELECT COUNT(*) as total, SUM(monto) as monto FROM depositos WHERE estado = 'pendiente'");
        $depositosPendientes = $stmt->fetch();
        
        // Nuevos usuarios (últimos 30 días)
        $stmt = $db->query("
            SELECT COUNT(*) as total 
            FROM usuarios 
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
            AND rol = 'usuario'
        ");
        $nuevosUsuarios = $stmt->fetch()['total'];
        
        // Packs activos
        $stmt = $db->query("SELECT COUNT(*) as total FROM packs WHERE activo = 1");
        $packsActivos = $stmt->fetch()['total'];
        
        jsonResponse([
            'success' => true,
            'stats' => [
                'total_usuarios' => intval($totalUsuarios),
                'inversion_activa' => floatval($inversionActiva),
                'ganancias_generadas' => floatval($gananciasGeneradas),
                'retiros_pendientes' => [
                    'cantidad' => intval($retirosPendientes['total']),
                    'monto' => floatval($retirosPendientes['monto'] ?? 0)
                ],
                'depositos_pendientes' => [
                    'cantidad' => intval($depositosPendientes['total']),
                    'monto' => floatval($depositosPendientes['monto'] ?? 0)
                ],
                'nuevos_usuarios_30d' => intval($nuevosUsuarios),
                'packs_activos' => intval($packsActivos)
            ]
        ]);
        
    } catch (Exception $e) {
        error_log("Error en dashboard-stats: " . $e->getMessage());
        errorResponse('Error en el servidor', 500);
    }
}

/**
 * Listar todos los usuarios
 */
function handleGetUsers() {
    try {
        $db = getDB();
        
        $stmt = $db->query("
            SELECT 
                u.id,
                u.id_unico,
                u.nombre,
                u.apellido,
                u.email,
                u.ciudad,
                u.pais,
                u.rango,
                u.sponsor_id,
                u.created_at,
                COUNT(DISTINCT p.id) as total_packs,
                SUM(CASE WHEN p.activo = 1 THEN p.monto_inicial ELSE 0 END) as inversion_activa,
                SUM(CASE WHEN p.activo = 1 THEN p.total_acumulado ELSE 0 END) as ganancia_total
            FROM usuarios u
            LEFT JOIN packs p ON u.id_unico = p.usuario_id
            WHERE u.rol = 'usuario'
            GROUP BY u.id
            ORDER BY u.created_at DESC
        ");
        
        $usuarios = $stmt->fetchAll();
        
        jsonResponse([
            'success' => true,
            'usuarios' => $usuarios
        ]);
        
    } catch (Exception $e) {
        error_log("Error al obtener usuarios: " . $e->getMessage());
        errorResponse('Error en el servidor', 500);
    }
}

/**
 * Listar retiros
 */
function handleGetRetiros() {
    try {
        $db = getDB();
        
        $stmt = $db->query("
            SELECT 
                r.id,
                r.usuario_id,
                r.monto,
                r.wallet,
                r.metodo,
                r.estado,
                r.comprobante_url,
                r.notas_admin,
                r.fecha_solicitud,
                r.fecha_procesado,
                u.nombre,
                u.apellido,
                u.email
            FROM retiros r
            JOIN usuarios u ON r.usuario_id = u.id_unico
            ORDER BY r.fecha_solicitud DESC
        ");
        
        $retiros = $stmt->fetchAll();
        
        jsonResponse([
            'success' => true,
            'retiros' => $retiros
        ]);
        
    } catch (Exception $e) {
        error_log("Error al obtener retiros: " . $e->getMessage());
        errorResponse('Error en el servidor', 500);
    }
}

/**
 * Listar depósitos
 */
function handleGetDepositos() {
    try {
        $db = getDB();
        
        $stmt = $db->query("
            SELECT 
                d.id,
                d.usuario_id,
                d.monto,
                d.comprobante_url,
                d.estado,
                d.notas_admin,
                d.fecha_solicitud,
                d.fecha_procesado,
                u.nombre,
                u.apellido,
                u.email
            FROM depositos d
            JOIN usuarios u ON d.usuario_id = u.id_unico
            ORDER BY d.fecha_solicitud DESC
        ");
        
        $depositos = $stmt->fetchAll();
        
        jsonResponse([
            'success' => true,
            'depositos' => $depositos
        ]);
        
    } catch (Exception $e) {
        error_log("Error al obtener depósitos: " . $e->getMessage());
        errorResponse('Error en el servidor', 500);
    }
}

/**
 * Actualizar estado de retiro
 */
function handleUpdateRetiro($retiroId) {
    $data = getRequestBody();
    $estado = $data['estado'] ?? '';
    $notas = $data['notas_admin'] ?? '';
    $comprobante = $data['comprobante_url'] ?? null;
    
    if (!in_array($estado, ['aprobado', 'rechazado', 'procesado'])) {
        errorResponse('Estado inválido');
    }
    
    try {
        $db = getDB();
        
        $stmt = $db->prepare("
            UPDATE retiros 
            SET 
                estado = ?,
                notas_admin = ?,
                comprobante_url = ?,
                fecha_procesado = NOW(),
                procesado_por = ?
            WHERE id = ?
        ");
        
        $user = validateToken();
        $stmt->execute([
            $estado,
            $notas,
            $comprobante,
            $user['id_unico'],
            $retiroId
        ]);
        
        registrarLog('admin', $user['id_unico'], 'retiro_actualizado', "Retiro #$retiroId actualizado a $estado");
        
        successResponse([], 'Retiro actualizado exitosamente');
        
    } catch (Exception $e) {
        error_log("Error al actualizar retiro: " . $e->getMessage());
        errorResponse('Error en el servidor', 500);
    }
}

/**
 * Actualizar estado de depósito
 */
function handleUpdateDeposito($depositoId) {
    $data = getRequestBody();
    $estado = $data['estado'] ?? '';
    $notas = $data['notas_admin'] ?? '';
    
    if (!in_array($estado, ['aprobado', 'rechazado'])) {
        errorResponse('Estado inválido');
    }
    
    try {
        $db = getDB();
        
        $stmt = $db->prepare("
            UPDATE depositos 
            SET 
                estado = ?,
                notas_admin = ?,
                fecha_procesado = NOW(),
                procesado_por = ?
            WHERE id = ?
        ");
        
        $user = validateToken();
        $stmt->execute([
            $estado,
            $notas,
            $user['id_unico'],
            $depositoId
        ]);
        
        registrarLog('admin', $user['id_unico'], 'deposito_actualizado', "Depósito #$depositoId actualizado a $estado");
        
        successResponse([], 'Depósito actualizado exitosamente');
        
    } catch (Exception $e) {
        error_log("Error al actualizar depósito: " . $e->getMessage());
        errorResponse('Error en el servidor', 500);
    }
}

?>
