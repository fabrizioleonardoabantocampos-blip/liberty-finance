<?php
/**
 * Endpoint de Prueba
 * Liberty Finance
 */

require_once __DIR__ . '/config.php';

// Test de conexión a la base de datos
try {
    $db = getDB();
    
    // Obtener versión de MySQL
    $stmt = $db->query("SELECT VERSION() as version");
    $mysql_version = $stmt->fetch();
    
    // Contar usuarios
    $stmt = $db->query("SELECT COUNT(*) as total FROM usuarios");
    $total_usuarios = $stmt->fetch();
    
    // Contar packs
    $stmt = $db->query("SELECT COUNT(*) as total FROM packs");
    $total_packs = $stmt->fetch();
    
    // Verificar configuración
    $rendimiento = getConfig('rendimiento_diario_porcentaje', null);
    
    jsonResponse([
        'success' => true,
        'message' => 'API funcionando correctamente',
        'info' => [
            'php_version' => phpversion(),
            'mysql_version' => $mysql_version['version'],
            'database' => DB_NAME,
            'app_name' => APP_NAME,
            'timezone' => date_default_timezone_get(),
            'current_time' => date('Y-m-d H:i:s')
        ],
        'stats' => [
            'usuarios' => intval($total_usuarios['total']),
            'packs' => intval($total_packs['total']),
            'rendimiento_diario' => $rendimiento !== null ? ($rendimiento * 100) . '%' : 'No configurado'
        ],
        'endpoints' => [
            'auth' => '/api/auth',
            'users' => '/api/users',
            'admin' => '/api/admin'
        ]
    ]);
    
} catch (Exception $e) {
    errorResponse('Error de conexión: ' . $e->getMessage(), 500);
}

?>
