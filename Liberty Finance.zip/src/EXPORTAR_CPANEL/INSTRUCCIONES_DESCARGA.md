# 📥 Cómo Descargar los Archivos de cPanel desde Figma Make

## 🎯 Objetivo

Obtener todos los archivos de la carpeta `/EXPORTAR_CPANEL/` para instalarlos en tu servidor cPanel.

---

## 📋 Opción 1: Descargar Archivos Individualmente (Recomendado)

Como Figma Make no permite descargar carpetas completas, debes copiar cada archivo manualmente.

### Paso a paso:

1. **Crear carpeta local en tu computadora:**
   ```
   C:\Liberty_Finance_cPanel\     (Windows)
   ~/Liberty_Finance_cPanel/      (Mac/Linux)
   ```

2. **Crear la estructura de carpetas:**
   ```
   Liberty_Finance_cPanel/
   ├── database/
   ├── api/
   ├── cron/
   └── public_html/
   ```

3. **Copiar cada archivo:**

   Para cada archivo listado abajo:
   - Clic en el archivo en Figma Make
   - Copiar todo el contenido (Ctrl+A, Ctrl+C)
   - Crear un nuevo archivo en tu editor local
   - Pegar el contenido (Ctrl+V)
   - Guardar con el nombre correcto

### 📄 Lista de Archivos a Copiar:

#### 📁 Raíz (/)
- `README_INSTALACION.md`
- `GUIA_COMPILACION.md`
- `ESTRUCTURA_ARCHIVOS.txt`
- `INSTRUCCIONES_DESCARGA.md` (este archivo)

#### 📁 database/
- `database/schema.sql`
- `database/initial_data.sql`

#### 📁 api/
- `api/config.php`
- `api/auth.php`
- `api/users.php`
- `api/admin.php`
- `api/comisiones.php`
- `api/test.php`

#### 📁 cron/
- `cron/daily_yields.php`

#### 📁 public_html/
- `public_html/.htaccess`

---

## 📋 Opción 2: Usar el Código para Crear Archivos Localmente

Si prefieres, puedes crear un script Node.js que genere todos los archivos automáticamente:

### Paso 1: Crear `generate_files.js`

```javascript
const fs = require('fs');
const path = require('path');

// Crear estructura de carpetas
const folders = [
  'Liberty_Finance_cPanel',
  'Liberty_Finance_cPanel/database',
  'Liberty_Finance_cPanel/api',
  'Liberty_Finance_cPanel/cron',
  'Liberty_Finance_cPanel/public_html'
];

folders.forEach(folder => {
  if (!fs.existsSync(folder)) {
    fs.mkdirSync(folder, { recursive: true });
    console.log(`✅ Carpeta creada: ${folder}`);
  }
});

console.log('\n📁 Estructura de carpetas creada exitosamente');
console.log('👉 Ahora copia manualmente el contenido de cada archivo desde Figma Make');
```

### Paso 2: Ejecutar el script

```bash
node generate_files.js
```

Esto creará la estructura de carpetas. Luego copia el contenido de cada archivo manualmente.

---

## 📋 Opción 3: Comprimir y Descargar (Si tu navegador lo permite)

Algunos navegadores permiten guardar archivos directamente desde la consola del desarrollador:

### Paso a paso:

1. **Abrir consola del navegador** (F12)

2. **Pegar este código en la consola:**

```javascript
// Función para descargar un archivo
function downloadFile(filename, content) {
  const blob = new Blob([content], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

console.log('✅ Función downloadFile lista. Usa:');
console.log('downloadFile("nombre.txt", "contenido del archivo")');
```

3. **Para cada archivo, ejecutar:**

```javascript
// Ejemplo para descargar README_INSTALACION.md
downloadFile('README_INSTALACION.md', `contenido aquí`);
```

⚠️ **Nota:** Debes copiar el contenido de cada archivo entre las comillas invertidas.

---

## ✅ Verificación de Archivos Descargados

Después de descargar todos los archivos, verifica que la estructura sea:

```
Liberty_Finance_cPanel/
│
├── README_INSTALACION.md
├── GUIA_COMPILACION.md
├── ESTRUCTURA_ARCHIVOS.txt
├── INSTRUCCIONES_DESCARGA.md
│
├── database/
│   ├── schema.sql
│   └── initial_data.sql
│
├── api/
│   ├── config.php
│   ├── auth.php
│   ├── users.php
│   ├── admin.php
│   ├── comisiones.php
│   └── test.php
│
├── cron/
│   └── daily_yields.php
│
└── public_html/
    └── .htaccess
```

### Checklist:

- [ ] 4 archivos en la raíz (.md y .txt)
- [ ] 2 archivos SQL en `database/`
- [ ] 6 archivos PHP en `api/`
- [ ] 1 archivo PHP en `cron/`
- [ ] 1 archivo `.htaccess` en `public_html/`

**Total:** 14 archivos

---

## 📦 Empaquetar para Transferir

Una vez tengas todos los archivos:

### Opción A: Comprimir en ZIP

1. **Windows:** Clic derecho en la carpeta → Enviar a → Carpeta comprimida
2. **Mac:** Clic derecho en la carpeta → Comprimir
3. **Linux:** `zip -r Liberty_Finance_cPanel.zip Liberty_Finance_cPanel/`

### Opción B: Transferir directamente por FTP

Si tienes acceso FTP a tu servidor, puedes subir los archivos directamente sin comprimir.

---

## 🚀 Próximos Pasos

Una vez tengas todos los archivos descargados:

1. ✅ Lee **README_INSTALACION.md** (guía completa de instalación)
2. ✅ Lee **GUIA_COMPILACION.md** (cómo compilar el frontend)
3. ✅ Sigue los pasos de instalación en orden

---

## 🆘 Problemas Comunes

### "No puedo descargar archivos"

**Solución:** Copia y pega manualmente el contenido de cada archivo en tu editor de código local (VS Code, Sublime, Notepad++, etc.)

### "Perdí la estructura de carpetas"

**Solución:** Consulta **ESTRUCTURA_ARCHIVOS.txt** para ver dónde va cada archivo.

### "Los archivos tienen extensión incorrecta"

**Solución:** Al guardar, asegúrate de:
- `.php` para archivos PHP
- `.sql` para archivos SQL
- `.md` para archivos Markdown
- `.txt` para archivos de texto
- `.htaccess` SIN extensión adicional (no .htaccess.txt)

### "El .htaccess no se ve"

**Solución:** Los archivos que empiezan con punto (`.`) son ocultos en algunos sistemas. Habilita "Mostrar archivos ocultos" en tu sistema operativo.

**Windows:**
- Explorador de archivos → Ver → Mostrar archivos ocultos

**Mac:**
- Finder → Cmd + Shift + . (punto)

**Linux:**
- Nautilus → Ctrl + H

---

## 📞 Soporte

Si tienes problemas descargando los archivos:

1. Revisa que hayas copiado todo el contenido (Ctrl+A antes de Ctrl+C)
2. Verifica que los nombres de archivo sean exactos (mayúsculas/minúsculas)
3. Asegúrate de guardar con la extensión correcta

---

## 🎉 ¡Listo!

Una vez descargados todos los archivos, continúa con **README_INSTALACION.md** para instalar el sistema en tu servidor cPanel.

