# 📦 Guía de Compilación para cPanel

## 🎯 Objetivo

Esta guía te ayudará a compilar el frontend de React y adaptarlo para que funcione con el backend PHP en cPanel.

---

## 📋 Requisitos Previos

- Node.js 16 o superior instalado en tu máquina local
- Acceso al código fuente del proyecto en Figma Make
- Credenciales de tu servidor cPanel

---

## 🔧 PASO 1: Modificar el Archivo de Configuración de API

Antes de compilar, debes modificar cómo el frontend se conecta al backend.

### 1.1. Abrir el archivo `/utils/api.ts`

Busca este archivo en el proyecto de Figma Make.

### 1.2. Modificar la URL de la API

**ANTES (Supabase):**
```typescript
const API_URL = `https://${projectId}.supabase.co/functions/v1/make-server-9f68532a`;
```

**DESPUÉS (cPanel):**
```typescript
const API_URL = 'https://tudominio.com/api'; // Reemplaza con tu dominio real
```

### 1.3. Ajustar las llamadas a la API

El archivo `utils/api.ts` debería quedar así:

```typescript
/**
 * Cliente de API para cPanel + PHP
 */

const API_URL = 'https://tudominio.com/api'; // 🔧 CAMBIAR POR TU DOMINIO

export async function callServer(endpoint: string, method: string = 'GET', body?: any) {
  try {
    const url = `${API_URL}${endpoint}`;
    
    const options: RequestInit = {
      method,
      headers: {
        'Content-Type': 'application/json',
      },
      credentials: 'omit', // No necesitamos cookies en cPanel
    };

    // Agregar token si existe
    const token = localStorage.getItem('authToken');
    if (token) {
      options.headers = {
        ...options.headers,
        'Authorization': `Bearer ${token}`,
      };
    }

    if (body && method !== 'GET') {
      options.body = JSON.stringify(body);
    }

    const response = await fetch(url, options);
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Error en la petición');
    }

    return await response.json();
  } catch (error) {
    console.error('Error en callServer:', error);
    throw error;
  }
}
```

---

## 🏗️ PASO 2: Compilar el Proyecto

### 2.1. Abrir terminal en la raíz del proyecto

```bash
cd /ruta/al/proyecto
```

### 2.2. Instalar dependencias (si no lo has hecho)

```bash
npm install
```

### 2.3. Compilar para producción

```bash
npm run build
```

Este comando generará una carpeta `dist/` con todos los archivos compilados.

---

## 📁 PASO 3: Estructura de la Carpeta `dist/`

Después de compilar, la carpeta `dist/` contendrá algo como:

```
dist/
├── index.html
├── assets/
│   ├── index-a1b2c3d4.js
│   ├── index-e5f6g7h8.css
│   ├── logo-i9j0k1l2.png
│   └── ...
└── favicon.ico
```

---

## 📤 PASO 4: Subir Archivos a cPanel

### 4.1. Conectar por FTP o usar Administrador de Archivos

**Opción A: FTP con FileZilla**
- Host: ftp.tudominio.com
- Usuario: tu usuario de cPanel
- Contraseña: tu contraseña de cPanel

**Opción B: Administrador de Archivos de cPanel**
- Ingresar a cPanel → Administrador de Archivos

### 4.2. Navegar a `public_html/`

Esta es la carpeta raíz donde se alojarán los archivos públicos.

### 4.3. Subir el contenido de `dist/`

**⚠️ IMPORTANTE:** NO subas la carpeta `dist/` completa. Sube su CONTENIDO.

**Correcto:**
```
/public_html/
  ├── index.html
  ├── assets/
  │   ├── index-a1b2c3d4.js
  │   ├── index-e5f6g7h8.css
  │   └── ...
  ├── api/          ← (Ya subido previamente)
  ├── .htaccess     ← (Ya subido previamente)
  └── favicon.ico
```

**Incorrecto:**
```
/public_html/
  └── dist/         ← ❌ NO HACER ESTO
      ├── index.html
      └── ...
```

---

## 🔄 PASO 5: Actualizar Rutas Absolutas (Si es necesario)

Si tu dominio está en un subdirectorio (ej: `tudominio.com/liberty/`), necesitas ajustar la base URL.

### 5.1. Crear o modificar `vite.config.ts`

```typescript
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  base: '/liberty/', // 🔧 Cambiar si usas subdirectorio
});
```

### 5.2. Recompilar

```bash
npm run build
```

---

## ✅ PASO 6: Verificar la Instalación

### 6.1. Probar la API

Visita:
```
https://tudominio.com/api/test
```

Deberías ver:
```json
{
  "success": true,
  "message": "API funcionando correctamente",
  "info": { ... }
}
```

### 6.2. Probar el Frontend

Visita:
```
https://tudominio.com
```

Deberías ver la página de login de Liberty Finance.

---

## 🐛 Solución de Problemas

### Error: "API no responde"

**Causa:** La URL de la API está mal configurada.

**Solución:**
1. Verifica que `API_URL` en `/utils/api.ts` apunte a tu dominio
2. Verifica que la carpeta `api/` esté en `public_html/`
3. Verifica que `.htaccess` esté en `public_html/`

### Error: "Archivos .js no se cargan"

**Causa:** Rutas incorrectas en el build.

**Solución:**
1. Si usas subdirectorio, configura `base` en `vite.config.ts`
2. Verifica que los archivos de `assets/` estén subidos correctamente

### Error: "404 en rutas de React"

**Causa:** `.htaccess` no está funcionando.

**Solución:**
1. Verifica que `.htaccess` esté en la raíz de `public_html/`
2. Verifica que `mod_rewrite` esté habilitado en Apache
3. Contacta a tu proveedor de hosting si no funciona

### La página carga pero no hace login

**Causa:** El backend no está conectado o las credenciales de BD son incorrectas.

**Solución:**
1. Verifica `api/config.php` con las credenciales correctas
2. Prueba `/api/test` para verificar la conexión
3. Revisa los logs de PHP en cPanel → Errores

---

## 🔄 Actualizaciones Futuras

Cuando hagas cambios en el código:

1. **Modificar código** en Figma Make o tu editor local
2. **Recompilar:**
   ```bash
   npm run build
   ```
3. **Subir solo los archivos modificados** de `dist/` a `public_html/`
   - Generalmente solo `index.html` y archivos de `assets/`
4. **Limpiar caché del navegador** (Ctrl+F5) para ver los cambios

---

## 📊 Checklist Final

Antes de considerar la instalación completa:

- [ ] Base de datos MySQL creada e importada
- [ ] Credenciales en `api/config.php` configuradas
- [ ] Carpeta `api/` subida a `public_html/api/`
- [ ] Archivo `.htaccess` subido a `public_html/.htaccess`
- [ ] `utils/api.ts` modificado con URL correcta
- [ ] Proyecto compilado con `npm run build`
- [ ] Contenido de `dist/` subido a `public_html/`
- [ ] `/api/test` responde correctamente
- [ ] Página principal carga sin errores
- [ ] Login funciona correctamente
- [ ] Cron job configurado para rendimientos diarios

---

## 🎉 ¡Listo!

Si todos los pasos se completaron correctamente, tu instalación de Liberty Finance debería estar funcionando en cPanel.

**Credenciales de admin por defecto:**
- Email: `admin@libertyfinance.com`
- Password: `admin123`

**⚠️ IMPORTANTE:** Cambia la contraseña de administrador inmediatamente después del primer login.

---

## 📞 Soporte

Si encuentras problemas:

1. Revisa los logs de PHP: cPanel → Errores
2. Revisa la consola del navegador (F12)
3. Verifica que todos los archivos se hayan subido correctamente
4. Asegúrate de que las credenciales de BD sean correctas

