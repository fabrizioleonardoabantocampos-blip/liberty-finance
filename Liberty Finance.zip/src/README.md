# 🚀 LIBERTY FINANCE - OFICINA VIRTUAL

## ✅ ESTADO ACTUAL

```
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║   ✅ SERVIDOR DESPLEGADO Y FUNCIONANDO                    ║
║                                                           ║
║   La aplicación está conectada a Supabase.              ║
║   Todas las funcionalidades están operativas.           ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝
```

---

## 🎯 INFORMACIÓN DEL PROYECTO

**Liberty Finance** es una plataforma de oficina virtual con sistema de comisiones multinivel, gestión de packs de inversión, matriz binaria y sistema de rangos.

### 🏗️ Arquitectura

- **Frontend:** React + TypeScript + Tailwind CSS
- **Backend:** Supabase Edge Functions (Hono)
- **Base de datos:** PostgreSQL (Supabase)
- **Autenticación:** Supabase Auth
- **Storage:** Supabase Storage

---

## 🔐 CREDENCIALES

### Admin
```
Email:    admin@libertyfinance.com
Password: admin123
```

### Usuario Demo (si existe)
```
Email:    usuario@demo.com
Password: demo123
```

---

## 🚀 INICIO RÁPIDO

### 1. **Despertar el Servidor (Importante)**

El servidor de Supabase entra en "hibernación" después de inactividad. Antes de usar la aplicación:

1. Ve a `/Setup`
2. Haz clic en **"⚡ Despertar Servidor"**
3. Espera 60 segundos
4. El servidor estará listo

### 2. **Login**

Usa las credenciales de admin para acceder al panel de administración.

---

## 📋 CARACTERÍSTICAS PRINCIPALES

### 👤 Panel de Usuario
- ✅ Dashboard con estadísticas en tiempo real
- ✅ Gestión de packs de inversión
- ✅ Sistema de comisiones (rendimiento diario, red, patrocinio)
- ✅ Wallet interno con retiros
- ✅ Visualización de red multinivel (directos y completa)
- ✅ Matriz binaria interactiva
- ✅ Sistema de rangos con premios
- ✅ Ruleta de premios
- ✅ Historial de transacciones

### 🔧 Panel de Administración
- ✅ Dashboard con métricas globales
- ✅ Gestión de usuarios
- ✅ Aprobación de depósitos y cobros
- ✅ Procesamiento de rendimientos diarios
- ✅ Configuración del sistema
- ✅ Gestión de rangos
- ✅ Sistema de fusión de usuarios duplicados
- ✅ Herramientas de diagnóstico

### ⚡ Optimizaciones Implementadas
- ✅ Caché en memoria (reduce tiempos de carga de 6 min a 5-10 seg)
- ✅ Carga paralela de datos
- ✅ Sistema anti-duplicados de rendimientos (3 capas)
- ✅ Bloqueo de rendimientos diarios para evitar procesamiento múltiple
- ✅ Timeouts optimizados en rutas críticas
- ✅ Detección y fusión automática de usuarios duplicados

---

## 🔄 SISTEMA DE COMISIONES

### Tipos de Comisiones

1. **Rendimiento Diario (0.25%)**
   - Se aplica sobre el monto del pack activo
   - Se procesa automáticamente cada día
   - Se divide proporcionalmente entre todos los packs activos
   - Un pack se inactiva al alcanzar el 200% de su valor inicial

2. **Comisión de Red (3%)**
   - Por compras de usuarios en tu red multinivel
   - Se calcula sobre el monto de la inversión

3. **Comisión de Patrocinio (5%)**
   - Por referidos directos que compran packs
   - Incentivo para construcción de red

### Sistema de Packs

| Pack | Monto | Rendimiento Diario |
|------|-------|--------------------|
| Pack 50 | $50 | $0.125 |
| Pack 100 | $100 | $0.25 |
| Pack 200 | $200 | $0.50 |
| Pack 500 | $500 | $1.25 |
| Pack 1000 | $1,000 | $2.50 |
| Pack 3000 | $3,000 | $7.50 |
| Pack 5000 | $5,000 | $12.50 |
| Pack 10000 | $10,000 | $25.00 |

**Importante:** Cada pack se inactiva automáticamente al alcanzar el 200% de su valor inicial.

---

## 🛠️ HERRAMIENTAS DE DIAGNÓSTICO

### `/Setup` - Página de Configuración

Herramientas disponibles:

1. **🚨 Diagnóstico de Timeouts**
   - Prueba conectividad con el servidor
   - Verifica estado de endpoints críticos
   - Despierta el servidor si está hibernando

2. **📊 Diagnóstico Final**
   - Verifica estado completo del sistema
   - Prueba base de datos
   - Valida configuración

3. **⚡ Despertar Servidor**
   - Activa el servidor si está en hibernación
   - Recomendado ejecutar antes de usar la app

---

## 🔧 MANTENIMIENTO

### Procesamiento de Rendimientos

Los rendimientos diarios se procesan automáticamente, pero también se pueden procesar manualmente desde el panel de admin:

1. Ve a **Admin → Dashboard**
2. Haz clic en **"Procesar Rendimientos Diarios"**
3. El sistema aplicará los rendimientos a todos los usuarios con packs activos

### Sistema Anti-Duplicados (3 Capas)

1. **Capa 1:** Verificación de fecha en memoria
2. **Capa 2:** Lock de procesamiento en KV Store
3. **Capa 3:** Validación en base de datos antes de insertar

### Detección de Usuarios Duplicados

El sistema detecta automáticamente usuarios con:
- Mismo email
- Misma wallet
- Mismo teléfono

Desde el panel de admin puedes fusionar usuarios duplicados manteniendo la integridad de los datos.

---

## 📊 MATRIZ BINARIA

La matriz binaria organiza a los usuarios en una estructura de árbol:
- Cada usuario puede tener máximo 2 referidos directos
- Los referidos adicionales se colocan automáticamente en la red
- Visualización interactiva con zoom y navegación
- Colores indican estado (con pack, sin pack, inactivo)

---

## 🎯 SISTEMA DE RANGOS

| Rango | Directos | Volumen | Premio |
|-------|----------|---------|--------|
| Inicial | 0 | $0 | Bienvenida |
| Bronce | 3 | $300 | Certificado Digital |
| Plata | 6 | $1,000 | Bono $50 |
| Oro | 10 | $3,000 | Bono $150 |
| Platino | 15 | $7,500 | Bono $400 |
| Diamante | 25 | $15,000 | Viaje Internacional |

---

## 🐛 SOLUCIÓN DE PROBLEMAS

### Error: Timeout en requests

**Solución:**
1. Ve a `/Setup`
2. Haz clic en **"⚡ Despertar Servidor"**
3. Espera 60 segundos
4. Intenta de nuevo

### Error: No cargan datos en el dashboard

**Solución:**
1. Verifica que el servidor esté activo (paso anterior)
2. Limpia caché del navegador (Ctrl+Shift+R)
3. Ve a `/Setup` → "Diagnóstico Final"

### Error: 502 Bad Gateway

**Causa:** El Edge Function está procesando una operación pesada

**Solución:**
- Espera 30-60 segundos
- El timeout está configurado para operaciones largas
- No recargues la página durante el procesamiento

---

## 📁 ESTRUCTURA DEL PROYECTO

```
/
├── components/           # Componentes React
│   ├── admin/           # Componentes del panel admin
│   ├── user/            # Componentes del panel usuario
│   ├── auth/            # Autenticación y login
│   ├── ui/              # Componentes UI reutilizables
│   └── debug/           # Herramientas de debugging
├── pages/               # Páginas principales
│   ├── Setup.tsx        # Herramientas de diagnóstico
│   ├── MigracionPage.tsx
│   └── ...
├── utils/               # Utilidades
│   ├── api.ts           # Cliente API
│   ├── demoMode.ts      # Modo demo (desactivado)
│   └── supabase/        # Configuración Supabase
├── supabase/
│   └── functions/
│       └── server/      # Edge Function (Backend)
│           ├── index.tsx
│           ├── kv_store.tsx
│           └── ...
└── styles/              # Estilos globales
```

---

## 🔒 SEGURIDAD

- ✅ Autenticación con Supabase Auth
- ✅ Tokens JWT para sesiones
- ✅ Validación de permisos en cada endpoint
- ✅ Service Role Key protegida (solo backend)
- ✅ Sanitización de inputs
- ✅ Rate limiting en operaciones críticas

---

## 📧 SISTEMA DE EMAILS

El sistema usa **Resend** para envío de emails:
- Confirmación de registro
- Notificaciones de depósitos aprobados
- Notificaciones de retiros procesados
- Alertas de rendimientos

---

## 🚀 DESPLIEGUE

El servidor Edge Function ya está desplegado en Supabase.

### Para redesplegar (si necesitas actualizar el código):

```bash
supabase functions deploy server
```

---

## 📝 NOTAS IMPORTANTES

### Credenciales Admin
Las credenciales de admin están estandarizadas:
- Email: `admin@libertyfinance.com`
- Password: `admin123`

**⚠️ IMPORTANTE:** Cambia estas credenciales en producción.

### Primer Uso
1. Despierta el servidor en `/Setup`
2. Espera 60 segundos
3. Login con credenciales de admin
4. Configura wallet de destino en Admin → Configuración

### Base de Datos
- La tabla principal es `kv_store_9f68532a` (key-value store)
- Todos los datos se almacenan en formato JSON
- Sistema optimizado para prototipado rápido

---

## 🎉 TODO FUNCIONANDO

El sistema está completamente operativo con:
- ✅ Backend desplegado
- ✅ Base de datos conectada
- ✅ Autenticación funcionando
- ✅ Sistema de comisiones activo
- ✅ Caché optimizado
- ✅ Timeouts configurados
- ✅ Sistema anti-duplicados activo

**¡Liberty Finance está listo para usar!** 🚀

---

## 📞 SOPORTE TÉCNICO

Para problemas o consultas:
1. Revisa esta documentación
2. Ve a `/Setup` para diagnósticos
3. Verifica logs en la consola del navegador
4. Revisa logs del Edge Function en Supabase

---

**Última actualización:** 31 de diciembre de 2025  
**Estado:** 🟢 OPERATIVO  
**Servidor:** ✅ DESPLEGADO  
**Versión:** 1.0.0
