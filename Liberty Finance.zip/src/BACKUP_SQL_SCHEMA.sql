-- =====================================================
-- LIBERTY FINANCE - ESQUEMA SQL COMPLETO
-- Base de Datos Relacional Equivalente al KV Store
-- Fecha: 2025-11-19
-- =====================================================

-- IMPORTANTE: Este esquema es OPCIONAL
-- El sistema actual funciona con KV Store (clave-valor)
-- Este SQL es solo para migración futura a PostgreSQL/MySQL

-- =====================================================
-- TABLA: users
-- =====================================================
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    id_unico VARCHAR(50) UNIQUE NOT NULL,
    nombre VARCHAR(100) NOT NULL,
    apellido VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    telefono VARCHAR(50) NOT NULL,
    ciudad VARCHAR(100),
    wallet VARCHAR(100),
    password VARCHAR(255) NOT NULL,
    referral_code VARCHAR(50),
    referido_por UUID REFERENCES users(id),
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    activo BOOLEAN DEFAULT FALSE,
    rango VARCHAR(50) DEFAULT 'Sin Rango',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Índices para users
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_id_unico ON users(id_unico);
CREATE INDEX idx_users_referido_por ON users(referido_por);
CREATE INDEX idx_users_activo ON users(activo);
CREATE INDEX idx_users_created_at ON users(created_at);

-- =====================================================
-- TABLA: packs
-- =====================================================
CREATE TABLE IF NOT EXISTS packs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    nombre VARCHAR(50) NOT NULL,
    monto DECIMAL(10, 2) NOT NULL,
    fecha_compra TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    activo BOOLEAN DEFAULT TRUE,
    rendimiento_diario DECIMAL(10, 2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Índices para packs
CREATE INDEX idx_packs_user_id ON packs(user_id);
CREATE INDEX idx_packs_activo ON packs(activo);
CREATE INDEX idx_packs_fecha_compra ON packs(fecha_compra);

-- Constraint: Solo un pack activo por usuario
CREATE UNIQUE INDEX idx_packs_user_activo ON packs(user_id) WHERE activo = TRUE;

-- =====================================================
-- TABLA: comisiones
-- =====================================================
CREATE TABLE IF NOT EXISTS comisiones (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    tipo VARCHAR(20) NOT NULL CHECK (tipo IN ('red', 'patrocinio', 'rendimiento')),
    monto DECIMAL(10, 2) NOT NULL,
    nivel INT,
    referido_id UUID REFERENCES users(id),
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    descripcion TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Índices para comisiones
CREATE INDEX idx_comisiones_user_id ON comisiones(user_id);
CREATE INDEX idx_comisiones_tipo ON comisiones(tipo);
CREATE INDEX idx_comisiones_fecha ON comisiones(fecha);
CREATE INDEX idx_comisiones_referido_id ON comisiones(referido_id);

-- =====================================================
-- TABLA: cobros (retiros)
-- =====================================================
CREATE TABLE IF NOT EXISTS cobros (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    monto DECIMAL(10, 2) NOT NULL,
    wallet VARCHAR(100) NOT NULL,
    estado VARCHAR(20) NOT NULL DEFAULT 'pendiente' CHECK (estado IN ('pendiente', 'aprobado', 'rechazado', 'completado')),
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_procesado TIMESTAMP,
    tx_hash VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Índices para cobros
CREATE INDEX idx_cobros_user_id ON cobros(user_id);
CREATE INDEX idx_cobros_estado ON cobros(estado);
CREATE INDEX idx_cobros_fecha ON cobros(fecha);

-- =====================================================
-- TABLA: rendimientos
-- =====================================================
CREATE TABLE IF NOT EXISTS rendimientos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    monto DECIMAL(10, 2) NOT NULL,
    porcentaje DECIMAL(5, 4) NOT NULL DEFAULT 0.01,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Índices para rendimientos
CREATE INDEX idx_rendimientos_user_id ON rendimientos(user_id);
CREATE INDEX idx_rendimientos_fecha ON rendimientos(fecha);

-- =====================================================
-- TABLA: depositos
-- =====================================================
CREATE TABLE IF NOT EXISTS depositos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    pack_nombre VARCHAR(50) NOT NULL,
    monto DECIMAL(10, 2) NOT NULL,
    wallet_destino VARCHAR(100) NOT NULL,
    comprobante TEXT,
    estado VARCHAR(20) NOT NULL DEFAULT 'pendiente' CHECK (estado IN ('pendiente', 'verificado', 'rechazado')),
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_procesado TIMESTAMP,
    procesado_por UUID REFERENCES users(id),
    metodo_pago VARCHAR(20) DEFAULT 'manual' CHECK (metodo_pago IN ('manual', 'nowpayments')),
    payment_id VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Índices para depositos
CREATE INDEX idx_depositos_user_id ON depositos(user_id);
CREATE INDEX idx_depositos_estado ON depositos(estado);
CREATE INDEX idx_depositos_fecha ON depositos(fecha);
CREATE INDEX idx_depositos_payment_id ON depositos(payment_id);

-- =====================================================
-- TABLA: productos
-- =====================================================
CREATE TABLE IF NOT EXISTS productos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    nombre VARCHAR(100) NOT NULL,
    descripcion TEXT,
    precio DECIMAL(10, 2) NOT NULL,
    imagen TEXT,
    stock INT NOT NULL DEFAULT 9999,
    activo BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Índices para productos
CREATE INDEX idx_productos_activo ON productos(activo);
CREATE INDEX idx_productos_nombre ON productos(nombre);

-- =====================================================
-- TABLA: rangos
-- =====================================================
CREATE TABLE IF NOT EXISTS rangos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    nombre VARCHAR(50) UNIQUE NOT NULL,
    nivel INT NOT NULL,
    directos_requeridos INT NOT NULL,
    volumen_requerido DECIMAL(12, 2) NOT NULL,
    bono_porcentaje DECIMAL(5, 2) NOT NULL,
    imagen TEXT,
    color VARCHAR(20),
    descripcion TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Índices para rangos
CREATE INDEX idx_rangos_nivel ON rangos(nivel);
CREATE INDEX idx_rangos_nombre ON rangos(nombre);

-- =====================================================
-- TABLA: ruleta_historial
-- =====================================================
CREATE TABLE IF NOT EXISTS ruleta_historial (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    premio VARCHAR(100) NOT NULL,
    puntos DECIMAL(10, 2) NOT NULL,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Índices para ruleta_historial
CREATE INDEX idx_ruleta_user_id ON ruleta_historial(user_id);
CREATE INDEX idx_ruleta_fecha ON ruleta_historial(fecha);

-- =====================================================
-- TABLA: configuracion_admin
-- =====================================================
CREATE TABLE IF NOT EXISTS configuracion_admin (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    wallet_principal VARCHAR(100),
    wallets_secundarios TEXT[], -- Array de wallets
    comision_referido_directo DECIMAL(5, 4) DEFAULT 0.10,
    qr_code_url TEXT,
    rendimiento_activo BOOLEAN DEFAULT TRUE,
    porcentaje_rendimiento DECIMAL(5, 4) DEFAULT 0.01,
    ultima_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Solo debe haber una fila de configuración
CREATE UNIQUE INDEX idx_config_admin_singleton ON configuracion_admin((true));

-- =====================================================
-- VISTAS ÚTILES
-- =====================================================

-- Vista: Resumen de usuarios con métricas
CREATE OR REPLACE VIEW v_user_metrics AS
SELECT 
    u.id,
    u.id_unico,
    u.nombre,
    u.apellido,
    u.email,
    u.rango,
    u.activo,
    COALESCE(SUM(p.monto), 0) AS inversion_total,
    COALESCE(MAX(p.monto), 0) AS pack_actual_monto,
    COALESCE(SUM(r.monto), 0) AS rendimiento_total,
    COALESCE(SUM(c.monto) FILTER (WHERE c.tipo = 'red'), 0) AS comisiones_red_total,
    COALESCE(SUM(c.monto) FILTER (WHERE c.tipo = 'patrocinio'), 0) AS comisiones_patrocinio_total,
    COUNT(DISTINCT ref.id) AS referidos_directos,
    u.fecha_registro
FROM users u
LEFT JOIN packs p ON u.id = p.user_id AND p.activo = TRUE
LEFT JOIN rendimientos r ON u.id = r.user_id
LEFT JOIN comisiones c ON u.id = c.user_id
LEFT JOIN users ref ON ref.referido_por = u.id
GROUP BY u.id, u.id_unico, u.nombre, u.apellido, u.email, u.rango, u.activo, u.fecha_registro;

-- Vista: Comisiones pendientes por usuario
CREATE OR REPLACE VIEW v_comisiones_pendientes AS
SELECT 
    u.id AS user_id,
    u.id_unico,
    u.nombre,
    u.apellido,
    SUM(c.monto) AS comisiones_pendientes,
    COUNT(*) AS num_comisiones
FROM users u
INNER JOIN comisiones c ON u.id = c.user_id
WHERE c.fecha >= NOW() - INTERVAL '30 days'
GROUP BY u.id, u.id_unico, u.nombre, u.apellido;

-- Vista: Retiros pendientes
CREATE OR REPLACE VIEW v_cobros_pendientes AS
SELECT 
    co.id,
    co.monto,
    co.wallet,
    co.fecha,
    u.id_unico,
    u.nombre,
    u.apellido,
    u.email
FROM cobros co
INNER JOIN users u ON co.user_id = u.id
WHERE co.estado = 'pendiente'
ORDER BY co.fecha ASC;

-- Vista: Depósitos pendientes
CREATE OR REPLACE VIEW v_depositos_pendientes AS
SELECT 
    d.id,
    d.pack_nombre,
    d.monto,
    d.wallet_destino,
    d.comprobante,
    d.metodo_pago,
    d.fecha,
    u.id_unico,
    u.nombre,
    u.apellido,
    u.email
FROM depositos d
INNER JOIN users u ON d.user_id = u.id
WHERE d.estado = 'pendiente'
ORDER BY d.fecha ASC;

-- =====================================================
-- FUNCIONES ALMACENADAS
-- =====================================================

-- Función: Calcular total de comisiones de un usuario
CREATE OR REPLACE FUNCTION fn_total_comisiones(p_user_id UUID)
RETURNS DECIMAL(10,2) AS $$
    SELECT COALESCE(SUM(monto), 0)
    FROM comisiones
    WHERE user_id = p_user_id;
$$ LANGUAGE SQL STABLE;

-- Función: Calcular total de rendimientos de un usuario
CREATE OR REPLACE FUNCTION fn_total_rendimientos(p_user_id UUID)
RETURNS DECIMAL(10,2) AS $$
    SELECT COALESCE(SUM(monto), 0)
    FROM rendimientos
    WHERE user_id = p_user_id;
$$ LANGUAGE SQL STABLE;

-- Función: Calcular inversión total de un usuario
CREATE OR REPLACE FUNCTION fn_inversion_total(p_user_id UUID)
RETURNS DECIMAL(10,2) AS $$
    SELECT COALESCE(SUM(monto), 0)
    FROM packs
    WHERE user_id = p_user_id;
$$ LANGUAGE SQL STABLE;

-- Función: Obtener referidos directos activos
CREATE OR REPLACE FUNCTION fn_referidos_directos_activos(p_user_id UUID)
RETURNS INT AS $$
    SELECT COUNT(*)::INT
    FROM users
    WHERE referido_por = p_user_id AND activo = TRUE;
$$ LANGUAGE SQL STABLE;

-- Función: Calcular volumen de red
CREATE OR REPLACE FUNCTION fn_volumen_red(p_user_id UUID)
RETURNS DECIMAL(12,2) AS $$
WITH RECURSIVE red AS (
    -- Referidos directos
    SELECT id, referido_por, 1 AS nivel
    FROM users
    WHERE referido_por = p_user_id
    
    UNION ALL
    
    -- Niveles subsecuentes (hasta nivel 10)
    SELECT u.id, u.referido_por, r.nivel + 1
    FROM users u
    INNER JOIN red r ON u.referido_por = r.id
    WHERE r.nivel < 10
)
SELECT COALESCE(SUM(p.monto), 0)
FROM red r
INNER JOIN packs p ON r.id = p.user_id
WHERE p.activo = TRUE;
$$ LANGUAGE SQL STABLE;

-- =====================================================
-- TRIGGERS
-- =====================================================

-- Trigger: Actualizar updated_at en users
CREATE OR REPLACE FUNCTION fn_update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_users_updated_at
    BEFORE UPDATE ON users
    FOR EACH ROW
    EXECUTE FUNCTION fn_update_updated_at();

-- Trigger: Desactivar packs anteriores al activar uno nuevo
CREATE OR REPLACE FUNCTION fn_desactivar_packs_anteriores()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.activo = TRUE THEN
        UPDATE packs
        SET activo = FALSE
        WHERE user_id = NEW.user_id
        AND id != NEW.id
        AND activo = TRUE;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_packs_activar
    BEFORE INSERT OR UPDATE ON packs
    FOR EACH ROW
    WHEN (NEW.activo = TRUE)
    EXECUTE FUNCTION fn_desactivar_packs_anteriores();

-- =====================================================
-- DATOS INICIALES
-- =====================================================

-- Insertar productos por defecto
INSERT INTO productos (nombre, descripcion, precio, stock, activo) VALUES
('Pack 50', 'Pack de inversión inicial', 50, 9999, TRUE),
('Pack 100', 'Pack de inversión básico', 100, 9999, TRUE),
('Pack 200', 'Pack de inversión intermedio', 200, 9999, TRUE),
('Pack 500', 'Pack de inversión avanzado', 500, 9999, TRUE),
('Pack 1k', 'Pack de inversión profesional', 1000, 9999, TRUE),
('Pack 2k', 'Pack de inversión premium', 2000, 9999, TRUE),
('Pack 5k', 'Pack de inversión exclusivo', 5000, 9999, TRUE),
('Pack 10k', 'Pack de inversión VIP', 10000, 9999, TRUE)
ON CONFLICT DO NOTHING;

-- Insertar rangos por defecto
INSERT INTO rangos (nombre, nivel, directos_requeridos, volumen_requerido, bono_porcentaje, color, descripcion) VALUES
('Sin Rango', 0, 0, 0, 0, '#94a3b8', 'Usuario nuevo'),
('Silver', 1, 3, 5000, 2, '#94a3b8', '3 directos y $5K en ventas'),
('Gold', 2, 5, 15000, 3, '#eab308', '5 directos y $15K en ventas'),
('Platinum', 3, 8, 50000, 4, '#06b6d4', '8 directos y $50K en ventas'),
('Ruby', 4, 12, 150000, 5, '#dc2626', '12 directos y $150K en ventas'),
('Emerald', 5, 20, 500000, 6, '#10b981', '20 directos y $500K en ventas'),
('Diamante', 6, 30, 1500000, 7, '#3b82f6', '30 directos y $1.5M en ventas'),
('Black', 7, 50, 5000000, 8, '#1f2937', '50 directos y $5M en ventas'),
('Crown Black', 8, 100, 15000000, 10, '#581c87', '100 directos y $15M en ventas')
ON CONFLICT (nombre) DO NOTHING;

-- Insertar configuración admin por defecto
INSERT INTO configuracion_admin (
    wallet_principal,
    comision_referido_directo,
    rendimiento_activo,
    porcentaje_rendimiento
) VALUES (
    'TYourWalletAddressHere',
    0.10,
    TRUE,
    0.01
)
ON CONFLICT DO NOTHING;

-- =====================================================
-- CONSULTAS ÚTILES PARA REPORTES
-- =====================================================

-- Total de usuarios registrados
-- SELECT COUNT(*) AS total_usuarios FROM users;

-- Total de usuarios activos
-- SELECT COUNT(*) AS usuarios_activos FROM users WHERE activo = TRUE;

-- Total invertido en la plataforma
-- SELECT SUM(monto) AS total_invertido FROM packs WHERE activo = TRUE;

-- Total de comisiones pagadas
-- SELECT SUM(monto) AS total_comisiones FROM comisiones;

-- Total de retiros completados
-- SELECT SUM(monto) AS total_retirado FROM cobros WHERE estado = 'completado';

-- Top 10 usuarios por inversión
-- SELECT 
--     u.id_unico,
--     u.nombre,
--     u.apellido,
--     SUM(p.monto) AS inversion_total
-- FROM users u
-- INNER JOIN packs p ON u.id = p.user_id
-- GROUP BY u.id, u.id_unico, u.nombre, u.apellido
-- ORDER BY inversion_total DESC
-- LIMIT 10;

-- Top 10 usuarios por comisiones ganadas
-- SELECT 
--     u.id_unico,
--     u.nombre,
--     u.apellido,
--     SUM(c.monto) AS comisiones_totales
-- FROM users u
-- INNER JOIN comisiones c ON u.id = c.user_id
-- GROUP BY u.id, u.id_unico, u.nombre, u.apellido
-- ORDER BY comisiones_totales DESC
-- LIMIT 10;

-- Distribución de usuarios por rango
-- SELECT 
--     rango,
--     COUNT(*) AS cantidad
-- FROM users
-- GROUP BY rango
-- ORDER BY cantidad DESC;

-- =====================================================
-- FIN DEL ESQUEMA SQL
-- =====================================================

-- NOTAS IMPORTANTES:
-- 1. Este esquema es equivalente al sistema KV Store actual
-- 2. NO es necesario para el funcionamiento actual
-- 3. Solo usar si se decide migrar a PostgreSQL/MySQL
-- 4. Las relaciones y constraints garantizan integridad de datos
-- 5. Las vistas facilitan consultas complejas
-- 6. Los triggers automatizan validaciones
-- 7. Las funciones optimizan cálculos repetitivos
