# 🚀 Flujo Completo del Sistema CRM - Liberty Finance

## 📋 Resumen del Sistema

Este documento describe el flujo completo del sistema CRM desde el registro hasta los retiros.

---

## 🔄 Flujo de Usuario (Paso a Paso)

### **1️⃣ Registro de Usuario**

```typescript
// El usuario se registra con o sin código de referido
const resultado = await authAPI.register({
  nombre: 'Juan',
  apellido: 'Pérez',
  email: 'juan@example.com',
  telefono: '+51999999999',
  ciudad: 'Lima',
  wallet: 'TXXXXXXXXXxxxxxxxxx', // Su wallet personal TRC20
  password: 'password123',
  referralCode: 'JUAN2024', // Su código único
  referidoPor: 'id-del-patrocinador' // OPCIONAL: ID del usuario que lo refirió
});
```

**Resultado:**
- ✅ Usuario creado con ID único (ej: `LF1234567890123`)
- ✅ Recibe 100 puntos de bienvenida
- ✅ Código de referido generado
- ❌ **AÚN NO PUEDE GANAR COMISIONES** (necesita comprar un pack)

---

### **2️⃣ Compra de Pack (Con Depósito)**

#### **Paso 2.1: Usuario selecciona un pack**

El usuario abre el diálogo de compra y selecciona entre:
- Pack 50 ($50)
- Pack 100 ($100)
- Pack 200 ($200)
- Pack 300 ($300)
- Pack 500 ($500)
- Pack 1k ($1,000)
- Pack 5k ($5,000)
- Pack 10k ($10,000)

#### **Paso 2.2: Se muestra la wallet del admin**

```typescript
// El sistema obtiene la wallet configurada por el admin
const config = await configuracionAPI.get();
// Muestra: config.walletPrincipal (ej: TXXXXXXXXXxxxxxxxxx)
```

**El usuario ve:**
1. ✅ Wallet del admin para transferir
2. ✅ Botón para copiar la wallet
3. ✅ Monto exacto a depositar
4. ✅ Instrucciones paso a paso

#### **Paso 2.3: Usuario hace el depósito**

El usuario:
1. Copia la wallet del admin
2. Abre su wallet (TronLink, Trust Wallet, etc.)
3. Envía exactamente el monto del pack en USDT (red TRC20)
4. Copia el hash de la transacción (opcional)

#### **Paso 2.4: Usuario confirma el depósito**

```typescript
const deposito = await depositosAPI.create({
  userId: user.id,
  packNombre: 'Pack 100',
  monto: 100,
  walletDestino: config.walletPrincipal,
  comprobante: '0xabcdef...' // Hash de transacción (opcional)
});
```

**Resultado:**
- ✅ Depósito registrado con estado `pendiente`
- ✅ Usuario ve mensaje: "Depósito en verificación (5-10 min)"
- 🔔 Notificación al admin sobre nuevo depósito

---

### **3️⃣ Verificación por el Administrador**

#### **Paso 3.1: Admin ve el depósito pendiente**

En el panel de admin, sección "Gestionar Depósitos":

```
📋 Depósitos Pendientes: 1

┌─────────────────────────────────────────┐
│ ⏱️ PENDIENTE                             │
│                                          │
│ Usuario: Juan Pérez                      │
│ Email: juan@example.com                  │
│ Pack: Pack 100                           │
│ Monto: $100 USDT                         │
│                                          │
│ Wallet del Usuario:                      │
│ TXXXXXXXXXxxxxxxxxx                      │
│                                          │
│ Hash: 0xabcdef...                        │
│                                          │
│ [✅ Aprobar] [❌ Rechazar]                │
└─────────────────────────────────────────┘
```

#### **Paso 3.2: Admin verifica en la blockchain**

El admin:
1. Ve el hash de transacción
2. Verifica en TronScan que la transacción existe
3. Confirma que el monto es correcto
4. Hace clic en "Aprobar"

#### **Paso 3.3: Sistema activa el pack automáticamente**

```typescript
// Al aprobar el depósito, el sistema:
await depositosAPI.update(depositoId, {
  estado: 'verificado',
  procesadoPor: 'admin-id'
});

// Automáticamente se ejecuta:
// 1. Crear el pack
const pack = await crm.createPack({
  userId: deposito.userId,
  nombre: deposito.packNombre,
  monto: deposito.monto,
  rendimientoDiario: 2 // 2% diario
});

// 2. Calcular comisiones de red
await crm.calcularComisionesRed(deposito.userId, deposito.monto);
```

**Resultado:**
- ✅ Pack activado para el usuario
- ✅ Comisiones de red calculadas (10 niveles)
- ✅ Bono de patrocinio del 10% al referidor directo
- ✅ Usuario puede empezar a ganar comisiones

---

### **4️⃣ Distribución de Comisiones**

#### **Ejemplo de distribución:**

Si Juan fue referido por María y compró Pack 100 ($100):

```
María (patrocinadora directa):
├─ Comisión Nivel 1: $8 (8%)
└─ Bono de Patrocinio: $10 (10%)
   TOTAL: $18

Si María fue referida por Pedro:
Pedro (nivel 2):
└─ Comisión Nivel 2: $6 (6%)

Y así sucesivamente hasta 10 niveles:
- Nivel 1: 8%  ($8)
- Nivel 2: 6%  ($6)
- Nivel 3: 4%  ($4)
- Nivel 4: 2%  ($2)
- Nivel 5: 1%  ($1)
- Nivel 6: 1%  ($1)
- Nivel 7: 1%  ($1)
- Nivel 8: 1%  ($1)
- Nivel 9: 0.5% ($0.50)
- Nivel 10: 0.5% ($0.50)
+ Bono patrocinio: 10% ($10)

TOTAL DISTRIBUIDO: $35 (35% del pack)
```

---

### **5️⃣ Usuario Solicita Retiro**

#### **Paso 5.1: Ver balance disponible**

```typescript
// El usuario ve sus comisiones totales
const { total } = await comisionesAPI.getTotalByUserId(userId);
// Resultado: $18 (por ejemplo)
```

#### **Paso 5.2: Solicitar retiro**

```typescript
const cobro = await cobrosAPI.create({
  userId: user.id,
  monto: 18,
  wallet: user.wallet // Su wallet personal
});
```

**Resultado:**
- ✅ Solicitud de retiro creada con estado `pendiente`
- ✅ Usuario ve: "Retiro en proceso (5-10 min)"
- 🔔 Notificación al admin sobre nuevo retiro

---

### **6️⃣ Procesamiento de Retiro por Admin**

#### **Paso 6.1: Admin ve la solicitud**

En el panel de admin, sección "Gestionar Retiros":

```
📋 Retiros Pendientes: 1

┌─────────────────────────────────────────┐
│ ⏱️ PENDIENTE                             │
│                                          │
│ Usuario: María García                    │
│ Email: maria@example.com                 │
│ Monto: $18 USDT                          │
│                                          │
│ Wallet de Destino (TRC20):               │
│ TYYYYYYYYYyyyyyyyyy                      │
│                                          │
│ [✅ Aprobar] [❌ Rechazar]                │
└─────────────────────────────────────────┘
```

#### **Paso 6.2: Admin procesa el pago**

El admin:
1. Copia la wallet del usuario
2. Envía el monto solicitado en USDT (TRC20)
3. Copia el hash de la transacción
4. Hace clic en "Aprobar"
5. Pega el hash de transacción (opcional)
6. Confirma

```typescript
await cobrosAPI.update(cobroId, {
  estado: 'completado',
  txHash: '0xabcdef...' // Hash de la transacción
});
```

**Resultado:**
- ✅ Retiro marcado como completado
- ✅ Usuario puede ver el hash de transacción
- ✅ Usuario recibe sus fondos en su wallet

---

## 👨‍💼 Panel de Administrador

### **Secciones principales:**

#### **1. Configuración de Wallet**
- Editar wallet principal para recibir depósitos
- Solo el admin puede cambiarla
- Se aplica inmediatamente a todos los usuarios

#### **2. Gestionar Depósitos**
- Ver todos los depósitos (pendientes, verificados, rechazados)
- Aprobar o rechazar depósitos
- Al aprobar: pack se activa automáticamente
- Al aprobar: comisiones se distribuyen automáticamente

#### **3. Gestionar Retiros**
- Ver todas las solicitudes de retiro
- Aprobar o rechazar retiros
- Ingresar hash de transacción
- Ver wallet de destino del usuario

#### **4. Estadísticas**
```typescript
const stats = await adminAPI.getEstadisticas();

// Retorna:
{
  totalUsuarios: 150,
  usuariosActivos: 142,
  totalInversiones: 45000,
  totalCobros: 12000,
  cobrosPendientes: 5,
  packsPorTipo: {
    'Pack 50': 10,
    'Pack 100': 25,
    'Pack 200': 30,
    // ...
  }
}
```

---

## 🔐 Validaciones del Sistema

### **Al registrar usuario:**
- ✅ Email único
- ✅ ID único generado automáticamente
- ✅ Referido válido (si aplica)

### **Al crear depósito:**
- ✅ Monto del pack válido
- ✅ Usuario existe
- ✅ Wallet admin configurada

### **Al verificar depósito:**
- ✅ Solo admin puede aprobar/rechazar
- ✅ Pack se crea solo si es verificado
- ✅ Comisiones se calculan automáticamente

### **Al solicitar retiro:**
- ✅ Usuario tiene saldo suficiente
- ✅ Monto mayor a 0
- ✅ Wallet válida

### **Al aprobar retiro:**
- ✅ Solo admin puede aprobar/rechazar
- ✅ Estado cambia a completado
- ✅ Hash de transacción opcional

---

## 📱 Componentes Creados

### **Usuario:**
- `ComprarPack.tsx` - Diálogo para comprar packs con depósito
- `HistorialDepositos.tsx` - Ver historial de depósitos y estados

### **Admin:**
- `GestionarDepositos.tsx` - Aprobar/rechazar depósitos
- `GestionarRetiros.tsx` - Aprobar/rechazar retiros
- `ConfiguracionWallet.tsx` - Configurar wallet principal

---

## 🎯 Flujo Visual Completo

```
👤 USUARIO                          👨‍💼 ADMIN
─────────────────────────────────────────────────────

1. Registro
   └─> ✅ Usuario creado
   
2. Seleccionar Pack
   └─> 💵 Ver wallet admin
   
3. Hacer depósito TRC20
   └─> 📝 Confirmar depósito
       └─> ⏱️ Estado: Pendiente ──────> 🔔 Notificación
                                           │
                                           ▼
                                       👀 Ver depósito
                                           │
                                           ▼
                                       ✅ Aprobar
                                           │
   ┌────────────────────────────────────────┘
   │
   ▼
4. ✅ Pack activado
   ├─> 💰 Comisiones distribuidas
   └─> 🎉 Puede ganar comisiones
   
5. 💵 Solicitar retiro
   └─> ⏱️ Estado: Pendiente ──────> 🔔 Notificación
                                           │
                                           ▼
                                       💸 Enviar USDT
                                           │
                                           ▼
                                       ✅ Aprobar
                                           │
   ┌────────────────────────────────────────┘
   │
   ▼
6. ✅ Retiro completado
   └─> 💰 Fondos recibidos
```

---

## 💡 Casos de Uso

### **Caso 1: Usuario nuevo sin referidor**
1. Se registra normalmente
2. No tiene `referidoPor`
3. Compra un pack
4. ✅ Pack activado
5. ❌ Nadie recibe comisiones por su compra

### **Caso 2: Usuario nuevo con referidor**
1. Usa código de Juan al registrarse
2. `referidoPor` = ID de Juan
3. Compra Pack 100
4. ✅ Pack activado
5. ✅ Juan recibe $18 ($8 + $10)
6. ✅ La red de Juan recibe comisiones

### **Caso 3: Usuario con red**
1. María tiene 5 referidos directos
2. Cada referido compra Pack 100
3. María recibe por cada uno:
   - $8 (comisión nivel 1)
   - $10 (bono patrocinio)
   - **Total: $18 × 5 = $90**

### **Caso 4: Red multinivel profunda**
1. Juan → María → Pedro → Ana → Luis
2. Luis compra Pack 100
3. Distribución:
   - Ana: $18 (nivel 1 + bono)
   - Pedro: $6 (nivel 2)
   - María: $4 (nivel 3)
   - Juan: $2 (nivel 4)

---

## ⚠️ Notas Importantes

1. **Wallet TRC20**: Solo USDT en red Tron (TRC20)
2. **Verificación manual**: Admin debe verificar depósitos y retiros
3. **Comisiones automáticas**: Se calculan al verificar el depósito
4. **Sin pack activo**: Usuario NO puede ganar comisiones
5. **Puntos de bienvenida**: 100 puntos al registrarse
6. **Tiempo de verificación**: 5-10 minutos (según disponibilidad admin)

---

## 🚀 Todo Listo para Usar

El sistema está completamente funcional y listo para integrar en tu aplicación. Todos los componentes están creados y la API está lista.

**Para implementar:**
1. Importa los componentes en tus vistas
2. Conecta con el hook `useAuth`
3. ¡Listo para usar!
