import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface DashboardData {
  usuario: any;
  pack: any;
  wallet: any;
  comisiones: any;
  rendimientos: any;
  red: any;
  _meta: any;
}

interface DashboardContextType {
  data: DashboardData | null;
  loading: boolean;
  error: string | null;
  refresh: () => Promise<void>;
  updateData: (newData: Partial<DashboardData>) => void;
}

const DashboardContext = createContext<DashboardContextType | undefined>(undefined);

export function DashboardProvider({ children, userId }: { children: ReactNode; userId: string }) {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadDashboard = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const startTime = Date.now();
      console.log(`⚡ [DashboardContext] Cargando datos del usuario ${userId}...`);
      
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-9f68532a/users/${userId}/dashboard-completo`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
            'Content-Type': 'application/json'
          }
        }
      );

      if (!response.ok) {
        throw new Error(`Error ${response.status}: ${response.statusText}`);
      }

      const dashboardData = await response.json();
      const loadTime = Date.now() - startTime;
      
      console.log(`✅ [DashboardContext] Datos cargados en ${loadTime}ms (Backend: ${dashboardData._meta?.loadTime}ms)`);
      console.log(`📊 [DashboardContext] Resumen:`, {
        pack: dashboardData.pack?.activo?.nombre || 'Sin pack',
        saldo: dashboardData.wallet?.saldoDisponible,
        directos: dashboardData.red?.directos?.total,
        redTotal: dashboardData.red?.completa?.total
      });
      
      setData(dashboardData);
      setError(null);
    } catch (err: any) {
      console.error('❌ [DashboardContext] Error al cargar dashboard:', err);
      setError(err.message || 'Error desconocido');
    } finally {
      setLoading(false);
    }
  };

  const refresh = async () => {
    console.log('🔄 [DashboardContext] Refrescando datos...');
    await loadDashboard();
  };

  const updateData = (newData: Partial<DashboardData>) => {
    setData(prev => prev ? { ...prev, ...newData } : null);
  };

  useEffect(() => {
    if (userId) {
      loadDashboard();
    }
  }, [userId]);

  return (
    <DashboardContext.Provider value={{ data, loading, error, refresh, updateData }}>
      {children}
    </DashboardContext.Provider>
  );
}

export function useDashboard() {
  const context = useContext(DashboardContext);
  if (context === undefined) {
    throw new Error('useDashboard debe usarse dentro de un DashboardProvider');
  }
  return context;
}
