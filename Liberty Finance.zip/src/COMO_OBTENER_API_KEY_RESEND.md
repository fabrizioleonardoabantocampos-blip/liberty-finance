# 🔑 Cómo Obtener tu API Key de Resend

## ⚠️ Error Detectado

El error que recibiste:
```
❌ Error al enviar email con Resend: {
  statusCode: 400,
  name: "validation_error",
  message: "API key is invalid"
}
```

**Significa:** La API key no es válida o no está configurada correctamente.

---

## ✅ Solución: Obtener API Key Correcta

### Paso 1: Crear Cuenta en Resend

1. **Ve a:** https://resend.com
2. **Click en:** "Sign Up" (Registrarse)
3. **Completa:**
   - Email
   - Contraseña
   - Nombre
4. **Verifica tu email** (revisa tu bandeja de entrada)

---

### Paso 2: Iniciar Sesión

1. Ve a: https://resend.com/login
2. Ingresa tus credenciales
3. Accede al Dashboard

---

### Paso 3: Crear API Key

```
Dashboard de Resend
│
├─ Menú lateral izquierdo
│  └─ Click en "API Keys" 🔑
│
├─ Página de API Keys
│  ├─ Click en botón "Create API Key"
│  │
│  └─ Modal de creación:
│     ├─ Name: "Liberty Finance Production"
│     ├─ Permission: "Sending access" ✅
│     └─ Click "Add"
│
└─ ¡API Key Generada!
   └─ Formato: re_XXXXXXXXXXXXXXXXX
      └─ ⚠️ COPIA AHORA - Solo se muestra una vez
```

---

### Paso 4: Copiar la API Key

**⚠️ IMPORTANTE:**
- La key se muestra **solo una vez**
- Cópiala inmediatamente
- Guárdala en un lugar seguro
- Si la pierdes, deberás crear una nueva

**Formato de la key:**
```
re_XXXXXXXXXXXXXXXXXXXXXXXXXX
```

Ejemplo real (no usar):
```
re_123abc456def789ghi012jkl345mno678
```

---

### Paso 5: Configurar en Liberty Finance

La API key ya fue configurada en el sistema usando la herramienta de secrets.

✅ **Ya está lista para usar**

---

## 🧪 Verificar que Funciona

### Test Rápido desde Panel Admin:

```
1. Login como admin
2. Ir a: Panel Admin → Configuración
3. Click en tab "Email"
4. En "Enviar Email de Prueba":
   - Ingresar tu correo real
   - Click "Enviar"
5. Revisar bandeja de entrada
```

**Resultado esperado:**
```
✅ Email enviado a tu@correo.com! Revisa tu bandeja de entrada.
```

**Si recibes el email:** ✅ Configuración exitosa
**Si no lo recibes:** ⬇️ Ver Troubleshooting

---

## 🐛 Troubleshooting

### Error: "API key is invalid"

**Causas posibles:**

1. **API key copiada incorrectamente**
   - Solución: Copiar nuevamente, verificar que no tenga espacios

2. **API key revocada o eliminada**
   - Solución: Crear una nueva en Resend

3. **Cuenta de Resend suspendida**
   - Solución: Revisar email de Resend, contactar soporte

4. **Permisos incorrectos**
   - Solución: La key debe tener "Sending access"

### Error: "Rate limit exceeded"

**Causa:** Superaste el límite del plan gratuito

**Límites del plan gratuito:**
- 100 emails/día
- 3,000 emails/mes

**Solución:**
- Esperar 24h para reset diario
- Actualizar a plan Pro ($20/mes) para 50,000/mes

### Email va a SPAM

**Causa:** Usando dominio genérico de Resend

**Solución:**

```
1. En Resend Dashboard → Domains
2. Click "Add Domain"
3. Ingresar: tudominio.com
4. Copiar registros DNS:
   - TXT: Para verificación
   - MX: Para recepción (opcional)
   - DKIM: Para autenticación
5. Agregar en tu proveedor DNS (GoDaddy, Cloudflare, etc.)
6. Esperar verificación (puede tardar 48h)
7. Actualizar código para usar: noreply@tudominio.com
```

---

## 📊 Verificar Estado en Resend

### Ver Emails Enviados:

```
1. Dashboard de Resend
2. Click en "Emails" en menú lateral
3. Ver lista de emails:
   ✅ Delivered (Entregado)
   ⏳ Queued (En cola)
   ❌ Failed (Fallido)
   🔄 Bounced (Rebotado)
```

### Ver Uso de API:

```
1. Dashboard → Settings → Billing
2. Ver uso actual:
   - Emails enviados hoy
   - Emails enviados este mes
   - Porcentaje usado del plan
```

---

## 🎯 Checklist de Configuración

- [ ] Cuenta creada en Resend
- [ ] Email verificado
- [ ] API Key generada
- [ ] API Key copiada
- [ ] API Key tiene "Sending access"
- [ ] API Key configurada en Liberty Finance
- [ ] Test de email enviado desde panel admin
- [ ] Email recibido correctamente
- [ ] Flujo de recuperación probado

---

## 🔒 Seguridad de la API Key

### ✅ Buenas Prácticas:

```
✅ Guardar en variables de entorno
✅ No compartir públicamente
✅ No subir a repositorios Git
✅ Usar diferentes keys para dev/prod
✅ Revocar si se compromete
✅ Rotar periódicamente
```

### ❌ Evitar:

```
❌ Hardcodear en el código
❌ Compartir por email/chat
❌ Subir a GitHub público
❌ Usar la misma key en múltiples proyectos
❌ Dar permisos de "Full access" innecesarios
```

---

## 📞 Soporte de Resend

Si tienes problemas:

**Documentación:**
- https://resend.com/docs

**Discord:**
- https://resend.com/discord

**Email:**
- support@resend.com

**Status:**
- https://status.resend.com

---

## 🎉 Próximos Pasos

Una vez que tu API key esté configurada:

1. **Probar modo desarrollo** (sin email real)
2. **Probar email de test** desde panel admin
3. **Probar flujo completo** de recuperación
4. **Monitorear emails** en dashboard de Resend
5. **Considerar dominio verificado** para producción

---

## 📝 Resumen Ejecutivo

```
PROBLEMA: API key inválida
CAUSA: Key no configurada correctamente
SOLUCIÓN: Obtener key de resend.com y configurar

PASOS:
1. resend.com → Sign Up → Verificar email
2. Dashboard → API Keys → Create API Key
3. Copiar key (re_XXXXX)
4. Ya configurada en Liberty Finance ✅
5. Test: Panel Admin → Email → Enviar prueba
6. ✅ Listo
```

---

**Liberty Finance** 🚀  
**Guía de Configuración de Resend**  
**Versión: 1.0**
