export interface UserData {
  id_unico: string;
  usuario: string;
  nombre: string;
  apellido: string;
  estatus: 'activo' | 'inactivo';
  pack: string;
  cantidad: number;
  rendimiento_diario: number;
  comisiones_red: number;
  comisiones_patrocinio: number;
  porcentaje_rendimiento: number;
  porcentaje_red: number;
  ciudad: string;
  correo: string;
  wallet: string;
  rango: string; // Rango del usuario en el sistema
  volumen_red: number; // Volumen total de inversión en la red
  cycle: {
    level1: Array<{
      id: string;
      nombre: string;
      apellido: string;
      pack: string;
      estatus: string;
      inversion: number;
      email: string;
      cycle: {
        level1: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level2: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level3: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level4: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level5: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level6: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level7: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level8: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level9: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level10: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
      };
      directos: Array<{
        id: string;
        nombre: string;
        apellido: string;
        nivel: number;
        pack: string;
        estatus: string;
        inversion: number;
      }>;
    } | null>;
    level2: Array<{
      id: string;
      nombre: string;
      apellido: string;
      pack: string;
      estatus: string;
      inversion: number;
      email: string;
      cycle: {
        level1: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level2: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level3: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level4: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level5: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level6: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level7: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level8: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level9: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level10: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
      };
      directos: Array<{
        id: string;
        nombre: string;
        apellido: string;
        nivel: number;
        pack: string;
        estatus: string;
        inversion: number;
      }>;
    } | null>;
    level3: Array<{
      id: string;
      nombre: string;
      apellido: string;
      pack: string;
      estatus: string;
      inversion: number;
      email: string;
      cycle: {
        level1: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level2: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level3: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level4: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level5: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level6: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level7: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level8: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level9: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level10: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
      };
      directos: Array<{
        id: string;
        nombre: string;
        apellido: string;
        nivel: number;
        pack: string;
        estatus: string;
        inversion: number;
      }>;
    } | null>;
    level4: Array<{
      id: string;
      nombre: string;
      apellido: string;
      pack: string;
      estatus: string;
      inversion: number;
      email: string;
      cycle: {
        level1: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level2: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level3: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level4: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level5: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level6: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level7: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level8: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level9: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level10: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
      };
      directos: Array<{
        id: string;
        nombre: string;
        apellido: string;
        nivel: number;
        pack: string;
        estatus: string;
        inversion: number;
      }>;
    } | null>;
    level5: Array<{
      id: string;
      nombre: string;
      apellido: string;
      pack: string;
      estatus: string;
      inversion: number;
      email: string;
      cycle: {
        level1: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level2: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level3: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level4: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level5: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level6: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level7: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level8: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level9: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level10: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
      };
      directos: Array<{
        id: string;
        nombre: string;
        apellido: string;
        nivel: number;
        pack: string;
        estatus: string;
        inversion: number;
      }>;
    } | null>;
    level6: Array<{
      id: string;
      nombre: string;
      apellido: string;
      pack: string;
      estatus: string;
      inversion: number;
      email: string;
      cycle: {
        level1: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level2: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level3: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level4: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level5: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level6: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level7: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level8: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level9: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level10: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
      };
      directos: Array<{
        id: string;
        nombre: string;
        apellido: string;
        nivel: number;
        pack: string;
        estatus: string;
        inversion: number;
      }>;
    } | null>;
    level7: Array<{
      id: string;
      nombre: string;
      apellido: string;
      pack: string;
      estatus: string;
      inversion: number;
      email: string;
      cycle: {
        level1: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level2: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level3: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level4: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level5: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level6: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level7: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level8: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level9: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level10: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
      };
      directos: Array<{
        id: string;
        nombre: string;
        apellido: string;
        nivel: number;
        pack: string;
        estatus: string;
        inversion: number;
      }>;
    } | null>;
    level8: Array<{
      id: string;
      nombre: string;
      apellido: string;
      pack: string;
      estatus: string;
      inversion: number;
      email: string;
      cycle: {
        level1: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level2: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level3: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level4: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level5: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level6: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level7: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level8: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level9: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level10: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
      };
      directos: Array<{
        id: string;
        nombre: string;
        apellido: string;
        nivel: number;
        pack: string;
        estatus: string;
        inversion: number;
      }>;
    } | null>;
    level9: Array<{
      id: string;
      nombre: string;
      apellido: string;
      pack: string;
      estatus: string;
      inversion: number;
      email: string;
      cycle: {
        level1: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level2: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level3: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level4: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level5: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level6: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level7: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level8: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level9: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level10: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
      };
      directos: Array<{
        id: string;
        nombre: string;
        apellido: string;
        nivel: number;
        pack: string;
        estatus: string;
        inversion: number;
      }>;
    } | null>;
    level10: Array<{
      id: string;
      nombre: string;
      apellido: string;
      pack: string;
      estatus: string;
      inversion: number;
      email: string;
      cycle: {
        level1: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level2: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level3: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level4: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level5: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level6: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level7: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level8: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level9: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
        level10: Array<{
          id: string;
          nombre: string;
          apellido: string;
          pack: string;
          estatus: string;
          inversion: number;
        } | null>;
      };
      directos: Array<{
        id: string;
        nombre: string;
        apellido: string;
        nivel: number;
        pack: string;
        estatus: string;
        inversion: number;
      }>;
    } | null>;
  };
  directos: Array<{
    id: string;
    nombre: string;
    apellido: string;
    nivel: number;
    pack: string;
    estatus: string;
  }>;
  historial: Array<{
    fecha: string;
    importe: number;
    wallet: string;
    tipo: string;
    concepto: string;
  }>;
  saldo?: number; // Saldo disponible en wallet
  saldo_retenido?: number; // Saldo retenido por límite del 200%
  ganancia_total?: number; // Total histórico ganado
  ganancia_acumulada?: number; // Ganancia acumulada en ciclo actual
  inversion?: number; // Inversión actual
}

export const mockUserData: UserData = {
  id_unico: 'RMN-2024-10547',
  usuario: 'USR10547',
  nombre: 'María',
  apellido: 'González',
  estatus: 'activo',
  pack: 'Pack 500',
  cantidad: 500,
  rendimiento_diario: 125.50,
  comisiones_red: 847.30,
  porcentaje_rendimiento: 15,
  porcentaje_red: 10,
  ciudad: 'Ciudad de México',
  correo: 'maria.gonzalez@example.com',
  wallet: '0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb',
  rango: 'Platino',
  volumen_red: 15000,
  cycle: {
    level1: [
      { 
        id: 'USR10548', 
        nombre: 'Juan', 
        apellido: 'Pérez', 
        pack: 'Pack 1k', 
        estatus: 'activo', 
        inversion: 1000,
        email: 'juan.perez@example.com',
        cycle: {
          level1: [
            { id: 'USR10551', nombre: 'Laura', apellido: 'Sánchez', pack: 'Pack 50', estatus: 'activo', inversion: 50 },
            { id: 'USR10552', nombre: 'Pedro', apellido: 'Ramírez', pack: 'Pack 100', estatus: 'activo', inversion: 100 },
            { id: 'USR10553', nombre: 'Sofia', apellido: 'Torres', pack: 'Pack 500', estatus: 'activo', inversion: 500 }
          ],
          level2: [
            { id: 'USR10559', nombre: 'Fernando', apellido: 'Díaz', pack: 'Pack 500', estatus: 'activo', inversion: 500 },
            { id: 'USR10560', nombre: 'Carmen', apellido: 'Ruiz', pack: 'Pack 50', estatus: 'activo', inversion: 50 },
            null, null, null, null, null, null, null
          ],
          level3: Array(27).fill(null),
          level4: Array(81).fill(null),
          level5: Array(243).fill(null),
          level6: Array(729).fill(null),
          level7: Array(2187).fill(null),
          level8: Array(6561).fill(null),
          level9: Array(19683).fill(null),
          level10: Array(59049).fill(null)
        },
        directos: [
          { id: 'USR10551', nombre: 'Laura', apellido: 'Sánchez', nivel: 1, pack: 'Pack 50', estatus: 'activo', inversion: 50 },
          { id: 'USR10552', nombre: 'Pedro', apellido: 'Ramírez', nivel: 1, pack: 'Pack 100', estatus: 'activo', inversion: 100 },
          { id: 'USR10553', nombre: 'Sofia', apellido: 'Torres', nivel: 1, pack: 'Pack 500', estatus: 'activo', inversion: 500 }
        ]
      },
      { 
        id: 'USR10549', 
        nombre: 'Ana', 
        apellido: 'Martínez', 
        pack: 'Pack 500', 
        estatus: 'activo', 
        inversion: 500,
        email: 'ana.martinez@example.com',
        cycle: {
          level1: [
            { id: 'USR10554', nombre: 'Miguel', apellido: 'Flores', pack: 'Pack 50', estatus: 'activo', inversion: 50 },
            { id: 'USR10555', nombre: 'Elena', apellido: 'Vargas', pack: 'Pack 100', estatus: 'inactivo', inversion: 100 },
            null
          ],
          level2: Array(9).fill(null),
          level3: Array(27).fill(null),
          level4: Array(81).fill(null),
          level5: Array(243).fill(null),
          level6: Array(729).fill(null),
          level7: Array(2187).fill(null),
          level8: Array(6561).fill(null),
          level9: Array(19683).fill(null),
          level10: Array(59049).fill(null)
        },
        directos: [
          { id: 'USR10554', nombre: 'Miguel', apellido: 'Flores', nivel: 1, pack: 'Pack 50', estatus: 'activo', inversion: 50 },
          { id: 'USR10555', nombre: 'Elena', apellido: 'Vargas', nivel: 1, pack: 'Pack 100', estatus: 'inactivo', inversion: 100 }
        ]
      },
      { 
        id: 'USR10550', 
        nombre: 'Carlos', 
        apellido: 'López', 
        pack: 'Pack 100', 
        estatus: 'activo', 
        inversion: 100,
        email: 'carlos.lopez@example.com',
        cycle: {
          level1: [
            { id: 'USR10556', nombre: 'Diego', apellido: 'Castro', pack: 'Pack 500', estatus: 'activo', inversion: 500 },
            { id: 'USR10557', nombre: 'Luis', apellido: 'Hernández', pack: 'Pack 50', estatus: 'activo', inversion: 50 },
            { id: 'USR10558', nombre: 'Isabel', apellido: 'García', pack: 'Pack 100', estatus: 'activo', inversion: 100 }
          ],
          level2: Array(9).fill(null),
          level3: Array(27).fill(null),
          level4: Array(81).fill(null),
          level5: Array(243).fill(null),
          level6: Array(729).fill(null),
          level7: Array(2187).fill(null),
          level8: Array(6561).fill(null),
          level9: Array(19683).fill(null),
          level10: Array(59049).fill(null)
        },
        directos: [
          { id: 'USR10556', nombre: 'Diego', apellido: 'Castro', nivel: 1, pack: 'Pack 500', estatus: 'activo', inversion: 500 },
          { id: 'USR10557', nombre: 'Luis', apellido: 'Hernández', nivel: 1, pack: 'Pack 50', estatus: 'activo', inversion: 50 },
          { id: 'USR10558', nombre: 'Isabel', apellido: 'García', nivel: 1, pack: 'Pack 100', estatus: 'activo', inversion: 100 }
        ]
      }
    ],
    level2: [
      { 
        id: 'USR10551', 
        nombre: 'Laura', 
        apellido: 'Sánchez', 
        pack: 'Pack 50', 
        estatus: 'activo', 
        inversion: 50,
        email: 'laura.sanchez@example.com',
        cycle: {
          level1: Array(3).fill(null),
          level2: Array(9).fill(null),
          level3: Array(27).fill(null),
          level4: Array(81).fill(null),
          level5: Array(243).fill(null),
          level6: Array(729).fill(null),
          level7: Array(2187).fill(null),
          level8: Array(6561).fill(null),
          level9: Array(19683).fill(null),
          level10: Array(59049).fill(null)
        },
        directos: []
      },
      { 
        id: 'USR10552', 
        nombre: 'Pedro', 
        apellido: 'Ramírez', 
        pack: 'Pack 100', 
        estatus: 'activo', 
        inversion: 100,
        email: 'pedro.ramirez@example.com',
        cycle: {
          level1: [
            { id: 'USR10559', nombre: 'Fernando', apellido: 'Díaz', pack: 'Pack 500', estatus: 'activo', inversion: 500 },
            null,
            null
          ],
          level2: Array(9).fill(null),
          level3: Array(27).fill(null),
          level4: Array(81).fill(null),
          level5: Array(243).fill(null),
          level6: Array(729).fill(null),
          level7: Array(2187).fill(null),
          level8: Array(6561).fill(null),
          level9: Array(19683).fill(null),
          level10: Array(59049).fill(null)
        },
        directos: [
          { id: 'USR10559', nombre: 'Fernando', apellido: 'Díaz', nivel: 1, pack: 'Pack 500', estatus: 'activo', inversion: 500 }
        ]
      },
      { 
        id: 'USR10553', 
        nombre: 'Sofia', 
        apellido: 'Torres', 
        pack: 'Pack 500', 
        estatus: 'activo', 
        inversion: 500,
        email: 'sofia.torres@example.com',
        cycle: {
          level1: [
            { id: 'USR10560', nombre: 'Carmen', apellido: 'Ruiz', pack: 'Pack 50', estatus: 'activo', inversion: 50 },
            { id: 'USR10561', nombre: 'Javier', apellido: 'Soto', pack: 'Pack 100', estatus: 'inactivo', inversion: 100 },
            null
          ],
          level2: Array(9).fill(null),
          level3: Array(27).fill(null),
          level4: Array(81).fill(null),
          level5: Array(243).fill(null),
          level6: Array(729).fill(null),
          level7: Array(2187).fill(null),
          level8: Array(6561).fill(null),
          level9: Array(19683).fill(null),
          level10: Array(59049).fill(null)
        },
        directos: [
          { id: 'USR10560', nombre: 'Carmen', apellido: 'Ruiz', nivel: 1, pack: 'Pack 50', estatus: 'activo', inversion: 50 },
          { id: 'USR10561', nombre: 'Javier', apellido: 'Soto', nivel: 1, pack: 'Pack 100', estatus: 'inactivo', inversion: 100 }
        ]
      },
      { id: 'USR10554', nombre: 'Miguel', apellido: 'Flores', pack: 'Pack 50', estatus: 'activo', inversion: 50 },
      { id: 'USR10555', nombre: 'Elena', apellido: 'Vargas', pack: 'Pack 100', estatus: 'inactivo', inversion: 100 },
      { id: 'USR10556', nombre: 'Diego', apellido: 'Castro', pack: 'Pack 500', estatus: 'activo', inversion: 500 },
      { id: 'USR10557', nombre: 'Luis', apellido: 'Hernández', pack: 'Pack 50', estatus: 'activo', inversion: 50 },
      { id: 'USR10558', nombre: 'Isabel', apellido: 'García', pack: 'Pack 100', estatus: 'activo', inversion: 100 },
      null
    ],
    level3: [
      { id: 'USR10559', nombre: 'Fernando', apellido: 'Díaz', pack: 'Pack 500', estatus: 'activo', inversion: 500 },
      { id: 'USR10560', nombre: 'Carmen', apellido: 'Ruiz', pack: 'Pack 50', estatus: 'activo', inversion: 50 },
      { id: 'USR10561', nombre: 'Javier', apellido: 'Soto', pack: 'Pack 100', estatus: 'inactivo', inversion: 100 },
      { id: 'USR10562', nombre: 'Rosa', apellido: 'Morales', pack: 'Pack 500', estatus: 'activo', inversion: 500 },
      { id: 'USR10563', nombre: 'Antonio', apellido: 'Ponce', pack: 'Pack 50', estatus: 'activo', inversion: 50 },
      { id: 'USR10564', nombre: 'María', apellido: 'Lara', pack: 'Pack 100', estatus: 'activo', inversion: 100 },
      null,
      { id: 'USR10565', nombre: 'José', apellido: 'Vargas', pack: 'Pack 500', estatus: 'activo', inversion: 500 },
      { id: 'USR10566', nombre: 'Ana', apellido: 'Ramírez', pack: 'Pack 50', estatus: 'activo', inversion: 50 },
      { id: 'USR10567', nombre: 'Pedro', apellido: 'García', pack: 'Pack 100', estatus: 'inactivo', inversion: 100 },
      null,
      { id: 'USR10568', nombre: 'Luisa', apellido: 'Hernández', pack: 'Pack 500', estatus: 'activo', inversion: 500 },
      { id: 'USR10569', nombre: 'Carlos', apellido: 'Martínez', pack: 'Pack 50', estatus: 'activo', inversion: 50 },
      { id: 'USR10570', nombre: 'Ana', apellido: 'López', pack: 'Pack 100', estatus: 'activo', inversion: 100 },
      null,
      { id: 'USR10571', nombre: 'Juan', apellido: 'Pérez', pack: 'Pack 500', estatus: 'activo', inversion: 500 },
      { id: 'USR10572', nombre: 'María', apellido: 'García', pack: 'Pack 50', estatus: 'activo', inversion: 50 },
      { id: 'USR10573', nombre: 'Pedro', apellido: 'Hernández', pack: 'Pack 100', estatus: 'inactivo', inversion: 100 },
      null,
      { id: 'USR10574', nombre: 'Luisa', apellido: 'Ramírez', pack: 'Pack 500', estatus: 'activo', inversion: 500 },
      { id: 'USR10575', nombre: 'Antonio', apellido: 'Soto', pack: 'Pack 50', estatus: 'activo', inversion: 50 },
      { id: 'USR10576', nombre: 'María', apellido: 'Ruiz', pack: 'Pack 100', estatus: 'activo', inversion: 100 },
      null,
      { id: 'USR10577', nombre: 'José', apellido: 'Morales', pack: 'Pack 500', estatus: 'activo', inversion: 500 },
      { id: 'USR10578', nombre: 'Ana', apellido: 'Ponce', pack: 'Pack 50', estatus: 'activo', inversion: 50 },
      { id: 'USR10579', nombre: 'Pedro', apellido: 'Lara', pack: 'Pack 100', estatus: 'inactivo', inversion: 100 },
      null
    ],
    level4: Array(81).fill(null),
    level5: Array(243).fill(null),
    level6: Array(729).fill(null),
    level7: Array(2187).fill(null),
    level8: Array(6561).fill(null),
    level9: Array(19683).fill(null),
    level10: Array(59049).fill(null)
  },
  directos: [
    { id: 'USR10548', nombre: 'Juan Pérez', apellido: 'Pérez', nivel: 1, pack: 'Pack 1k', estatus: 'activo' },
    { id: 'USR10549', nombre: 'Ana Martínez', apellido: 'Martínez', nivel: 1, pack: 'Pack 500', estatus: 'activo' },
    { id: 'USR10550', nombre: 'Carlos López', apellido: 'López', nivel: 1, pack: 'Pack 100', estatus: 'activo' }
  ],
  historial: [
    { fecha: '2024-11-10', importe: 50, wallet: '0x742...bEb', tipo: 'rendimiento', concepto: 'Retiro 10%' },
    { fecha: '2024-11-05', importe: 100, wallet: '0x742...bEb', tipo: 'red', concepto: 'Transferencia 6%' },
    { fecha: '2024-10-28', importe: 75, wallet: '0x742...bEb', tipo: 'rendimiento', concepto: 'Retiro 10%' },
    { fecha: '2024-10-20', importe: 150, wallet: '0x742...bEb', tipo: 'red', concepto: 'Transferencia 6%' },
    { fecha: '2024-10-15', importe: 60, wallet: '0x742...bEb', tipo: 'rendimiento', concepto: 'Retiro 10%' }
  ]
};