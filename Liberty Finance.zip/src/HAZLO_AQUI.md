# 🎯 MIGRAR NEXXFY CRM → LIBERTY FINANCE

## ⚡ MÉTODO MÁS FÁCIL (Recomendado)

### PASO 1: Abre el archivo HTML

1. Busca el archivo: **`migracion-simple.html`** en esta carpeta
2. Haz **doble clic** para abrirlo en tu navegador
3. Verás un formulario bonito 👇

```
┌─────────────────────────────────────┐
│   🚀 Migración de Datos             │
│   Nexxfy CRM → Liberty Finance      │
│                                     │
│   🔵 ORIGEN: Nexxfy CRM             │
│   [Project ID]                      │
│   [Anon Key]                        │
│                                     │
│           ↓                         │
│                                     │
│   🟢 DESTINO: Liberty Finance       │
│   [Project ID]                      │
│   [Anon Key]                        │
│                                     │
│   [🚀 Iniciar Migración]            │
└─────────────────────────────────────┘
```

### PASO 2: Llena el formulario

Necesitas 4 datos:

#### 🔵 De NEXXFY CRM (origen):

1. Ve a: https://supabase.com/dashboard
2. Selecciona tu proyecto **Nexxfy CRM**
3. Ve a **Settings** → **API**
4. Copia:
   - **Project URL** (la parte entre `https://` y `.supabase.co`)
   - **anon public** key

#### 🟢 De LIBERTY FINANCE (destino):

1. En el mismo dashboard de Supabase
2. Selecciona tu proyecto **Liberty Finance**
3. Ve a **Settings** → **API**
4. Copia:
   - **Project URL** (la parte entre `https://` y `.supabase.co`)
   - **anon public** key

### PASO 3: Haz clic en "Iniciar Migración"

- Espera 30-60 segundos
- Verás: "🎉 ¡Migración Completada!"
- Se descargará un backup automáticamente

---

## 🚨 SI SALE ERROR

### Error: "Failed to fetch" o "Error 404"

**Causa:** Falta agregar el código de backup al servidor

**Solución:**

1. Abre el archivo: **`/COPIAR_Y_PEGAR_EN_INDEX.txt`**
2. Copia TODO el contenido
3. Ve a Supabase Dashboard del proyecto **Nexxfy CRM**
4. Ve a: **Edge Functions** → **server** → **index.tsx**
5. Busca la línea: `// RUTAS DE DOCUMENTOS LEGALES` (línea ~1094)
6. **PEGA el código ANTES de esa línea**
7. Guarda (Ctrl+S o Cmd+S)
8. **REPITE lo mismo en el proyecto Liberty Finance**
9. Espera 2-3 minutos
10. Intenta migrar de nuevo

### Error: "Invalid credentials" o "Unauthorized"

**Causa:** Las credenciales están mal

**Solución:**

- Verifica que copiaste el **anon public** key (NO la service_role key)
- Verifica que el Project ID esté correcto
- NO incluyas `https://` ni `.supabase.co`, solo el ID

### Error: "Formato de backup inválido"

**Causa:** La base origen no tiene las rutas de backup

**Solución:** Sigue los pasos de "Failed to fetch" arriba

---

## 📱 MÉTODO ALTERNATIVO: Con la Interfaz Visual

Si prefieres usar la interfaz de la app:

1. Abre tu aplicación Liberty Finance
2. Agrega al final de la URL: `?migracion=true`
3. Ejemplo: `https://tu-app.com?migracion=true`
4. Sigue los pasos en pantalla

---

## 📋 QUÉ SE VA A MIGRAR

✅ **Todos los usuarios** con sus datos  
✅ **Todos los depósitos** (pendientes, aprobados, rechazados)  
✅ **Todos los packs** activos  
✅ **Todas las comisiones** generadas  
✅ **Todos los retiros** (pendientes, aprobados, completados)  
✅ **Productos** (los 8 packs de Liberty)  
✅ **Rangos** (los 8 niveles)  
✅ **Puntos** de cada usuario  
✅ **Configuración** del sistema  

---

## ⏱️ TIEMPO ESTIMADO

- **Agregar código:** 2-3 minutos (una sola vez)
- **Llenar formulario:** 1 minuto
- **Migración automática:** 30-60 segundos

**Total:** Menos de 5 minutos ⚡

---

## 🎯 RESUMEN ULTRA RÁPIDO

```bash
1. Abre: migracion-simple.html
2. Llena los 4 campos
3. Clic en "Iniciar Migración"
4. ¡Listo! 🎉
```

---

## 📞 ¿NECESITAS AYUDA?

Dime exactamente qué error sale y te ayudo inmediatamente:

- "Sale error 404"
- "Sale failed to fetch"
- "No encuentro el archivo HTML"
- "No sé dónde pegar el código"

¡Estoy aquí para ayudarte! 😊

---

**Fecha:** 2025-11-19  
**Versión:** 1.0 (HTML Simple)  
**Dificultad:** ⭐ Muy fácil
