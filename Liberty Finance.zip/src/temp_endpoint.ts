// 🚀 ENDPOINT SUPER OPTIMIZADO V2: Dashboard Completo (SIN cargar todos los usuarios)
app.get("/make-server-9f68532a/users/:userId/dashboard-completo", async (c) => {
  try {
    const userId = c.req.param('userId');
    
    // 🚀 VERIFICAR CACHÉ DE DASHBOARD PRIMERO
    const cachedDashboard = cacheDashboards.get(userId);
    if (cachedDashboard && (Date.now() - cachedDashboard.timestamp < DASHBOARD_CACHE_TTL)) {
      console.log(`⚡ [CACHE HIT] Dashboard cargado desde caché para: ${userId} (${Date.now() - cachedDashboard.timestamp}ms de antigüedad)`);
      return c.json(cachedDashboard.data);
    }
    
    console.log(`⚡ [v2025-OPTIMIZADO-V2] Usando nueva función optimizada SIN getAllUsers() para ${userId}...`);
    
    const startTime = Date.now();
    
    // 🚀 NUEVA VERSIÓN: Usar función optimizada que NO carga todos los usuarios
    const dashboardData = await withTimeout(
      crm.getDashboardDataOptimizado(userId),
      30000, // 30 segundos timeout
      null
    );
    
    if (!dashboardData) {
      throw new Error('Timeout al cargar dashboard');
    }
    
    const loadTime = Date.now() - startTime;
    console.log(`✅ [OPTIMIZADO V2] Dashboard completo cargado en ${loadTime}ms (sin getAllUsers)`);
    
    // Formatear respuesta en el formato esperado por el frontend
    const response = {
      usuario: dashboardData.usuario,
      pack: {
        activo: dashboardData.pack.activo ? {
          id: dashboardData.pack.activo.id,
          nombre: dashboardData.pack.activo.nombre,
          monto: dashboardData.pack.activo.monto,
          fechaActivacion: dashboardData.pack.activo.fechaCompra,
          completado: dashboardData.pack.completado
        } : null,
        inversionTotal: dashboardData.pack.inversionTotal,
        todosLosPacks: dashboardData.pack.todosLosPacks.map((p: any) => ({
          id: p.id,
          nombre: p.nombre,
          monto: p.monto,
          activo: p.activo,
          fechaActivacion: p.fechaCompra
        }))
      },
      wallet: dashboardData.wallet,
      comisiones: dashboardData.comisiones,
      rendimientos: {
        total: dashboardData.comisiones.porTipo.rendimiento,
        historial: dashboardData.comisiones.historial.filter((c: any) => c.tipo === 'rendimiento')
      },
      red: dashboardData.red,
      _meta: {
        loadTime,
        optimizado: true,
        cached: false,
        timestamp: new Date().toISOString()
      }
    };
    
    // 🚀 GUARDAR EN CACHÉ
    cacheDashboards.set(userId, {
      data: response,
      timestamp: Date.now()
    });
    console.log(`💾 Dashboard optimizado guardado en caché para: ${userId}`);
    
    return c.json(response);
  } catch (error) {
    console.error('❌ Error al cargar dashboard completo (V2 optimizado):', error);
    console.error('Stack:', error instanceof Error ? error.stack : 'No stack trace');
    
    // Manejo de timeout específico
    const errorMsg = error instanceof Error ? error.message : String(error);
    if (errorMsg.includes('timeout') || errorMsg.includes('Timeout') || errorMsg.includes('closed') || errorMsg.includes('ECONNRESET')) {
      console.error('⚠️ Error de timeout/conexión detectado');
      return c.json({ 
        error: "La solicitud tardó demasiado tiempo. Por favor intente de nuevo.",
        code: "REQUEST_TIMEOUT"
      }, 504);
    }
    
    return c.json({ 
      error: "Error al cargar dashboard completo",
      details: errorMsg
    }, 500);
  }
});
