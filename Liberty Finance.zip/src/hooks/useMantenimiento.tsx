import { useState, useEffect } from 'react';

export function useMantenimiento() {
  const [enMantenimiento, setEnMantenimiento] = useState(false);
  const [horaActual, setHoraActual] = useState('');
  const [tiempoRestante, setTiempoRestante] = useState('');
  const [mantenimientoManual, setMantenimientoManual] = useState(false);

  const verificarMantenimiento = async () => {
    // 🔥 MANTENIMIENTO DESACTIVADO PERMANENTEMENTE
    setEnMantenimiento(false);
    setMantenimientoManual(false);
    
    const ahora = new Date();
    const horaFormateada = ahora.toLocaleTimeString('es-ES', { 
      hour: '2-digit', 
      minute: '2-digit',
      second: '2-digit'
    });
    setHoraActual(horaFormateada);
    setTiempoRestante('');
    
    return false;
    
    /* CÓDIGO ANTERIOR (DESACTIVADO)
    const hora = ahora.getHours();
    const minutos = ahora.getMinutes();
    
    // Convertir a minutos desde medianoche para facilitar comparación
    const minutoActual = hora * 60 + minutos;
    const inicioMantenimiento = 1 * 60; // 1:00 AM = 60 minutos
    const finMantenimiento = 10 * 60; // 10:00 AM = 600 minutos
    
    // Verificar si estamos en horario de mantenimiento automático (1:00 AM - 10:00 AM)
    const estaEnMantenimientoAutomatico = minutoActual >= inicioMantenimiento && minutoActual < finMantenimiento;
    */
  };

  useEffect(() => {
    // Verificar inmediatamente
    verificarMantenimiento();
    
    // Verificar cada 30 segundos
    const interval = setInterval(verificarMantenimiento, 30000);
    
    return () => clearInterval(interval);
  }, []);

  return {
    enMantenimiento,
    horaActual,
    tiempoRestante,
    mantenimientoManual,
    verificarMantenimiento
  };
}
