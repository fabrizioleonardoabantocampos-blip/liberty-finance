import { useState, useEffect, useCallback, useRef } from 'react';

interface UseAutoRefreshOptions {
  enabled?: boolean;
  interval?: number; // en milisegundos
  refetchOnFocus?: boolean;
}

export function useAutoRefresh<T>(
  fetchFn: () => Promise<T>,
  options: UseAutoRefreshOptions = {}
) {
  const {
    enabled = true,
    interval = 5000, // 5 segundos por defecto
    refetchOnFocus = true
  } = options;

  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
  
  const fetchFnRef = useRef(fetchFn);
  fetchFnRef.current = fetchFn;

  const refetch = useCallback(async () => {
    if (!enabled) return;
    
    setLoading(true);
    setError(null);
    
    try {
      const result = await fetchFnRef.current();
      setData(result);
      setLastUpdate(new Date());
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Error desconocido'));
      console.error('Error en useAutoRefresh:', err);
    } finally {
      setLoading(false);
    }
  }, [enabled]);

  // Efecto para polling
  useEffect(() => {
    if (!enabled || interval <= 0) return;

    // Primera carga
    refetch();

    // Polling
    const intervalId = setInterval(() => {
      refetch();
    }, interval);

    return () => clearInterval(intervalId);
  }, [enabled, interval, refetch]);

  // Efecto para refetch cuando la ventana recibe foco
  useEffect(() => {
    if (!refetchOnFocus) return;

    const handleFocus = () => {
      refetch();
    };

    window.addEventListener('focus', handleFocus);
    return () => window.removeEventListener('focus', handleFocus);
  }, [refetchOnFocus, refetch]);

  return {
    data,
    loading,
    error,
    refetch,
    lastUpdate
  };
}
