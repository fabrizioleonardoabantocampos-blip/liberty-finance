import { useMemo } from 'react';
import { useDashboard } from '../contexts/DashboardContext';

/**
 * Hook que transforma los datos del DashboardContext
 * al formato legacy esperado por los componentes existentes
 */
export function useUserData() {
  const { data, loading, error, refresh } = useDashboard();

  const userData = useMemo(() => {
    if (!data) return null;

    const { usuario, pack, wallet, comisiones, rendimientos, red } = data;

    return {
      // Datos del usuario
      id: usuario.id,
      id_unico: usuario.id_unico,
      nombre: usuario.nombre,
      apellido: usuario.apellido,
      email: usuario.email,
      telefono: usuario.telefono,
      pais: usuario.pais,
      activo: usuario.activo,
      rango: usuario.rango,
      referralCode: usuario.referralCode,
      referidoPor: usuario.referidoPor,

      // Pack e inversión
      pack: pack.activo?.nombre || 'Sin pack',
      inversion: pack.inversionTotal,
      packActivo: pack.activo,
      todosLosPacks: pack.todosLosPacks,

      // Wallet
      saldo_disponible: wallet.saldoDisponible,
      ganancia_acumulada: wallet.totalGanado,
      limite_retiro: wallet.limiteRetiro,
      porcentaje_alcanzado: wallet.porcentajeAlcanzado,

      // Comisiones
      comisiones_red: comisiones.porTipo.red,
      comisiones_patrocinio: comisiones.porTipo.binaria,
      rendimiento_diario: comisiones.porTipo.rendimiento,
      comisiones_totales: comisiones.total,

      // Rendimientos
      rendimientos_acumulados: rendimientos.total,

      // Red
      directos: red.completa.lista, // ✅ TODA la red genealógica (directos + indirectos hasta 10 niveles)
      totalDirectos: red.directos.total,
      directosConPack: red.directos.conPack,
      
      // Matriz
      cycle: red.matriz || {},
      
      // Lista de referidos para componente Referidos
      // Incluye todos los niveles de la red genealógica
      referidosDirectosData: red.directos.lista, // Solo directos (nivel 1)
      redCompleta: red.completa.lista
    };
  }, [data]);

  return {
    userData,
    loading,
    error,
    refresh,
    rawData: data
  };
}
