import { useState, useEffect } from 'react';
import { configuracionAPI } from '../utils/api';
import logoImageDefault from 'figma:asset/ae011bd8c8ee731107978c5fe892f24a22d34163.png';

export function useLogo() {
  const [logoUrl, setLogoUrl] = useState<string>(logoImageDefault);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    cargarLogo();
  }, []);

  const cargarLogo = async () => {
    try {
      const config = await configuracionAPI.get();
      if (config.logoUrl) {
        setLogoUrl(config.logoUrl);
      }
    } catch (error) {
      console.error('Error al cargar logo:', error);
      // Si hay error, usar el logo por defecto
    } finally {
      setLoading(false);
    }
  };

  return { logoUrl, loading };
}
