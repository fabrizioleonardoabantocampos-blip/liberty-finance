# 🚨 URGENTE - El Servidor NO Está Desplegado

## ❌ El Problema

Las credenciales están **correctas**, pero el Edge Function `server` **NO está desplegado** en Supabase.

Por eso ves:
```
⚠️ Timeout (30000ms) en intento 1/4
⚠️ Error de red en intento 1/4, reintentando en 2000ms...
```

## ✅ Solución: Desplegar el Edge Function

### Opción 1: Usando Supabase CLI (Recomendado)

#### Paso 1: Instalar Supabase CLI

**macOS / Linux:**
```bash
brew install supabase/tap/supabase
```

**Windows:**
```powershell
scoop bucket add supabase https://github.com/supabase/scoop-bucket.git
scoop install supabase
```

**NPM (Todas las plataformas):**
```bash
npm install -g supabase
```

#### Paso 2: Login a Supabase

```bash
supabase login
```

Esto abrirá tu navegador. Haz click en "Allow" para autorizar.

#### Paso 3: Ligar el Proyecto

```bash
supabase link --project-ref tfgjnkmstcjdhmzvznbu
```

**Nota:** `tfgjnkmstcjdhmzvznbu` es tu Project ID.

Si te pide confirmación, escribe `y` y presiona Enter.

#### Paso 4: Desplegar el Edge Function

```bash
supabase functions deploy server
```

Deberías ver:
```
Deploying function server...
✓ Function deployed successfully
```

#### Paso 5: Verificar

```bash
curl https://tfgjnkmstcjdhmzvznbu.supabase.co/functions/v1/make-server-9f68532a/ping \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRmZ2pua21zdGNqZGhtenZ6bmJ1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM1NzQ0NjAsImV4cCI6MjA3OTE1MDQ2MH0.5NNcqsrb9mDlgGctmWibczOliG7xgMoB5yc-JklpIHQ"
```

Respuesta esperada: `pong`

---

### Opción 2: Desde Supabase Dashboard (Más lento)

#### Paso 1: Ve a Supabase Dashboard

1. Abre: https://supabase.com/dashboard
2. Selecciona tu proyecto: **Liberty Finance**

#### Paso 2: Ve a Edge Functions

1. En el menú lateral, haz clic en **Edge Functions**
2. Verás si hay funciones desplegadas

#### Paso 3: Crear Nueva Función

Si NO ves la función `server`:

1. Haz clic en **"New Function"**
2. Nombre: `server`
3. En el editor, **NO intentes copiar todo el archivo** (es muy grande)
4. **Usa Supabase CLI** (Opción 1) en su lugar

**Nota:** El archivo `/supabase/functions/server/index.tsx` tiene más de 11,000 líneas. 
El editor web de Supabase NO puede manejar archivos tan grandes.
**DEBES usar Supabase CLI.**

---

### Opción 3: Verificar si Ya Está Desplegado

Puede que el Edge Function esté desplegado pero con otro nombre o haya un error.

#### A. Listar funciones existentes

```bash
supabase functions list
```

#### B. Ver logs del servidor

1. Ve a: https://supabase.com/dashboard/project/tfgjnkmstcjdhmzvznbu/functions
2. Si ves la función `server`, haz clic en ella
3. Haz clic en **"Logs"**
4. Busca errores en color rojo

#### C. Verificar estado

En Supabase Dashboard → Edge Functions:
- ✅ **Active** = Funciona correctamente
- ⚠️ **Paused** = Debes reactivarla
- ❌ **Error** = Debes redesplegarla

---

## 🔧 Troubleshooting del Deploy

### Error: "Function already exists"

```bash
# Forzar redespliegue
supabase functions deploy server --no-verify-jwt
```

### Error: "Project not linked"

```bash
# Desligar y volver a ligar
supabase unlink
supabase link --project-ref tfgjnkmstcjdhmzvznbu
```

### Error: "Authentication failed"

```bash
# Logout y login nuevamente
supabase logout
supabase login
```

### Error: "Permission denied"

Verifica que tu cuenta de Supabase tenga permisos de administrador en el proyecto.

---

## 📋 Script Completo (Copia y Pega)

Para **macOS / Linux**:

```bash
#!/bin/bash

echo "🚀 Desplegando servidor de Liberty Finance..."

# 1. Verificar que Supabase CLI esté instalado
if ! command -v supabase &> /dev/null; then
    echo "❌ Supabase CLI no está instalado"
    echo "Instalando con NPM..."
    npm install -g supabase
fi

# 2. Login (si no está logueado)
echo "🔐 Verificando autenticación..."
supabase login

# 3. Ligar proyecto
echo "🔗 Ligando proyecto..."
supabase link --project-ref tfgjnkmstcjdhmzvznbu

# 4. Desplegar función
echo "📦 Desplegando Edge Function..."
supabase functions deploy server

# 5. Verificar
echo "✅ Verificando despliegue..."
curl https://tfgjnkmstcjdhmzvznbu.supabase.co/functions/v1/make-server-9f68532a/ping \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRmZ2pua21zdGNqZGhtenZ6bmJ1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM1NzQ0NjAsImV4cCI6MjA3OTE1MDQ2MH0.5NNcqsrb9mDlgGctmWibczOliG7xgMoB5yc-JklpIHQ"

echo ""
echo "🎉 ¡Despliegue completado!"
```

Guarda como `deploy.sh` y ejecuta:
```bash
chmod +x deploy.sh
./deploy.sh
```

Para **Windows (PowerShell)**:

```powershell
# Script de despliegue para Windows
Write-Host "🚀 Desplegando servidor de Liberty Finance..." -ForegroundColor Green

# 1. Verificar Supabase CLI
if (!(Get-Command supabase -ErrorAction SilentlyContinue)) {
    Write-Host "❌ Supabase CLI no está instalado" -ForegroundColor Red
    Write-Host "Instalando con NPM..." -ForegroundColor Yellow
    npm install -g supabase
}

# 2. Login
Write-Host "🔐 Verificando autenticación..." -ForegroundColor Cyan
supabase login

# 3. Ligar proyecto
Write-Host "🔗 Ligando proyecto..." -ForegroundColor Cyan
supabase link --project-ref tfgjnkmstcjdhmzvznbu

# 4. Desplegar
Write-Host "📦 Desplegando Edge Function..." -ForegroundColor Cyan
supabase functions deploy server

# 5. Verificar
Write-Host "✅ Verificando despliegue..." -ForegroundColor Cyan
$uri = "https://tfgjnkmstcjdhmzvznbu.supabase.co/functions/v1/make-server-9f68532a/ping"
$headers = @{
    "Authorization" = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRmZ2pua21zdGNqZGhtenZ6bmJ1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM1NzQ0NjAsImV4cCI6MjA3OTE1MDQ2MH0.5NNcqsrb9mDlgGctmWibczOliG7xgMoB5yc-JklpIHQ"
}
Invoke-RestMethod -Uri $uri -Headers $headers

Write-Host ""
Write-Host "🎉 ¡Despliegue completado!" -ForegroundColor Green
```

Guarda como `deploy.ps1` y ejecuta:
```powershell
.\deploy.ps1
```

---

## 📊 Después del Despliegue

### 1. Verificar que funciona

Abre tu navegador y ve a:
```
https://tfgjnkmstcjdhmzvznbu.supabase.co/functions/v1/make-server-9f68532a/health
```

Deberías ver:
```json
{
  "status": "ok",
  "timestamp": 1735689234567,
  "server": "Liberty Finance API",
  "uptime": 12
}
```

### 2. Probar en la aplicación

1. Recarga la aplicación (F5)
2. Ve a `/Setup`
3. Haz clic en **"🔍 Diagnóstico de Conectividad"**
4. Deberías ver **3 tests en VERDE** ✅

### 3. Iniciar sesión

1. Ve a la página de Login
2. Email: `admin@libertyfinance.com`
3. Password: `admin123`
4. Deberías entrar sin problemas 🎉

---

## ⚠️ Notas Importantes

### El archivo es GRANDE

El archivo `/supabase/functions/server/index.tsx` tiene **11,360 líneas**.

Por eso:
- ❌ NO intentes copiarlo manualmente en el dashboard
- ❌ NO uses el editor web de Supabase
- ✅ USA Supabase CLI

### Dependencias

El Edge Function usa estas dependencias (ya incluidas en el deploy):
- Hono (framework web)
- @supabase/supabase-js
- Resend (emails)

Supabase CLI las instalará automáticamente.

### Tiempo de Deploy

El primer deploy puede tardar **2-5 minutos**:
- Subiendo código: ~30 segundos
- Instalando dependencias: ~1-2 minutos
- Inicializando: ~30 segundos
- Cold start inicial: ~30-60 segundos

**TOTAL: 3-5 minutos la primera vez**

---

## 🆘 Si el Deploy Falla

### Error: "Too large"

Si el archivo es demasiado grande:

1. Verifica que estés en la carpeta raíz del proyecto
2. Asegúrate de que `/supabase/functions/server/index.tsx` exista
3. Intenta con `--no-verify-jwt`:
   ```bash
   supabase functions deploy server --no-verify-jwt
   ```

### Error: "Module not found"

Si falta un módulo:

1. Verifica que `deno.json` o `import_map.json` existan
2. Las importaciones deben usar `npm:` prefix:
   ```typescript
   import { Hono } from "npm:hono";
   ```

### Error: "Syntax error"

Si hay error de sintaxis:

1. Verifica que el archivo `/supabase/functions/server/index.tsx` no esté corrupto
2. Busca el número de línea del error
3. Revisa esa línea en el archivo

---

## 🎉 Una Vez Desplegado

El servidor estará disponible 24/7 y:

- ✅ Responderá en **2-5 segundos** (después del cold start)
- ✅ Manejará **cold starts** automáticamente (30-90s primera vez)
- ✅ Se **auto-escalará** según el tráfico
- ✅ Tendrá **logs** accesibles en Supabase Dashboard

---

**Fecha:** 31 de diciembre de 2025  
**Prioridad:** 🔴 CRÍTICO  
**Acción requerida:** Desplegar Edge Function  
**Tiempo estimado:** 5-10 minutos
