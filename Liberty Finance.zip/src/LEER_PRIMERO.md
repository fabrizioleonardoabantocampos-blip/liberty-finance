# 🎯 MIGRAR DATOS - INSTRUCCIONES SÚPER SIMPLES

¡Hola! He preparado TODO para que puedas migrar tus datos de la base anterior a la nueva. 

**Solo necesitas hacer 3 cosas:**

---

## ✅ PASO 1: Agregar el Código al Servidor (1 minuto)

### En Supabase:

1. Abre tu proyecto en https://supabase.com/dashboard
2. Ve a **Edge Functions** > **server** > **index.tsx**
3. Busca la línea que dice `// RUTAS DE DOCUMENTOS LEGALES` (está como en la línea 1094)
4. **ANTES** de esa línea, pega el código del archivo `/COPIAR_Y_PEGAR_EN_INDEX.txt`
5. Guarda (Ctrl+S o Cmd+S)
6. Espera 1-2 minutos a que el servidor se actualice

**IMPORTANTE:** Haz esto en AMBAS bases de datos:
- ✅ En la base ANTERIOR (donde están tus datos)
- ✅ En la base NUEVA (donde quieres copiarlos)

---

## ✅ PASO 2: Abrir la Página de Migración (10 segundos)

Abre tu navegador y ve a tu aplicación agregando `?migracion=true` al final:

```
https://tu-app.com?migracion=true
```

O si estás en local:

```
http://localhost:5173?migracion=true
```

---

## ✅ PASO 3: Llenar el Formulario y Hacer Clic (2 minutos)

Verás una página muy bonita con un formulario. Solo necesitas:

### 1. Llenar 2 campos:

**¿Dónde encontrar estos datos de tu BASE ANTERIOR?**

a) **Project ID:**
   - Ve a https://supabase.com/dashboard
   - Selecciona tu proyecto ANTERIOR
   - Settings > General > Reference ID
   - Copia el ID (algo como `abcdefghijklmnop`)

b) **Anon Key:**
   - En el mismo proyecto ANTERIOR
   - Settings > API
   - Busca "anon" key (la pública)
   - Copia toda la key (empieza con `eyJ...`)

### 2. Pega en el formulario:

```
┌──────────────────────────────────────┐
│ Project ID Anterior: [pega aquí]    │
│ Anon Key Anterior:   [pega aquí]    │
│                                      │
│  [Exportar Datos] ← Haz clic aquí   │
└──────────────────────────────────────┘
```

### 3. Espera 10-30 segundos

Verás:
```
✅ Exportación completada!
👥 50 usuarios
💵 120 depósitos
💰 350 comisiones
```

### 4. Haz clic en "Importar Ahora"

```
┌──────────────────────────────────────┐
│  [Importar Ahora] ← Haz clic aquí   │
└──────────────────────────────────────┘
```

### 5. Espera 10-30 segundos

Verás:
```
🎉 ¡MIGRACIÓN COMPLETADA!
[Ir al Panel de Admin]
```

---

## 🎉 ¡LISTO!

Todos tus datos están en la nueva base:
- ✅ Usuarios
- ✅ Depósitos
- ✅ Comisiones
- ✅ Packs
- ✅ Retiros
- ✅ Todo!

---

## 📋 RESUMEN VISUAL

```
PASO 1: Copiar código
├─ Abrir Supabase Dashboard
├─ Ir a Edge Functions > server > index.tsx
├─ Buscar "// RUTAS DE DOCUMENTOS LEGALES"
├─ Pegar código ANTES de esa línea
└─ Guardar

PASO 2: Abrir página
└─ Ir a: tu-url?migracion=true

PASO 3: Migrar
├─ Llenar Project ID de base anterior
├─ Llenar Anon Key de base anterior
├─ Clic en "Exportar Datos"
├─ Esperar...
├─ Clic en "Importar Ahora"
├─ Esperar...
└─ ¡LISTO! 🎉
```

---

## ⏱️ TIEMPO TOTAL: 3-5 minutos

- Paso 1: 1 minuto
- Paso 2: 10 segundos
- Paso 3: 2-3 minutos
- **Total:** ☕ Menos que hacer un café

---

## ❓ AYUDA RÁPIDA

### "No encuentro dónde pegar el código"

Busca en el archivo `index.tsx` esta línea:

```typescript
// ==========================================
// RUTAS DE DOCUMENTOS LEGALES (PDFs)
// ==========================================
```

Pega el código **ANTES** de esa línea (como en la línea 1093).

### "Sale error al exportar"

- ✅ Verifica que agregaste el código en la base ANTERIOR
- ✅ Espera 2 minutos después de guardar
- ✅ Verifica que el Project ID y Anon Key sean correctos

### "Sale error al importar"

- ✅ Verifica que agregaste el código en la base NUEVA también
- ✅ Espera 2 minutos después de guardar

### "No abre la página de migración"

Usa la URL completa:
```
https://tu-dominio.com/?migracion=true
```

O en local:
```
http://localhost:5173/?migracion=true
```

---

## 📁 ARCHIVOS CREADOS PARA TI

1. **`/LEER_PRIMERO.md`** ← Estás aquí 👋
2. **`/COPIAR_Y_PEGAR_EN_INDEX.txt`** ← Código para el servidor
3. **`/INSTRUCCIONES_MIGRACION_SIMPLE.md`** ← Guía detallada
4. **`/GUIA_MIGRACION_RAPIDA.md`** ← Guía técnica completa
5. **`/pages/MigracionPage.tsx`** ← La página visual (ya está lista)

---

## 🚀 ¿Listo para empezar?

1. Abre `/COPIAR_Y_PEGAR_EN_INDEX.txt`
2. Copia todo el contenido
3. Pégalo en tu `index.tsx` (en ambas bases)
4. Ve a `?migracion=true`
5. ¡Migra tus datos!

**¿Dudas?** Solo dime "no funciona paso X" y te ayudo 😊

---

**Creado:** 2025-11-19  
**Tiempo de implementación:** 3-5 minutos  
**Dificultad:** ⭐ Muy fácil  
**Lo que vas a lograr:** ✅ Migrar 100% de tus datos
