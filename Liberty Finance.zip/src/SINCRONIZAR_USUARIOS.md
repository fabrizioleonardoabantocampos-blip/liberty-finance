# 🔄 SINCRONIZAR USUARIOS DE SUPABASE AUTH → KV STORE

## Problema
Los nuevos usuarios se registran en **Supabase Auth** pero NO aparecen en el **Panel de Admin** porque no se guardan en el **KV Store**.

## Solución Rápida (Script de Consola)

### 1️⃣ Abre la consola del navegador (F12)

### 2️⃣ Pega y ejecuta este script:

```javascript
async function sincronizarUsuarios() {
  console.log('🔄 Iniciando sincronización...');
  
  try {
    const response = await fetch('https://cnuvezjkprgozeqpspyh.supabase.co/functions/v1/make-server-9f68532a/admin/sincronizar-usuarios-auth', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNudXZlemprcHJnb3plcXBzcHloIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzI4MzY1NzcsImV4cCI6MjA0ODQxMjU3N30.zqXo-cw_qUQcQEP-DHu6aZIUe_U2o4XXJpxDXKN7cTI'
      }
    });
    
    const data = await response.json();
    
    console.log('✅ SINCRONIZACIÓN COMPLETA:');
    console.log(`   Total en Supabase Auth: ${data.totalAuth}`);
    console.log(`   Ya existían en KV: ${data.yaExistian}`);
    console.log(`   ✨ Sincronizados ahora: ${data.sincronizados}`);
    console.log(`   ❌ Errores: ${data.errores}`);
    
    if (data.detalles.sincronizados.length > 0) {
      console.log('\n📝 Usuarios sincronizados:');
      data.detalles.sincronizados.forEach(u => {
        console.log(`   - ${u.nombre} (${u.email})`);
      });
    }
    
    if (data.detalles.errores.length > 0) {
      console.log('\n⚠️ Errores:');
      data.detalles.errores.forEach(e => {
        console.log(`   - ${e.email}: ${e.error}`);
      });
    }
    
    alert(`✅ Sincronización completa!\n\n${data.sincronizados} usuarios agregados al sistema.\n\nRecarga la página para verlos.`);
    
  } catch (error) {
    console.error('❌ Error:', error);
    alert('❌ Error al sincronizar. Ver consola para detalles.');
  }
}

sincronizarUsuarios();
```

### 3️⃣ Espera a que termine (verás los logs en la consola)

### 4️⃣ Recarga la página y ve al Panel de Admin → Usuarios

---

## ¿Qué hace este script?

1. **Obtiene TODOS los usuarios de Supabase Auth**
2. **Compara con los usuarios en KV Store**
3. **Crea los usuarios faltantes** en KV Store
4. **Inicializa sus puntos** (100 puntos de bienvenida)
5. **Muestra un reporte** de lo que hizo

---

## Notas Importantes

- ✅ **NO duplica usuarios** - solo agrega los que faltan
- ✅ **Preserva usuarios existentes** - no los modifica
- ✅ **Seguro de ejecutar** - puedes correrlo las veces que quieras
- ⚠️ **Usuarios migrados** tendrán password = "MIGRATED_FROM_AUTH"
  - Pueden usar "Recuperar Contraseña" para establecer una nueva

---

## Para Admin: Botón de Sincronización en el Panel

El endpoint ya está creado en:
`POST /make-server-9f68532a/admin/sincronizar-usuarios-auth`

Puedes agregar un botón en `/components/admin/AdminUsers.tsx` que llame a este endpoint.

