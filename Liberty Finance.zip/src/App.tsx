import { useState, useEffect } from 'react';
import { Landing } from './components/Landing';
import { Login } from './components/auth/Login';
import { Register } from './components/auth/Register';
import { ForgotPassword } from './components/auth/ForgotPassword';
import { RecuperarPassword } from './components/auth/RecuperarPassword';
import { UserDashboard } from './components/user/UserDashboard';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { Setup } from './pages/Setup';
import MigracionPage from './pages/MigracionPage';
import { DebugLogin } from './pages/DebugLogin';
import DiagnosticoComisiones from './pages/DiagnosticoComisiones';
import { Toaster } from './components/ui/sonner';
import { LoadingScreen } from './components/auth/LoadingScreen';
import { AlertaCredenciales } from './components/debug/AlertaCredenciales';
import { BannerModoDemo } from './components/debug/BannerModoDemo';
import { DespertarBanner } from './components/debug/DespertarBanner';

type View = 'landing' | 'login' | 'register' | 'forgot' | 'recuperar' | 'setup' | 'migracion' | 'debug' | 'diagnostico';
type UserType = 'user' | 'admin' | null;

export default function App() {
  const [currentView, setCurrentView] = useState<View>('landing');
  const [userType, setUserType] = useState<UserType>(null);
  const [referralCode, setReferralCode] = useState<string>('');
  const [isCheckingSession, setIsCheckingSession] = useState(true);
  const [showGlobalLoading, setShowGlobalLoading] = useState(false);
  const [loadingMessage, setLoadingMessage] = useState('Cargando...');

  const checkExistingSession = () => {
    try {
      const userStr = localStorage.getItem('currentUser');
      const sessionType = localStorage.getItem('userType');
      
      if (userStr && sessionType) {
        const user = JSON.parse(userStr);
        
        // Verificar si es admin
        if (user.email === 'admin@libertyfinance.com' && sessionType === 'admin') {
          setUserType('admin');
        } else if (sessionType === 'user') {
          setUserType('user');
        }
      }
    } catch (error) {
      console.error('Error al verificar sesión:', error);
      // Si hay error, limpiar localStorage
      localStorage.removeItem('currentUser');
      localStorage.removeItem('userType');
    } finally {
      setIsCheckingSession(false);
    }
  };

  const handleLogin = (type: 'user' | 'admin') => {
    // ✅ ACTIVAR LOADING SCREEN GLOBAL de 20 segundos
    console.log('✅ App: Activando LoadingScreen global de 20s');
    setShowGlobalLoading(true);
    setLoadingMessage('Preparando tu dashboard...');
    
    // Guardar tipo de usuario en localStorage para persistencia
    localStorage.setItem('userType', type);
    
    // Cambiar el tipo de usuario (esto mostrará el dashboard)
    setUserType(type);
  };

  const handleLogout = () => {
    setUserType(null);
    setCurrentView('landing');
    // Limpiar localStorage
    localStorage.removeItem('currentUser');
    localStorage.removeItem('userType');
    
    // Limpiar URL y redirigir a la raíz (o a una URL específica si se requiere)
    window.history.replaceState({}, '', '/');
  };

  const handleGoToLogin = () => {
    setCurrentView('login');
  };

  // Verificar sesión al cargar
  useEffect(() => {
    checkExistingSession();
  }, []);

  // Capturar parámetros de la URL
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    
    // Verificar si es página de setup
    const setupParam = params.get('setup');
    if (setupParam === 'true') {
      setCurrentView('setup');
      return;
    }
    
    // Verificar si es página de migración
    const migracionParam = params.get('migracion');
    if (migracionParam === 'true') {
      setCurrentView('migracion');
      return;
    }
    
    // Verificar si es página de debug
    const debugParam = params.get('debug');
    if (debugParam === 'true') {
      setCurrentView('debug');
      return;
    }
    
    // Verificar si es página de diagnóstico
    const diagnosticoParam = params.get('diagnostico');
    if (diagnosticoParam === 'true') {
      setCurrentView('diagnostico');
      return;
    }
    
    // Capturar código de referido
    const refCode = params.get('ref');
    if (refCode) {
      setReferralCode(refCode);
      // Ir directamente a registro si hay código de referido
      setCurrentView('register');
    }
  }, []);

  // Mostrar nada mientras verifica sesión
  if (isCheckingSession) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-slate-600">Cargando...</p>
        </div>
      </div>
    );
  }

  // Show dashboards if logged in
  if (userType === 'admin') {
    return (
      <>
        <BannerModoDemo />
        <LoadingScreen 
          isVisible={showGlobalLoading}
          message={loadingMessage}
          onComplete={() => {
            console.log('✅ LoadingScreen global completado');
            setShowGlobalLoading(false);
          }}
        />
        <AdminDashboard onLogout={handleLogout} />
        <Toaster position="top-center" richColors />
      </>
    );
  }

  if (userType === 'user') {
    return (
      <>
        <BannerModoDemo />
        <LoadingScreen 
          isVisible={showGlobalLoading}
          message={loadingMessage}
          onComplete={() => {
            console.log('✅ LoadingScreen global completado');
            setShowGlobalLoading(false);
          }}
        />
        <UserDashboard onLogout={handleLogout} />
        <Toaster position="top-center" richColors />
      </>
    );
  }

  // Show landing page
  if (currentView === 'landing') {
    return (
      <>
        <BannerModoDemo />
        <AlertaCredenciales />
        <Landing onLoginClick={handleGoToLogin} />
        <Toaster position="top-center" richColors />
      </>
    );
  }

  // Show setup screen
  if (currentView === 'setup') {
    return (
      <>
        <Setup onNavigate={(page) => setCurrentView(page as View)} />
        <Toaster position="top-center" richColors />
      </>
    );
  }

  // Show migracion screen
  if (currentView === 'migracion') {
    return (
      <>
        <MigracionPage onNavigate={(page) => setCurrentView(page as View)} />
        <Toaster position="top-center" richColors />
      </>
    );
  }

  // Show debug login screen
  if (currentView === 'debug') {
    return (
      <>
        <DebugLogin onNavigate={(page) => setCurrentView(page as View)} />
        <Toaster position="top-center" richColors />
      </>
    );
  }

  // Show diagnostico screen
  if (currentView === 'diagnostico') {
    return (
      <>
        <DiagnosticoComisiones onNavigate={(page) => setCurrentView(page as View)} />
        <Toaster position="top-center" richColors />
      </>
    );
  }

  // Show auth screens
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900">
      <DespertarBanner />
      {currentView === 'login' && (
        <Login 
          onLogin={handleLogin}
          onRegister={() => setCurrentView('register')}
          onForgotPassword={() => setCurrentView('recuperar')}
        />
      )}
      {currentView === 'register' && (
        <Register onBack={() => setCurrentView('login')} referralCode={referralCode} />
      )}
      {currentView === 'forgot' && (
        <ForgotPassword onBack={() => setCurrentView('login')} />
      )}
      {currentView === 'recuperar' && (
        <RecuperarPassword onBackToLogin={() => setCurrentView('login')} />
      )}
      <Toaster position="top-center" richColors />
    </div>
  );
}
