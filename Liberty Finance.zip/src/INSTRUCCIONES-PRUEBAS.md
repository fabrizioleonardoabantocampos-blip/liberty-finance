# 🚀 Instrucciones de Prueba - Liberty Finance CRM

## ✅ Sistema Actualizado y Funcional

Hemos completado las siguientes mejoras:

### 1. **Sistema de Autenticación Completo**
- ✅ Login conectado al servidor
- ✅ Registro conectado al servidor
- ✅ Detección automática del código de referido desde la URL
- ✅ Usuario administrador por defecto creado

### 2. **Sistema de Referidos Funcional**
- ✅ Cada usuario obtiene un código de referido único (id_unico)
- ✅ Los links de referidos funcionan dentro de la aplicación
- ✅ El registro detecta automáticamente el código de referido de la URL
- ✅ Los referidos quedan correctamente asignados a su referidor

### 3. **Reseteo de Datos**
- ✅ Todos los datos han sido reseteados a cero
- ✅ Base de datos limpia para hacer pruebas
- ✅ Usuario admin creado por defecto

---

## 🧪 Flujo de Pruebas Completo

### **Paso 1: Resetear Datos (Opcional - Ya está hecho)**

Si necesitas resetear los datos en cualquier momento:

```javascript
// En la consola del navegador o en una herramienta como Postman
fetch('https://[PROJECT_ID].supabase.co/functions/v1/make-server-9f68532a/dev/reset', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer [PUBLIC_ANON_KEY]'
  }
})
```

### **Paso 2: Login como Administrador**

1. Ve a la aplicación
2. Inicia sesión con:
   - **Email:** admin@libertyfinance.com
   - **Password:** admin123
3. ✅ Deberías ver el panel de administrador

### **Paso 3: Registrar Usuario A (Sin referido)**

1. Cierra sesión del admin
2. Haz clic en "Regístrate aquí"
3. Completa el formulario:
   - Nombre: Juan
   - Apellido: Pérez
   - Email: juan@example.com
   - Teléfono: +52 123 456 7890
   - Ciudad: Ciudad de México
   - Wallet: TJuanWallet123456
   - Password: password123
   - **NO ingreses código de referido**
4. Haz clic en "Crear Cuenta"
5. ✅ Deberías ver un mensaje de éxito
6. Inicia sesión con juan@example.com / password123

### **Paso 4: Obtener Link de Referido de Juan**

1. Una vez dentro del dashboard de Juan
2. Ve a la sección **"Mis Referidos"**
3. ✅ Verás tu link de referido (algo como: `http://localhost:3000?ref=LF1731686400000123`)
4. **Copia este link**

### **Paso 5: Registrar Usuario B (Con referido de Juan)**

1. Cierra sesión de Juan
2. **Pega el link de referido en el navegador**
3. ✅ Deberías ver la página de registro con el código pre-llenado
4. Completa el formulario:
   - Nombre: María
   - Apellido: González
   - Email: maria@example.com
   - Teléfono: +52 234 567 8901
   - Ciudad: Guadalajara
   - Wallet: TMariaWallet456789
   - Password: password123
   - ✅ El código de referido ya debería estar pre-llenado
5. Haz clic en "Crear Cuenta"
6. ✅ Deberías ver un mensaje de éxito indicando el código de referido

### **Paso 6: Verificar Referidos de Juan**

1. Cierra sesión de María
2. Inicia sesión como Juan (juan@example.com / password123)
3. Ve a la sección **"Mis Referidos"**
4. ✅ Deberías ver a María González en tu lista de referidos directos
5. ✅ El contador de "Total Referidos" debería mostrar 1

### **Paso 7: Probar Comisiones (Como Admin)**

1. Cierra sesión de Juan
2. Inicia sesión como admin (admin@libertyfinance.com / admin123)
3. Ve a **"Gestionar Depósitos"**
4. Debería haber un depósito pendiente de María (si hizo uno)
5. Verifica el depósito
6. ✅ Se debería crear automáticamente:
   - Un pack para María
   - Una comisión de patrocinio del 10% para Juan
   - Comisiones de red para los niveles superiores (si los hay)

### **Paso 8: Verificar Comisiones de Juan**

1. Cierra sesión del admin
2. Inicia sesión como Juan
3. Ve a la sección **"Inicio"**
4. ✅ Deberías ver tus comisiones actualizadas:
   - Comisiones de Patrocinio: $X.XX (10% del depósito de María)
   - Comisiones de Red: $X.XX (basado en los niveles)

---

## 🔍 Verificaciones Importantes

### ✅ Verificar en Consola del Servidor

Deberías ver logs como:
```
✅ Usuario registrado: María González (LF1731686400000456) - Referido por: [ID de Juan]
✅ Depósito verificado - Pack activado para usuario [ID de María]
📤 Comisión creada: $X.XX para usuario [ID de Juan] - Nivel 1
```

### ✅ Verificar en Consola del Navegador

Si hay errores, aparecerán en la consola. Asegúrate de revisar:
- Errores de red
- Respuestas del servidor
- Errores de JavaScript

---

## 🎯 Casos de Uso Adicionales

### **Caso 1: Registrar Usuario C referido por María**

1. María inicia sesión
2. Va a "Mis Referidos"
3. Copia su link de referido
4. Registra a un nuevo usuario (Carlos) usando ese link
5. ✅ Carlos queda como referido de María
6. ✅ Cuando Carlos compre un pack:
   - María recibe 10% de comisión de patrocinio
   - Juan recibe 8% de comisión de red (nivel 2)

### **Caso 2: Sistema de 10 Niveles**

Continúa el patrón:
- Usuario A refiere a Usuario B
- Usuario B refiere a Usuario C
- Usuario C refiere a Usuario D
- ... hasta 10 niveles

Cuando el Usuario del nivel 10 compra un pack:
- Nivel 1 (referidor directo): 8% comisión de red + 10% bono patrocinio
- Nivel 2: 6% comisión de red
- Nivel 3: 4% comisión de red
- Nivel 4-8: 2%, 1%, 1%, 1%, 1%, 0.5%
- Nivel 9-10: 0.5% cada uno

---

## 📊 Datos de Prueba por Defecto

### Usuario Administrador
- **Email:** admin@libertyfinance.com
- **Password:** admin123
- **ID Único:** LF-ADMIN-001

### Packs Disponibles
- Pack 50: $50 USDT - 2% diario
- Pack 100: $100 USDT - 2% diario
- Pack 500: $500 USDT - 2% diario
- Pack 1000: $1,000 USDT - 2% diario
- Pack 5000: $5,000 USDT - 2% diario
- Pack 10000: $10,000 USDT - 2% diario

---

## 🚨 Solución de Problemas

### Error: "No hay sesión activa"
- **Solución:** Haz logout y vuelve a iniciar sesión

### Error: "El email ya está registrado"
- **Solución:** Usa otro email o resetea los datos

### Error: "Código de referido no encontrado"
- **Solución:** Verifica que el código de referido sea correcto

### Error: "Error al cargar datos del usuario"
- **Solución:** Asegúrate de que el servidor esté corriendo

### Los referidos no aparecen
- **Solución:** Verifica que el código de referido se haya usado correctamente durante el registro

---

## 📝 Notas Importantes

1. **Servidor Debe Estar Corriendo:** Asegúrate de que el servidor de Supabase Edge Functions esté activo
2. **LocalStorage:** Los datos de sesión se guardan en localStorage del navegador
3. **Logs:** Revisa siempre los logs del servidor para debugging
4. **Reseteo:** Puedes resetear los datos en cualquier momento usando la ruta `/dev/reset`

---

## 🎉 Sistema Listo para Pruebas

El sistema está completamente funcional con:
- ✅ Autenticación completa
- ✅ Sistema de referidos funcionando
- ✅ Detección automática de códigos de referido
- ✅ Base de datos limpia y reseteada
- ✅ Usuario admin creado
- ✅ Comisiones de 10 niveles implementadas
- ✅ Panel de administrador completo

**¡Empieza a probar y disfruta del sistema!** 🚀
