# 📚 Sistema CRM de Liberty Finance - Documentación Completa

## 🎯 Descripción General

Este sistema CRM completo está construido usando la **tabla KV (Key-Value)** de Supabase, que es perfecta para almacenar todos los datos de manera flexible y escalable sin necesidad de crear tablas adicionales.

---

## 🗄️ Estructura de Datos

### **Usuarios** (`user:{id}`)
```typescript
{
  id: string;
  id_unico: string;           // ID único del usuario (ej: LF1234567890)
  nombre: string;
  apellido: string;
  email: string;
  telefono: string;
  ciudad: string;
  wallet: string;            // Dirección de wallet USDT
  password: string;          // En producción: hashear
  referralCode: string;      // Código de referido personal
  referidoPor?: string;      // ID del usuario que lo refirió
  fechaRegistro: string;
  activo: boolean;
}
```

### **Packs** (`pack:{id}` y `user:{userId}:pack:{id}`)
```typescript
{
  id: string;
  userId: string;
  nombre: string;            // Pack 50, Pack 100, etc.
  monto: number;             // Monto de inversión en USDT
  fechaCompra: string;
  activo: boolean;
  rendimientoDiario: number; // Porcentaje de rendimiento diario
}
```

### **Comisiones** (`comision:{id}` y `user:{userId}:comision:{id}`)
```typescript
{
  id: string;
  userId: string;
  tipo: 'red' | 'patrocinio' | 'rendimiento';
  monto: number;
  nivel?: number;            // Para comisiones de red (1-10)
  referidoId?: string;       // ID del referido que generó la comisión
  fecha: string;
  descripcion: string;
}
```

### **Cobros** (`cobro:{id}` y `user:{userId}:cobro:{id}`)
```typescript
{
  id: string;
  userId: string;
  monto: number;
  wallet: string;
  estado: 'pendiente' | 'aprobado' | 'rechazado' | 'completado';
  fecha: string;
  fechaProcesado?: string;
  txHash?: string;           // Hash de transacción blockchain
}
```

### **Productos** (`producto:{id}`)
```typescript
{
  id: string;
  nombre: string;
  descripcion: string;
  precio: number;            // Precio en puntos
  imagen?: string;
  stock: number;
  activo: boolean;
}
```

### **Compras** (`compra:{id}` y `user:{userId}:compra:{id}`)
```typescript
{
  id: string;
  userId: string;
  productoId: string;
  cantidad: number;
  precioTotal: number;
  fecha: string;
  estado: 'pendiente' | 'enviado' | 'entregado';
}
```

### **Puntos** (`puntos:{userId}`)
```typescript
{
  userId: string;
  puntos: number;
  ultimaActualizacion: string;
}
```

### **Ruleta** (`ruleta:{id}` y `user:{userId}:ruleta:{id}`)
```typescript
{
  id: string;
  userId: string;
  premio: string;
  puntos?: number;
  fecha: string;
}
```

---

## 🚀 API Endpoints

### **Autenticación**

#### POST `/auth/register`
```typescript
Body: {
  nombre: string;
  apellido: string;
  email: string;
  telefono: string;
  ciudad: string;
  wallet: string;
  password: string;
  referralCode?: string;
  referidoPor?: string;
}

Response: {
  success: true,
  user: User (sin password)
}
```

#### POST `/auth/login`
```typescript
Body: {
  email: string;
  password: string;
}

Response: {
  success: true,
  user: User (sin password)
}
```

---

### **Usuarios**

#### GET `/users/:userId`
Obtiene datos de un usuario específico.

#### GET `/users`
Obtiene todos los usuarios.

#### PUT `/users/:userId`
Actualiza datos de un usuario.

---

### **Packs**

#### POST `/packs`
```typescript
Body: {
  userId: string;
  nombre: string;
  monto: number;
  rendimientoDiario: number;
}

// ¡IMPORTANTE! Al crear un pack, automáticamente se calculan
// las comisiones de red para los 10 niveles según el plan:
// - Nivel 1: 8%
// - Nivel 2: 6%
// - Nivel 3: 4%
// - Nivel 4: 2%
// - Niveles 5-8: 1%
// - Niveles 9-10: 0.5%
// + Bono de patrocinio: 10% al referidor directo
```

#### GET `/users/:userId/packs`
Obtiene todos los packs de un usuario.

---

### **Comisiones**

#### GET `/users/:userId/comisiones`
Obtiene todas las comisiones de un usuario.

#### GET `/users/:userId/comisiones/total`
Obtiene el total de comisiones de un usuario.

---

### **Cobros**

#### POST `/cobros`
```typescript
Body: {
  userId: string;
  monto: number;
  wallet: string;
}
```

#### GET `/users/:userId/cobros`
Obtiene todos los cobros de un usuario.

#### GET `/cobros`
Obtiene todos los cobros (admin).

#### PUT `/cobros/:cobroId`
```typescript
Body: {
  estado?: 'pendiente' | 'aprobado' | 'rechazado' | 'completado';
  txHash?: string;
}
```

---

### **Productos**

#### POST `/productos`
```typescript
Body: {
  nombre: string;
  descripcion: string;
  precio: number;
  imagen?: string;
  stock: number;
}
```

#### GET `/productos`
Obtiene todos los productos activos.

---

### **Compras**

#### POST `/compras`
```typescript
Body: {
  userId: string;
  productoId: string;
  cantidad: number;
  precioTotal: number;
}

// Los puntos se descuentan automáticamente
```

#### GET `/users/:userId/compras`
Obtiene todas las compras de un usuario.

---

### **Puntos**

#### GET `/users/:userId/puntos`
Obtiene los puntos de un usuario.

#### POST `/users/:userId/puntos/add`
```typescript
Body: {
  puntos: number;
}
```

---

### **Ruleta**

#### POST `/ruleta/spin`
```typescript
Body: {
  userId: string;
  premio: string;
  puntos?: number;
}

// Si el premio incluye puntos, se agregan automáticamente
```

#### GET `/users/:userId/ruleta`
Obtiene el historial de ruleta de un usuario.

---

### **Red Multinivel**

#### GET `/users/:userId/referidos`
Obtiene los referidos directos (nivel 1).

#### GET `/users/:userId/red/:nivel`
Obtiene los referidos de un nivel específico (1-10).

---

### **Admin - Estadísticas**

#### GET `/admin/estadisticas`
```typescript
Response: {
  totalUsuarios: number;
  usuariosActivos: number;
  totalInversiones: number;
  totalCobros: number;
  cobrosPendientes: number;
  packsPorTipo: {
    'Pack 50': number;
    'Pack 100': number;
    // ...
  }
}
```

---

## 💻 Uso en el Frontend

### **1. Importar las utilidades**
```typescript
import { authAPI, packsAPI, comisionesAPI, /* ... */ } from './utils/api';
import { useAuth } from './hooks/useAuth';
```

### **2. Usar el hook de autenticación**
```typescript
function MiComponente() {
  const { user, login, logout, isAuthenticated } = useAuth();

  const handleLogin = async () => {
    try {
      const resultado = await authAPI.login(email, password);
      if (resultado.success) {
        login(resultado.user);
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  return (
    <div>
      {isAuthenticated ? (
        <p>Bienvenido {user.nombre}!</p>
      ) : (
        <button onClick={handleLogin}>Iniciar Sesión</button>
      )}
    </div>
  );
}
```

### **3. Comprar un pack**
```typescript
const handleCompraPack = async () => {
  try {
    const pack = await packsAPI.create({
      userId: user.id,
      nombre: 'Pack 100',
      monto: 100,
      rendimientoDiario: 2
    });
    
    console.log('Pack comprado:', pack);
    toast.success('¡Pack comprado exitosamente!');
    
    // Las comisiones de red se calcularon automáticamente
  } catch (error) {
    console.error('Error:', error);
    toast.error('Error al comprar pack');
  }
};
```

### **4. Ver comisiones**
```typescript
const [comisiones, setComisiones] = useState([]);
const [total, setTotal] = useState(0);

useEffect(() => {
  const cargarComisiones = async () => {
    const data = await comisionesAPI.getByUserId(user.id);
    setComisiones(data);
    
    const { total } = await comisionesAPI.getTotalByUserId(user.id);
    setTotal(total);
  };
  
  cargarComisiones();
}, [user.id]);
```

---

## 🔐 Sistema Multinivel

### **Niveles de Comisión**
```
Nivel 1:  8% 
Nivel 2:  6%
Nivel 3:  4%
Nivel 4:  2%
Nivel 5:  1%
Nivel 6:  1%
Nivel 7:  1%
Nivel 8:  1%
Nivel 9:  0.5%
Nivel 10: 0.5%

+ Bono de Patrocinio: 10% (adicional al patrocinador directo)
```

### **Ejemplo de Cálculo**

Si Juan refiere a María y María compra un Pack 100 ($100):

1. **Juan recibe:**
   - Comisión Nivel 1: $8 (8%)
   - Bono de Patrocinio: $10 (10%)
   - **Total: $18**

2. **Si Juan fue referido por Pedro:**
   - Pedro recibe Comisión Nivel 2: $6 (6%)

3. **Y así sucesivamente hasta 10 niveles**

---

## 📦 Paquetes de Inversión

```typescript
const PACKS = [
  { nombre: 'Pack 50', monto: 50 },
  { nombre: 'Pack 100', monto: 100 },
  { nombre: 'Pack 200', monto: 200 },
  { nombre: 'Pack 300', monto: 300 },
  { nombre: 'Pack 500', monto: 500 },
  { nombre: 'Pack 1k', monto: 1000 },
  { nombre: 'Pack 5k', monto: 5000 },
  { nombre: 'Pack 10k', monto: 10000 }
];
```

---

## ✅ Ventajas de Usar la Tabla KV

1. **✨ Sin configuración adicional** - Ya está lista para usar
2. **🚀 Flexible** - Almacena cualquier estructura de datos
3. **⚡ Rápida** - Búsquedas por clave muy eficientes
4. **📈 Escalable** - Soporta millones de registros
5. **🔍 Búsqueda por prefijo** - Fácil obtener datos relacionados

---

## 🎨 Ejemplos de Uso

Ver archivo `/utils/ejemplos-uso-crm.ts` para ejemplos completos de:
- Registro y login
- Compra de packs
- Consulta de comisiones
- Solicitud de cobros
- Compra de productos
- Sistema de puntos
- Ruleta de premios
- Red multinivel
- Panel de administrador

---

## 📝 Notas Importantes

1. **Seguridad**: En producción, hashear las contraseñas con bcrypt
2. **Validaciones**: Agregar validaciones de datos en el frontend y backend
3. **Paginación**: Para listas grandes, implementar paginación
4. **Cache**: Considerar cachear datos frecuentes en el frontend
5. **Logs**: Todos los errores se registran en la consola del servidor

---

## 🚀 ¡Todo Listo para Usar!

El sistema CRM está completamente funcional y listo para integrar en tus componentes. No necesitas crear tablas adicionales ni configurar nada más.

**Archivos principales:**
- `/supabase/functions/server/crm.tsx` - Lógica del CRM
- `/supabase/functions/server/index.tsx` - API REST
- `/utils/api.ts` - Cliente API para el frontend
- `/hooks/useAuth.ts` - Hook de autenticación
- `/utils/ejemplos-uso-crm.ts` - Ejemplos de uso

---

## 🆘 Soporte

Si tienes dudas sobre cómo implementar alguna funcionalidad, revisa los ejemplos en `/utils/ejemplos-uso-crm.ts` o consulta esta documentación.
