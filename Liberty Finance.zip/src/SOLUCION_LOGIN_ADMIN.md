# 🔐 Solución de Problemas de Login - Liberty Finance

## ✅ Problema Resuelto

Se corrigió el error **"Contraseña incorrecta"** al intentar iniciar sesión con el usuario administrador.

## 🔍 Causa del Problema

Había una **inconsistencia** en las contraseñas del administrador:

1. El endpoint `/debug/create-admin` creaba el admin con contraseña `admin123`
2. Pero el endpoint `/auth/login` **actualizaba automáticamente** la contraseña a `Tux-tai#1090..` en cada intento de login
3. Esto causaba que la contraseña correcta fuera diferente de la que esperaba el usuario

## ✨ Solución Implementada

### 1. **Contraseña Estandarizada**
Se actualizó el código del servidor para usar una contraseña **consistente y simple**:

```typescript
const ADMIN_PASS = 'admin123'; // ✅ CONTRASEÑA SIMPLE Y CONSISTENTE
```

### 2. **Endpoints de Debug Creados**

#### **a) Crear/Verificar Admin**
- **Ruta:** `/debug/create-admin`
- **Método:** POST
- **Función:** Crea el usuario admin si no existe, o lo verifica si ya existe

#### **b) Resetear Contraseña Admin**
- **Ruta:** `/debug/reset-admin-password`
- **Método:** POST
- **Función:** Resetea la contraseña del admin a `admin123`

### 3. **Componentes de UI Creados**

Se crearon tres componentes de debug en `/components/debug/`:

1. **CrearAdmin.tsx** - Botón para crear/verificar el usuario admin
2. **ResetAdminPassword.tsx** - Botón para resetear la contraseña
3. **TestLogin.tsx** - Formulario para probar el login

Todos están disponibles en la página `/Setup.tsx`

## 🔐 Credenciales Actuales

```
Email: admin@libertyfinance.com
Contraseña: admin123
```

## 📋 Cómo Usar las Herramientas de Debug

### Opción 1: Página de Setup (Recomendado)

1. Ve a la página `/Setup` en tu aplicación
2. Verás las siguientes secciones:
   - **Inicializar Sistema** - Carga datos por defecto
   - **Crear/Verificar Admin** - Verifica que el admin exista
   - **Resetear Contraseña Admin** - Resetea la contraseña a `admin123`
   - **Probar Login** - Prueba las credenciales directamente

### Opción 2: Desde la Consola del Navegador

```javascript
// Resetear contraseña
fetch('https://YOUR_PROJECT_ID.supabase.co/functions/v1/make-server-9f68532a/debug/reset-admin-password', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer YOUR_ANON_KEY'
  }
})
.then(r => r.json())
.then(console.log);
```

## 🚨 Troubleshooting

### Error: "Contraseña incorrecta"

**Solución:**
1. Ve a la página de Setup
2. Haz clic en "Resetear Contraseña del Admin"
3. Espera la confirmación
4. Intenta iniciar sesión con: `admin@libertyfinance.com` / `admin123`

### Error: "Usuario no encontrado"

**Solución:**
1. Ve a la página de Setup
2. Haz clic en "Crear Usuario Admin"
3. Espera la confirmación
4. Intenta iniciar sesión con: `admin@libertyfinance.com` / `admin123`

### Warnings de Timeout en la Consola

Estos mensajes son **normales** y forman parte del sistema de reintentos:
```
⚠️ Timeout (30000ms) en intento 1/4
⚠️ Error de red en intento 1/4, reintentando en 2000ms...
```

El sistema reintenta automáticamente si hay problemas de red. Solo debes preocuparte si el login **finalmente falla**.

## 🔧 Cambios en el Código

### Archivo: `/supabase/functions/server/index.tsx`

**Antes:**
```typescript
const NEW_ADMIN_PASS = 'Tux-tai#1090..';
```

**Después:**
```typescript
const ADMIN_PASS = 'admin123'; // ✅ CONTRASEÑA SIMPLE Y CONSISTENTE
```

### Nuevo Endpoint: `/debug/reset-admin-password`

Permite resetear la contraseña del administrador en cualquier momento sin necesidad de acceder a la base de datos.

## 📝 Notas de Seguridad

### En Producción

⚠️ **IMPORTANTE:** Después de deployar a producción:

1. **Cambia la contraseña del admin inmediatamente** desde el panel de configuración
2. **Desactiva o protege** los endpoints de debug:
   - `/debug/create-admin`
   - `/debug/reset-admin-password`
3. Considera implementar un sistema de autenticación más robusto con:
   - Hashing de contraseñas (bcrypt)
   - Tokens JWT
   - Autenticación de dos factores (2FA)

### Contraseñas Seguras

Para producción, usa contraseñas que cumplan:
- Mínimo 12 caracteres
- Mayúsculas y minúsculas
- Números y símbolos especiales
- No usar palabras comunes del diccionario

## ✅ Verificación Final

Para confirmar que todo funciona:

1. ✅ Resetea la contraseña del admin
2. ✅ Usa "Probar Login" en la página de Setup
3. ✅ Verifica que aparezca: `{"success": true, "user": {...}}`
4. ✅ Intenta el login real desde la página de Login
5. ✅ Confirma que accedes al Dashboard de Admin

## 🎯 Próximos Pasos

Después de resolver el login:

1. Configura tu wallet principal en **Configuración → Wallet**
2. Revisa que los **productos** estén visibles
3. Revisa que los **rangos** estén configurados
4. Configura el **sistema de emails** con Resend
5. Registra un **usuario de prueba**
6. Realiza un **depósito de prueba**

## 📞 Soporte

Si sigues teniendo problemas después de seguir esta guía:

1. Revisa la consola del navegador (F12) para errores específicos
2. Verifica que las credenciales de Supabase estén correctas en `/utils/supabase/info.tsx`
3. Confirma que el servidor de Supabase Edge Functions esté funcionando
4. Usa la herramienta "Probar Login" para debugging

---

**Última actualización:** 31 de diciembre de 2025  
**Versión:** 1.0.0
