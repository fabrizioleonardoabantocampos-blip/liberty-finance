
  # Liberty Finance

  This is a code bundle for Liberty Finance. The original project is available at https://www.figma.com/design/O966nPsHt2Bbhf4y5rzm0W/Liberty-Finance.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  